import os
import pandas as pd
import pymysql
import logging
import shutil
import traceback
import time
from flask import Flask, request, jsonify, session

app = Flask(__name__)

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Define the project directory and folders
project_dir = os.getcwd()
input_folder = os.path.join(project_dir, 'input')
pending_folder = os.path.join(project_dir, 'pending')
done_folder = os.path.join(project_dir, 'done')
exception_folder = os.path.join(project_dir, 'exception')

# Ensure the pending, done, and exception folders exist
try:
    os.makedirs(pending_folder, exist_ok=True)
    os.makedirs(done_folder, exist_ok=True)
    os.makedirs(exception_folder, exist_ok=True)
    logger.info("Folders created or already exist.")
except Exception as e:
    logger.error(f"Failed to create folders: {str(e)}")
    raise

# Database configuration
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': '',
    'db': 'db_steptool',
    'charset': 'utf8mb4',
    'cursorclass': pymysql.cursors.DictCursor
}

def get_db_connection():
    try:
        conn = pymysql.connect(**DB_CONFIG)
        logger.info("Database connection established successfully.")
        return conn
    except Exception as e:
        logger.error(f"Failed to establish a database connection: {str(e)}")
        raise

@app.route('/upload', methods=['POST'])
def upload_file():
    enteredby = session.get('id', 0)
    accountId = session.get('accountId', 0)

    msgarr = {"status": "Error", "message": "Something went wrong. Please try again."}
    flag = 0
    errormsg = ""
    errormsgarr = {"Activity not found": []}

    if 'file' not in request.files:
        return jsonify(msgarr), 400

    file = request.files['file']
    if file.filename == '':
        return jsonify(msgarr), 400

    projectId = request.form.get('projectId', '0')
    releaseId = request.form.get('releaseId', '0')

    if file:
        filename = file.filename
        targetPath = os.path.join(input_folder, filename)
        file.save(targetPath)
        os.chmod(targetPath, 0o777)

        try:
            df = pd.read_excel(targetPath)
            conn = get_db_connection()
            cursor = conn.cursor()

            testcaseId = None  # Initialize testcaseId

            for index, row in df.iterrows():
                if index > 0:  # Skip header row
                    scenarioId = str(row[0]) if pd.notna(row[0]) else "0"
                    newFlag = str(row[1]) if pd.notna(row[1]) else "0"
                    activity = str(row[2]) if pd.notna(row[2]) else ""
                    module = str(row[3]) if pd.notna(row[3]) else ""
                    submodule = str(row[4]) if pd.notna(row[4]) else ""
                    testscenariodesc = str(row[5]) if pd.notna(row[5]) else ""
                    testcasedesc = str(row[6]) if pd.notna(row[6]) else ""
                    steps = str(row[7]) if pd.notna(row[7]) else ""
                    expectedresult = str(row[8]) if pd.notna(row[8]) else ""
                    precondition = str(row[9]) if pd.notna(row[9]) else ""
                    testdata = str(row[10]) if pd.notna(row[10]) else ""
                    testmode = str(row[11]) if pd.notna(row[11]) else ""

                    if newFlag == "1":
                        proj_data = pd.read_sql("SELECT s_p_code FROM s_project WHERE s_p_id = %s AND accountId = %s ORDER BY s_p_id DESC LIMIT 1", conn, params=(projectId, accountId))
                        if not proj_data.empty:
                            projcode = proj_data.iloc[0]['s_p_code']
                            scenario_data = pd.read_sql("SELECT s_d_tempscenarioId FROM s_testcase WHERE projectId = %s AND accountId = %s ORDER BY s_d_tempscenarioId DESC LIMIT 1", conn, params=(projectId, accountId))
                            if not scenario_data.empty:
                                scenarioId = int(scenario_data.iloc[0]['s_d_tempscenarioId']) + 1
                            else:
                                scenarioId = 1
                            scenarioIdstr = f"TS-{scenarioId}"

                            activity_data = pd.read_sql("SELECT s_a_id FROM s_activitymaster WHERE s_a_code = %s AND accountId = %s", conn, params=(activity, accountId))
                            if not activity_data.empty:
                                activityId = activity_data.iloc[0]['s_a_id']
                            else:
                                logger.error(f"Activity data not found for activity code: {activity}")
                                errormsgarr["Activity not found"].append(index + 1)
                                continue

                            testcase_data = pd.read_sql("SELECT s_t_tempid FROM s_testcase WHERE projectId = %s AND accountId = %s ORDER BY s_t_tempid DESC LIMIT 1", conn, params=(projectId, accountId))
                            if not testcase_data.empty:
                                testcaseNum = int(testcase_data.iloc[0]['s_t_tempid']) + 1
                            else:
                                testcaseNum = 1
                            testcaseIdstr = f"{projcode}-TC-{testcaseNum}"

                            if activityId != 0:
                                testcase_sql = """
                                INSERT INTO s_testcase (
                                    projectId, releaseId, s_t_activityIds, s_d_tempscenarioId, s_t_testscenarionum,
                                    s_t_tempid, s_t_testcasenum, s_t_module, s_t_submodule, s_t_testscenariodesc,
                                    s_t_testcasedesc, s_t_steps, s_t_expectedresult, s_t_precondition, s_t_testdata,
                                    s_t_enteredby, accountId, s_t_testmode, s_t_author
                                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                                """
                                cursor.execute(testcase_sql, (
                                    projectId, releaseId, activityId, scenarioId, scenarioIdstr,
                                    testcaseNum, testcaseIdstr, module, submodule, testscenariodesc,
                                    testcasedesc, steps, expectedresult, precondition, testdata,
                                    enteredby, accountId, testmode, enteredby
                                ))
                                testcaseId = cursor.lastrowid
                                conn.commit()

                                stepsql = """
                                INSERT INTO s_testcase_steps (
                                    s_tss_num, testcaseId, s_tss_steps, s_tss_expectedresult, accountId, s_tss_enteredby
                                ) VALUES (%s, %s, %s, %s, %s, %s)
                                """
                                cursor.execute(stepsql, (1, testcaseId, steps, expectedresult, accountId, enteredby))
                                conn.commit()

                                if activityId and activityId != 0:
                                    chkstmt = pd.read_sql(f"SELECT * FROM s_testcasefinal WHERE testcaseId = {testcaseId} AND activityId = {activityId} AND accountId = {accountId}", conn)
                                    if chkstmt.empty:
                                        msql = f"INSERT INTO s_testcasefinal(testcaseId, projectId, releaseId, activityId, s_f_testresult, s_f_actualresult, s_f_executiontime, defectId, s_f_enteredby, accountId, s_f_activestatus) VALUES({testcaseId}, {projectId}, {releaseId}, {activityId}, 'Not Executed', '', NULL, 0, {enteredby}, {accountId}, 'Active')"
                                        cursor.execute(msql)
                                    else:
                                        finalsql = f"UPDATE s_testcasefinal SET s_f_activestatus = 'Active' WHERE testcaseId = {testcaseId} AND activityId = {activityId} AND accountId = {accountId}"
                                        cursor.execute(finalsql)
                                    conn.commit()
                                flag = 1
                            else:
                                errormsg = f"Error at line no {index + 1}: Activity not found.<br/>"
                    else:
                        if testcaseId is not None and testcaseId > 0:
                            stepsql = """
                            INSERT INTO s_testcase_steps (
                                s_tss_num, testcaseId, s_tss_steps, s_tss_expectedresult, accountId, s_tss_enteredby
                            ) VALUES (%s, %s, %s, %s, %s, %s)
                            """
                            cursor.execute(stepsql, (1, testcaseId, steps, expectedresult, accountId, enteredby))
                            conn.commit()

            if flag > 0:
                msgarr["status"] = "Success"
                msgarr["message"] = "Testcase uploaded successfully."
                if errormsg:
                    msgarr["message"] = "Some testcase uploaded successfully."
                    msgarr["errmsg"] = errormsgarr
            else:
                msgarr["status"] = "Error"
                msgarr["message"] = "Testcase upload failed."
                if errormsg:
                    msgarr["errmsg"] = errormsgarr

        except Exception as e:
            logger.error(f"An error occurred: {str(e)}")
            logger.error(traceback.format_exc())
            conn.rollback()
        finally:
            cursor.close()
            conn.close()

    return jsonify(msgarr)

if __name__ == '__main__':
    app.run(debug=True)
