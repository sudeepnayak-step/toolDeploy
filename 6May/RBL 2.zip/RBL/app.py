
import os
import pandas as pd
import pymysql
import logging
import shutil
import traceback
import time

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Define the project directory and folders
project_dir = os.getcwd()
input_folder = os.path.join(project_dir, 'input')
pending_folder = os.path.join(project_dir, 'pending')
done_folder = os.path.join(project_dir, 'done')
exception_folder = os.path.join(project_dir, 'exception')

# Ensure the pending, done, and exception folders exist
try:
    os.makedirs(pending_folder, exist_ok=True)
    os.makedirs(done_folder, exist_ok=True)
    os.makedirs(exception_folder, exist_ok=True)
    logger.info("Folders created or already exist.")
except Exception as e:
    logger.error(f"Failed to create folders: {str(e)}")
    raise

# Database configuration
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': '',
    'db': 'db_steptool',
    'charset': 'utf8mb4',
    'cursorclass': pymysql.cursors.DictCursor
}

def get_db_connection():
    try:
        conn = pymysql.connect(**DB_CONFIG)
        logger.info("Database connection established successfully.")
        return conn
    except Exception as e:
        logger.error(f"Failed to establish a database connection: {str(e)}")
        raise

def verify_row(row):
    exceptions = []
    try:
        if str(row.iloc[1]) != "1":
            exceptions.append("newFlag is not set to '1'.")
    except Exception as e:
        exceptions.append(f"Column 'newFlag': {str(e)}")

    return exceptions

def process_file(file_path, projectId, releaseId, enteredby, accountId):
    logger.info(f"Starting to process file: {file_path}")
    conn = None
    row_exceptions = []
    data_to_insert = []

    try:
        logger.info("Reading Excel file.")
        df = pd.read_excel(file_path)
        logger.info(f"Excel file {file_path} read successfully.")

        # Verify each row and collect data
        for index, row in df.iterrows():
            exceptions = verify_row(row)
            if exceptions:
                row_exceptions.append((index, exceptions))
                logger.error(f"Exceptions in row {index + 1}: {', '.join(exceptions)}")

        # If there are any exceptions in rows, skip processing
        if row_exceptions:
            logger.error(f"Exceptions found in rows. Skipping file processing for {file_path}.")
            return False, row_exceptions

        conn = get_db_connection()
        with conn.cursor() as cursor:
            for index, row in df.iterrows():
                try:
                    scenarioId = str(row.iloc[0]) if pd.notna(row.iloc[0]) else ""
                    newFlag = str(row.iloc[1]) if pd.notna(row.iloc[1]) else "0"
                    activity = str(row.iloc[2]) if pd.notna(row.iloc[2]) else ""
                    module = str(row.iloc[3]) if pd.notna(row.iloc[3]) else ""
                    submodule = str(row.iloc[4]) if pd.notna(row.iloc[4]) else ""
                    testscenariodesc = str(row.iloc[5]) if pd.notna(row.iloc[5]) else ""
                    testcasedesc = str(row.iloc[6]) if pd.notna(row.iloc[6]) else ""
                    steps = str(row.iloc[7]) if pd.notna(row.iloc[7]) else ""
                    expectedresult = str(row.iloc[8]) if pd.notna(row.iloc[8]) else ""
                    precondition = str(row.iloc[9]) if pd.notna(row.iloc[9]) else ""
                    testdata = str(row.iloc[10]) if pd.notna(row.iloc[10]) else ""
                    testmode = str(row.iloc[11]) if pd.notna(row.iloc[11]) else ""

                    cursor.execute("SELECT s_p_code FROM s_project WHERE s_p_id = %s AND accountId = %s ORDER BY s_p_id DESC LIMIT 1", (projectId, accountId))
                    proj_data = cursor.fetchone()
                    if proj_data is None:
                        raise ValueError("Project data not found.")
                    projcode = proj_data['s_p_code']

                    cursor.execute("SELECT s_d_tempscenarioId FROM s_testcase WHERE projectId = %s AND accountId = %s ORDER BY s_d_tempscenarioId DESC LIMIT 1", (projectId, accountId))
                    scenario_data = cursor.fetchone()
                    scenarioId = int(scenario_data['s_d_tempscenarioId']) + 1 if scenario_data else 1
                    scenarioIdstr = f"TS-{scenarioId}"

                    cursor.execute("SELECT s_a_id FROM s_activitymaster WHERE s_a_code = %s AND accountId = %s", (activity, accountId))
                    activity_data = cursor.fetchone()
                    if activity_data is None:
                        raise ValueError("Activity data not found.")
                    activityId = activity_data['s_a_id']

                    cursor.execute("SELECT s_t_tempid FROM s_testcase WHERE projectId = %s AND accountId = %s ORDER BY s_t_tempid DESC LIMIT 1", (projectId, accountId))
                    testcase_data = cursor.fetchone()
                    testcaseNum = int(testcase_data['s_t_tempid']) + 1 if testcase_data else 1
                    testcaseIdstr = f"{projcode}-TC-{testcaseNum}"

                    if activityId != 0:
                        data_to_insert.append((
                            str(projectId), str(releaseId), str(activityId), str(scenarioId), scenarioIdstr,
                            str(testcaseNum), testcaseIdstr, str(module), str(submodule), str(testscenariodesc),
                            str(testcasedesc), str(steps), str(expectedresult), str(precondition), str(testdata),
                            str(enteredby), str(accountId), str(testmode), str(enteredby)
                        ))
                    else:
                        raise ValueError("activityId is 0, which is not allowed.")

                except Exception as e:
                    logger.error(f"Error processing row {index + 1}: {str(e)}")
                    logger.error(traceback.format_exc())
                    row_exceptions.append((index, [str(e)]))

        if row_exceptions:
            logger.error(f"Exceptions found in rows. Skipping file processing for {file_path}.")
            return False, row_exceptions

        # Insert all data at once if no exceptions
        try:
            with conn.cursor() as cursor:
                sql = """
                INSERT INTO s_testcase (
                    projectId, releaseId, s_t_activityIds, s_d_tempscenarioId, s_t_testscenarionum,
                    s_t_tempid, s_t_testcasenum, s_t_module, s_t_submodule, s_t_testscenariodesc,
                    s_t_testcasedesc, s_t_steps, s_t_expectedresult, s_t_precondition, s_t_testdata,
                    s_t_enteredby, accountId, s_t_testmode, s_t_author
                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                """
                cursor.executemany(sql, data_to_insert)
                conn.commit()
                logger.info("Data inserted successfully.")
        except Exception as e:
            logger.error(f"Error inserting data into database: {str(e)}")
            logger.error(traceback.format_exc())
            if conn:
                conn.rollback()
            return False, [(0, [str(e)])]
        

    except Exception as e:
        logger.error(f"An error occurred during database operations: {str(e)}")
        logger.error(traceback.format_exc())
        if conn:
            conn.rollback()
        return False, [(0, [str(e)])]

    finally:
        if conn:
            conn.close()

    return True, []

def update_scriptaction_status(account_id, project_id, release_id, file_path, status):
    db = None
    try:
        db = get_db_connection()
        cursor = db.cursor()
        sql = """
        UPDATE scriptaction
        SET status = %s
        WHERE account_id = %s AND project_id = %s AND released_id = %s AND file_path = %s
        """
        values = (status, account_id, project_id, release_id, file_path)
        cursor.execute(sql, values)
        db.commit()
        logger.info(f"Status updated to '{status}' for account_id: {account_id}, project_id: {project_id}, release_id: {release_id}, file_path: {file_path}")
    except Exception as err:
        logger.error(f"Error updating status in scriptaction table: {str(err)}")
        if db:
            db.rollback()
        raise
    finally:
        if cursor:
            cursor.close()
        if db:
            db.close()

def process_pending_files():
    try:
        db = get_db_connection()
        cursor = db.cursor(pymysql.cursors.DictCursor)
        cursor.execute("SELECT account_id, enteredby_id, project_id, released_id, status, file_path FROM scriptaction")
        rows = cursor.fetchall()
        logger.info(f"Fetched {len(rows)} rows from the database.")
    except Exception as err:
        logger.error(f"Error executing SQL query: {str(err)}")
        cursor.close()
        db.close()
        return

    for row in rows:
        account_id = row['account_id']
        enteredby_id = row['enteredby_id']
        project_id = row['project_id']
        released_id = row['released_id']
        status = row['status']
        filepath = row['file_path']

        logger.info(f"Processing row - account_id: {account_id}, status: {status}, filepath: {filepath}")

        if status == 'pending':
            excel_file_path = os.path.join(input_folder, os.path.basename(filepath))
            logger.info(f"Constructed Excel file path: {excel_file_path}")

            if os.path.exists(excel_file_path):
                try:
                    success, row_exceptions = process_file(excel_file_path, project_id, released_id, enteredby_id, account_id)
                    if success:
                        update_scriptaction_status(account_id, project_id, released_id, filepath, "done")
                        done_file_path = os.path.join(done_folder, os.path.basename(filepath))
                        shutil.move(excel_file_path, done_file_path)
                        logger.info(f"File {filepath} moved to done folder.")
                    else:
                        update_scriptaction_status(account_id, project_id, released_id, filepath, "Exception")
                        exception_file_path = os.path.join(exception_folder, os.path.basename(filepath))
                        shutil.move(excel_file_path, exception_file_path)
                        logger.info(f"File {filepath} moved to exception folder due to processing error.")
                        for index, exceptions in row_exceptions:
                            logger.error(f"Row {index + 1} had exceptions: {', '.join(exceptions)}")
                except Exception as e:
                    logger.error(f"Error processing Excel file {filepath}: {str(e)}")
                    logger.error(traceback.format_exc())
            else:
                logger.error(f"File {filepath} not found in the input folder. Skipping processing for this file.")
        else:
            logger.info(f"Skipping row with account_id: {account_id} as status is not 'pending'")

    cursor.close()
    db.close()

# Main loop to run the script every 5 minutes
while True:
    logger.info("Starting the script execution...")
    process_pending_files()
    logger.info("Script execution completed. Waiting for 5 minutes before the next run...")
    time.sleep(30)  # Wait for 300 seconds (5 minutes)
