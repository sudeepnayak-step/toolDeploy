<?php
include('../config.php');
include('../chkloginsession.php');
?>
<!doctype html>
<html class="no-js" lang="en">
<head>
   
    <?php include(STEP_dir.'headmetatag.php'); ?>
	<link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">

    <link rel="stylesheet" href="<?php echo $STEP->wwwroot; ?>vendors/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo $STEP->wwwroot; ?>vendors/fontawesome5/css/all.min.css">
    <link rel="stylesheet" href="<?php echo $STEP->wwwroot; ?>vendors/themify-icons/css/themify-icons.css">
	<link rel="stylesheet" href="<?php echo $STEP->wwwroot; ?>assets/css/style.css">
    <link rel="stylesheet" href="<?php echo $STEP->wwwroot; ?>assets/css/mystyle.css">
</head>
<body style="background: url('../images/loginbg.jpg') no-repeat center center fixed; 
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;">
    

      <div class="sufee-login d-flex align-content-center flex-wrap" >
        <div class="container111" style="margin: 5%;">
            <div class="login-content" >
                <div class="login-form" style="width:400px;">

                  <div class="container" style="display: flex; align-items: center; justify-content: center; margin-bottom:50px; margin-top:-20px">
                    <img src="<?php echo STEP_root; ?>images/tc-logo.png" alt="Logo 1" class="logo" style="height:40px"/>
                    <div class="vertical-line" style=" width: 2px; height: 65px; border: solid #d2d2d2 0.5px;display:none;"></div>
                    <img src="<?php echo STEP_root; ?>images/logo.jpg" alt="Logo 2" class="logo" style="height:60px"/>
                  </div>

                  
                  <div id="informationalert"></div>

                </div>
            </div>
        </div>
    </div>
    
    <script src="<?php echo $STEP->wwwroot; ?>vendors/jquery/dist/jquery.min.js"></script>
    <script src="<?php echo $STEP->wwwroot; ?>assets/js/jsconfig.js"></script>	
    <script src="<?php echo STEP_root; ?>assets/js/init-scripts/callback-init.js"></script>
  </body>

  </html>
