<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


header('Access-Control-Allow-Origin: *');
include('../api/config.php');

$response = array();
$profilePath = "admin.jpg";
$msg = "Oops! Something went wrong. Please try again later.";
// session_start();
// echo "<pre/>"; print_r($_GET);
$clientId = "b5eea9e7-ca02-49a6-92d6-8840b8f28ac9";
$clientSecret = "nlt8Q~0agxny.b5h5MRSOmWcTArJfDQST_l0kaaw"; // "a7e19e17-5510-4884-a538-90e8dc259fc4";
$tenantId ="common"; // "bcdf4a66-70c4-4aec-b926-fbdced7b7884"; // or your directory tenant ID
$redirectUri = "https://www.vapt.testcalibre.com/api/callback.php";
//echo $_GET['code'];
if (!isset($_POST['code'])) {
    // die("Authorization code not received");
    $msg = "Authorization code not received";
    $response['status'] = "Error";
    $response['msg'] = $msg;
	echo json_encode($response);
	die();
}

// Exchange code for token
$tokenUrl = "https://login.microsoftonline.com/$tenantId/oauth2/v2.0/token";
$data = [
    'client_id' => $clientId,
    'scope' => 'openid profile email',
    'code' => $_POST['code'],
    'redirect_uri' => $redirectUri,
    'grant_type' => 'authorization_code',
    'client_secret' => $clientSecret
];

$ch = curl_init($tokenUrl);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

$ssoresponse = curl_exec($ch);

if (!$ssoresponse){
// die("Token request failed: " . curl_error($ch));
    $msg = "Token request failed: " . curl_error($ch);
    $response['status'] = "Error";
    $response['msg'] = $msg;
    echo json_encode($response);
    die();
} 
curl_close($ch);

$tokenData = json_decode($ssoresponse, true);

//echo "<pre/>"; print_r($tokenData);
$accessToken = $tokenData['access_token'] ?? null;

if (!$accessToken) {
    // die("Access token not received");
    $msg = "Access token not received";
    $response['status'] = "Error";
    $response['msg'] = $msg;
	echo json_encode($response);
	die();
}

// Get user info
$userInfoUrl = "https://graph.microsoft.com/v1.0/me";
$headers = [
    "Authorization: Bearer $accessToken",
    "Accept: application/json"
];

$ch = curl_init($userInfoUrl);
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$userResponse = curl_exec($ch);
curl_close($ch);

$user = json_decode($userResponse, true);

// Save to session or login logic
// $_SESSION['user'] = $user;

// echo "<h3>Welcome, " . htmlspecialchars($user['displayName']) . " (" . htmlspecialchars($user['mail']) . ")</h3>";
// echo "<pre>"; print_r($user); echo "</pre>";
$username = htmlspecialchars($user['mail']);

// Validate credentials
if(!empty($username)){
	
    $sql = "SELECT s_u_id, s_u_username, s_u_password,s_u_type,s_u_employeeId,s_users.accountId,s_u_licno,s_u_expirytime,IFNULL(s_role_management.ruleIds,'') as ruleIds, s_employees.profile_path,s_users.roleId as roleId FROM s_users 
    left join s_role_management on s_role_management.roleId = s_users.roleId and s_role_management.accountId = s_users.accountId 
	LEFT JOIN s_employees ON s_employees.s_e_id = s_users.s_u_employeeId
    WHERE BINARY `s_u_username` LIKE  ? ";
	//echo $sql;
    if($stmt = mysqli_prepare($conn, $sql)){
        // Bind variables to the prepared statement as parameters
        mysqli_stmt_bind_param($stmt, "s", $param_username);
        
        // Set parameters
        $param_username = strtolower($username);
        
        // Attempt to execute the prepared statement
        if(mysqli_stmt_execute($stmt)){
            // Store result		
            mysqli_stmt_store_result($stmt);
            // Check if username exists, if yes then verify password
            if(mysqli_stmt_num_rows($stmt) == 1){                    
                // Bind result variables
                mysqli_stmt_bind_result($stmt, $id, $username, $hashed_password,$type,$empid,$accountId,$liccount,$expiry,$ruleIds, $profilePath, $roleId);
                if(mysqli_stmt_fetch($stmt)){
                    // if(password_verify($password, $hashed_password)){
                        if(date("Y-m-d 23:59:59") <= $expiry){

                            // Password is correct, so start a new session
                             session_start();
                            $userarr = array();
                            // Store data in session variables
                            $userarr["loggedin"] = true;
                            $userarr["id"] = $id;
                            $userarr["username"] = $username;
                            $userarr["usertype"] = $type;
                            $userarr["userempid"] = $empid;
                            $userarr["liccount"] = $liccount;
                            $userarr["ruleIds"] = $ruleIds;
                            $userarr["accountId"] = $id;
                            if($type == "Admin"){
                                $userarr["accountId"] = $id;
                            }else if($type == "Employee"){
                                $userarr["accountId"] = $accountId;
                            }
							$userarr["profile_path"] = $profilePath;
                            $userarr["roleId"] = $roleId;
                            
                            $msg = "1";

                            $response['status'] = "Success";
                            $response['msg'] = $userarr;

                        } else{
                            // Display an error message if password is not valid
                            $msg = "Oops... Your account got expired.";
                            $response['status'] = "Error";
                            $response['msg'] = $msg;
                        }
                    // } else{
                    //     // Display an error message if password is not valid
                    //     $msg = "The password you entered was not valid.";
                    //     $response['status'] = "Error";
                    //     $response['msg'] = $msg;
                    // }
                }
            } else{
                // Display an error message if username doesn't exist
                $msg = "No account found with that username.";
                $response['status'] = "Error";
                $response['msg'] = $msg;
            }
        } else{
            $msg =  "Oops! Something went wrong. Please try again later.";
            $response['status'] = "Error";
            $response['msg'] = $msg;
        }
    // Close statement
    mysqli_stmt_close($stmt);
    }
    
}

// $_SESSION['profile_path'] = $profilePath;
echo json_encode($response);
