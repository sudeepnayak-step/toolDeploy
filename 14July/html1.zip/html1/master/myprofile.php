<?php
include('../config.php');
include('../chksession.php');
?>
<!doctype html>
<html class="no-js" lang="en">
<head>
    <?php include(STEP_dir.'headmetatag.php'); ?>
    <?php include(STEP_dir.'css.php'); ?>
    <style>
        .alert-container {
            position: fixed;
            top: 80px;
            right: 20px;
            z-index: 9999;
            width: 300px;
        }
    </style>
</head>
<body>
    <?php include(STEP_dir.'leftpanel.php'); ?>
    <div id="right-panel" class="right-panel" style="background-color: #f8f9fa;">
        <?php include(STEP_dir.'header.php'); ?>
        <div class="row breadcrumbs">
            <div class="col-10">
                <div class="page-header float-left">
                    <div class="page-title">
                        <ol class="breadcrumb text-left">
                            <li><a href="<?php echo STEP_root; ?>index.php">Dashboard</a></li>
                            <li class="active">My Profile</li>
                        </ol>
                    </div>
                </div>
            </div>
            <div class="profile-right col-2 mt-2">
                <button type="button" id="editProfileBtn" class="btn btn-secondary" data-toggle="modal" data-target="#editProfileModal">
                    <i class="fa fa-edit"></i> Edit Profile
                </button>
            </div>
        </div>

        <!-- Alert Container -->
        <div class="alert-container"></div>

        <div class="content mt-3">
            <div class="animated fadeIn">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="profile-container">
                            <div class="profile-left">
                                <img class="profile-picture" src="<?php echo STEP_root; ?>images/<span id='profile-picture-path'>admin.jpg</span>" id="profilePicture">
                                <div class="profile-info">
                                    <div style="font-size:32px;" class="profile-name">
                                        <span id="profileFirstName"></span> <span id="profileLastName"></span>
                                    </div>
                                    <div class="profile-role"><span id="profileRole"></span></div>
                                    <div class="profile-email"><span id="profileEmail"></span></div>
                                    <div class="profile-phone">
                                        <i class="fa fa-phone" id="phoneIcon" style="display: none;"> </i>
                                        <span id="profilePhone"></span>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Edit Profile Modal -->
    <div class="modal fade" id="editProfileModal" tabindex="-1" role="dialog" aria-labelledby="editProfileModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="editProfileModalLabel">Edit Profile</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <form id="editProfileForm" enctype="multipart/form-data">
                        <div class="profile-picture-upload">
                            <img id="imagePreview" src="#" alt="Preview" style="display: none;">
                            <img class="modal-profile-picture" id="modalProfilePicture" src="<?php echo STEP_root; ?>images/<span id='modal-profile-picture-path'>admin.jpg</span>">
                            <div class="mt-2">
                                <label class="btn btn-sm btn-outline-primary mb-0">
                                    <i class="fa fa-camera"></i> Change Photo
                                    <input type="file" name="profilePicture" id="fileInput5" accept="image/*" style="display: none;">
                                </label>
                                <button type="button" id="removeProfilePictureBtn" class="btn btn-sm btn-outline-danger">
                                    <i class="fa fa-trash"></i> Remove
                                </button>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="firstName">First Name *</label>
                            <input type="text" class="form-control" id="firstName" name="firstName" required>
                        </div>
                        <div class="form-group">
                            <label for="lastName">Last Name *</label>
                            <input type="text" class="form-control" id="lastName" name="lastName" required>
                        </div>
                        <div class="form-group">
                            <label for="phoneNumber">Phone Number</label>
                            <input type="tel" class="form-control" id="phoneNumber" name="phoneNumber" pattern="[0-9]{10,15}" title="10-15 digit phone number">
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary mr-4" data-dismiss="modal">Cancel</button>
                    <button type="button" id="saveProfileBtn" class="btn btn-secondary">
                        <span id="saveButtonText">Save Changes</span>
                        <span id="saveSpinner" class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"></span>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <?php include(STEP_dir.'js.php'); ?>
    <script src="<?php echo STEP_root; ?>assets/js/init-scripts/master/profile-init.js"></script>
</body>
</html>
