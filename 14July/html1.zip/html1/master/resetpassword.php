<div class="modal fade" id="resetpasswordmodal" tabindex="-1" role="dialog" aria-labelledby="scrollmodalLabel" aria-hidden="true" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog modal-sm" role="document">
        <div class="modal-content">
            <div class="modal-header bg-step">
                <h5 class="modal-title" id="scrollmodalLabel">Reset Password</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div id="alertmsg"></div>
            <form id="resetpasswordform" method="post" class="form-horizontal">
                <div class="modal-body">
                    
                        
                    <div class="form-group">
                            <label>Old Password</label>
                            <input type="password" class="form-control" placeholder="Old Password"  name="oldpassword" id="oldpassword">
                    </div>
                    <div class="form-group">
                            <label>New Password</label>
                            <input type="password" class="form-control" placeholder="New Password"  name="newpassword" id="newpassword">
                    </div>
                    <div class="form-group">
                            <label>Confirm Password</label>
                            <input type="password" class="form-control" placeholder="Confirm Password"  name="cpassword" id="cpassword">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-step">Reset</button>
                </div>
            </form>
        </div>
    </div>
</div>

