<?php
include('../config.php');
include('../chksession.php');
$activetab = "defectActive";

$enteredby = 0;$accountId = 0;$userempid = 0;
 

if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
    $userempid = $_SESSION["userempid"];
}
$defectId = isset($_GET['id']) && !empty($_GET['id']) ? $_GET['id'] : 0;
?>
<!doctype html>
<html class="no-js" lang="en">

<head>
    <?php include(STEP_dir.'headmetatag.php'); ?>
    <?php include(STEP_dir.'css.php'); ?>
</head>

<body>

    <?php include(STEP_dir.'leftpanel.php'); ?>

    <div id="right-panel" class="right-panel"  style="background-color: white;">
        <?php include(STEP_dir.'header.php'); ?>

        <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>Defect Attachments</h1>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li><a href="<?php echo STEP_root; ?>index.php">Dashboard</a></li>

                            <li><a href="<?php echo STEP_root; ?>master/defects.php">Defect Management</a></li>
                            <li class="active">Defect Attachments</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <div class="content mt-3">
            <div class="animated fadeIn">
                <div class="row">
                    <?php
                    $imgexts = array('gif', 'png', 'jpg','jpeg');
                    $docexts = array('docx','doc');
                    $excelexts = array('xls','xlsx','xlt');
                    $csvexts = array('csv');
                    $dir = STEP_dir."defectdata/".$accountId."/".$defectId."/";
                    if(is_dir($dir)) {

                        $files = array_diff(scandir($dir), array('..', '.'));
                        if(count($files) >0){
                            foreach($files as $file){
                                $ext = pathinfo($file, PATHINFO_EXTENSION);
                                if (file_exists(STEP_dir.'defectdata/'.$accountId.'/'.$defectId."/".$file)) {
                                    if(in_array($ext, $docexts)){
                                        ?>
                                        <div class="col-md-2">
                                            <div class="card">
                                                <div class="card-body">
                                                    <div class="mx-auto d-block" align="center">
                                                       <a href="<?php echo STEP_root.'defectdata/'.$accountId.'/'.$defectId."/".$file;?>"> <img src="<?php echo STEP_root.'images/doc.png';?>" height="50%" width="50%"></a>
                                                    </div>
                                                    <hr>
                                                    <div class="card-text text-sm-center">
                                                        <a href="<?php echo STEP_root.'defectdata/'.$accountId.'/'.$defectId."/".$file;?>"><i class="fa fa-download pr-1"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php
                                    }else if(in_array($ext, $csvexts)){
                                        ?>
                                        <div class="col-md-2">
                                            <div class="card">
                                                <div class="card-body">
                                                    <div class="mx-auto d-block" align="center">
                                                       <a href="<?php echo STEP_root.'defectdata/'.$accountId.'/'.$defectId."/".$file;?>"> <img src="<?php echo STEP_root.'images/csv.png';?>" height="50%" width="50%"></a>
                                                    </div>
                                                    <hr>
                                                    <div class="card-text text-sm-center">
                                                        <a href="<?php echo STEP_root.'defectdata/'.$accountId.'/'.$defectId."/".$file;?>"><i class="fa fa-download pr-1"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php
                                    }else if(in_array($ext, $excelexts)){
                                        ?>
                                        <div class="col-md-2">
                                            <div class="card">
                                                <div class="card-body">
                                                    <div class="mx-auto d-block" align="center">
                                                        <a href="<?php echo STEP_root.'defectdata/'.$accountId.'/'.$defectId."/".$file;?>"><img src="<?php echo STEP_root.'images/excel.png';?>" height="50%" width="50%"></a>
                                        
                                                    </div>
                                                    <hr>
                                                    <div class="card-text text-sm-center">
                                                        <a href="<?php echo STEP_root.'defectdata/'.$accountId.'/'.$defectId."/".$file;?>"><i class="fa fa-download pr-1"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php
                                    }else if(in_array($ext, $imgexts)){
                                        ?>
                                        <div class="col-md-2">
                                            <div class="card">
                                                <div class="card-body">
                                                    <div class="mx-auto d-block" align="center">
                                                        <a href="<?php echo STEP_root.'defectdata/'.$accountId.'/'.$defectId."/".$file;?>"   target="_blank"><img src="<?php echo STEP_root.'defectdata/'.$defectId."/".$file;?>" ></a>
                                    
                                                    </div>
                                                    <hr>
                                                    <div class="card-text text-sm-center">
                                                        <a href="<?php echo STEP_root.'defectdata/'.$accountId.'/'.$defectId."/".$file;?>" download   target="_blank"><i class="fa fa-download pr-1"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php
                                    }else {
                                        ?>
                                        <div class="col-md-2">
                                            <div class="card">
                                                <div class="card-body">
                                                    <div class="mx-auto d-block" align="center">
                                    
                                                       <a href="<?php echo STEP_root.'defectdata/'.$accountId.'/'.$defectId."/".$file;?>"> <i class="fa fa-file-text pr-1"></i></a>
                                                    </div>
                                                    <hr>
                                                    <div class="card-text text-sm-center">
                                                        <a href="<?php echo STEP_root.'defectdata/'.$accountId.'/'.$defectId."/".$file;?>" download><i class="fa fa-download pr-1"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php
                                    }                               
                                
                                }
                            
                            }
                        }
                    }else{

                        // echo "else";
                    }
                    ?>
                    <div class="col-md-12">
                        
                    </div>


                </div>
            </div><!-- .animated -->
        </div><!-- .content -->


    </div><!-- /#right-panel -->

    <?php include(STEP_dir.'js.php'); ?>
    <script src="<?php echo STEP_root; ?>assets/js/init-scripts/master/project-init.js"></script>

    

</body>

</html>
