<?php
include('../config.php');
include('../chksession.php');
$activetab = "helpActive";
?>
<!doctype html>
<html class="no-js" lang="en">

<head>
    <?php include(STEP_dir.'headmetatag.php'); ?>
    <?php include(STEP_dir.'css.php'); ?>
</head>

<body>

    <?php include(STEP_dir.'leftpanel.php'); ?>


    <div id="right-panel" class="right-panel"  style="background-color: white;">
        <?php include(STEP_dir.'header.php'); ?>

        <div class="breadcrumbs">
            <div class="col-sm-12">
                <div class="page-header float-left">
                    <div class="page-title">
                        <ol class="breadcrumb text-left">
                            <li><a href="<?php echo STEP_root; ?>index.php">Dashboard</a></li>                            
                            <li class="active">Help</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <div class="container" >
            <p>This document provides a step-by-step guide to using the Admin Panel effectively. It covers the system flow, module access, and how to manage key features.
<br/><a target="_blank" src="<?php echo STEP_root; ?>help-docs/user_guide.pdf"> Help / User Guide </a></p>
        <div style="border: 1px solid #ccc; padding: 10px; height: 500px; display:none;">
  <a target="_blank" src="<?php echo STEP_root; ?>help-docs/user_guide.pdf"> Help / User Guide </a>
  <!--<iframe src="<?php echo STEP_root; ?>help-docs/user_guide.pdf" width="100%" height="550px" style="border: none;"></iframe>-->
</div>
        </div>
    </div>
    
    



    <?php include(STEP_dir.'js.php'); ?>

</body>

</html>
