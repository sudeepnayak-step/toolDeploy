<?php
include('../config.php');
include('../chksession.php');
$activetab = "projectActive";
 
$enteredby = 0;$accountId = 0;$userempid = 0;
 

if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
    $userempid = $_SESSION["userempid"];
}
$projectId = isset($_GET['id']) && !empty($_GET['id']) ? $_GET['id'] : 0;
?>
<!doctype html>
<html class="no-js" lang="en">

<head>
    <?php include(STEP_dir.'headmetatag.php'); ?>
    <?php include(STEP_dir.'css.php'); ?>
</head>

<body>

    <?php include(STEP_dir.'leftpanel.php'); ?>


    <div id="right-panel" class="right-panel"  style="background-color: white;">
        <?php include(STEP_dir.'header.php'); ?>

        <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>Project Documents</h1>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li><a href="<?php echo STEP_root; ?>index.php">Dashboard</a></li>                   
                            <li><a href="<?php echo STEP_root; ?>testmanagement.php">Test Management</a></li>
                            <li><a href="<?php echo STEP_root; ?>master/projects.php">Projects</a></li>
                            <li class="active">Project Documents</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <div class="content mt-3">
            <div class="animated fadeIn">
                <div class="row">
                    <?php
                    $imgexts = array('gif', 'png', 'jpg','jpeg');
                    $docexts = array('docx','doc');
                    $csvexts = array('csv');
                    $excelexts = array('xls','xlsx','xlt');
                    $dir = STEP_dir."attachments/".$accountId."/project/".$projectId."/";
                    if(is_dir($dir)) {

                        $files = array_diff(scandir($dir), array('..', '.'));
                        if(count($files) >0){
                            foreach($files as $file){
                                $ext = pathinfo($file, PATHINFO_EXTENSION);
                                if (file_exists(STEP_dir.'attachments/'.$accountId.'/project/'.$projectId."/".$file)) {
                                    if(in_array($ext, $docexts)){
                                        ?>
                                        <div class="col-md-2">
                                            <div class="card">
                                                <div class="card-body">
                                                    <div class="mx-auto d-block" align="center">
                                                        <a href="<?php echo STEP_root.'attachments/'.$accountId.'/project/'.$projectId."/".$file;?>"  target="_blank"> <img src="<?php echo STEP_root.'images/doc.png';?>" height="50%" width="50%"></a>
                                                    </div>
                                                    <hr>
                                                    <div class="card-text text-sm-center">
                                                        <a href="<?php echo STEP_root.'attachments/'.$accountId.'/project/'.$projectId."/".$file;?>" download target="_blank"><i class="fa fa-download pr-1"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php
                                    }else if(in_array($ext, $csvexts)){
                                        ?>
                                        <div class="col-md-2">
                                            <div class="card">
                                                <div class="card-body">
                                                    <div class="mx-auto d-block" align="center">
                                                         <a href="<?php echo STEP_root.'attachments/'.$accountId.'/project/'.$projectId."/".$file;?>"  target="_blank"><img src="<?php echo STEP_root.'images/csv.png';?>" height="50%" width="50%"></a>
                                                    </div>
                                                    <hr>
                                                    <div class="card-text text-sm-center">
                                                        <a href="<?php echo STEP_root.'attachments/'.$accountId.'/project/'.$projectId."/".$file;?>" download target="_blank"><i class="fa fa-download pr-1"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php
                                    }else if(in_array($ext, $excelexts)){
                                        ?>
                                        <div class="col-md-2">
                                            <div class="card">
                                                <div class="card-body">
                                                    <div class="mx-auto d-block" align="center">
                                                         <a href="<?php echo STEP_root.'attachments/'.$accountId.'/project/'.$projectId."/".$file;?>"  target="_blank"><img src="<?php echo STEP_root.'images/excel.png';?>" height="50%" width="50%"></a>
                                                    </div>
                                                    <hr>
                                                    <div class="card-text text-sm-center">
                                                        <a href="<?php echo STEP_root.'attachments/'.$accountId.'/project/'.$projectId."/".$file;?>" download target="_blank"><i class="fa fa-download pr-1"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php
                                    }else if(in_array($ext, $imgexts)){
                                        ?>
                                        <div class="col-md-2">
                                            <div class="card">
                                                <div class="card-body">
                                                    <div class="mx-auto d-block" align="center">
                                                        <a href="<?php echo STEP_root.'attachments/'.$accountId.'/project/'.$projectId."/".$file;?>"  target="_blank"> <img src="<?php echo STEP_root.'attachments/'.$accountId.'/project/'.$projectId."/".$file;?>" ></a>
                                                    </div>
                                                    <hr>
                                                    <div class="card-text text-sm-center">
                                                        <a href="<?php echo STEP_root.'attachments/'.$accountId.'/project/'.$projectId."/".$file;?>" target="_blank" download><i class="fa fa-download pr-1"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php
                                    }else {
                                        ?>
                                        <div class="col-md-2">
                                            <div class="card">
                                                <div class="card-body">
                                                    <div class="mx-auto d-block" align="center">
                                    
                                                        <i class="fa fa-file-text pr-1"></i>
                                                    </div>
                                                    <hr>
                                                    <div class="card-text text-sm-center">
                                                        <a href="<?php echo STEP_root.'attachments/'.$accountId.'/project/'.$projectId."/".$file;?>" target="_blank" download><i class="fa fa-download pr-1"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <?php
                                    }
                                }
                            
                            }
                        }
                    }else{

                        echo "else";
                    }
                    ?>
                    <div class="col-md-12">
                        
                    </div>


                </div>
            </div><!-- .animated -->
        </div><!-- .content -->


    </div><!-- /#right-panel -->

    <?php include(STEP_dir.'js.php'); ?>
    <script src="<?php echo STEP_root; ?>assets/js/init-scripts/master/project-init.js"></script>

    

</body>

</html>
