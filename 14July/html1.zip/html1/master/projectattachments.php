<?php
include('../config.php');
include('../chksession.php');
$activetab = "projectActive";
 
$enteredby = 0;$accountId = 0;$userempid = 0;
 

if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
    $userempid = $_SESSION["userempid"];
}
$projectId = isset($_GET['id']) && !empty($_GET['id']) ? $_GET['id'] : 0;
?>
<!doctype html>
<html class="no-js" lang="en">

<head>
    <?php include(STEP_dir.'headmetatag.php'); ?>
    <?php include(STEP_dir.'css.php'); ?>
</head>

<body>

    <?php include(STEP_dir.'leftpanel.php'); ?>

    <div id="right-panel" class="right-panel"  style="background-color: white;">
        <?php include(STEP_dir.'header.php'); ?>

        <div class="breadcrumbs">
            <div class="col-sm-4">
                <div class="page-header float-left">
                    <div class="page-title">
                        <h1>Project Documents</h1>
                    </div>
                </div>
            </div>
            <div class="col-sm-8">
                <div class="page-header float-right">
                    <div class="page-title">
                        <ol class="breadcrumb text-right">
                            <li><a href="<?php echo STEP_root; ?>index.php">Dashboard</a></li>                   
                            <li><a href="<?php echo STEP_root; ?>testmanagement.php">Test Management</a></li>
                            <li><a href="<?php echo STEP_root; ?>master/projects.php">Projects</a></li>
                            <li class="active">Project Documents</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <div class="container" >
            <div class="row" id="attachmentdiv"></div>
        </div>
    </div>

    <?php include(STEP_dir.'js.php'); ?>
    <script src="<?php echo STEP_root; ?>assets/js/init-scripts/master/attachment-init.js"></script>

    

</body>

</html>
