<div class="modal fade" id="testcasedetailsmodal" tabindex="-1" role="dialog" aria-labelledby="scrollmodalLabel" aria-hidden="true" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header bg-step">
                <h5 class="modal-title" id="scrollmodalLabel">Testcase</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form id="testcasedetailsform" method="post" class="form-horizontal">
                <div class="modal-body">
                    
                        <div class="row form-group">
                            <div class="col-4 " style="display: none;">
                                <div class="form-group">
                                    <label for="testcaseDBId" class=" form-control-label">Activity ID : </label>
                                    <input type="text" id="testcaseDBId" name="testcaseDBId" placeholder="Enter activity name" value="0" class="form-control">
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="form-group">
                                    <label for="tc_projectId" class=" form-control-label">Project : <span id="tc_projectId" style="font-weight: bold;"></span></label>
                                </div>
                            </div>
                            
                            <div class="col-4">
                                <div class="form-group">
                                    <label for="tc_releaseId" class=" form-control-label">Release : <span id="tc_releaseId" style="font-weight: bold;"></span></label>
                                </div>
                            </div>
                            
                            <div class="col-4">
                                <div class="form-group">
                                    <label for="tc_activityId" class=" form-control-label">Test Type : <span id="tc_activityId" style="font-weight: bold;"></span></label>
                                </div>
                            </div>
                        </div>
                        <div class="row form-group">
                            
                            <div class="col-4">
                                <div class="form-group">
                                    <label for="tc_scenarioId" class=" form-control-label">Testcase Scenario : <span id="tc_scenarioId" style="font-weight: bold;"></span></label>
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="form-group">
                                    <label for="tc_module" class=" form-control-label">Module : <span id="tc_module" style="font-weight: bold;"></span></label>
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="form-group">
                                    <label for="tc_submodule" class=" form-control-label">Sub Module : <span id="tc_submodule" style="font-weight: bold;"></span></label>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row form-group">

                            <div class="col-4 hidden">
                                <div class="form-group">
                                    <label for="tc_assignto" class=" form-control-label">Assign to : <span id="tc_assignto" style="font-weight: bold;"></span></label>
                                </div>
                            </div>

                            <div class="col-4">
                                <div class="form-group">
                                    <label for="tc_author" class=" form-control-label">Author : <span id="tc_author" style="font-weight: bold;"></span></label>
                                </div>
                            </div>

                            <div class="col-4">
                                <div class="form-group">
                                    <label for="tc_reviewer" class=" form-control-label">Reviewer : <span id="tc_reviewer" style="font-weight: bold;"></span></label>
                                </div>
                            </div>
                            
                            <div class="col-4">
                                <div class="form-group">
                                    <label for="tc_testmode" class=" form-control-label">Test Mode : <span id="tc_testmode" style="font-weight: bold;"></span></label>
                                </div>
                            </div>
                        </div>
                        <div class="row form-group">

                            <div class="col-6">
                                <div class="form-group">
                                    <label for="tc_testscenariodesc" class=" form-control-label">Test Scenario Description : </label>
                                    <textarea  class="form-control" name="tc_testscenariodesc" id="tc_testscenariodesc" rows="2"></textarea>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-group">
                                    <label for="tc_testcasedesc" class=" form-control-label">Test Case Description : </label>
                                    <textarea  class="form-control" name="tc_testcasedesc" id="tc_testcasedesc" rows="2"></textarea>
                                </div>
                            </div>
                        </div>
                        <div class="row form-group hidden">

                            <div class="col-6">
                                <div class="form-group">
                                    <label for="tc_steps" class=" form-control-label">Steps : </label>
                                    <textarea  class="form-control" name="tc_steps" id="tc_steps" rows="2"></textarea>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-group">
                                    <label for="tc_expectedresult" class=" form-control-label">Expected Result : </label>
                                    <textarea  class="form-control" name="tc_expectedresult" id="tc_expectedresult" rows="2"></textarea>
                                </div>
                            </div>
                        </div>
                        <div class="row form-group">

                            <div class="col-6">
                                <div class="form-group">
                                    <label for="tc_precondition" class=" form-control-label">Pre-Condition : </label>
                                    <textarea  class="form-control" name="precondition" id="precondition" rows="2"></textarea>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-group">
                                    <label for="testdata" class=" form-control-label">Test Data : </label>
                                    <textarea  class="form-control" name="tc_testdata" id="tc_testdata" rows="2"></textarea>
                                </div>
                            </div>
                        </div>
                        
                        <div class="row form-group">

                            <div class="col-6">
                                <div class="form-group">
                                    <label for="tc_comment" class=" form-control-label">Comment : </label>
                                    <textarea  class="form-control" name="tc_comment" id="tc_comment" rows="2"></textarea>
                                </div>
                            </div>
                        </div>

                        <div class="row form-group">
                            <div class="col-12">
                                <table id="testcasehistoryTbl" class="table compact table-bordered table-hover " style="width:100%;">
                                    <thead  class="bg-step text-white">
                                        <tr>
                                        <th>Iteration</th> 
                                        <th>Test Result</th> 
                                        <th>Steps</th> 
                                        <th>Execution Starttime</th>
                                        <th>Execution Endtime</th>
                                        <th>Execution Time</th>
                                        <th>Artifacts</th>
                                        </tr> 
                                    </thead>
                                </table>
                            </div>
                        </div>
                        
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Ok</button>
                </div>
            </form>
        </div>
    </div>
</div>

