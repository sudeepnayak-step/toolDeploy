﻿<div class="modal fade" id="stepexecutionmodal" tabindex="-1" role="dialog" aria-labelledby="scrollmodalLabel" aria-hidden="true" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header bg-step">
                <h5 class="modal-title" id="scrollmodalLabel">Steps</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form id="stepexecutionform" method="post" class="form-horizontal">
                <div class="modal-body">
                    
                        <div class="row form-group">
                            <div class="col-4 " style="display: none;">
                                <div class="form-group">
                                    <label for="executionId" class=" form-control-label">Activity ID : </label>
                                    <input type="text" id="executionId" name="executionId" placeholder="Enter activity name" value="0" class="form-control">
                                </div>
                            </div>

                        </div>

                        <table id="stepexecutionTbl" class="table compact table-bordered table-hover " style="width:100%;">
                            <thead  class="bg-step text-white">
                                <tr align="left">
                                <th class="notexport">id</th> 
                                <th>Step No</th>
                                <th>Steps</th>  
                                <th>Expected Result</th> 
                                <th>Test Result</th> 
                                <th>Actual Result</th> 
				<th>Reason</th> 
                                <th>Comment</th>
                                <th>Iteration</th> 
                                </tr> 
                            </thead>
                            
                        </table>
			<!-- new code -->
			<div class="form-group" id='exefilediv' style='display:none;'>
                        <label for="file">Upload Documents</label>
                        <input type="file" class="form-control-file" id="file" name="docfile">
                    </div>
                        
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-step">Save</button>
                </div>
            </form>
        </div>
    </div>
</div>

