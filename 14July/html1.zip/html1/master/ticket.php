<?php
include('../config.php');
include('../chksession.php');
$activetab = "ticketActive";
?>
<!doctype html>
<html class="no-js" lang="en">

<head>
    <?php include(STEP_dir.'headmetatag.php'); ?>
    <?php include(STEP_dir.'css.php'); ?>
</head>

<body>

    <?php include(STEP_dir.'leftpanel.php'); ?>


    <div id="right-panel" class="right-panel"  style="background-color: white;">
        <?php include(STEP_dir.'header.php'); ?>

        <div class="breadcrumbs">
            <div class="col-sm-12">
                <div class="page-header float-left">
                    <div class="page-title">
                        <ol class="breadcrumb text-left">
                            <li><a href="<?php echo STEP_root; ?>index.php">Dashboard</a></li>                            
                            <li class="active">Ticket</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <div class="container" >
        	
	    <div class="row mb-3">
            <div class="col-md-4 text-left "   >
            </div>	 
      	    <div class="col-md-4"></div>
            <div class="col-md-4 text-right">
                <?php if(isset($_SESSION["usertype"]) && $_SESSION["usertype"] == "Employee"){ ?>
                    
                <button type="button" class="btn btn-step "  id="raisedticketbtn" data-toggle="modal" data-target="#ticketmodal"><i class="fa fa-plus"></i> Raise Ticket</button>
                <?php } ?>
            </div>
        </div>
	    <table id="ticketTbl" class="table compact nowrap table-bordered table-hover" style="width:100%;">
                <thead  class="bg-step text-white" id="filters">
                    <tr align="left">
                    
                        <th>Sr. No.</th>     
                        <th>Ticket No.</th>
                        <th>Problem Statement</th>
                        <th>Module</th>
                        <th>Description</th>
                        <th>Raised By</th>
                        <th>Raised At</th>
                        <th>Updated At</th>
                        <th></th>
                        <th>Status</th>
                        <th class="text-center notexport">Action</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>
    
    
    <div class="modal fade" id="ticketmodal" tabindex="-1" role="dialog" aria-labelledby="scrollmodalLabel" aria-hidden="true" data-backdrop="static" data-keyboard="false">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-step">
                    <h5 class="modal-title" id="scrollmodalLabel">Raise Ticket</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form id="ticketform" method="post" class="form-horizontal">
                    <div class="modal-body">

                        <!-- <input type="hidden" id="ticketId" name="ticketId"  value="0" > -->
                        <div class="row  form-group">
                            <div class="col-12">
                                <div class="form-group  required">
                                    <label for="problem" class="form-control-label">Problem Statement : </label>
                                    <input type="text" class="form-control" id="problem" name="problem" placeholder="Enter Problem Statement" required="" data-exist=""  data-id="0">
                                </div> 
                            </div>
                        </div>

                        <div class="row form-group">
                            <div class="col-12">
                                <div class="form-group required">
                                    <label for="description" class=" form-control-label">Addtional Information : </label>
                                    <textarea  class="form-control" name="description" id="description" rows="5"></textarea>
                                </div>
                            </div>
                        </div>
                        <div class="row form-group">
                            <div class="col-4">
                                <div class="form-group">
                                    <label for="module" class=" form-control-label">Module : </label>
                                        <select class="form-control" id="module" name="module" data-exist="" >
                                        <option value="" >Select Module</option>
                                        <option value="Login">Login</option>
                                        <option value="Project">Project</option>
                                        <option value="Release">Release</option>
                                        <option value="Test Plan">Test Plan</option>
                                        <option value="Requirement">Requirement</option>
                                        <option value="Testcase">Testcase</option>
                                        <option value="Test Suite">Test Suite</option>
                                        <option value="Defect">Defect</option>
                                        <option value="Chart">Chart</option>
                                        <option value="Dashboard">Dashboard</option>
                                        <option value="Other">Other</option>
                                        </select>
                                </div>
                            </div>
                        </div>

                        
                        <div class="row form-group">
                            <div class="col-sm-12">
                                        <label for="file">Upload File</label>
                                        <input type="file" class="" id="file" name="fileToUpload[]"  multiple="multiple" style="width:100%"/>
                            </div>
                        </div>

                        <div class="row hidden activestatus">
                            <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12   mb-3">
                            </div>
                            <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12 text-right  mb-3">
                                <span id="createdat" ></span>
                            </div>
                            
                        </div>


                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-gray" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-step">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>


    
    <div class="modal fade" id="replymodal" tabindex="-1" role="dialog" aria-labelledby="scrollmodalLabel" aria-hidden="true" data-backdrop="static" data-keyboard="false">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-step">
                    <h5 class="modal-title" id="scrollmodalLabel">Raise Ticket</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form id="replyform" method="post" class="form-horizontal">

                    <div class="modal-body " id="replyticket">
                        <input type="text" id="ticketId" name="ticketId" value="" />
                        <div class="form-group row  mb-4">
                            <label for="ticketnum" class="col-sm-4 col-form-label col-form-label-sm">Ticket No. : </label>
                            <div class="col-sm-8">
                                <label  class="  col-form-label col-form-label-sm" id="ticketnum"></label>
                            </div>
                        </div>

                        <div class="form-group row  mb-4">
                            <label for="problem" class="col-sm-4 col-form-label col-form-label-sm">Problem Statement : </label>
                            <div class="col-sm-8">
                                <label  class="  col-form-label col-form-label-sm" id="problem"></label>
                            </div>
                        </div>

                        <div class="form-group row  mb-4">
                            <label for="description" class="col-sm-4 col-form-label col-form-label-sm">Additional Information : </label>
                            <div class="col-sm-8">
                                <label  class="  col-form-label col-form-label-sm" id="description"></label>
                            </div>
                        </div>

                        <div class="form-group row  mb-4">
                            <label for="status" class="col-sm-4 col-form-label col-form-label-sm">Status : </label>
                            <div class="col-sm-8">
                                <label  class="  col-form-label col-form-label-sm" id="status"></label>
                            </div>
                        </div>

                        <div class="row hidden activestatus">
                            <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12   mb-3">
                            </div>
                            <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12 text-right  mb-3">
                                <span id="createdat" ></span>
                            </div>
                            
                        </div>
                        <h6 id="attachmentsheaderedit" class="hidden">Attachments</h6>
                        <br/>
                        <div class="row form-group" id="attachmentsedit"></div>

                        <div  id="escalation" class="mb-4"></div>
                        <hr/>
                        <div class="row form-group">
                            <div class="col-12">
                                <div class="form-group required">
                                    <label for="resolution_note" class=" form-control-label">Reason to Escalate | Resolution Note </label>
                                    <textarea  class="form-control" name="resolution_note" id="resolution_note" rows="5" required></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-gray" data-dismiss="modal">Close</button>
                        <button type="submit"  class="btn btn-success" name="action" value="close">Close Ticket</button>
                        <button type="submit"  class="btn btn-step" name="action" value="escalate">Escalate to Next Level</button>

                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="modal fade" id="ticketviewmodal" tabindex="-1" role="dialog" aria-labelledby="scrollmodalLabel" aria-hidden="true" data-backdrop="static" data-keyboard="false">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-step">
                    <h5 class="modal-title" id="scrollmodalLabel">Raise Ticket</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                    <div class="modal-body " id="viewticket">
                        <div class="form-group row  mb-4">
                            <label for="ticketnum" class="col-sm-4 col-form-label col-form-label-sm">Ticket No. : </label>
                            <div class="col-sm-8">
                                <label  class="  col-form-label col-form-label-sm" id="ticketnum"></label>
                            </div>
                        </div>

                        <div class="form-group row  mb-4">
                            <label for="problem" class="col-sm-4 col-form-label col-form-label-sm">Problem Statement : </label>
                            <div class="col-sm-8">
                                <label  class="  col-form-label col-form-label-sm" id="problem"></label>
                            </div>
                        </div>

                        <div class="form-group row  mb-4">
                            <label for="description" class="col-sm-4 col-form-label col-form-label-sm">Additional Information : </label>
                            <div class="col-sm-8">
                                <label  class="  col-form-label col-form-label-sm" id="description"></label>
                            </div>
                        </div>


                        <div class="form-group row  mb-4">
                            <label for="status" class="col-sm-4 col-form-label col-form-label-sm">Status : </label>
                            <div class="col-sm-8">
                                <label  class="  col-form-label col-form-label-sm" id="status"></label>
                            </div>
                        </div>

                        <div class="row hidden activestatus">
                            <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12   mb-3">
                            </div>
                            <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12 text-right  mb-3">
                                <span id="createdat" ></span>
                            </div>
                            
                        </div>
                        <h6 id="attachmentsheaderedit" class="hidden">Attachments</h6>
                        <br/>
                        <div class="row form-group" id="attachmentsedit"></div>

                        <hr/>
                        <div  id="escalation" class="mb-4"></div>

                        
                    </div>
                    <div class="modal-footer">
                        <button class="btn btn-gray" data-dismiss="modal">Close</button>
        
                    </div>
            </div>
        </div>
    </div>

    <?php include(STEP_dir.'js.php'); ?>
    <script src="<?php echo STEP_root; ?>assets/js/init-scripts/master/ticket-init.js"></script>

    

</body>

</html>
