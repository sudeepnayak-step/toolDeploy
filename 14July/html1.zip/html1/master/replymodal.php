<div class="modal fade" id="replymodal" tabindex="-1" role="dialog" aria-labelledby="scrollmodalLabel" aria-hidden="true" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog modal-sm" role="document">
        <div class="modal-content">
            <div class="modal-header bg-step">
                <h5 class="modal-title" id="scrollmodalLabel">Reply</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form id="replyform" method="post" class="form-horizontal" action="" enctype="multipart/form-data">
                <div class="modal-body">
                    
                        <input type="hidden" name="nCommentId" id="nCommentId" value="0"/>
                        <div class="row form-group">
                            <div class="col-12">
                                <div class="form-group">
                                    <label for="replycomment" class=" form-control-label">Comment : </label>
                                    <textarea  class="form-control " name="replycomment" id="replycomment" row="4"></textarea>
                                </div>
                            </div>
                            
                        </div>
                        
                        
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-step">Submit</button>
                </div>
            </form>
        </div>
    </div>
</div>


