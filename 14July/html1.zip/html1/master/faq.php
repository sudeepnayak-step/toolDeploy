<?php
include('../config.php');
include('../chksession.php');
$activetab = "helpActive";
?>
<!doctype html>
<html class="no-js" lang="en">

<head>
    <?php include(STEP_dir.'headmetatag.php'); ?>
    <?php include(STEP_dir.'css.php'); ?>
</head>
<style>
    .btn-link {
      display: flex;
      justify-content: space-between;
      align-items: center;
      width: 100%;
      text-align: left;
      font-weight: bold;
      /* font-size: 1.1rem; */
      text-decoration: none !important;
    }

    .card-header{
        padding : 0 !important;
    }
    .btn-link::after {
      content: "−"; /* Minus when expanded */
      font-size: 1.5rem;
      transition: all 0.3s ease;
    }

    .btn-link.collapsed::after {
      content: "+"; /* Plus when collapsed */
    }
  </style>
<body>

    <?php include(STEP_dir.'leftpanel.php'); ?>


    <div id="right-panel" class="right-panel"  style="background-color: white;">
        <?php include(STEP_dir.'header.php'); ?>

        <div class="breadcrumbs">
            <div class="col-sm-12">
                <div class="page-header float-left">
                    <div class="page-title">
                        <ol class="breadcrumb text-left">
                            <li><a href="<?php echo STEP_root; ?>index.php">Dashboard</a></li>                            
                            <li class="active">FAQs</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <div class="container" >
            
        <p class="text-left mb-4">Frequently Asked Questions</p>
  <div id="accordion">

    <!--<div class="card">
      <div class="card-header" id="headingOne">
        <h5 class="mb-0">
          <a class="btn btn-link" data-toggle="collapse" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
          How do I filter projects by date, owner, or status?
          </a>
        </h5>
      </div>

      <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion">
        <div class="card-body">
        Use the filter dropdowns and datepickers at the top of the table to select project, status, owner, or plan dates. The table updates automatically.
        </div>
      </div>
    </div>

    <div class="card">
      <div class="card-header" id="headingTwo">
        <h5 class="mb-0">
          <a class="btn btn-link collapsed" data-toggle="collapse" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
          What does the "Status" column show?
          </a>
        </h5>
      </div>
      <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
        <div class="card-body">
        It indicates the current phase of the project, e.g., Complete, In Progress, or Pending.
        </div>
      </div>
    </div>

    <div class="card">
      <div class="card-header" id="headingThree">
        <h5 class="mb-0">
          <a class="btn btn-link collapsed" data-toggle="collapse" href="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
          How do I create a new project?
          </a>
        </h5>
      </div>
      <div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordion">
        <div class="card-body">
        Click the "+ ADD Project" button. Fill out the form in the modal with the required details (marked with *) and save.
        </div>
      </div>
    </div>

<div class="card">
      <div class="card-header" id="headingThre">
        <h5 class="mb-0">
          <a class="btn btn-link collapsed" data-toggle="collapse" href="#collapseThre" aria-expanded="false" aria-controls="collapseThre">
          How do I create a new release????
          </a>
        </h5>
      </div>
      <div id="collapseThre" class="collapse" aria-labelledby="headingThre" data-parent="#accordion">
        <div class="card-body">
        Click the "+ ADD Release" button. Fill out the form in the modal with the required details (marked with *) and save.
        </div>
      </div>
    </div>

    <div class="card">
      <div class="card-header" id="headingFour">
        <h5 class="mb-0">
          <a class="btn btn-link collapsed" data-toggle="collapse" href="#collapseFour" aria-expanded="false" aria-controls="collapseFour">
          Can I assign multiple team members?
          </a>
        </h5>
      </div>
      <div id="collapseFour" class="collapse" aria-labelledby="headingFour" data-parent="#accordion">
        <div class="card-body">
        Yes, use the Team Member multiselect dropdown to assign more than one member.
        </div>
      </div>
    </div>-->

<!-- New Code -->
<div class="card">
    <div class="card-header" id="heading1">
      <h5 class="mb-0">
        <a class="btn btn-link collapsed" data-toggle="collapse" href="#collapse1" aria-expanded="false" aria-controls="collapse1">
          What are the different types of KPIs shown in the dashboard?
        </a>
      </h5>
    </div>
    <div id="collapse1" class="collapse" aria-labelledby="heading1" data-parent="#accordion">
      <div class="card-body">
        The dashboard shows KPIs such as Total Projects, Test Execution Rate, Defect Aging, Defect Leakage (UAT & Production), Iteration-wise pass/fail trend, and milestone completion.
      </div>
    </div>
  </div>

  <div class="card">
    <div class="card-header" id="heading2">
      <h5 class="mb-0">
        <a class="btn btn-link collapsed" data-toggle="collapse" href="#collapse2" aria-expanded="false" aria-controls="collapse2">
          Can I view dashboard data specific to a particular tester or owner?
        </a>
      </h5>
    </div>
    <div id="collapse2" class="collapse" aria-labelledby="heading2" data-parent="#accordion">
      <div class="card-body">
        Currently, dashboards are filtered at the project, release, and activity level. Individual user/tester-based views can be generated from specific reports.
      </div>
    </div>
  </div>

  <div class="card">
    <div class="card-header" id="heading3">
      <h5 class="mb-0">
        <a class="btn btn-link collapsed" data-toggle="collapse" href="#collapse3" aria-expanded="false" aria-controls="collapse3">
          Is it possible to configure which KPIs appear on the dashboard?
        </a>
      </h5>
    </div>
    <div id="collapse3" class="collapse" aria-labelledby="heading3" data-parent="#accordion">
      <div class="card-body">
        Admin users can control chart visibility and parameters through the Chart Settings module.
      </div>
    </div>
  </div>

  <div class="card">
    <div class="card-header" id="heading4">
      <h5 class="mb-0">
        <a class="btn btn-link collapsed" data-toggle="collapse" href="#collapse4" aria-expanded="false" aria-controls="collapse4">
          Can I schedule the Daily Status Report (DSR) to be auto-emailed?
        </a>
      </h5>
    </div>
    <div id="collapse4" class="collapse" aria-labelledby="heading4" data-parent="#accordion">
      <div class="card-body">
        Yes. You can set project-specific email configurations in the Project Email Settings module and use the "Send Email" option in the DSR view.
      </div>
    </div>
  </div>

  <div class="card">
    <div class="card-header" id="heading5">
      <h5 class="mb-0">
        <a class="btn btn-link collapsed" data-toggle="collapse" href="#collapse5" aria-expanded="false" aria-controls="collapse5">
          What does "Actual Start Date" capture?
        </a>
      </h5>
    </div>
    <div id="collapse5" class="collapse" aria-labelledby="heading5" data-parent="#accordion">
      <div class="card-body">
        This date is user-generated when the first test activity (e.g., test plan or test case execution) begins under the project.
      </div>
    </div>
  </div>

  <div class="card">
    <div class="card-header" id="heading6">
      <h5 class="mb-0">
        <a class="btn btn-link collapsed" data-toggle="collapse" href="#collapse6" aria-expanded="false" aria-controls="collapse6">
          Can a user be part of multiple projects?
        </a>
      </h5>
    </div>
    <div id="collapse6" class="collapse" aria-labelledby="heading6" data-parent="#accordion">
      <div class="card-body">
        Yes, users can be assigned to multiple projects based on role and access permissions.
      </div>
    </div>
  </div>

  <div class="card">
    <div class="card-header" id="heading7">
      <h5 class="mb-0">
        <a class="btn btn-link collapsed" data-toggle="collapse" href="#collapse7" aria-expanded="false" aria-controls="collapse7">
          What happens if I mark a project as inactive?
        </a>
      </h5>
    </div>
    <div id="collapse7" class="collapse" aria-labelledby="heading7" data-parent="#accordion">
      <div class="card-body">
        Inactive projects won’t appear in filters or dashboard views but are retained in the system for audit/history.
      </div>
    </div>
  </div>

  <div class="card">
    <div class="card-header" id="heading8">
      <h5 class="mb-0">
        <a class="btn btn-link collapsed" data-toggle="collapse" href="#collapse8" aria-expanded="false" aria-controls="collapse8">
          Can I assign multiple owners to a project?
        </a>
      </h5>
    </div>
    <div id="collapse8" class="collapse" aria-labelledby="heading8" data-parent="#accordion">
      <div class="card-body">
        Currently, one primary owner is supported. Other stakeholders can be tagged via roles or the business/team fields.
      </div>
    </div>
  </div>

  <div class="card">
    <div class="card-header" id="heading9">
      <h5 class="mb-0">
        <a class="btn btn-link collapsed" data-toggle="collapse" href="#collapse9" aria-expanded="false" aria-controls="collapse9">
          What is the significance of Revised Start/End Dates?
        </a>
      </h5>
    </div>
    <div id="collapse9" class="collapse" aria-labelledby="heading9" data-parent="#accordion">
      <div class="card-body">
        These reflect updated planning milestones when timelines change due to delays or rescheduling.
      </div>
    </div>
  </div>

  <div class="card">
    <div class="card-header" id="heading10">
      <h5 class="mb-0">
        <a class="btn btn-link collapsed" data-toggle="collapse" href="#collapse10" aria-expanded="false" aria-controls="collapse10">
          Can I link a release to multiple test plans?
        </a>
      </h5>
    </div>
    <div id="collapse10" class="collapse" aria-labelledby="heading10" data-parent="#accordion">
      <div class="card-body">
        Yes, a single release can have multiple test plans representing different QA cycles (e.g., Smoke, Regression).
      </div>
    </div>
  </div>

  <div class="card">
    <div class="card-header" id="heading11">
      <h5 class="mb-0">
        <a class="btn btn-link collapsed" data-toggle="collapse" href="#collapse11" aria-expanded="false" aria-controls="collapse11">
          Is there a way to view test execution at the release level?
        </a>
      </h5>
    </div>
    <div id="collapse11" class="collapse" aria-labelledby="heading11" data-parent="#accordion">
      <div class="card-body">
        Yes, through the dashboard or Release Report, you can view execution trends filtered by release.
      </div>
    </div>
  </div>

  <div class="card">
    <div class="card-header" id="heading12">
      <h5 class="mb-0">
        <a class="btn btn-link collapsed" data-toggle="collapse" href="#collapse12" aria-expanded="false" aria-controls="collapse12">
          What does "Active Status" mean for a release?
        </a>
      </h5>
    </div>
    <div id="collapse12" class="collapse" aria-labelledby="heading12" data-parent="#accordion">
      <div class="card-body">
        It shows whether a release is currently in progress. Inactive releases are archived but not deleted.
      </div>
    </div>
  </div>

  <div class="card">
    <div class="card-header" id="heading13">
      <h5 class="mb-0">
        <a class="btn btn-link collapsed" data-toggle="collapse" href="#collapse13" aria-expanded="false" aria-controls="collapse13">
          What’s the impact of changing a release date mid-execution?
        </a>
      </h5>
    </div>
    <div id="collapse13" class="collapse" aria-labelledby="heading13" data-parent="#accordion">
      <div class="card-body">
        This affects dashboard timelines, progress charts, and may reset planning KPIs.
      </div>
    </div>
  </div>

  <div class="card">
    <div class="card-header" id="heading14">
      <h5 class="mb-0">
        <a class="btn btn-link collapsed" data-toggle="collapse" href="#collapse14" aria-expanded="false" aria-controls="collapse14">
          Can multiple test plans exist for the same module?
        </a>
      </h5>
    </div>
    <div id="collapse14" class="collapse" aria-labelledby="heading14" data-parent="#accordion">
      <div class="card-body">
        Yes. You can create parallel test plans to validate different aspects like Performance, Regression, etc.
      </div>
    </div>
  </div>

  <div class="card">
    <div class="card-header" id="heading15">
      <h5 class="mb-0">
        <a class="btn btn-link collapsed" data-toggle="collapse" href="#collapse15" aria-expanded="false" aria-controls="collapse15">
          What is the difference between Activity and Test Plan?
        </a>
      </h5>
    </div>
    <div id="collapse15" class="collapse" aria-labelledby="heading15" data-parent="#accordion">
      <div class="card-body">
        Activity refers to the testing scope or feature (e.g., Login), while Test Plan is the execution grouping tied to a release.
      </div>
    </div>
  </div>

  <div class="card">
    <div class="card-header" id="heading16">
      <h5 class="mb-0">
        <a class="btn btn-link collapsed" data-toggle="collapse" href="#collapse16" aria-expanded="false" aria-controls="collapse16">
          How is quality status (Excellent/Good) calculated?
        </a>
      </h5>
    </div>
    <div id="collapse16" class="collapse" aria-labelledby="heading16" data-parent="#accordion">
      <div class="card-body">
        Based on thresholds defined in the Quality Threshold Setting under the Master module.
      </div>
    </div>
  </div>

  <div class="card">
    <div class="card-header" id="heading17">
      <h5 class="mb-0">
        <a class="btn btn-link collapsed" data-toggle="collapse" href="#collapse17" aria-expanded="false" aria-controls="collapse17">
          Can I reassign test plan activities mid-cycle?
        </a>
      </h5>
    </div>
    <div id="collapse17" class="collapse" aria-labelledby="heading17" data-parent="#accordion">
      <div class="card-body">
        Yes, using the edit option to update the assigned tester or owner.
      </div>
    </div>
  </div>

  <div class="card">
    <div class="card-header" id="heading18">
      <h5 class="mb-0">
        <a class="btn btn-link collapsed" data-toggle="collapse" href="#collapse18" aria-expanded="false" aria-controls="collapse18">
          Can I track issues linked to a specific test plan?
        </a>
      </h5>
    </div>
    <div id="collapse18" class="collapse" aria-labelledby="heading18" data-parent="#accordion">
      <div class="card-body">
        Yes, each test plan can have linked risks/issues visible in the activity list.
      </div>
    </div>
  </div>

  <div class="card">
    <div class="card-header" id="heading19">
      <h5 class="mb-0">
        <a class="btn btn-link collapsed" data-toggle="collapse" href="#collapse19" aria-expanded="false" aria-controls="collapse19">
          What is the benefit of linking test cases to requirements?
        </a>
      </h5>
    </div>
    <div id="collapse19" class="collapse" aria-labelledby="heading19" data-parent="#accordion">
      <div class="card-body">
        It ensures traceability and test coverage validation, and supports RTM generation for audits.
      </div>
    </div>
  </div>

  <div class="card">
    <div class="card-header" id="heading20">
      <h5 class="mb-0">
        <a class="btn btn-link collapsed" data-toggle="collapse" href="#collapse20" aria-expanded="false" aria-controls="collapse20">
          How do I handle duplicate or evolving requirements?
        </a>
      </h5>
    </div>
    <div id="collapse20" class="collapse" aria-labelledby="heading20" data-parent="#accordion">
      <div class="card-body">
        Use versioning in the description or comments. Avoid deleting; instead, mark obsolete ones as inactive.
      </div>
    </div>
  </div>

  <div class="card">
    <div class="card-header" id="heading21">
      <h5 class="mb-0">
        <a class="btn btn-link collapsed" data-toggle="collapse" href="#collapse21" aria-expanded="false" aria-controls="collapse21">
          Can I assign a requirement to multiple reviewers?
        </a>
      </h5>
    </div>
    <div id="collapse21" class="collapse" aria-labelledby="heading21" data-parent="#accordion">
      <div class="card-body">
        Only one reviewer can be directly assigned, but notes can be added for collaborative review.
      </div>
    </div>
  </div>

  <div class="card">
    <div class="card-header" id="heading22">
      <h5 class="mb-0">
        <a class="btn btn-link collapsed" data-toggle="collapse" href="#collapse22" aria-expanded="false" aria-controls="collapse22">
          Can I get a matrix view of requirement-test case-defect mapping?
        </a>
      </h5>
    </div>
    <div id="collapse22" class="collapse" aria-labelledby="heading22" data-parent="#accordion">
      <div class="card-body">
        Yes, through the Requirement report section, which supports export in Excel.
      </div>
    </div>
  </div>

  <div class="card">
    <div class="card-header" id="heading23">
      <h5 class="mb-0">
        <a class="btn btn-link collapsed" data-toggle="collapse" href="#collapse23" aria-expanded="false" aria-controls="collapse23">
          Are requirement statuses auto-updated?
        </a>
      </h5>
    </div>
    <div id="collapse23" class="collapse" aria-labelledby="heading23" data-parent="#accordion">
      <div class="card-body">
        No. They must be manually updated based on linked test case execution results.
      </div>
    </div>
  </div>

  <div class="card">
    <div class="card-header" id="heading24">
      <h5 class="mb-0">
        <a class="btn btn-link collapsed" data-toggle="collapse" href="#collapse24" aria-expanded="false" aria-controls="collapse24">
          Can I reuse a test case across different releases?
        </a>
      </h5>
    </div>
    <div id="collapse24" class="collapse" aria-labelledby="heading24" data-parent="#accordion">
      <div class="card-body">
        Yes, test cases are reusable and can be linked to different releases via test suites.
      </div>
    </div>
  </div>

  <div class="card">
    <div class="card-header" id="heading25">
      <h5 class="mb-0">
        <a class="btn btn-link collapsed" data-toggle="collapse" href="#collapse25" aria-expanded="false" aria-controls="collapse25">
          What does "Test Mode" refer to?
        </a>
      </h5>
    </div>
    <div id="collapse25" class="collapse" aria-labelledby="heading25" data-parent="#accordion">
      <div class="card-body">
        Indicates the method of execution—Manual, Automated, or Hybrid.
      </div>
    </div>
  </div>

  <div class="card">
    <div class="card-header" id="heading26">
      <h5 class="mb-0">
        <a class="btn btn-link collapsed" data-toggle="collapse" href="#collapse26" aria-expanded="false" aria-controls="collapse26">
          Can test cases be version controlled?
        </a>
      </h5>
    </div>
    <div id="collapse26" class="collapse" aria-labelledby="heading26" data-parent="#accordion">
      <div class="card-body">
        Currently, updates are logged via Audit Logs. A formal versioning system is in roadmap.
      </div>
    </div>
  </div>

  <div class="card">
    <div class="card-header" id="heading27">
      <h5 class="mb-0">
        <a class="btn btn-link collapsed" data-toggle="collapse" href="#collapse27" aria-expanded="false" aria-controls="collapse27">
          What is the upload format for bulk import?
        </a>
      </h5>
    </div>
    <div id="collapse27" class="collapse" aria-labelledby="heading27" data-parent="#accordion">
      <div class="card-body">
        The system accepts Excel templates with fields like Scenario ID, Description, Expected Result, etc.download the sample format and use that templete for uploading.
      </div>
    </div>
  </div>

  <div class="card">
    <div class="card-header" id="heading28">
      <h5 class="mb-0">
        <a class="btn btn-link collapsed" data-toggle="collapse" href="#collapse28" aria-expanded="false" aria-controls="collapse28">
          Can I preview steps before executing?
        </a>
      </h5>
    </div>
    <div id="collapse28" class="collapse" aria-labelledby="heading28" data-parent="#accordion">
      <div class="card-body">
        Yes. From the test suite, click on the test case to view all defined steps before starting execution.
      </div>
    </div>
  </div>

  <div class="card">
    <div class="card-header" id="heading29">
      <h5 class="mb-0">
        <a class="btn btn-link collapsed" data-toggle="collapse" href="#collapse29" aria-expanded="false" aria-controls="collapse29">
          Can one test case be part of multiple test suites?
        </a>
      </h5>
    </div>
    <div id="collapse29" class="collapse" aria-labelledby="heading29" data-parent="#accordion">
      <div class="card-body">
        Yes, a test case can be reused in multiple test suites across releases and plans.
      </div>
    </div>
  </div>

  <div class="card">
    <div class="card-header" id="heading30">
      <h5 class="mb-0">
        <a class="btn btn-link collapsed" data-toggle="collapse" href="#collapse30" aria-expanded="false" aria-controls="collapse30">
          How do I track execution status at the suite level?
        </a>
      </h5>
    </div>
    <div id="collapse30" class="collapse" aria-labelledby="heading30" data-parent="#accordion">
      <div class="card-body">
        Use the "Test Execution Report" button to view suite-wise results.
      </div>
    </div>
  </div>

  <div class="card">
    <div class="card-header" id="heading31">
      <h5 class="mb-0">
        <a class="btn btn-link collapsed" data-toggle="collapse" href="#collapse31" aria-expanded="false" aria-controls="collapse31">
          What if I want to run only failed test cases again?
        </a>
      </h5>
    </div>
    <div id="collapse31" class="collapse" aria-labelledby="heading31" data-parent="#accordion">
      <div class="card-body">
        Filter by result = Failed and execute those selectively or clone the suite for retest.
      </div>
    </div>
  </div>

  <div class="card">
    <div class="card-header" id="heading32">
      <h5 class="mb-0">
        <a class="btn btn-link collapsed" data-toggle="collapse" href="#collapse32" aria-expanded="false" aria-controls="collapse32">
          Can I assign test suites to different testers?
        </a>
      </h5>
    </div>
    <div id="collapse32" class="collapse" aria-labelledby="heading32" data-parent="#accordion">
      <div class="card-body">
        Yes, each suite can have a different assigned executor.
      </div>
    </div>
  </div>

  <div class="card">
    <div class="card-header" id="heading33">
      <h5 class="mb-0">
        <a class="btn btn-link collapsed" data-toggle="collapse" href="#collapse33" aria-expanded="false" aria-controls="collapse33">
          How does bulk result upload work?
        </a>
      </h5>
    </div>
    <div id="collapse33" class="collapse" aria-labelledby="heading33" data-parent="#accordion">
      <div class="card-body">
        Prepare an Excel with Test Case ID, Step, Result, Actual Result, and upload via the Bulk Upload option.
      </div>
    </div>
  </div>
<!-- New code end -->


        </div>
    </div>
    
    



    <?php include(STEP_dir.'js.php'); ?>

</body>

</html>
