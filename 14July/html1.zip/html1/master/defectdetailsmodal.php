<div class="modal fade" id="defectdetailsmodal" tabindex="-1" role="dialog" aria-labelledby="scrollmodalLabel" aria-hidden="true" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog modal-xl" role="document">
        <div class="modal-content">
            <div class="modal-header bg-step">
                <h5 class="modal-title"  id="defectnumtxt">Defect</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form id="defectdetailsform" method="post" class="form-horizontal">
                <div class="modal-body">
                    <div class="container" >

                        <div class="row form-group">
                            <p class="col-md-4" id="projecttxt"></p>
                            <p class="col-md-4" id="releasetxt"></p>
                            <p class="col-md-4" id="testcasetxt"></p>
                        </div>
                        <div class="row form-group">
                            <p class="col-md-4" id="moduletxt"></p>
                            <p class="col-md-4" id="submoduletxt"></p>
                            <p class="col-md-4" id="defecttypetxt"></p>
                        </div>
                        <div class="row form-group">
                            <p class="col-md-4" id="severitytxt"></p>
                            <p class="col-md-4" id="prioritytxt"></p>
                            <p class="col-md-4" id="defectstatustxt"></p>
                        </div>
                        <div class="row form-group">
                            <p class="col-md-6" id="shortdesctxt"></p>
                            <p class="col-md-6" id="longdesctxt"></p>
                        </div>
                        <div class="row form-group">
                            <p class="col-md-6" id="testdatetxt"></p>
                            <p class="col-md-6" id="steptxt"></p>
                        </div>
                        <div class="row form-group">
                            <p class="col-md-6" id="expectedtxt"></p>
                            <p class="col-md-6" id="actualtxt"></p>
                        </div>
                        <div class="row form-group">
                            <p class="col-md-12" id="assignmenttxt"></p>
                        </div>
                        <div class="row form-group">
                            <p class="col-md-6" id="createdattxt"></p>
                            <p class="col-md-6" id="updatedtxt"></p>
                        </div>
    
                <h6 id="defectattachmentsheader" class="hidden">Attachments</h6>
                <br/>
                <div class="row form-group" id="defectattachments"></div>
                <div class="row form-group ">
                    <div class="col-md-4" ></div>
                </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Ok</button>
                </div>
            </form>
        </div>
    </div>
</div>