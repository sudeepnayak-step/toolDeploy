<div class="modal fade" id="stepmodal" tabindex="-1" role="dialog" aria-labelledby="scrollmodalLabel" aria-hidden="true" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header bg-step">
                <h5 class="modal-title" id="scrollmodalLabel">Steps</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form id="stepform" method="post" class="form-horizontal">
                <div class="modal-body">
                    
                        <div class="row form-group">
                            <div class="col-4 " style="display: none;">
                                <div class="form-group">
                                    <label for="stepId" class=" form-control-label">Activity ID : </label>
                                    <input type="text" id="stepId" name="stepId" placeholder="Enter activity name" value="0" class="form-control">
                                </div>
                            </div>

                        </div>
                        <div class="row form-group">

                            <div class="col-6">
                                <div class="form-group">
                                    <label for="steps" class=" form-control-label">Steps : </label>
                                    <input type="hidden" id="steps_change" name="steps_change"  value="0" />
                                    <textarea  class="form-control" name="steps" id="steps" rows="2"></textarea>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-group">
                                    <label for="expectedresult" class=" form-control-label">Expected Result : </label>
                                    <input type="hidden" id="expectedresult_change" name="expectedresult_change"  value="0" />
                                    <textarea  class="form-control" name="expectedresult" id="expectedresult" rows="2"></textarea>
                                </div>
                            </div>
                        </div>
                        
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-gray" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-step">Save</button>
                </div>
            </form>
        </div>
    </div>
</div>

