<?php

define('STEP_root', 'https://www.vapt.testcalibre.com/');
define('STEP_dir', '/var/www/html/');
$STEP  = new ArrayObject();

$STEP->wwwroot = "https://www.vapt.testcalibre.com/";

define('GD','table compact nowrap border table-bordered table-hover');
header("X-Content-Type-Options: nosniff");
header("X-Frame-Options: DENY");
header("Strict-Transport-Security: max-age=31536000; includeSubDomains; preload");
header("Content-Security-Policy: default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline';");
//header("Content-Security-Policy: default-src 'self'; style-src 'self' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com;");
header("Referrer-Policy: no-referrer");
header("Permissions-Policy: camera=(), microphone=(), geolocation=()");
?>
