<?php
include('../config.php');
include('../chksession.php');
$activetab = "auditlogActive";

if (
    (isset($_SESSION["usertype"]) && ($_SESSION["usertype"] == "Admin" || $_SESSION["usertype"] == "StepAdmin")) ||
    (isset($_SESSION["ruleIds"]) && in_array("3", explode(",", $_SESSION["ruleIds"])))
) {
    //  Allowed - do nothing or continue
} else {
    //  Not Allowed - redirect to unauthorized page
    header("Location: " . STEP_root . "unauthorized.php");
    exit();
}
?>
<!doctype html>
<html class="no-js" lang="en">

<head>
    <?php include(STEP_dir.'headmetatag.php'); ?>
    <?php include(STEP_dir.'css.php'); ?>
</head>

<body>

    <?php include(STEP_dir.'leftpanel.php'); ?>

    <div id="right-panel" class="right-panel">
        <?php include(STEP_dir.'header.php'); ?>

        <div class="breadcrumbs">
            <div class="col-sm-8">
                <div class="page-header float-left">
                    <div class="page-title">
                        <ol class="breadcrumb text-left">
                            <li><a href="<?php echo STEP_root; ?>index.php">Dashboard</a></li>
                            <!--<li>Master</li>-->
                            <li class="active">Audit Logs</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <div class="container">
       
            <table id="auditTbl" class="table compact table-bordered table-hover " style="width:100%">
                <thead class="bg-step text-white">
                    <tr>
                    <th>Sr. No</th>
                    <th>Description</th>
                    <th>Module</th>
                    <th>ID</th>
                    <th>Changed By</th> 
                    <th>Changed At</th> 
                    </tr> 
                </thead>
            </table>
        </div>
    </div>


    <?php include(STEP_dir.'js.php'); ?>
    <script src="<?php echo STEP_root; ?>assets/js/init-scripts/basicmaster/auditlogs-init.js"></script>

    

</body>

</html>
