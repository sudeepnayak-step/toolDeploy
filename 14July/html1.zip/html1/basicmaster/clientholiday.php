<?php
include('../config.php');
include('../chksession.php');
$activetab = "holidayActive";

if (
    (isset($_SESSION["usertype"]) && ($_SESSION["usertype"] == "Admin" || $_SESSION["usertype"] == "StepAdmin")) ||
    (isset($_SESSION["ruleIds"]) && in_array("3", explode(",", $_SESSION["ruleIds"])))
) {
    //  Allowed - do nothing or continue
} else {
    //  Not Allowed - redirect to unauthorized page
    header("Location: " . STEP_root . "unauthorized.php");
    exit();
}
?>
<!doctype html>
<html class="no-js" lang="en">

<head>
    <?php include(STEP_dir.'headmetatag.php'); ?>
    <?php include(STEP_dir.'css.php'); ?>
</head>

<body>

    <?php include(STEP_dir.'leftpanel.php'); ?>

    <div id="right-panel" class="right-panel">
        <?php include(STEP_dir.'header.php'); ?>

        <div class="breadcrumbs">
            <div class="col-sm-8">
                <div class="page-header float-left">
                    <div class="page-title">
                        <ol class="breadcrumb text-left">
                            <li><a href="<?php echo STEP_root; ?>index.php">Dashboard</a></li>
                            <li class="text-muted">Master</li>
                            <li class="active">Business Holidays</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <div class="container">
            <div class="row">   
                <div class="col-md-10"></div>
                <div class="col-md-2 text-right">
                    <button class="btn btn-step dropdown-toggle" type="button" id="dropdownActionButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    Bulk Action
                    </button>
                    <div class="dropdown-menu" aria-labelledby="dropdownActionButton">
                    <a class="dropdown-item" href="javascript:void(0)" data-toggle="modal" data-target="#uploadmodal"  data-type="Upload">Upload Holidays</a>
                    <a class="dropdown-item" href="<?php echo STEP_root; ?>api/DownloadSample.php?type=Holidays"  target="_blank" data-type="Download">Download Sample Format</a>
                    </div>
                </div>
            </div>
            <div class="col-md-12" id="errmsg">
            </div>
            <div class="row">   

                <div class="col-md-12 text-right">&nbsp;</div>
            </div>

            <table id="clientTbl" class="table compact table-bordered table-hover " style="width:100%">
                <thead class="bg-step text-white">
                    <tr>
                    <th class="notexport">ID</th>
                    <th>Business Name</th>
                    <th class="notexport">Active Status</th> 
                    <th class="notexport">Holidays</th> 
                    </tr> 
                </thead>
                
            </table>
        </div><!-- .content -->


    </div><!-- /#right-panel -->
    <div class="modal fade" id="uploadmodal" tabindex="-1" role="dialog" aria-labelledby="scrollmodalLabel" aria-hidden="true" data-backdrop="static" data-keyboard="false">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-step">
                    <h5 class="modal-title" id="scrollmodalLabel">Upload Holidays</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form id="uploadform" method="post" action="/" class="form-horizontal"  enctype="multipart/form-data">
                    <div class="modal-body">
                        
                        
                            <div class="row form-group">
                                <div class="col-sm-6 ">
                                    <div class="form-group required">
                                        <label for="file" class=" form-control-label">Upload File</label>
                                        <input type="file" class="form-control" id="file" name="file" style="width:100%" required>
                                    </div>
                                    </div>
                            </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-step">Upload</button>
                    </div>
                </form>
            </div>
        </div>
    </div>


    <?php include(STEP_dir.'js.php'); ?>
    <script src="<?php echo STEP_root; ?>assets/js/init-scripts/basicmaster/holidayclient-init.js"></script>

    

</body>

</html>
