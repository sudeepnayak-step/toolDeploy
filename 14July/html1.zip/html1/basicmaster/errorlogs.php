<?php
include('../config.php');
include('../chksession.php');
$activetab = "errorlogActive";
?>
<!doctype html>
<html class="no-js" lang="en">

<head>
    <?php include(STEP_dir.'headmetatag.php'); ?>
    <?php include(STEP_dir.'css.php'); ?>
</head>

<body>

    <?php include(STEP_dir.'leftpanel.php'); ?>


    <div id="right-panel" class="right-panel">
        <?php include(STEP_dir.'header.php'); ?>

        <div class="breadcrumbs">
            <div class="col-sm-8">
                <div class="page-header float-left">
                    <div class="page-title">
                        <ol class="breadcrumb text-left">
                            <li><a href="<?php echo STEP_root; ?>index.php">Dashboard</a></li>
                            <li class="active">Error Logs</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <div class="container">
       
            <table id="errorlogTbl" class="table compact table-bordered table-hover " style="width:100%">
                <thead class="bg-step text-white">
                    <tr>
                    <th>Sr. No</th>
                    <th>Error No.</th>
                    <th>Description</th>
                    <th>Error File</th>
                    <th>Line No.</th> 
                    <th>Error Logged At</th> 
                    </tr> 
                </thead>
            </table>
        </div>
    </div>
    <?php include(STEP_dir.'js.php'); ?>
    <script src="<?php echo STEP_root; ?>assets/js/init-scripts/basicmaster/errorlog-init.js"></script>

    

</body>

</html>
