<?php
include('../config.php');
include('../chksession.php');
$activetab = "ragActive";

if (
    (isset($_SESSION["usertype"]) && ($_SESSION["usertype"] == "Admin" || $_SESSION["usertype"] == "StepAdmin")) ||
    (isset($_SESSION["ruleIds"]) && in_array("3", explode(",", $_SESSION["ruleIds"])))
) {
    //  Allowed - do nothing or continue
} else {
    //  Not Allowed - redirect to unauthorized page
    header("Location: " . STEP_root . "unauthorized.php");
    exit();
}
?>
<!doctype html>
<html class="no-js" lang="en">

<head>
    <?php include(STEP_dir.'headmetatag.php'); ?>
    <?php include(STEP_dir.'css.php'); ?>
</head>

<body>

    <?php include(STEP_dir.'leftpanel.php'); ?>

    <div id="right-panel" class="right-panel">
        <?php include(STEP_dir.'header.php'); ?>

        <div class="breadcrumbs">
            <div class="col-sm-8">
                <div class="page-header float-left">
                    <div class="page-title">
                        <ol class="breadcrumb text-left">
                            <li><a href="<?php echo STEP_root; ?>index.php">Dashboard</a></li>
                            <li class="text-muted">Master</li>
                            <li class="active">RAG Threshold Setting</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <div class="content mt-3">
            <div class="animated fadeIn">

                <div class="row">

                    <div class="col-md-12">
                        <form id="thresholdform" method="post" class="form-horizontal">
                            <div class="modal-body">
                                
                                    <div class="row form-group">

                                        <div class="col-4 " style="display: none;">
                                            <div class="form-group">
                                                <label for="rId" class=" form-control-label"> ID : </label>
                                                <input type="text" id="rId" name="rId" placeholder="Enter activity name" value="0" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="form-group required">
                                                <label for="amber" class=" form-control-label">Amber %: </label>
                                                <input type="number" id="amber" name="amber" placeholder="Enter Amber %" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="form-group required">
                                                <label for="red" class=" form-control-label">Red % : </label>
                                                <input type="number" id="red" name="red" placeholder="Enter Red %" class="form-control">
                                            </div>
                                        </div>
                                    </div>
                            </div>
                            <div class="modal-footer center" >
                                <button type="submit" class="btn btn-step">Save</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>


    </div>


    <?php include(STEP_dir.'js.php'); ?>
    <script src="<?php echo STEP_root; ?>assets/js/init-scripts/basicmaster/ragthreshold-init.js"></script>

    

</body>

</html>
