<?php
include('../config.php');
include('../chksession.php');
$activetab = "projemailsettingActive";

if (
    (isset($_SESSION["usertype"]) && ($_SESSION["usertype"] == "Admin" || $_SESSION["usertype"] == "StepAdmin")) ||
    (isset($_SESSION["ruleIds"]) && in_array("3", explode(",", $_SESSION["ruleIds"])))
) {
    //  Allowed - do nothing or continue
} else {
    //  Not Allowed - redirect to unauthorized page
    header("Location: " . STEP_root . "unauthorized.php");
    exit();
}
?>
<!doctype html>
<html class="no-js" lang="en">

<head>
    <?php include(STEP_dir.'headmetatag.php'); ?>
    <?php include(STEP_dir.'css.php'); ?>
</head>

<body>

    <?php include(STEP_dir.'leftpanel.php'); ?>

    <div id="right-panel" class="right-panel">
        <?php include(STEP_dir.'header.php'); ?>

        <div class="breadcrumbs">
            <div class="col-sm-8">
                <div class="page-header float-left">
                    <div class="page-title">
                        <ol class="breadcrumb text-left">
                            <li><a href="<?php echo STEP_root; ?>index.php">Dashboard</a></li>
                            <li class="active">Project Email Setting</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <div class="container">
            <div class="row">   

                <div class="col-md-12 text-right">
                    <button type="button" class="btn btn-step m-3" id="addEmailsetting" data-toggle="modal" data-target="#emailsettingmodal">ADD</button>
                </div>
            </div>
            <table id="emailsettingTbl" class="table compact table-bordered table-hover " style="width:100%">
                <thead class="bg-step text-white">
                    <tr>
                    <th class="notexport">
                        <div class="custom-control custom-checkbox">
                            <input type="checkbox" class="custom-control-input" id="select_all">
                            <label class="custom-control-label" for="select_all">&nbsp;</label>
                        </div>
                    </th>
                    <th>Project</th>
                    <th>Subject</th>
                    <th>Sender</th>
                    <th>Receiver</th> 
                    <th>CC</th> 
                    <th>BCC</th> 
                    <th class="notexport">Action</th> 
                    </tr> 
                </thead>
            </table>
        </div>

    </div>
    <div class="modal fade" id="emailsettingmodal" tabindex="-1" role="dialog" aria-labelledby="scrollmodalLabel" aria-hidden="true" data-backdrop="static" data-keyboard="false">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-step">
                    <h5 class="modal-title" id="scrollmodalLabel">Project Email Setting</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form id="emailsettingform" method="post" class="form-horizontal">
                    <div class="modal-body">
                        <div class="row ">
                
                                <div class="col-4">
                                    <div class="form-group required">
                                        <label for="projectId" class=" form-control-label">Project : </label>

                                        <select class="selectpicker form-control" id="projectId" name="projectId"  data-live-search="true" title="Select project" data-hide-disabled="true" data-exist=""></select>
                                    </div>
                                </div>
                        </div>
                            <div class="row form-group">

                                <div class="col-4 " style="display: none;">
                                    <div class="form-group">
                                        <label for="emailsettingId" class=" form-control-label"> ID : </label>
                                        <input type="text" id="emailsettingId" name="emailsettingId" placeholder="Enter activity name" value="0" class="form-control">
                                    </div>
                                </div>
                                <div class="col-4">
                                    <div class="form-group required">
                                        <label for="hostname" class=" form-control-label">Hostname : </label>
                                        <input type="text" id="hostname" name="hostname" placeholder="Enter hostname" class="form-control">
                                    </div>
                                </div>
                                <div class="col-4">
                                    <div class="form-group required">
                                        <label for="portno" class=" form-control-label">Port No. : </label>
                                        <input type="number" id="portno" name="portno" placeholder="Enter port no." class="form-control">
                                    </div>
                                </div>
                                <div class="col-4">
                                    <div class="form-group">
                                        <label for="fromname" class=" form-control-label">Sender Name : </label>
                                        <input type="text" id="fromname" name="fromname" placeholder="Enter from name" class="form-control">
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row form-group">

                                <div class="col-4">
                                    <div class="form-group required">
                                        
                                        <label for="receiver" class=" form-control-label">Sent To : </label>
                                        <input type="hidden" id="receiver_change" name="receiver_change"  value="0" />
                                        <textarea  class="form-control" name="receiver" id="receiver" rows="2"></textarea>
                                    </div>
                                </div>

                                <div class="col-4">
                                    <div class="form-group">
                                        <label for="cc" class=" form-control-label">CC : </label>
                                        <input type="hidden" id="cc_change" name="cc_change"  value="0" />
                                        <textarea  class="form-control" name="cc" id="cc" rows="2"></textarea>
                                    </div>
                                </div>
                                <div class="col-4">
                                    <div class="form-group">
                                        <label for="bcc" class=" form-control-label">BCC : </label>
                                        <input type="hidden" id="bcc_change" name="bcc_change"  value="0" />
                                        <textarea  class="form-control" name="bcc" id="bcc" rows="2"></textarea>
                                    </div>
                                </div>
                            </div>
                            <div class="row form-group">
                                <div class="col-4">
                                    <div class="form-group required">
                                        <label for="subject" class=" form-control-label">Subject : </label>
                                        <input type="text" id="subject" name="subject" placeholder="Enter subject" class="form-control">
                                    </div>
                                </div>
                                <div class="col-4">
                                    <div class="form-group required">
                                        <label for="username" class=" form-control-label">Email Id : </label>
                                        <input type="email" id="username" name="username" placeholder="Enter email id" class="form-control">
                                    </div>
                                </div>
                                <div class="col-4">
                                    <div class="form-group required">
                                        <label for="password" class=" form-control-label">Password : </label>
                                        <input type="password" id="password" name="password" placeholder="Enter password" class="form-control">
                                    </div>
                                </div>
                            </div>

                            <div class="row form-group">
                                <div class="col-4">
                                    <div class="form-group required">
                                        <label for="scheduletime" class=" form-control-label">Schedule Time : </label>
                                        <input type="text" id="scheduletime" name="scheduletime" placeholder="Enter schedule time" class="form-control">
                                    </div>
                                </div>
                            </div>

                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-step">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>


    <?php include(STEP_dir.'js.php'); ?>
    <script src="<?php echo STEP_root; ?>assets/js/init-scripts/basicmaster/projemailsetting-init.js"></script>

    

</body>

</html>
