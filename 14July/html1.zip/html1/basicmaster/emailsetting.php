<?php
include('../config.php');
include('../chksession.php');
$activetab = "emailsettingActive";

if (
    (isset($_SESSION["usertype"]) && ($_SESSION["usertype"] == "Admin" || $_SESSION["usertype"] == "StepAdmin")) ||
    (isset($_SESSION["ruleIds"]) && in_array("3", explode(",", $_SESSION["ruleIds"])))
) {
    //  Allowed - do nothing or continue
} else {
    //  Not Allowed - redirect to unauthorized page
    header("Location: " . STEP_root . "unauthorized.php");
    exit();
}
?>
<!doctype html>
<html class="no-js" lang="en">
<head>
    <?php include(STEP_dir.'headmetatag.php'); ?>
    <?php include(STEP_dir.'css.php'); ?>
</head>

<body>

    <?php include(STEP_dir.'leftpanel.php'); ?>

    <div id="right-panel" class="right-panel">
        <?php include(STEP_dir.'header.php'); ?>

        <div class="breadcrumbs">
            
            <div class="col-sm-8">
                <div class="page-header float-left">
                    <div class="page-title">
                        <ol class="breadcrumb text-left">
                            <li><a href="<?php echo STEP_root; ?>index.php">Dashboard</a></li>
                            <li class="active">General Email Setting</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <div class="content mt-3">
            <div class="animated fadeIn">

                <div class="row">

                    <div class="col-md-12">
                        <form id="emailsettingform" method="post" class="form-horizontal"  autocomplete="off">
                            <div class="modal-body">
                                
                                    <div class="row form-group">

                                        <div class="col-4 " style="display: none;">
                                            <div class="form-group">
                                                <label for="emailsettingId" class=" form-control-label"> ID : </label>
                                                <input type="text" id="emailsettingId" name="emailsettingId" placeholder="Enter activity name" value="0" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="form-group required">
                                                <label for="hostname" class=" form-control-label">Hostname : </label>
                                                <input type="text" id="hostname" name="hostname" placeholder="Enter hostname" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="form-group required">
                                                <label for="portno" class=" form-control-label">Port No. : </label>
                                                <input type="number" id="portno" name="portno" placeholder="Enter port no." class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="form-group required">
                                                <label for="fromname" class=" form-control-label">Sender Name : </label>
                                                <input type="text" id="fromname" name="fromname" placeholder="Enter from name" class="form-control">
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="row form-group">
                                        <div class="col-4">
                                            <div class="form-group required">
                                                <label for="username" class=" form-control-label">Email Id : </label>
                                                <input type="email" id="username" name="username" placeholder="Enter email id" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="form-group">
                                                <label for="password" class=" form-control-label">Password : </label>
                                                <input type="password" id="password" name="password" placeholder="Enter password" class="form-control">
                                            </div>
                                        </div>
                                    </div>
                            </div>
                            <div class="modal-footer center" >
                                <button type="submit" class="btn btn-step">Save</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

   




    <?php include(STEP_dir.'js.php'); ?>
    <script src="<?php echo STEP_root; ?>assets/js/init-scripts/basicmaster/emailsetting-init.js"></script>

    

</body>

</html>
