<?php
include('../config.php');
include('../chksession.php');
$activetab = "masteractivityActive";

if (
    (isset($_SESSION["usertype"]) && ($_SESSION["usertype"] == "Admin" || $_SESSION["usertype"] == "StepAdmin")) ||
    (isset($_SESSION["ruleIds"]) && in_array("3", explode(",", $_SESSION["ruleIds"])))
) {
    //  Allowed - do nothing or continue
} else {
    //  Not Allowed - redirect to unauthorized page
    header("Location: " . STEP_root . "unauthorized.php");
    exit();
}
?>
<!doctype html>

<html class="no-js" lang="en">

<head>
    <?php include(STEP_dir.'headmetatag.php'); ?>
    <?php include(STEP_dir.'css.php'); ?>
</head>

<body>

    <?php include(STEP_dir.'leftpanel.php'); ?>


    <div id="right-panel" class="right-panel">
        <?php include(STEP_dir.'header.php'); ?>

        <div class="breadcrumbs">
            <div class="col-sm-8">
                <div class="page-header float-left">
                    <div class="page-title">
                        <ol class="breadcrumb text-left">
                            <li><a href="<?php echo STEP_root; ?>index.php">Dashboard</a></li>
                            <li class="text-muted">Master</li>
                            <li class="active">Activity</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <div class="container">
            <div class="row">   

                <div class="col-md-12 text-right">
                    <button type="button" class="btn btn-step m-3" id="addActivity" data-toggle="modal" data-target="#activitymodal">ADD</button>
                </div>
            </div>
            <table id="activityTbl" class="table compact table-bordered table-hover " style="width:100%">
                <thead class="bg-step text-white">
                    <tr>
                    <th class="notexport">
                        <div class="custom-control custom-checkbox">
                            <input type="checkbox" class="custom-control-input" id="select_all">
                            <label class="custom-control-label" for="select_all">&nbsp;</label>
                        </div>
                    </th>
                    <th>Activity Name</th>
                    <th>Activity Code</th>
                    <th>Type</th> 
                    <th>Active Status</th> 
                    <th class="notexport">Action</th> 
                    </tr> 
                </thead>
            </table>
        </div>
    </div>
    
    <div class="modal fade" id="activitymodal" tabindex="-1" role="dialog" aria-labelledby="scrollmodalLabel" aria-hidden="true" data-backdrop="static" data-keyboard="false">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header bg-step">
                    <h5 class="modal-title" id="scrollmodalLabel">Activity Master</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form id="activityform" method="post" class="form-horizontal">
                    <div class="modal-body">
                        
                            <div class="row form-group">

                                <div class="col-4 " style="display: none;">
                                    <div class="form-group">
                                        <label for="activityId" class=" form-control-label">Activity ID : </label>
                                        <input type="text" id="activityId" name="activityId" placeholder="Enter Activity Name" value="0" class="form-control">
                                    </div>
                                </div>
                                <div class="col-4">
                                    <div class="form-group required">
                                        <label for="activityname" class=" form-control-label">Activity Name : </label>
                                        <input type="text" id="activityname" name="activityname" placeholder="Enter Activity Name"  data-id="0" class="form-control">
                                    </div>
                                </div>
                                <div class="col-4">
                                    <div class="form-group required">
                                        <label for="activitycode" class=" form-control-label">Activity Code : </label>
                                        <input type="text" id="activitycode" name="activitycode" placeholder="Enter Activity Code"  data-id="0"  class="form-control">
                                    </div>
                                </div>
                                <div class="col-4">
                                    <div class="form-group required">
                                        <label for="activitytype" class=" form-control-label">Type : </label>
                                            <select class="form-control" id="activitytype" name="activitytype" title="Select Type">
                                            <option value="" >Select Type</option>
                                            <option value="Execution">Execution</option>
                                            <option value="Non Execution">Non Execution</option>
                                            </select>
                                    </div>
                                </div>
                            </div>
                            
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                        <button type="submit" class="btn btn-step">Save</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php include(STEP_dir.'js.php'); ?>
    <script src="<?php echo STEP_root; ?>assets/js/init-scripts/basicmaster/activity-init.js"></script>

</body>

</html>
