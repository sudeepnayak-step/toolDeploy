<?php
include('../config.php');
include('../chksession.php');
$activetab = "chartActive";

if (
    (isset($_SESSION["usertype"]) && ($_SESSION["usertype"] == "Admin" || $_SESSION["usertype"] == "StepAdmin")) ||
    (isset($_SESSION["ruleIds"]) && in_array("3", explode(",", $_SESSION["ruleIds"])))
) {
    //  Allowed - do nothing or continue
} else {
    //  Not Allowed - redirect to unauthorized page
    header("Location: " . STEP_root . "unauthorized.php");
    exit();
}
?>
<!doctype html>
<html class="no-js" lang="en">

<head>
    <?php include(STEP_dir.'headmetatag.php'); ?>
    <?php include(STEP_dir.'css.php'); ?>
</head>

<body>

    <?php include(STEP_dir.'leftpanel.php'); ?>

    <div id="right-panel" class="right-panel">
        <?php include(STEP_dir.'header.php'); ?>

        <div class="breadcrumbs">
            <div class="col-sm-12">
                <div class="page-header float-left">
                    <div class="page-title">
                        <ol class="breadcrumb text-left">
                            <li><a href="<?php echo STEP_root; ?>index.php">Dashboard</a></li>
                            <!--<li>Master</li>-->
                            <li class="active">Chart Setting</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <div class="container">
       
            <div class="row">   

                <div class="col-md-12 text-right">
                    <button type="button" class="btn btn-step m-3" id="addChart" data-toggle="modal" data-target="#chartmodal">ADD</button>
                </div>
            </div>
            <table id="chartTbl" class="table compact table-bordered table-hover " style="width:100%">
                <thead class="bg-step text-white">
                    <tr>
                    <th class="notexport">
                        <div class="custom-control custom-checkbox">
                            <input type="checkbox" class="custom-control-input" id="select_all">
                            <label class="custom-control-label" for="select_all">&nbsp;</label>
                        </div>
                    </th>
                    <th>Title</th>
                    <th>Subtitle</th>
                    <th>Type</th> 
                    <th>Module</th> 
                    <th>X-axis</th> 
                    <th>Y-axis</th> 
                    <th>Percentage</th> 
                    <th>Active Status</th> 
                    <th class="notexport">Action</th> 
                    </tr> 
                </thead>
            </table>
        </div>
    </div>
<div class="modal fade" id="chartmodal" tabindex="-1" role="dialog" aria-labelledby="scrollmodalLabel" aria-hidden="true" data-backdrop="static" data-keyboard="false">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header bg-step">
                <h5 class="modal-title" id="scrollmodalLabel">Chart Setting</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form id="chartform" method="post" class="form-horizontal">
                <div class="modal-body">
                    
                        <div class="row form-group">

                            <div class="col-4 " style="display: none;">
                                <div class="form-group">
                                    <label for="chartId" class=" form-control-label">Activity ID : </label>
                                    <input type="text" id="chartId" name="chartId" placeholder="Enter Activity Name" value="0" class="form-control">
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="form-group required">
                                    <label for="charttitle" class=" form-control-label">Title : </label>
                                    <input type="text" id="charttitle" name="charttitle" placeholder="Enter Title" class="form-control">
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="form-group">
                                    <label for="chartsubtitle" class=" form-control-label">Sub Title : </label>
                                    <input type="text" id="chartsubtitle" name="chartsubtitle" placeholder="Enter Subtitle" class="form-control">
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="form-group required">
                                    <label for="charttype" class=" form-control-label">Type : </label>
                                        <select class="form-control" id="charttype" name="charttype" title="Select Type">
                                        <option value="" >Select Type</option>
                                        <option value="Column">Column</option>
                                        <option value="Line">Line</option>
                                        <option value="Pie">Pie</option>
                                        </select>
                                </div>
                            </div>
                        </div>

                        <div class="section row"  >
                            <div class="col-4">
                                <div class="form-group required">
                                    <label for="activestatus" class=" form-control-label">Active Status : </label>
                                        <select class="form-control" id="activestatus" name="activestatus" required="">
                                        <option value="" >Select Status</option>
                                        <option value="Active" selected="">Active</option>
                                        <option value="Inactive">Inactive</option>
                                        </select>
                                </div>
                            </div>
                            <div class="col-4">
                                <div class="form-group required ">
                                        <label for="module"  class=" form-control-label">Module</label>
                                    <select id='module' class="form-control " name='module' required >
                                    <option value=''>Select Module</option>
                                    <option value='Project' >Project</option>
                                    <option value='Defect' >Defect</option>
                                    <option value='Test Execution' >Test Execution</option>
                                </select>
                                </div>
                            </div>
                            <div class="col-4 hidden required" id="xaxisdiv">
                                <div class="form-group">
                                    <label for="xAxis" class=" form-control-label">X-axis : </label>

                                    <select class="selectpicker form-control" id="xAxis" name="xAxis"  data-live-search="true" title="Select xAxis" data-hide-disabled="true" ></select>
                                </div>
                            </div>
                            <div class="col-4 hidden required" id="yaxisdiv">
                                <div class="form-group">
                                    <label for="yAxis" class=" form-control-label">Y-axis : </label>

                                    <select class="selectpicker form-control" id="yAxis" name="yAxis"  data-live-search="true" title="Select yAxis" data-hide-disabled="true" ></select>
                                </div>
                            </div>
                            <div class="col-4 hidden " id="caltypediv">

                                <div class="form-group required ">
                                    <label for="caltype"  class=" form-control-label" >Type</label>
                                    <select id='caltype' class="form-control "  name='caltype'  >
                                        <option value=''>Select Type</option>
                                        <option value='Count' >Count</option>
                                        <option value='Percentage' >Percentage</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-step">Save</button>
                </div>
            </form>
        </div>
    </div>
</div>




<?php include(STEP_dir.'js.php'); ?>
<script src="<?php echo STEP_root; ?>assets/js/init-scripts/basicmaster/chart-init.js"></script>

    

</body>

</html>
