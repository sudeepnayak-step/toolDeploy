<?php
include('../config.php');
include('../chksession.php');
$activetab = "qualityActive";

if (
    (isset($_SESSION["usertype"]) && ($_SESSION["usertype"] == "Admin" || $_SESSION["usertype"] == "StepAdmin")) ||
    (isset($_SESSION["ruleIds"]) && in_array("3", explode(",", $_SESSION["ruleIds"])))
) {
    //  Allowed - do nothing or continue
} else {
    //  Not Allowed - redirect to unauthorized page
    header("Location: " . STEP_root . "unauthorized.php");
    exit();
}
?>
<!doctype html>
<html class="no-js" lang="en">

<head>
    <?php include(STEP_dir.'headmetatag.php'); ?>
    <?php include(STEP_dir.'css.php'); ?>
</head>

<body>

    <?php include(STEP_dir.'leftpanel.php'); ?>

    <div id="right-panel" class="right-panel">
        <?php include(STEP_dir.'header.php'); ?>

        <div class="breadcrumbs">
            <div class="col-sm-8">
                <div class="page-header float-left">
                    <div class="page-title">
                        <ol class="breadcrumb text-left">
                            <li><a href="<?php echo STEP_root; ?>index.php">Dashboard</a></li>
                            <li class="text-muted">Master</li>
                            <li class="active">Quality Threshold Setting</li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>

        <div class="content mt-3">
            <div class="animated fadeIn">

                <div class="row">

                    <div class="col-md-12">
                        <form id="thresholdform" method="post" class="form-horizontal">
                            <div class="modal-body">
                                
                                    <div class="row form-group">

                                        <div class="col-4 " style="display: none;">
                                            <div class="form-group">
                                                <label for="qId" class=" form-control-label"> ID : </label>
                                                <input type="text" id="qId" name="qId" placeholder="Enter activity name" value="0" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="form-group required">
                                                <label for="excellent" class=" form-control-label">Excellent %: </label>
                                                <input type="number" id="excellent" name="excellent" placeholder="Enter Excellent %" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="form-group required">
                                                <label for="good" class=" form-control-label">Good % : </label>
                                                <input type="number" id="good" name="good" placeholder="Enter Good %" class="form-control">
                                            </div>
                                        </div>
                                        <div class="col-4">
                                            <div class="form-group required">
                                                <label for="normal" class=" form-control-label">Normal : </label>
                                                <input type="number" id="normal" name="normal" placeholder="Enter %" class="form-control">
                                            </div>
                                        </div>
                                    </div>
                            </div>
                            <div class="modal-footer center" >
                                <button type="submit" class="btn btn-step">Save</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>


    </div>

    <?php include(STEP_dir.'js.php'); ?>
    <script src="<?php echo STEP_root; ?>assets/js/init-scripts/basicmaster/qualitystatus-init.js"></script>

    

</body>

</html>
