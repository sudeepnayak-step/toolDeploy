
    <link rel="apple-touch-icon" href="apple-icon.png">
    <link rel="shortcut icon" href="favicon.ico">

    <link rel="stylesheet" href="<?php echo $STEP->wwwroot; ?>vendors/bootstrap/dist/css/bootstrap.min.css">
<!--    <link rel="stylesheet" href="<?php echo $STEP->wwwroot; ?>vendors/font-awesome/css/font-awesome.min.css">-->
    <link rel="stylesheet" href="<?php echo $STEP->wwwroot; ?>vendors/fontawesome5/css/all.min.css">
    <link rel="stylesheet" href="<?php echo $STEP->wwwroot; ?>vendors/themify-icons/css/themify-icons.css">
    <link rel="stylesheet" href="<?php echo $STEP->wwwroot; ?>vendors/flag-icon-css/css/flag-icon.min.css">
    <link rel="stylesheet" href="<?php echo $STEP->wwwroot; ?>vendors/selectFX/css/cs-skin-elastic.css">
    <link rel="stylesheet" href="<?php echo $STEP->wwwroot; ?>vendors/jqvmap/dist/jqvmap.min.css">


    <link rel="stylesheet" href="<?php echo $STEP->wwwroot; ?>vendors/datatables.net-bs4/css/dataTables.bootstrap4.min.css">
    <link rel="stylesheet" href="<?php echo $STEP->wwwroot; ?>vendors/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css">
    <link rel="stylesheet" href="<?php echo $STEP->wwwroot; ?>assets/css/bootstrap-datepicker3.css"/>
    <link href="<?php echo $STEP->wwwroot; ?>assets/css/bootstrap-select.min.css" rel="stylesheet" />

    <!-- <link rel="stylesheet" href="<?php echo $STEP->wwwroot; ?>assets/css/responsive.dataTables.min.css"> -->
    <link rel="stylesheet" href="<?php echo $STEP->wwwroot; ?>assets/css/style.css">
    <link rel="stylesheet" href="<?php echo $STEP->wwwroot; ?>assets/css/mystyle.css">
    <link rel="stylesheet" href="<?php echo $STEP->wwwroot; ?>assets/css/editor.css">
    <!-- <link rel="stylesheet" href="<?php echo $STEP->wwwroot; ?>assets/summernote/summernote.css"> -->

<!-- add summernote -->
<!-- <link href="//cdnjs.cloudflare.com/ajax/libs/summernote/0.8.12/summernote.css" rel="stylesheet"> -->
<!--    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>-->

    <!-- <link href="https://cdn.jsdelivr.net/npm/select2@4.0.12/dist/css/select2.min.css" rel="stylesheet" /> -->
    <link href="<?php echo $STEP->wwwroot; ?>assets/css/select2.min.css" rel="stylesheet" />
    <link href="<?php echo $STEP->wwwroot; ?>assets/css/jquery-confirm.min.css" rel="stylesheet" />

    <!-- <link href="//cdnjs.cloudflare.com/ajax/libs/x-editable/1.5.0/bootstrap3-editable/css/bootstrap-editable.css" rel="stylesheet"/> -->

    <link rel="stylesheet" href="<?php echo $STEP->wwwroot; ?>assets/bootstrap-datetimepicker-master/css/bootstrap-datetimepicker.min.css"/>
<!-- <link rel="stylesheet" href="<?php echo $STEP->wwwroot; ?>assets/css/bootstrap-icons.css"/>-->

<!--<link rel="stylesheet" href="<?php echo $STEP->wwwroot; ?>assets/css/googlefont.css">-->

<style>
.Editor-editor ol,.Editor-editor ul {
    padding-left: 0.8em;
}

.ms-login-btn {
/*  display: inline-flex; */
  align-items: center;
 margin-top : 10%;
border:none;
  padding: 10px 16px;
  background-color: #0067DF; /* Dark button */
  color: white;
  text-decoration: none;
  border-radius: 6px;
  font-family: Arial, sans-serif;
  font-weight: 500;
  font-size: 14px;
  transition: background-color 0.2s ease;
}

.ms-login-btn:hover {
  background-color: #1a6199 ;
}

.ms-login-btn:active {
  background-color: #000;
}

.ms-logo {
  height: 18px;
  width: auto;
  margin-right: 8px;
}
</style>
