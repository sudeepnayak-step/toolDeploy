<?php
include('config.php');
include('chkloginsession.php');
?>
<!doctype html>
<html class="no-js" lang="en">
<head>
   
    <?php include(STEP_dir.'headmetatag.php'); ?>
    <?php include(STEP_dir.'css.php'); ?>
</head>

<body style="background: url('images/loginbg.jpg') no-repeat center center fixed; 
  -webkit-background-size: cover;
  -moz-background-size: cover;
  -o-background-size: cover;
  background-size: cover;">


<!--<img  src="<?php echo STEP_root; ?>images/tclogo-white.png" alt="" width="10%"  style="margin-left:5%; margin-top:2%;"  />-->
    <div class="sufee-login d-flex align-content-center flex-wrap" >
        <div class="container111" style="margin: 5%;">
            <div class="login-content" >
                <div class="login-form" style="width:400px;">

  <div class="container" style="display: flex; align-items: center; justify-content: center; margin-bottom:50px; margin-top:-20px">
    <img src="<?php echo STEP_root; ?>images/tc-logo.png" alt="Logo 1" class="logo" style="height:40px"/>
    <div class="vertical-line" style=" width: 2px; height: 65px; border: solid #d2d2d2 0.5px;display:none;"></div>
    <img src="<?php echo STEP_root; ?>images/logo.jpg" alt="Logo 2" class="logo" style="height:60px"/>
  </div>

<!-- Login with Admin Button -->
<div class="register-link text-center" style="margin-top:10%;">
<button type="button" class="btn btn-primary" onclick="showLoginForm()">Login with Admin</button>
</div>
<div class="register-link text-center" style="margin-top:10%;" >
<button type="button" class="ms-login-btn btn btn-primary" onclick="loginWithMicrosoft()">
<img src="images/microsoft.jpg" alt="Microsoft Logo" class="ms-logo"> Login with SSO
</button>
</div>
 
<!-- JavaScript to Show Form -->
<script>
    function showLoginForm() {
        //document.getElementById('loginform').style.display = 'block';
        $('#loginform').toggle();
    }
</script>


                    <form id="loginform" method="post" style="display: none;margin-top: 27px;">
                        <div class="form-group">
                            <label>Username</label>
                            <input type="text" class="form-control" placeholder="Enter Username Here" name="username" id="username">
                        </div>
                            <div class="form-group">
                                <label>Password</label>
                                <input type="password" class="form-control" placeholder="Enter Password Here"  name="password" id="password">
                        </div>
                        <div class="checkbox">

                        </div>
                        <div class="register-link m-t-15 text-center">
                            <button type="submit" class=" btn-step btn-lg " align="center" style="width: 50%;
                            text-transform: uppercase;
                            font-size: 18px;
                            /* padding: 15px; */
                            border: 0; align-items: center;" >Sign in</button>
                        </div>
		        
                        <!--<div class="register-link text-center">
                          <button class="ms-login-btn" id="loginwithmicrosoft" type="button"><img src="images/Microsoft_logo.png" alt="Microsoft Logo" class="ms-logo"> Login with Microsoft</button>
                        </div>-->
                        <div class="register-link text-center" style="margin-top:10%; font-size: 14px;">
                            <a href="<?php echo STEP_root; ?>forgot.php">Forgot Password?</a>
                        </div>

                                
                    </form>
                </div>
            </div>
        </div>
    </div>


    <?php include(STEP_dir.'js.php'); ?>
    <script src="<?php echo STEP_root; ?>assets/js/crypto-js-js.min.js"></script>
    <script src="<?php echo STEP_root; ?>assets/js/init-scripts/login-init.js"></script>

    
</body>

</html>
