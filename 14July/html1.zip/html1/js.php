
    <!-- Right Panel -->

    <script src="<?php echo $STEP->wwwroot; ?>vendors/jquery/dist/jquery.min.js"></script>
    <script src="<?php echo $STEP->wwwroot; ?>vendors/popper.js/dist/umd/popper.min.js"></script>
    <script src="<?php echo $STEP->wwwroot; ?>vendors/bootstrap/dist/js/bootstrap.min.js"></script>
    <script src="<?php echo $STEP->wwwroot; ?>assets/js/main.js"></script>


    <script src="<?php echo $STEP->wwwroot; ?>vendors/chart.js/dist/Chart.bundle.min.js"></script>
    <script src="<?php echo $STEP->wwwroot; ?>assets/js/dashboard.js"></script>
    <script src="<?php echo $STEP->wwwroot; ?>assets/js/widgets.js"></script>
    <script src="<?php echo $STEP->wwwroot; ?>vendors/jqvmap/dist/jquery.vmap.min.js"></script>
    <script src="<?php echo $STEP->wwwroot; ?>vendors/jqvmap/examples/js/jquery.vmap.sampledata.js"></script>
    <script src="<?php echo $STEP->wwwroot; ?>vendors/jqvmap/dist/maps/jquery.vmap.world.js"></script>


    <!-- //// datatable // -->


    <script src="<?php echo $STEP->wwwroot; ?>vendors/datatables.net/js/jquery.dataTables.min.js"></script>
    <script src="<?php echo $STEP->wwwroot; ?>vendors/datatables.net-bs4/js/dataTables.bootstrap4.min.js"></script>
    <script src="<?php echo $STEP->wwwroot; ?>vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
    <script src="<?php echo $STEP->wwwroot; ?>vendors/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js"></script>
    <script src="<?php echo $STEP->wwwroot; ?>vendors/jszip/dist/jszip.min.js"></script>
    <script src="<?php echo $STEP->wwwroot; ?>vendors/pdfmake/build/pdfmake.min.js"></script>
    <script src="<?php echo $STEP->wwwroot; ?>vendors/pdfmake/build/vfs_fonts.js"></script>
    <script src="<?php echo $STEP->wwwroot; ?>vendors/datatables.net-buttons/js/buttons.html5.min.js"></script>
    <script src="<?php echo $STEP->wwwroot; ?>vendors/datatables.net-buttons/js/buttons.print.min.js"></script>
    <script src="<?php echo $STEP->wwwroot; ?>vendors/datatables.net-buttons/js/buttons.colVis.min.js"></script>
    <script src="<?php echo $STEP->wwwroot; ?>vendors/datatables.net-buttons/js/buttons.colVis.min.js"></script>

    <!-- /// form validation  -->
    <script src="<?php echo $STEP->wwwroot; ?>assets/js/jquery.validate.min.js"></script>
    <!-- Bootstrap Date-Picker Plugin -->
    <script type="text/javascript" src="<?php echo $STEP->wwwroot; ?>assets/js/bootstrap-datepicker.min.js"></script>
    <script src="<?php echo $STEP->wwwroot; ?>assets/js/bootstrap-select.min.js"></script>
    <script src="<?php echo $STEP->wwwroot; ?>assets/js/jsconfig.js"></script>
    <script src="<?php echo $STEP->wwwroot; ?>assets/js/editor.js"></script>
    <script src="<?php echo $STEP->wwwroot; ?>assets/js/jquery-confirm.min.js"></script>
    <!--<script src="<?php echo $STEP->wwwroot; ?>assets/js/highcharts.js"></script>-->
    <script src="<?php echo $STEP->wwwroot; ?>assets/js/no-data-to-display.js"></script>

    <script src="<?php echo $STEP->wwwroot; ?>assets/js/select2.min.js"></script>

    <script src="<?php echo $STEP->wwwroot; ?>assets/js/jquery.mockjax.js"></script>
    <script src="<?php echo $STEP->wwwroot; ?>assets/js/moment.min.js"></script>
    <script src="<?php echo $STEP->wwwroot; ?>assets/js/bootstrap-notify.min.js"></script>

    <script type="text/javascript" src="<?php echo $STEP->wwwroot; ?>assets/bootstrap-datetimepicker-master/js/bootstrap-datetimepicker.min.js"></script>

    <script>
        (function($) {
            "use strict";

            jQuery('#vmap').vectorMap({
                map: 'world_en',
                backgroundColor: null,
                color: '#ffffff',
                hoverOpacity: 0.7,
                selectedColor: '#1de9b6',
                enableZoom: true,
                showTooltip: true,
                values: sample_data,
                scaleColors: ['#1de9b6', '#03a9f5'],
                normalizeFunction: 'polynomial'
            });

        })(jQuery);
    </script>
<script>
  // fileInput1 - xlsx, docx, jpg, png
  const input1 = document.getElementById('fileInput1');
  if (input1) {
    input1.addEventListener('change', function () {
      const allowedTypes = [
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', // .xlsx
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document', // .docx
        'image/jpeg', // .jpg, .jpeg
        'image/png'   // .png
      ];
      const file = this.files[0];
      if (file && !allowedTypes.includes(file.type)) {
        alert('Invalid file type. Please upload .xlsx, .docx, .jpg, or .png files only.');
        this.value = '';
      }
    });
  }
 
  // fileInput2 - xlsx only
  const input2 = document.getElementById('fileInput2');
  if (input2) {
    input2.addEventListener('change', function () {
      const allowedTypes = [
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' // .xlsx
      ];
      const file = this.files[0];
      if (file && !allowedTypes.includes(file.type)) {
        alert('Invalid file type. Please upload .xlsx files only.');
        this.value = '';
      }
    });
  }
 
  // fileInput3 - xlsx, docx
  const input3 = document.getElementById('fileInput3');
  if (input3) {
    input3.addEventListener('change', function () {
      const allowedTypes = [
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', // .xlsx
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document' // .docx
      ];
      const file = this.files[0];
      if (file && !allowedTypes.includes(file.type)) {
        alert('Invalid file type. Please upload .xlsx or .docx files only.');
        this.value = '';
      }
    });
  }
 
  // fileInput4 - jpg, png, docx
  const input4 = document.getElementById('fileInput4');
  if (input4) {
    input4.addEventListener('change', function () {
      const allowedTypes = [
        'image/jpeg', // .jpg, .jpeg
        'image/png',  // .png
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document' // .docx
      ];
      const file = this.files[0];
      if (file && !allowedTypes.includes(file.type)) {
        alert('Invalid file type. Please upload .jpg, .png, or .docx files only.');
        this.value = '';
      }
    });
  }
 
  // fileInput5 - jpg, png
  const input5 = document.getElementById('fileInput5');
  if (input5) {
    input5.addEventListener('change', function () {
      const allowedTypes = [
        'image/jpeg', // .jpg, .jpeg
        'image/png'   // .png
      ];
      const file = this.files[0];
      if (file && !allowedTypes.includes(file.type)) {
        alert('Invalid file type. Please upload .jpg or .png files only.');
        this.value = '';
      }
    });
  }
 
  function sanitizeInput(input) {
    const div = document.createElement('div');
    div.innerText = input;
    return div.innerHTML;
    }
</script>
