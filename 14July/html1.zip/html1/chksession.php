


<?php
session_start();
 
//echo "<pre>";print_r($_SESSION);echo "</pre>";exit;

// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: ". STEP_root."login.php");
    exit;
}
?>
