import schedule
import requests
import time

def sendnotification():
    print ("sendnotification")
    nurl = "https://www.testcalibre.com/api/sendEmail.php"
    try:
        res = requests.get(nurl,timeout=30)
    except requests.ConnectionError as e:
        print("OOPS!! Connection Error. Make sure you are connected to Internet. Technical Details given below.\n")
        print(str(e))  
    except requests.Timeout as e:
        print("OOPS!! Timeout Error")
        print(str(e))
    except requests.RequestException as e:
        print("OOPS!! General Error")
        print(str(e))
    except KeyboardInterrupt:
        print("Someone closed the program")
    
if __name__ == "__main__":

    schedule.every(1).minutes.do(sendnotification)
    
    # Loop so that the scheduling task 
    # keeps on running all time. 
    while True:                  
        # Checks whether a scheduled task  
        # is pending to run or not 
        schedule.run_pending() 
        time.sleep(1)
