import requests
from flask import Flask, jsonify, request
from flask_cors import CORS  # Import the CORS extension

app = Flask(__name__)

# Enable CORS for all routes
#CORS(app)
CORS(app, resources={r"/execute": {"origins": "https://www.testcalibre.com"}})
@app.route('/execute', methods=['POST'])
def execute_python_script():
    # API endpoint URL and headers from your original script
    url = "https://cloud.uipath.com/stepojdmnfrh/DefaultTenant/orchestrator_/api/TestAutomation/StartTestSetExecution"
    # url = "https://cloud.uipath.com/stepojdmnfrh/DefaultTenant/orchestrator_/api/TestAutomation/StartTestSetExecution?testSetKey=5bd1922f-27b3-4716-9e48-816a80226e95&triggerType=ExternalTool&X-UIPATH-OrganizationUnitId=3591727"
 
    params = {
        'testSetKey': '5bd1922f-27b3-4716-9e48-816a80226e95',
        'triggerType': 'Manual',
        'X-UIPATH-OrganizationUnitId': '3591727'
    }
    
    headers = {
        'X-UIPATH-OrganizationUnitId': '3591727',
        'Authorization': 'Bearer rt_E9C1505C30193F6B0919E1131D236CF03DEFE936FDA854C4337BF9F274A17FA3-1',
        'Content-Type': 'application/json'  # Assuming the body is expected to be JSON
    }
    
    try:
        # Send the POST request to the API
        response = requests.post(url, headers=headers, params=params)

        if response.status_code == 200:
            return jsonify({'status': 'success', 'message': 'Test started successfully'+response.text})
        else:
            return jsonify({'status': 'error', 'message': response.text}), 500

    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)}), 500

if __name__ == '__main__':
#    app.run(debug=True)
   # Specify the path to your SSL certificate and key files
    app.run(debug=True, host='0.0.0.0', port=5000, ssl_context=('/etc/letsencrypt/live/www.testcalibre.com/fullchain.pem', '/etc/letsencrypt/live/www.testcalibre.com/privkey.pem'))
# import requests
 
# url = "https://cloud.uipath.com/stepojdmnfrh/DefaultTenant/orchestrator_/api/TestAutomation/StartTestSetExecution?testSetKey=5bd1922f-27b3-4716-9e48-816a80226e95&triggerType=ExternalTool&X-UIPATH-OrganizationUnitId=3591727"
 
# payload = {}
# headers = {
#   'X-UIPATH-OrganizationUnitId': '3591727',
#   'Authorization': 'Bearer rt_E9C1505C30193F6B0919E1131D236CF03DEFE936FDA854C4337BF9F274A17FA3-1'
# }
 
# response = requests.request("POST", url, headers=headers, data=payload)
 
# print(response.text)
