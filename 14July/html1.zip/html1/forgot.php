<?php
include('config.php');
?>
<!doctype html>
<html class="no-js" lang="en">

<head>
   
    <?php include(STEP_dir.'headmetatag.php'); ?>
    <?php include(STEP_dir.'css.php'); ?>
</head>

<body style="background-image: url('images/loginbg.jpg');">


    <div class="sufee-login d-flex align-content-center flex-wrap" >
        <div class="container111" style="margin: 5%;">
            <div id="alertmsg"></div>
            <div class="login-content" >
                <div class="login-form">
                <div class="login-logo">
                    <a href="<?php echo STEP_root; ?>login.php">
                        <!--<img class="align-content" src="<?php echo STEP_root; ?>images/logo.jpg" alt="" height="50%" width="40%">-->
		<!--	<img style="width: 200px; object-fit:cover; object-position:center; margin-bottom: 20px; " class="align-content" src="<?php echo STEP_root; ?>images/tc-logo.png" alt=""> -->
			<img src="<?php echo STEP_root; ?>images/tc-logo.png" alt="Logo 1" class="logo" style="height:35px"/>
                        <div class="vertical-line" style=" width: 2px; height: 65px; border: solid #d2d2d2 0.5px;display:none;"></div>
                        <img src="<?php echo STEP_root; ?>images/logo.jpg" alt="Logo 2" class="logo" style="height:50px"/>
                    </a>
                </div>
                    <form id="forgotform" method="post">
                        <div class="form-group">
                            <label>EMAIL ADDRESS</label>
                            <input type="text" class="form-control" placeholder="Enter email id" name="emailid" id="emailid">
                        </div>

                        <button type="submit" class="btn btn-step btn-flat m-b-30 m-t-30">SUBMIT</button>
                                
                    </form>
                </div>
            </div>
        </div>
    </div>


    <?php include(STEP_dir.'js.php'); ?>
    <script src="<?php echo STEP_root; ?>assets/js/init-scripts/forgot-init.js"></script>

    
</body>

</html>
