<?php
if ($_SESSION['user_agent'] !== $_SERVER['HTTP_USER_AGENT'] || 
    $_SESSION['ip'] !== $_SERVER['REMOTE_ADDR']) {
    session_destroy();
    exit("Session Hijacked");
}
?>
