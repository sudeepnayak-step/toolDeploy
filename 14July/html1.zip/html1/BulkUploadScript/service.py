import os
import pandas as pd
import pymysql
import logging
import shutil
import traceback
import time
import sys
from datetime import datetime
import json

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Display errors and set up configurations
sys.tracebacklimit = 100
display_errors = True

# Define the project directory and folders
project_dir = os.getcwd()  # Assuming the script is run from the project directory
input_folder = os.path.join(project_dir, 'input')
pending_folder = os.path.join(project_dir, 'pending')
done_folder = os.path.join(project_dir, 'done')
exception_folder = os.path.join(project_dir, 'exception')  # Folder for exception files

# Ensure the pending, done, and exception folders exist
try:
    os.makedirs(pending_folder, exist_ok=True)
    os.makedirs(done_folder, exist_ok=True)
    os.makedirs(exception_folder, exist_ok=True)
    logger.info(f"Pending folder created at: {pending_folder}")
    logger.info(f"Done folder created at: {done_folder}")
    logger.info(f"Exception folder created at: {exception_folder}")
except Exception as e:
    logger.error(f"Failed to create folders: {str(e)}")
    logger.error(traceback.format_exc())
    raise

# Database configuration
DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': '$t3P@^A9T2O17',
    'db': 'testcalibre_vaptdb',
    'charset': 'utf8mb4',
    'cursorclass': pymysql.cursors.DictCursor
}

def get_db_connection():
    logger.info("Attempting to establish a database connection.")
    try:
        conn = pymysql.connect(**DB_CONFIG)
        logger.info("Database connection established successfully.")
        return conn
    except Exception as e:
        logger.error(f"Failed to establish a database connection: {str(e)}")
        logger.error(traceback.format_exc())
        raise

def insert_notification(conn, accountId, enteredby, error_message):
    try:
        with conn.cursor() as cursor:
            sql = """
            INSERT INTO s_notifications (
                `s_n_viewer`, `s_n_employees`, `s_n_assignto`, `s_n_recordid`,
                `s_n_recordnum`, `s_n_desc`, `s_n_attachments`, `s_n_filename`,
                `accountId`, `s_n_enteredby`, `s_n_newflag`, `s_n_emailflag`, `s_n_module`
            ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """
            params = (
                None, enteredby, '0', '0', 'Bulk Upload Process',
                f"Notification: {error_message}", '', '',
                accountId, enteredby, '0', '0', 'BulkUpload'
            )
            cursor.execute(sql, params)
            conn.commit()
            logger.info(f"Notification inserted successfully: {error_message}")
    except Exception as e:
        logger.error(f"Error inserting notification: {str(e)}")
        logger.error(traceback.format_exc())
        conn.rollback()

def process_file(file_path, projectId, releaseId, enteredby, accountId):
    msgarr = {"status": "Error", "message": "Something went wrong. Please try again."}
    errormsgarr = {"Activity not found": []}
    flag = 0
    errormsg = ""
    testcaseId = 0
    validation_successful = True
    aggregated_errors = []
    error_logs = {
        "activity_not_found": set()
    }

    try:
        logger.info(f"Starting to process file: {file_path}")
        logger.info("Reading Excel file.")
        df = pd.read_excel(file_path)
        logger.info(f"Excel file {file_path} read successfully.")
        conn = get_db_connection()

        # Validate all rows before processing
        for index, row in df.iterrows():
            try:
                scenarioId = str(row.iloc[0]) if pd.notna(row.iloc[0]) else "0"
                newFlag = str(row.iloc[1]) if pd.notna(row.iloc[1]) else "0"
                activity = str(row.iloc[2]) if pd.notna(row.iloc[2]) else ""

                if newFlag == "1" or newFlag == '1.0':
                    cursor = conn.cursor()
                    cursor.execute("SELECT * FROM s_activitymaster WHERE s_a_code = %s AND accountId = %s", (activity, accountId))
                    activity_data = cursor.fetchone()
                    if not activity_data:
                        errormsg = f"Row {index + 1}: activity not found."
                        aggregated_errors.append(errormsg)
                        error_logs["activity_not_found"].add(index + 1)
                        logger.error(errormsg)
                        validation_successful = False
            except Exception as e:
                errormsg = f"Row {index + 1}: {str(e)}"
                aggregated_errors.append(errormsg)
                logger.error(errormsg)
                logger.error(traceback.format_exc())
                validation_successful = False

        if aggregated_errors:
            error_message = "<br/>".join([f"{error_type.replace('_', ' ').title()} at row: {', '.join(map(str, sorted(rows)))}" for error_type, rows in error_logs.items() if rows])
            insert_notification(conn, accountId, enteredby, f"Validation errors found:<br/>{error_message}")

        if not validation_successful:
            logger.error("Validation failed. No data will be inserted.")
            conn.close()
            return {"status": "Error", "message": "Validation failed. No data inserted.", "errmsg": errormsgarr}

        stepnum = 1
        for index, row in df.iterrows():
            try:
                scenarioId = str(row.iloc[0]) if pd.notna(row.iloc[0]) else "0"
                newFlag = str(row.iloc[1]) if pd.notna(row.iloc[1]) else "0"
                activity = str(row.iloc[2]) if pd.notna(row.iloc[2]) else ""
                module = str(row.iloc[3]) if pd.notna(row.iloc[3]) else ""
                submodule = str(row.iloc[4]) if pd.notna(row.iloc[4]) else ""
                testscenariodesc = str(row.iloc[5]) if pd.notna(row.iloc[5]) else ""
                testcasedesc = str(row.iloc[6]) if pd.notna(row.iloc[6]) else ""
                steps = str(row.iloc[7]) if pd.notna(row.iloc[7]) else ""
                expectedresult = str(row.iloc[8]) if pd.notna(row.iloc[8]) else ""
                precondition = str(row.iloc[9]) if pd.notna(row.iloc[9]) else ""
                testdata = str(row.iloc[10]) if pd.notna(row.iloc[10]) else ""
                testmode = str(row.iloc[11]) if pd.notna(row.iloc[11]) else ""

                if newFlag == "1" or newFlag == '1.0':
                    scenarioIdstr = ""
                    testcaseNum = 0
                    stepnum = 1
                    testcaseIdstr = ""
                    projcode = ""
                    cursor = conn.cursor()
                    cursor.execute("SELECT * FROM s_project WHERE s_p_id = %s AND accountId = %s ORDER BY s_p_id DESC LIMIT 1", (projectId, accountId))
                    proj_data = cursor.fetchone()
                    if proj_data:
                        projcode = proj_data['s_p_code']
                        logger.info(f"Project code found: {projcode}")
                    else:
                        logger.error("Project data not found.")
                        raise ValueError("Project data not found.")

                    if scenarioId == "0" or scenarioId == "":
                        cursor.execute("SELECT * FROM s_testcase WHERE projectId = %s AND accountId = %s ORDER BY s_d_tempscenarioId DESC LIMIT 1", (projectId, accountId))
                        scenario_data = cursor.fetchone()
                        if scenario_data:
                            scenarioId = int(scenario_data[4]) + 1
                        else:
                            scenarioId = 1
                        scenarioIdstr = f"TS-{scenarioId}"
                    else:
                        scenarioIdstr = f"TS-{scenarioId}"

                    cursor.execute("SELECT * FROM s_activitymaster WHERE s_a_code = %s AND accountId = %s", (activity, accountId))
                    activity_data = cursor.fetchone()
                    activityId = activity_data['s_a_id'] if activity_data else 0

                    if activityId != 0:
                        cursor.execute("SELECT * FROM s_testcase WHERE projectId = %s AND accountId = %s ORDER BY s_t_tempid DESC LIMIT 1", (projectId, accountId))
                        testcase_data = cursor.fetchone()
                        if testcase_data:
                            testcaseNum = int(testcase_data['s_t_tempid']) + 1
                        else:
                            testcaseNum = 1
                        testcaseIdstr = f"{projcode}-TC-{testcaseNum}"

                        cursor.execute("""
                            INSERT INTO s_testcase (
                                projectId, releaseId, s_t_activityIds, s_d_tempscenarioId, s_t_testscenarionum,
                                s_t_tempid, s_t_testcasenum, s_t_module, s_t_submodule, s_t_testscenariodesc,
                                s_t_testcasedesc, s_t_steps, s_t_expectedresult, s_t_precondition, s_t_testdata,
                                s_t_enteredby, accountId, s_t_testmode, s_t_author
                            ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                        """, (
                            projectId, releaseId, activityId, scenarioId, scenarioIdstr,
                            testcaseNum, testcaseIdstr, module, submodule, testscenariodesc,
                            testcasedesc, steps, expectedresult, precondition, testdata,
                            enteredby, accountId, testmode, enteredby
                        ))
                        testcaseId = cursor.lastrowid
                        flag = 1
                        logger.info(f"Inserted testcase with ID: {testcaseId}")
                    if steps !="":
                        cursor.execute("""
                            INSERT INTO s_testcase_steps (
                                s_tss_num, testcaseId, s_tss_steps, s_tss_expectedresult, accountId, s_tss_enteredby
                            ) VALUES (%s, %s, %s, %s, %s, %s)
                        """, (stepnum, testcaseId, steps, expectedresult, accountId, enteredby))
                        logger.info(f"Inserted testcase steps for testcase ID: {testcaseId}")

                        cursor.execute("SELECT * FROM s_testcasefinal WHERE testcaseId = %s AND activityId = %s AND accountId = %s", (testcaseId, activityId, accountId))
                        final_data = cursor.fetchone()
                        if not final_data:
                            cursor.execute("""
                                INSERT INTO s_testcasefinal (
                                    testcaseId, projectId, releaseId, activityId, s_f_testresult, s_f_actualresult,
                                    s_f_executiontime, defectId, s_f_enteredby, accountId, s_f_activestatus
                                ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                            """, (testcaseId, projectId, releaseId, activityId, 'Not Executed', '', None, '0', enteredby, accountId, 'Active'))
                            logger.info(f"Inserted into s_testcasefinal for testcase ID: {testcaseId}")
                        else:
                            cursor.execute("""
                                UPDATE s_testcasefinal SET s_f_activestatus = 'Active'
                                WHERE testcaseId = %s AND activityId = %s AND accountId = %s
                            """, (testcaseId, activityId, accountId))
                            logger.info(f"Updated s_testcasefinal for testcase ID: {testcaseId}")
                    else:
                        errormsg = f"Row {index + 1}: activity not found."
                        aggregated_errors.append(errormsg)
                        logger.error(errormsg)
                else:
                    if  steps !="":
                        if testcaseId > 0:
                            stepnum += 1
                            cursor.execute("""
                                INSERT INTO s_testcase_steps (
                                    s_tss_num, testcaseId, s_tss_steps, s_tss_expectedresult, accountId, s_tss_enteredby
                                ) VALUES (%s, %s, %s, %s, %s, %s)
                            """, (stepnum, testcaseId, steps, expectedresult, accountId, enteredby))
                            logger.info(f"Inserted additional testcase steps for testcase ID: {testcaseId}")
            except Exception as e:
                logger.error(f"Error processing row {index + 1}: {str(e)}")
                logger.error(traceback.format_exc())
                if conn:
                    conn.rollback()
                raise

        conn.commit()
        logger.info("Database changes committed.")
        insert_notification(conn, accountId, enteredby, "Excel data processed successfully and inserted into the database.")
    except Exception as e:
        logger.error(f"An error occurred: {str(e)}")
        logger.error(traceback.format_exc())
        if conn:
            conn.rollback()
    finally:
        if conn:
            conn.close()
            logger.info("Database connection closed.")

    if flag > 0:
        msgarr["status"] = "Success"
        msgarr["message"] = "Testcase uploaded successfully."
        if errormsg:
            msgarr["message"] = "Some testcase uploaded successfully."
            msgarr["errmsg"] = errormsgarr
    else:
        msgarr["status"] = "Error"
        msgarr["message"] = "Something went wrong. Please try again."
        if errormsg:
            msgarr["message"] = "Testcase upload failed."
            msgarr["errmsg"] = errormsgarr
    return msgarr

def update_scriptaction_status(account_id, project_id, release_id, file_path, status, suiteId=None):
    db = None
    try:
        db = get_db_connection()
        cursor = db.cursor()

        if suiteId is not None:
            sql = """
            UPDATE scriptaction
            SET status = %s
            WHERE account_id = %s AND project_id = %s AND released_id = %s AND file_path = %s AND suiteId = %s
            """
            values = (status, account_id, project_id, release_id, file_path, suiteId)
        else:
            sql = """
            UPDATE scriptaction
            SET status = %s
            WHERE account_id = %s AND project_id = %s AND released_id = %s AND file_path = %s
            """
            values = (status, account_id, project_id, release_id, file_path)
          

        cursor.execute(sql, values)
        db.commit()
        logger.info(f"Status updated to '{status}' for account_id: {account_id}, project_id: {project_id}, release_id: {release_id}, file_path: {file_path}")
    except Exception as err:
        logger.error(f"Error updating status in scriptaction table: {str(err)}")
        logger.error(traceback.format_exc())
        if db:
            db.rollback()
        raise
    finally:
        if cursor:
            cursor.close()
        if db:
            db.close()

def process_defect_file(file_path, projectId, releaseId, enteredby, accountId):
    try:
        df = process_excel_file(file_path)
        if df is not None:
            success, errormsg, errormsgarr = process_data(df, os.path.basename(file_path), projectId, releaseId, enteredby, accountId)
            if success:
                logger.info(f"File {file_path} processed successfully.")
            else:
                logger.error(f"Failed to process file {file_path}. Errors: {errormsg}")
    except Exception as e:
        logger.error(f"Error processing defect file {file_path}: {str(e)}")
        logger.error(traceback.format_exc())
        raise

def process_excel_file(file_path):
    try:
        df = pd.read_excel(file_path)
        logger.info(f"Successfully read the Excel file: {file_path}")
        return df
    except Exception as e:
        logger.error(f"Failed to read the Excel file: {e}")
        return None

def process_data(df, excel_file_name, projectId, releaseId, enteredby, accountId):
    conn = None
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        errormsg = ""
        errormsgarr = {
            "Project ID not found": [],
            "Testcase not found": [],
            "Defect type not found": [],
            "Defect status not found": [],
            "Defect assignee not found": []
        }
        error_logs = {
            "project_id_not_found": set(),
            "testcase_not_found": set(),
            "defect_type_not_found": set(),
            "defect_status_not_found": set(),
            "defect_assignee_not_found": set()
        }
        validation_success = True

        for index, row in df.iterrows():
            row_errors = []
            testcaseNum = row.iloc[0] if pd.notna(row.iloc[0]) else "0"
            module = row.iloc[1] if pd.notna(row.iloc[1]) else ""
            submodule = row.iloc[2] if pd.notna(row.iloc[2]) else ""
            defecttype = row.iloc[3] if pd.notna(row.iloc[3]) else ""
            severity = row.iloc[4] if pd.notna(row.iloc[4]) else ""
            priority = row.iloc[5] if pd.notna(row.iloc[5]) else ""
            status = row.iloc[6] if pd.notna(row.iloc[6]) else ""
            assignto = row.iloc[7] if pd.notna(row.iloc[7]) else ""
            shortdesc = row.iloc[8] if pd.notna(row.iloc[8]) else ""
            longdesc = row.iloc[9] if pd.notna(row.iloc[9]) else ""
            testdata = row.iloc[10] if pd.notna(row.iloc[10]) else ""
            steps = row.iloc[11] if pd.notna(row.iloc[11]) else ""
            expectedresult = row.iloc[12] if pd.notna(row.iloc[12]) else ""
            actualresult = row.iloc[13] if pd.notna(row.iloc[13]) else ""
            raisedate = row.iloc[14] if pd.notna(row.iloc[14]) else ""
            closedate = row.iloc[15] if pd.notna(row.iloc[15]) else ""

            logger.info(f"Validating row {index + 1}")
            cursor.execute("SELECT s_p_code FROM s_project WHERE s_p_id = %s AND accountId = %s ORDER BY s_p_id DESC LIMIT 1", (projectId, accountId))
            projcode_result = cursor.fetchone()
            if not projcode_result or not projcode_result['s_p_code']:
                row_errors.append("Project ID not found")
                error_logs["project_id_not_found"].add(index + 1)

            cursor.execute("SELECT s_d_tempid FROM s_defect WHERE projectId = %s AND accountId = %s ORDER BY s_d_tempid DESC LIMIT 1", (projectId, accountId))
            defectId_result = cursor.fetchone()
            defectId = defectId_result['s_d_tempid'] + 1 if defectId_result else 1
            if defectId <= 0:
                row_errors.append("Generated defect ID is empty or zero.")

            cursor.execute("SELECT s_t_id FROM s_testcase WHERE projectId = %s AND accountId = %s AND s_t_testcasenum = %s", (projectId, accountId, testcaseNum))
            testcaseId_result = cursor.fetchone()
            if not testcaseId_result or testcaseId_result['s_t_id'] <= 0:
                row_errors.append("Testcase not found")
                error_logs["testcase_not_found"].add(index + 1)

            cursor.execute("SELECT s_dt_id FROM s_defecttypemaster WHERE accountId = %s AND s_dt_name = %s", (accountId, defecttype))
            defecttypeId_result = cursor.fetchone()
            if not defecttypeId_result or defecttypeId_result['s_dt_id'] <= 0:
                row_errors.append("Defect type not found")
                error_logs["defect_type_not_found"].add(index + 1)

            cursor.execute("SELECT s_ds_id FROM s_defectstatusmaster WHERE accountId = %s AND s_ds_name = %s", (accountId, status))
            defectstatusId_result = cursor.fetchone()
            if not defectstatusId_result or defectstatusId_result['s_ds_id'] <= 0:
                row_errors.append("Defect status not found")
                error_logs["defect_status_not_found"].add(index + 1)

            assigntostr = assignto.replace(' ', '')
            cursor.execute("SELECT s_e_id FROM s_employees WHERE accountId = %s AND CONCAT(s_e_fname, s_e_mname, s_e_lname) = %s", (accountId, assigntostr))
            assignId_result = cursor.fetchone()
            if not assignId_result or assignId_result['s_e_id'] <= 0:
                row_errors.append("Defect assignee not found")
                error_logs["defect_assignee_not_found"].add(index + 1)

            if row_errors:
                validation_success = False

        if not validation_success:
            error_message = "<br/>".join([f"{error_type.replace('_', ' ').title()} at row: {', '.join(map(str, sorted(rows)))}" for error_type, rows in error_logs.items() if rows])
            logger.error("Validation failed. No data will be inserted into the database.")
            logger.error("Error log: " + error_message)
            insert_notification(conn, accountId, enteredby, f"Validation failed with the following errors:<br/>{error_message}")
            return False, error_message, errormsgarr

        for index, row in df.iterrows():
            testcaseNum = row.iloc[0] if pd.notna(row.iloc[0]) else "0"
            module = row.iloc[1] if pd.notna(row.iloc[1]) else ""
            submodule = row.iloc[2] if pd.notna(row.iloc[2]) else ""
            defecttype = row.iloc[3] if pd.notna(row.iloc[3]) else ""
            severity = row.iloc[4] if pd.notna(row.iloc[4]) else ""
            priority = row.iloc[5] if pd.notna(row.iloc[5]) else ""
            status = row.iloc[6] if pd.notna(row.iloc[6]) else ""
            assignto = row.iloc[7] if pd.notna(row.iloc[7]) else ""
            shortdesc = row.iloc[8] if pd.notna(row.iloc[8]) else ""
            longdesc = row.iloc[9] if pd.notna(row.iloc[9]) else ""
            testdata = row.iloc[10] if pd.notna(row.iloc[10]) else ""
            steps = row.iloc[11] if pd.notna(row.iloc[11]) else ""
            expectedresult = row.iloc[12] if pd.notna(row.iloc[12]) else ""
            actualresult = row.iloc[13] if pd.notna(row.iloc[13]) else ""
            raisedate = row.iloc[14] if pd.notna(row.iloc[14]) else ""
            closedate = row.iloc[15] if pd.notna(row.iloc[15]) else ""

            cursor.execute("SELECT s_p_code FROM s_project WHERE s_p_id = %s AND accountId = %s ORDER BY s_p_id DESC LIMIT 1", (projectId, accountId))
            projcode_result = cursor.fetchone()
            projcode = projcode_result['s_p_code']

            cursor.execute("SELECT s_d_tempid FROM s_defect WHERE projectId = %s AND accountId = %s ORDER BY s_d_tempid DESC LIMIT 1", (projectId, accountId))
            defectId_result = cursor.fetchone()
            defectId = defectId_result['s_d_tempid'] + 1 if defectId_result else 1
            defectIdstr = f"{projcode}-D{defectId}"

            cursor.execute("SELECT s_t_id FROM s_testcase WHERE projectId = %s AND accountId = %s AND s_t_testcasenum = %s", (projectId, accountId, testcaseNum))
            testcaseId = cursor.fetchone()['s_t_id']

            cursor.execute("SELECT s_dt_id FROM s_defecttypemaster WHERE accountId = %s AND s_dt_name = %s", (accountId, defecttype))
            defecttypeId = cursor.fetchone()['s_dt_id']

            cursor.execute("SELECT s_ds_id FROM s_defectstatusmaster WHERE accountId = %s AND s_ds_name = %s", (accountId, status))
            defectstatusId = cursor.fetchone()['s_ds_id']

            assigntostr = assignto.replace(' ', '')
            cursor.execute("SELECT s_e_id FROM s_employees WHERE accountId = %s AND CONCAT(s_e_fname, s_e_mname, s_e_lname) = %s", (accountId, assigntostr))
            assignId = cursor.fetchone()['s_e_id']

            sql = """
            INSERT INTO s_defect (
                projectId, releaseId, testcaseId, s_d_tempid, s_d_defectnum, s_d_module, s_d_submodule,
                defecttypeId, s_d_severity, s_d_priority, defectstatusId, s_d_assignto, s_d_shortdesc,
                s_d_longdesc, s_d_testdata, s_d_steps, s_d_expectedresult, s_d_actualresult, s_d_comment,
                s_d_enteredby, accountId, s_d_createdtime, s_d_updatetime
            ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
            """
            cursor.execute(sql, (
                projectId, releaseId, testcaseId, defectId, defectIdstr, module, submodule,
                defecttypeId, severity, priority, defectstatusId, assignId, shortdesc,
                longdesc, testdata, steps, expectedresult, actualresult, "", enteredby, accountId, raisedate, closedate
            ))

        conn.commit()
        logger.info("All defects uploaded successfully.")
        insert_notification(conn, accountId, enteredby, f"Excel file {excel_file_name} has been processed successfully.")
        return True, "", errormsgarr
    except Exception as e:
        logger.error(f"Database error: {e}")
        conn.rollback()
        insert_notification(conn, accountId, enteredby, f"Database error occurred: {str(e)}")
        return False, f"Database error: {e}", errormsgarr
    finally:
        if 'cursor' in locals():
            cursor.close()
        if 'conn' in locals():
            conn.close()

def process_testexecution_file(file_path, enteredby, accountId, suiteId):
    msgarr = {"status": "Error", "message": "Something went wrong. Please try again."}
    errormsg = ""
    errormsgarr = {}
    flag = 0

    try:
        logger.info(f"Starting to process test execution file: {file_path}")
        logger.info("Reading Excel file.")
        df = pd.read_excel(file_path, na_values=[], keep_default_na=False)
        logger.info(f"Excel file {file_path} read successfully.")

        conn = get_db_connection()
        cursor = conn.cursor(pymysql.cursors.DictCursor)

        # Fetch projcode dynamically
        projcode_query = """
        SELECT p.s_p_code
        FROM s_testsuite ts
        JOIN s_project p ON ts.projectId = p.s_p_id
        WHERE ts.s_ts_id = %s;
        """
        cursor.execute(projcode_query, (suiteId,))
        result = cursor.fetchone()
        if result:
            projcode = result['s_p_code']
            logger.info(f"Project code fetched: {projcode}")
        else:
            errormsg = "Project code not found for the given suiteId."
            logger.error(errormsg)

        # Fetch reasons
        reasonsql = "SELECT s_r_id, s_r_name FROM s_reason WHERE accountId = %s ORDER BY s_r_id DESC"
        logger.info("Fetching reasons from the database")
        cursor.execute(reasonsql, (accountId,))
        reasonarr = {row['s_r_name']: row['s_r_id'] for row in cursor.fetchall()}

        # Fetch test suite data
        testsuitdata_sql = """
        SELECT s_ts_id, projectId, releaseId, activityId
        FROM s_testsuite
        WHERE s_ts_id = %s AND accountId = %s
        ORDER BY s_ts_id DESC
        """
        logger.info("Fetching test suite data")
        cursor.execute(testsuitdata_sql, (suiteId, accountId))
        tsuitdata = cursor.fetchone()
        if tsuitdata:
            testsuiteId = tsuitdata['s_ts_id']
            projectId = tsuitdata['projectId']
            releaseId = tsuitdata['releaseId']
            activityId = tsuitdata['activityId']

            # Fetch test cases
            tcsql = """
            SELECT s_t_id, s_t_testcasenum
            FROM s_testcase
            WHERE projectId = %s AND releaseId = %s AND FIND_IN_SET(%s, s_t_activityIds) AND accountId = %s
            """
            logger.info("Fetching test cases")
            cursor.execute(tcsql, (projectId, releaseId, activityId, accountId))
            tcarr = {row['s_t_testcasenum']: row['s_t_id'] for row in cursor.fetchall()}
            logger.info(f"Test cases from database: {tcarr}")

            # Dictionaries to collect row numbers for each type of error
            error_logs = {
                "testcase_not_found": set(),
                "testresult_not_found": set(),
                "step_not_found": set(),
                "missing_reason": set(),
                "missing_comment": set()
            }

            # Validate each row in the Excel file
            validation_errors = []
            valid_rows = []
            for rowIndex, row in df.iterrows():
                row_errors = []
                testcase = str(row.iloc[0]) if pd.notna(row.iloc[0]) else ""
                step = str(row.iloc[1]) if pd.notna(row.iloc[1]) else ""
                testresult = str(row.iloc[2]) if pd.notna(row.iloc[2]) else ""
                actualresult = str(row.iloc[3]) if pd.notna(row.iloc[3]) else ""
                reasontxt = str(row.iloc[4]) if pd.notna(row.iloc[4]) else ""
                comment = str(row.iloc[5]) if pd.notna(row.iloc[5]) else ""
                reasonId = 0

                if not testcase:
                    error_logs["testcase_not_found"].add(rowIndex + 1)
                    row_errors.append("Testcase not found")
                if not testresult:
                    error_logs["testresult_not_found"].add(rowIndex + 1)
                    row_errors.append("Testresult not found")
                if testresult == "NA":
                    reasonId = reasonarr.get(reasontxt, 0)
                    if reasonId == 0:
                        error_logs["missing_reason"].add(rowIndex + 1)
                        row_errors.append("Missing reason")
                    if not comment:
                        error_logs["missing_comment"].add(rowIndex + 1)
                        row_errors.append("Missing comment")

                testcaseId = tcarr.get(testcase, 0)
                if not testcaseId:
                    error_logs["testcase_not_found"].add(rowIndex + 1)
                    row_errors.append("Testcase ID not found")

                # Check if step exists
                stepexesql = """
                SELECT steps.s_tss_id AS stepId, steps.s_tss_expectedresult AS expectedresult,
                       exec.s_se_executionId AS executionId, exec.s_se_id AS stepexecutionId,
                       exec.s_se_iteration AS iteration
                FROM s_testcase_steps steps
                JOIN (
                    SELECT s1.s_se_id, s1.stepId, s1.s_se_iteration, s1.s_se_executionId
                    FROM s_tcstep_execution s1
                    INNER JOIN (
                        SELECT stepId, MAX(s_se_id) AS max_id
                        FROM s_tcstep_execution
                        WHERE s_se_executionId = (
                            SELECT s_st_id
                            FROM s_testexecution
                            WHERE testsuiteId = %s AND testcaseId = %s AND accountId = %s
                            ORDER BY s_st_id DESC
                            LIMIT 1
                        ) AND accountId = %s
                        GROUP BY stepId
                    ) s2 ON s1.stepId = s2.stepId AND s1.s_se_id = s2.max_id
                    WHERE s1.accountId = %s
                ) exec ON exec.stepId = steps.s_tss_id
                WHERE steps.s_tss_num = %s AND steps.testcaseId = %s AND steps.accountId = %s
                LIMIT 1
                """
                cursor.execute(stepexesql, (testsuiteId, testcaseId, accountId, accountId, accountId, step, testcaseId, accountId))
                tcsdata = cursor.fetchone()
                if not tcsdata:
                    error_logs["step_not_found"].add(rowIndex + 1)
                    row_errors.append("Step not found")

                if row_errors:
                    validation_errors.append(f"Row {rowIndex + 1}: {', '.join(row_errors)}")
                else:
                    valid_rows.append(rowIndex)

            # Log consolidated error messages
            for error_type, rows in error_logs.items():
                if rows:
                    logger.error(f"{error_type.replace('_', ' ').title()} at row: {', '.join(map(str, sorted(rows)))}")

            # If there are validation errors, log them and exit
            if validation_errors:
                error_message = "<br/>".join(validation_errors)
                insert_notification(conn, accountId, enteredby, f"Validation errors found:<br/>{error_message}")
                logger.error("Validation errors found. No data will be inserted.")
            else:
                # If all rows are valid, proceed with database insertion
                for rowIndex in valid_rows:
                    row = df.iloc[rowIndex]
                    try:
                        testcase = str(row.iloc[0]) if pd.notna(row.iloc[0]) else ""
                        step = str(row.iloc[1]) if pd.notna(row.iloc[1]) else ""
                        testresult = str(row.iloc[2]) if pd.notna(row.iloc[2]) else ""
                        actualresult = str(row.iloc[3]) if pd.notna(row.iloc[3]) else ""
                        reasontxt = str(row.iloc[4]) if pd.notna(row.iloc[4]) else ""
                        comment = str(row.iloc[5]) if pd.notna(row.iloc[5]) else ""
                        reasonId = 0
                        if testresult == "NA":
                            reasonId = reasonarr.get(reasontxt, 0)
                        testcaseId = tcarr.get(testcase, 0)
                        logger.info(f"Testcase ID for {testcase}: {testcaseId}")

                        stepexesql = """
                        SELECT steps.s_tss_id AS stepId, steps.s_tss_expectedresult AS expectedresult,
                               exec.s_se_executionId AS executionId, exec.s_se_id AS stepexecutionId,
                               exec.s_se_iteration AS iteration
                        FROM s_testcase_steps steps
                        JOIN (
                            SELECT s1.s_se_id, s1.stepId, s1.s_se_iteration, s1.s_se_executionId
                            FROM s_tcstep_execution s1
                            INNER JOIN (
                                SELECT stepId, MAX(s_se_id) AS max_id
                                FROM s_tcstep_execution
                                WHERE s_se_executionId = (
                                    SELECT s_st_id
                                    FROM s_testexecution
                                    WHERE testsuiteId = %s AND testcaseId = %s AND accountId = %s
                                    ORDER BY s_st_id DESC
                                    LIMIT 1
                                ) AND accountId = %s
                                GROUP BY stepId
                            ) s2 ON s1.stepId = s2.stepId AND s1.s_se_id = s2.max_id
                            WHERE s1.accountId = %s
                        ) exec ON exec.stepId = steps.s_tss_id
                        WHERE steps.s_tss_num = %s AND steps.testcaseId = %s AND steps.accountId = %s
                        LIMIT 1
                        """
                        cursor.execute(stepexesql, (testsuiteId, testcaseId, accountId, accountId, accountId, step, testcaseId, accountId))
                        tcsdata = cursor.fetchone()
                        if tcsdata:
                            stepId = tcsdata['stepId']
                            expectedresult = tcsdata['expectedresult'].replace("'", "`")
                            executionId = tcsdata['executionId']
                            stepexecutionId = tcsdata['stepexecutionId']
                            iteration = tcsdata['iteration']
                            if executionId:
                                if stepexecutionId:
                                    updatestepexedata_sql = """
                                    UPDATE s_tcstep_execution
                                    SET s_se_updatetime = %s, s_se_testresult = %s, s_se_actualresult = %s,
                                        reasonId = %s, s_se_comment = %s
                                    WHERE s_se_id = %s AND accountId = %s
                                    """
                                    cursor.execute(updatestepexedata_sql, (datetime.now(), testresult, actualresult, reasonId, comment, stepexecutionId, accountId))
                                    conn.commit()
                                    if cursor.rowcount > 0:
                                        flag = 1
                                        runsql = """
                                        UPDATE s_tcstep_iteration
                                        SET s_se_updatetime = %s, s_se_testresult = %s, s_se_actualresult = %s,
                                            reasonId = %s, s_se_comment = %s
                                        WHERE stepexecutionId = %s AND accountId = %s AND s_se_iteration = %s
                                        """
                                        cursor.execute(runsql, (datetime.now(), testresult, actualresult, reasonId, comment, stepexecutionId, accountId, iteration))
                                        conn.commit()
                                        allstepexedata_sql = """
                                        SELECT s_se_testresult
                                        FROM s_tcstep_execution
                                        WHERE s_se_executionId = %s AND accountId = %s
                                        ORDER BY s_se_id ASC
                                        """
                                        cursor.execute(allstepexedata_sql, (executionId, accountId))
                                        allstdata = cursor.fetchall()
                                        counts = {'Pass': 0, 'Fail': 0, 'In Progress': 0, 'Block': 0, 'NA': 0}
                                        for res in allstdata:
                                            if res['s_se_testresult'] in counts:
                                                counts[res['s_se_testresult']] += 1
                                        status = next((state for state in ['Fail', 'Block', 'In Progress', 'NA', 'Pass'] if counts[state] > 0), "")
                                        if status:
                                            execStatus = ", s_st_executionstatus = 2" if status in ['Pass', 'Fail'] else ""
                                            rtmupdatesql = f"""
                                            UPDATE s_testexecution
                                            SET s_st_updatetime = %s, s_st_testresult = %s {execStatus}
                                            WHERE s_st_id = %s
                                            """
                                            cursor.execute(rtmupdatesql, (datetime.now(), status, executionId))
                                            conn.commit()
                                            runupdatesql = f"""
                                            UPDATE s_testcaserun
                                            SET s_st_updatetime = %s, s_st_testresult = %s {execStatus}
                                            WHERE testexecutionId = %s AND s_st_iteration = %s
                                            """
                                            cursor.execute(runupdatesql, (datetime.now(), status, executionId, iteration))
                                            conn.commit()
                                            tcfinalsql = """
                                            UPDATE s_testcasefinal
                                            SET s_f_updatetime = %s, s_f_testresult = %s
                                            WHERE testcaseId = (SELECT testcaseId FROM s_testexecution WHERE s_st_id = %s AND accountId = %s)
                                            AND accountId = %s AND activityId = %s
                                            """
                                            cursor.execute(tcfinalsql, (datetime.now(), status, executionId, accountId, accountId, activityId))
                                            conn.commit()
                                            if testresult == "Fail":
                                                defectsqldata_sql = """
                                                SELECT s_d_tempid
                                                FROM s_defect
                                                WHERE projectId = %s AND accountId = %s
                                                ORDER BY s_d_tempid DESC
                                                LIMIT 1
                                                """
                                                cursor.execute(defectsqldata_sql, (projectId, accountId))
                                                defectdata = cursor.fetchone()
                                                defectId = (defectdata['s_d_tempid'] + 1) if defectdata else 1
                                                defectIdstr = f"{projcode}-D{defectId}"
                                                sql = """
                                                INSERT INTO s_defect
                                                (projectId, releaseId, testcaseId, s_d_tempid, s_d_defectnum, s_d_expectedresult, s_d_actualresult, accountId)
                                                VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                                                """
                                                cursor.execute(sql, (projectId, releaseId, testcaseId, defectId, defectIdstr, expectedresult, actualresult, accountId))
                                                conn.commit()
                                                tcdefectId = cursor.lastrowid
                                                updatedefectExecution_sql = """
                                                UPDATE s_testexecution
                                                SET defectId = %s
                                                WHERE s_st_id = %s
                                                """
                                                cursor.execute(updatedefectExecution_sql, (tcdefectId, executionId))
                                                conn.commit()
                                else:
                                    errormsg += f"Error at line no {rowIndex + 1}: Step Execution not found.<br/>"
                                    if "Step Execution not exist" not in errormsgarr:
                                        errormsgarr["Step Execution not exist"] = []
                                    errormsgarr["Step Execution not exist"].append(rowIndex + 1)
                                    logger.error(f"Step Execution not found at line {rowIndex + 1}")
                        else:
                            errormsg += f"Error at line no {rowIndex + 1}: Testcase not executed in testsuite.<br/>"
                            if "Testcase not executed in testsuite" not in errormsgarr:
                                errormsgarr["Testcase not executed in testsuite"] = []
                            errormsgarr["Testcase not executed in testsuite"].append(rowIndex + 1)
                            logger.error(f"Testcase not executed in testsuite at line {rowIndex + 1}")
                    except Exception as e:
                        errormsg += f"Error at line no {rowIndex + 1}: {e}<br/>"
                        logger.error(f"Unexpected error at line {rowIndex + 1}: {e}")
        else:
            errormsg += "Test suite data not found.<br/>"
            if "Test suite not exist" not in errormsgarr:
                errormsgarr["Test suite not exist"] = []
            errormsgarr["Test suite not exist"].append(1)
            logger.error("Test suite data not found")

        # Insert notification query
        error_message = "<br/>".join([f"{error_type.replace('_', ' ').title()} at row: {', '.join(map(str, sorted(rows)))}" for error_type, rows in error_logs.items() if rows])
        if not error_message:
            error_message = "Data uploaded successfully."

        insert_notification(conn, accountId, enteredby, error_message)
    except Exception as e:
        errormsg = f"An error occurred: {e}"
        errormsgarr["database error"] = [str(e)]
        logger.error(errormsg)
    finally:
        if conn:
            conn.close()
            logger.info("Database connection closed")

    if flag > 0:
        msgarr["status"] = "Success"
        msgarr["message"] = "Testcase result uploaded successfully."
        if errormsg:
            msgarr["message"] = "Some testcase result uploaded successfully."
            msgarr["errmsg"] = errormsgarr
    else:
        msgarr["status"] = "Error"
        msgarr["message"] = "Something went wrong. Please try again."
        if errormsg:
            msgarr["message"] = "Testcase result upload failed."
            msgarr["errmsg"] = errormsgarr

    logger.info("Script execution completed")
    return msgarr

def process_pending_files():
    try:
        db = get_db_connection()
        cursor = db.cursor(pymysql.cursors.DictCursor)
        cursor.execute("SELECT account_id, enteredby_id, project_id, released_id, status, file_path, type, suiteId FROM scriptaction WHERE status = 'pending' LIMIT 1")
        row = cursor.fetchone()
        logger.info("Fetched a row from the database.")
        if row:
            account_id = row['account_id']
            enteredby_id = row['enteredby_id']
            project_id = row['project_id']
            released_id = row['released_id']
            filepath = row['file_path']
            file_type = row['type']
            suiteId = row['suiteId']
            logger.info(f"Processing row - account_id: {account_id}, filepath: {filepath}")
            excel_file_path = os.path.join(input_folder, os.path.basename(filepath))
            logger.info(f"Constructed Excel file path: {excel_file_path}")
            if os.path.exists(excel_file_path):
                try:
                    update_scriptaction_status(account_id, project_id, released_id, filepath, "in progress", suiteId if file_type == 'testexecution' else None)
                    if file_type == 'testcase':
                        process_file(excel_file_path, project_id, released_id, enteredby_id, account_id)
                    elif file_type == 'defect':
                        process_defect_file(excel_file_path, project_id, released_id, enteredby_id, account_id)
                    elif file_type == 'testexecution':
                        process_testexecution_file(excel_file_path, enteredby_id, account_id, suiteId)
                    update_scriptaction_status(account_id, project_id, released_id, filepath, "done", suiteId if file_type == 'testexecution' else None)
                    done_file_path = os.path.join(done_folder, os.path.basename(filepath))
                    logger.info(f"New file path in done folder: {done_file_path}")
                    shutil.move(excel_file_path, done_file_path)
                    logger.info(f"File {filepath} moved to done folder.")
                except Exception as e:
                    logger.error(f"Error processing Excel file {filepath}: {str(e)}")
                    logger.error(traceback.format_exc())
                    update_scriptaction_status(account_id, project_id, released_id, filepath, "exception", suiteId if file_type == 'testexecution' else None)
                    exception_file_path = os.path.join(exception_folder, os.path.basename(filepath))
                    shutil.move(excel_file_path, exception_file_path)
                    logger.info(f"File {filepath} moved to exception folder due to processing error.")
            else:
                logger.error(f"File {filepath} not found in the input folder. Skipping processing for this file.")
        cursor.close()
        db.close()
    except Exception as err:
        logger.error(f"Error executing SQL query: {str(err)}")
        logger.error(traceback.format_exc())
        if 'cursor' in locals():
            cursor.close()
        if 'db' in locals():
            db.close()

# Main loop to run the script every 5 minutes
while True:
    logger.info("Starting the script execution...")
    process_pending_files()
    logger.info("Script execution completed. Waiting for 5 minutes before the next run...")
    time.sleep(300)  # Wait for 300 seconds (5 minutes)
