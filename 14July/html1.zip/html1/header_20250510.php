

<!-- Header-->
<header id="header" class="header">

    <div class="header-menu">

        <div class="col-sm-7">
            <a id="menuToggle" class="menutoggle pull-left"><i class="fa fa-list-ul"></i></a>
            <div class="header-left">
            </div>
        </div>

        <div class="col-sm-5">
            <div class="user-area dropdown float-right">
                <a href="<?php echo STEP_root; ?>index.php" class="dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    <img class="user-avatar rounded-circle" src="<?php echo STEP_root; ?>images/admin.jpg" alt="User Avatar">
                    
                </a>

                <div class="user-menu dropdown-menu">
                    <a class="nav-link" href="<?php echo STEP_root; ?>master/myprofile.php"><i class="fa fa-user"></i> My Profile</a>

                    <a class="nav-link" href="<?php echo STEP_root; ?>master/notification.php"><i class="fa fa-bell"></i> Notifications  <span id="notificationcount1" class="notificationcount1 ">0</span></a>

                    <a class="nav-link" href="JavaScript:Void(0)" data-toggle="modal" data-target="#resetpasswordmodal"><i class="fa fa-key"></i> Reset Password</a>
                    <a class="nav-link" href="JavaScript:Void(0)" id="logoutStep"><i class="fa fa-power-off"></i> Logout</a>
                </div>
            </div>
            
            <div class="language-select dropdown" id="language-select">
                <a class="dropdown-toggle" href="<?php echo STEP_root; ?>master/notification.php"  id="notificationmenu" aria-haspopup="true" aria-expanded="true">
                    <i class="fa fa-bell-o  text-step " style="font-size: 1.5em;"></i>
                    <span class="notificationcount bg-danger hidden" id="notificationcount"></span>
                </a>
            </div>

<!--           <div class="float-right mt-2" id="test-artifact">
                <a class="" href="<?php echo STEP_root; ?>stepartifact/StepArtifact-v1.exe" target="_blank" title="Download Step Artifact v1" >
                    <i class="fa fa-download  text-step " style=""></i>
                    
                </a>
            </div> -->
        </div>
    </div>

</header>
<img src="<?php echo STEP_root; ?>images/734.gif" id="loading-indicator" style="display:none" />
<?php include(STEP_dir.'master/resetpassword.php'); ?>
