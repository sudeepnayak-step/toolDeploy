<?php
include('config.php');
?>
<!doctype html>
<html class="no-js" lang="en">

<head>
   
    <?php include(STEP_dir.'headmetatag.php'); ?>
    <?php include(STEP_dir.'css.php'); ?>
</head>

<body style="background-image: url('images/loginbg.jpg');">


    <div class="sufee-login d-flex align-content-center flex-wrap" >
        <div class="container111" style="margin: 5%;">
            <div id="alertmsg"></div>
            
            <div class="login-content" >

                <div class="login-form">
                <div class="login-logo">
                    <a href="<?php echo STEP_root; ?>login.php">
                      <!--  <img class="align-content" src="<?php echo STEP_root; ?>images/logo.jpg" alt="" style="height:31px !important;">-->
			<img src="<?php echo STEP_root; ?>/images/tc-logo.png" alt="Logo 1" class="logo" style="height:31px"/>
    <div class="vertical-line" style=" width: 2px; height: 65px; border: solid #d2d2d2 0.5px;display:none;"></div>
    <img src="<?php echo STEP_root; ?>images/logo.jpg" alt="Logo 2" class="logo" style="height:60px"/>
                    </a>
                </div>
                <h4 style="margin-bottom: 10px;">Reset Password </h4>
                <hr>
                    <form id="activationform" method="post" class="hidden">
                        <div class="form-group">
                            <label>Username : </label> <span id="lblusername" class="text-step"></span>
                            <input type="hidden" class="form-control" placeholder="Username" name="username" id="username">
                        </div>
                        <div class="form-group">
                                <label>Password</label>
                                <input type="password" class="form-control" placeholder="Password"  name="password" id="password">
                        </div>
                        <div class="form-group">
                                <label>Confirm Password</label>
                                <input type="password" class="form-control" placeholder="Confirm Password"  name="cpassword" id="cpassword">
                        </div>
                                
                        <button type="submit" class="btn btn-step btn-flat m-b-30 m-t-30">SUBMIT</button>
                    </form>
                </div>
            </div>
        </div>
    </div>


    <?php include(STEP_dir.'js.php'); ?>
    <script src="<?php echo STEP_root; ?>assets/js/init-scripts/resetpassword-init.js"></script>

    
</body>

</html>
