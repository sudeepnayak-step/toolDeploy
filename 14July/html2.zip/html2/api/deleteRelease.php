<?php
include('config.php');
session_start();
 
$enteredby = 0;$accountId = 0;
 
/** delete release with its dependencies */
if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
}

$msgarr = array();
if($_SERVER['REQUEST_METHOD'] === 'POST'){

$id = (isset($_POST['id']) ? $_POST['id'] : "0");

if(!empty($id) && $id !="0") {

$sql = "DELETE FROM s_release WHERE s_r_id = ? AND accountId = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "ss", $id, $accountId);
mysqli_stmt_execute($stmt);
if($stmt)
	{
		
		$sql2 = "DELETE FROM s_defect  where releaseId = '".$id."' and accountId = '".$accountId."' ";
		$stmt2 = mysqli_query( $conn, $sql2);

		$sql3 = "DELETE FROM s_project_activity  where releaseId = '".$id."' and accountId = '".$accountId."' ";
		$stmt3 = mysqli_query( $conn, $sql3);


		$sql4 = "DELETE FROM s_rtm_testcase  where rtmId in (select s_rtm_id from s_rtm  where releaseId = '".$id."' and accountId = '".$accountId."') and accountId = '".$accountId."' ";
		$stmt4 = mysqli_query( $conn, $sql4);

		$sql4 = "DELETE FROM s_rtm  where releaseId = '".$id."' and accountId = '".$accountId."' ";
		$stmt4 = mysqli_query( $conn, $sql4);


		$sql4 = "DELETE FROM s_testcaserun  where testcaseId in (select s_t_id from s_testcase  where releaseId = '".$id."' and accountId = '".$accountId."') and accountId = '".$accountId."' ";
		$stmt4 = mysqli_query( $conn, $sql4);


		$sql4 = "DELETE FROM s_testexecution  where testcaseId in (select s_t_id from s_testcase  where releaseId = '".$id."' and accountId = '".$accountId."') and accountId = '".$accountId."' ";
		$stmt4 = mysqli_query( $conn, $sql4);
		
		$sql5 = "DELETE FROM s_testsuite  where releaseId = '".$id."' and accountId = '".$accountId."' ";
		$stmt5 = mysqli_query( $conn, $sql5);

		$sql6 = "DELETE FROM s_testcasefinal  where releaseId = '".$id."' and accountId = '".$accountId."' ";
		$stmt6 = mysqli_query( $conn, $sql6);

		$sql7 = "DELETE FROM s_testcase  where releaseId = '".$id."' and accountId = '".$accountId."' ";
		$stmt7 = mysqli_query( $conn, $sql7);

		$msgarr["status"] = "Success";
		$msgarr["message"] = "Release deleted successfully.";
	}
	else
	{
		$msgarr["status"] = "Error";
		$msgarr["message"] = "Something went wrong. Please try again.";
	}
}
}
echo json_encode($msgarr);