<?php
header('Access-Control-Allow-Origin: *');
include('config.php');
session_start();
 
$enteredby = 0;$accountId = 0;$userempid = 0;
 
   /** This PHP script retrieves the data from a database to show the value in dropdown
 * It formats the data and returns it in JSON format. */


$msgarr = array();
if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
    $userempid = $_SESSION["userempid"];
}

$where = "";
if(isset($_SESSION["usertype"]) && $_SESSION["usertype"] != "Admin"){
	$where .= " and projectId in (select s_p_id from s_project where s_p_id in (select projectId from s_project_members where employeeId = '".$userempid."'  and accountId = '".$accountId."') or s_p_enteredby = '".$enteredby."' and accountId = '".$accountId."')";
}
$mainarr['data'] = array();

if($_SERVER['REQUEST_METHOD'] === 'POST'){

$formtype = isset($_POST['formtype']) ? $_POST['formtype'] :"";

if($formtype == "Activity"){
	$sql = "SELECT * from s_activitymaster where s_a_activestatus = 'Active' and accountId = ?  ";
	
	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "i",$accountId);
	mysqli_stmt_execute($stmt);
	$result = mysqli_stmt_get_result($stmt);
	while($data = mysqli_fetch_assoc($result)){
		$mainarr['data'][] = array("id"=>$data['s_a_id'],
			"activityname"=>$data['s_a_name'],
			"activitycode"=>$data['s_a_code'],
			"activitytype"=>$data['s_a_type']
		);
	}
}else if($formtype == "Release"){

	$projectId = isset($_POST['projectId']) ? $_POST['projectId'] :"0";
	$sql = "SELECT * from s_release where ".($projectId != "0" ?  "projectId = '".$projectId."' and " : "" )." s_r_activestatus = 'Active' and accountId =?  $where";

	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "i",$accountId);
	mysqli_stmt_execute($stmt);
	$result = mysqli_stmt_get_result($stmt);
	while($data = mysqli_fetch_assoc($result)){
		$mainarr['data'][] = array("id"=>$data['s_r_id'],
			"releaseId"=>$data['s_r_name']
		);
	}
}else if($formtype == "Testcase"){

	$projectId = isset($_POST['projectId']) ? intval($_POST['projectId']) :0;
	$releaseId = isset($_POST['releaseId']) ? intval($_POST['releaseId']) :0;
	$sql = "SELECT * from s_testcase where projectId = ? and releaseId = ? and accountId =? ";
	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "iii",$projectId,$releaseId,$accountId);
	mysqli_stmt_execute($stmt);
	$result = mysqli_stmt_get_result($stmt);
	while($data = mysqli_fetch_assoc($result)){
		$mainarr['data'][] = array("id"=>$data['s_t_id'],
			"testcaseId"=>$data['s_t_testcasenum']
		);
	}
}else if($formtype == "Category"){

	$sql = "SELECT * from s_tccategorymaster where s_cat_activestatus = 'Active' and accountId = ?  ";

	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "i",$accountId);
	mysqli_stmt_execute($stmt);
	$result = mysqli_stmt_get_result($stmt);
	while($data = mysqli_fetch_assoc($result)){
		$mainarr['data'][] = array("id"=>$data['s_cat_id'],
			"name"=>$data['s_cat_name']
		);
	}
}else if($formtype == "DefectType"){

	$sql = "SELECT * from s_defecttypemaster where s_dt_activestatus = 'Active' and accountId = ? ";

	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "i",$accountId);
	mysqli_stmt_execute($stmt);
	$result = mysqli_stmt_get_result($stmt);
	while($data = mysqli_fetch_assoc($result)){
		$mainarr['data'][] = array("id"=>$data['s_dt_id'],
			"name"=>$data['s_dt_name']
		);
	}
}else if($formtype == "DefectStatus"){

	$sql = "SELECT * from s_defectstatusmaster where s_ds_activestatus = 'Active' and accountId = ? AND s_ds_name NOT IN('Pass','Fail') ";

	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "i",$accountId);
	mysqli_stmt_execute($stmt);
	$result = mysqli_stmt_get_result($stmt);
	while($data = mysqli_fetch_assoc($result)){
		$mainarr['data'][] = array("id"=>$data['s_ds_id'],
			"name"=>$data['s_ds_name']
		);
	}
}else if($formtype == "Defect"){
	$where = "";
	$projectId = isset($_POST['projectId']) ? intval($_POST['projectId']) :0;
	$releaseId = isset($_POST['releaseId']) ? intval($_POST['releaseId']) :0;
	$testcaseId = isset($_POST['testcaseId']) ? $_POST['testcaseId'] :"0";
	if($testcaseId !="0"){
		$where = " and testcaseId = '".$testcaseId."'  ";
	}
	$sql = "SELECT * from s_defect where projectId = ? and releaseId = ? and accountId =?  ".$where;
	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "iii",$projectId,$releaseId,$accountId);
	mysqli_stmt_execute($stmt);
	$result = mysqli_stmt_get_result($stmt);
	while($data = mysqli_fetch_assoc($result)){
		$mainarr['data'][] = array("id"=>$data['s_d_id'],
			"defectId"=>$data['s_d_defectnum']
		);
	}
}else if($formtype == "ProjectActivity"){

	$projectId = isset($_POST['projectId']) ? intval($_POST['projectId']) :0;
	$releaseId = isset($_POST['releaseId']) ? intval($_POST['releaseId']) :0;
	$sql = "SELECT * from s_activitymaster where s_a_activestatus = 'Active' and s_a_type = 'Execution' and s_a_id in ( Select activityId from s_project_activity where  projectId = ? and releaseId = ?  and accountId =? ) and accountId =? ";
	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "iiii",$projectId,$releaseId,$accountId,$accountId);
	mysqli_stmt_execute($stmt);
	$result = mysqli_stmt_get_result($stmt);
	while($data = mysqli_fetch_assoc($result)){
		$mainarr['data'][] = array("id"=>$data['s_a_id'],
			"activityId"=>$data['s_a_name']
		);
	}
}else if($formtype == "TestcaseScenario"){

	$projectId = isset($_POST['projectId']) ? intval($_POST['projectId']) :0;
	$flag = isset($_POST['flag']) ? $_POST['flag'] :"0";
	if($flag == 0){
		$mainarr['data'][] = array("id"=>"0",
			"name"=>"Autogenerate"
		);
	}
	$sql = "SELECT s_d_tempscenarioId,s_t_testscenarionum from s_testcase where projectId = ? and accountId = ?   group by s_d_tempscenarioId, s_t_testscenarionum ";
	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "ii",$projectId,$accountId);
	mysqli_stmt_execute($stmt);
	$result = mysqli_stmt_get_result($stmt);
	while($data = mysqli_fetch_assoc($result)){
		$mainarr['data'][] = array("id"=>$data['s_d_tempscenarioId'],
			"name"=>$data['s_t_testscenarionum']
		);
	}
}else if($formtype == "Employee"){

	$projectId = isset($_POST['projectId']) ? $_POST['projectId'] :"0";
	$sql = "SELECT * from  s_employees where s_e_activestatus = 'Active' and accountId = ?   Order by s_e_id desc";

	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "i",$accountId);
	mysqli_stmt_execute($stmt);
	$result = mysqli_stmt_get_result($stmt);
	while($data = mysqli_fetch_assoc($result)){
		$mainarr['data'][] = array("id"=>$data['s_e_id'],
			"name"=>$data['s_e_fname']." ".$data['s_e_mname']." ".$data['s_e_lname']
		);
	}
}else if($formtype == "Client"){

	$sql = "SELECT * from  s_client where s_c_activestatus = 'Active' and accountId = ?   Order by s_c_id desc";

	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "i",$accountId);
	mysqli_stmt_execute($stmt);
	$result = mysqli_stmt_get_result($stmt);
	while($data = mysqli_fetch_assoc($result)){
		$mainarr['data'][] = array("id"=>$data['s_c_id'],
			"name"=>$data['s_c_name']
		);
	}
}else if($formtype == "Assignee"){

	$projectId = isset($_POST['projectId']) ? intval($_POST['projectId']) :0;
	//$sql = "SELECT * from  s_employees where s_e_activestatus = 'Active' and s_e_id in(select employeeId from s_project_members where projectId = ? and accountId =? ) and accountId = ?    Order by s_e_id desc";

	//$stmt = mysqli_prepare($conn, $sql);
	//mysqli_stmt_bind_param($stmt, "iii",$projectId,$accountId,$accountId);
	
	$sql = "SELECT * FROM s_employees 
        WHERE s_e_activestatus = 'Active' 
        AND s_e_id IN (
            SELECT employeeId FROM s_project_members 
            WHERE accountId = ?";

	$params = [];
	$types = "i"; // for accountId in subquery
	$params[] = $accountId;

	if ($projectId != 0) {
		$sql .= " AND projectId = ?";
		$types .= "i";
		$params[] = $projectId;
	}

	$sql .= ") AND accountId = ? ORDER BY s_e_id DESC";
	$types .= "i";
	$params[] = $accountId;

	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, $types, ...$params);


	mysqli_stmt_execute($stmt);
	$result = mysqli_stmt_get_result($stmt);
	while($data = mysqli_fetch_assoc($result)){
		$mainarr['data'][] = array("id"=>$data['s_e_id'],
			"name"=>$data['s_e_fname']." ".$data['s_e_mname']." ".$data['s_e_lname']
		);
	}
}else if($formtype == "Scenario"){

	$projectId = isset($_POST['projectId']) ? intval($_POST['projectId']) :0;
	$releaseId = isset($_POST['releaseId']) ? intval($_POST['releaseId']) :0;
	$activityId = isset($_POST['activityId']) ? intval($_POST['activityId']) :0;
	
	$sql = "SELECT * from s_testcase where projectId = ? and releaseId = ? and activityId = ? and accountId =?   group by s_d_tempscenarioId ";

	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "iiii",$projectId,$releaseId,$activityId,$accountId);
	mysqli_stmt_execute($stmt);
	$result = mysqli_stmt_get_result($stmt);
	while($data = mysqli_fetch_assoc($result)){
		$mainarr['data'][] = array("id"=>$data['s_t_testscenarionum'],
			"name"=>$data['s_t_testscenarionum']
		);
	}
}else if($formtype == "ScenarioTestcase"){

	$projectId = isset($_POST['projectId']) ? intval($_POST['projectId']) :0;
	$releaseId = isset($_POST['releaseId']) ? intval($_POST['releaseId']) :0;
	$activityId = isset($_POST['activityId']) ? intval($_POST['activityId']) :0;
	$scenarioId = isset($_POST['scenarioId']) ? intval($_POST['scenarioId']) :0;
	
	$sql = "SELECT * from s_testcase where projectId = '".$projectId."' and accountId ='".$accountId."'  and releaseId = '".$releaseId."' and activityId = '".$activityId."' " . ($scenarioId !="0" && $scenarioId !="" ? " and s_t_testscenarionum = '".$scenarioId."'   " : "");

	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "iiii",$projectId,$accountId,$releaseId,$activityId);
	mysqli_stmt_execute($stmt);
	$result = mysqli_stmt_get_result($stmt);
	while($data = mysqli_fetch_assoc($result)){
		$mainarr['data'][] = array("id"=>$data['s_t_id'],
			"name"=>$data['s_t_testcasenum']
		);
	}
}else if($formtype == "FilterTestcase"){
	$where = "";
	if(isset($_POST['projectId']) && !empty($_POST['projectId']) && $_POST['projectId'] !="0"){
		$where = " AND projectId = '".$_POST['projectId']."' ";
	}
	if(isset($_POST['releaseId']) && !empty($_POST['releaseId']) && $_POST['releaseId'] !="0"){
		if($where == ""){
			$where = " AND releaseId = '".$_POST['releaseId']."' ";
		}else{
			$where .= " AND releaseId = '".$_POST['releaseId']."' ";
		}
	}
	if(isset($_POST['activityId']) && !empty($_POST['activityId']) && $_POST['activityId'] !="0"){
		if($where == ""){
			$where = " AND find_in_set('".$_POST['activityId']."',s_t_activityIds) ";
		}else{
			$where .= " AND find_in_set('".$_POST['activityId']."',s_t_activityIds) ";
		}
	}
	if(isset($_POST['module']) && !empty($_POST['module']) && $_POST['module'] !="0"){
		if($where == ""){
			$where = " AND s_t_module = '".$_POST['module']."' ";
		}else{
			$where .= " AND s_t_module = '".$_POST['module']."' ";
		}
	}

	$rtmId = (isset($_POST['rtmId']) ? $_POST['rtmId'] : "0");
	if($rtmId !="0" && $rtmId !=""){
			$where .= " AND s_t_id  not in (select testcaseId from s_rtm_testcase where rtmId =  '".$rtmId."' and accountId='".$accountId."' )";
	}
	$sql = "SELECT * from s_testcase  where accountId = ?  ".$where;
 	
	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "i",$accountId);
	mysqli_stmt_execute($stmt);
	$result = mysqli_stmt_get_result($stmt);
	while($data = mysqli_fetch_assoc($result)){
		$mainarr['data'][] = array("testcaseid"=>$data['s_t_id'],
			"modulename"=>$data['s_t_module'],
			"testcasename"=>$data['s_t_testcasenum']
		);
	}
}else if($formtype == "FilterDefect"){
	$where = "";
	if(isset($_POST['projectId']) && !empty($_POST['projectId']) && $_POST['projectId'] !="0"){
		$where = " AND projectId = '".$_POST['projectId']."' ";
	}
	if(isset($_POST['releaseId']) && !empty($_POST['releaseId']) && $_POST['releaseId'] !="0"){
		if($where == ""){
			$where = " AND releaseId = '".$_POST['releaseId']."' ";
		}else{
			$where .= " AND releaseId = '".$_POST['releaseId']."' ";
		}
	}
	if(isset($_POST['module']) && !empty($_POST['module']) && $_POST['module'] !="0"){
		if($where == ""){
			$where = " AND s_d_module = '".$_POST['module']."' ";
		}else{
			$where .= " AND s_d_module = '".$_POST['module']."' ";
		}
	}
	
	$sql = "SELECT * from s_defect  where accountId = ? ".$where;
 	
	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "i",$accountId);
	mysqli_stmt_execute($stmt);
	$result = mysqli_stmt_get_result($stmt);
	while($data = mysqli_fetch_assoc($result)){
		$mainarr['data'][] = array("defectid"=>$data['s_d_id'],
			"modulename"=>$data['s_d_module'],
			"defectname"=>$data['s_d_defectnum']
		);
	}
}else if($formtype == "RuleModule"){

	$sql = "SELECT * from s_rule_module where s_rm_activestatus = 'Active'";
	$stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    while ($data = mysqli_fetch_assoc($result)) {
		$mainarr['data'][] = array("id"=>$data['s_rm_id'],
			"name"=>$data['s_rm_name']
		);
	}
}else if($formtype == "Role"){
	$enteredby = (isset($_POST["enteredby"]) && !empty($_POST["enteredby"]) ? $_POST["enteredby"] : 0);
	$accountId = (isset($_POST["accountId"]) && !empty($_POST["accountId"]) ? $_POST["accountId"] : 0);
	$userempid = (isset($_POST["userempid"]) && !empty($_POST["userempid"])  ? $_POST["userempid"] : 0);

	$sql = "SELECT * from s_role where s_role_activestatus = 'Active' and accountId = ?  ";

	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "i",$accountId);
	mysqli_stmt_execute($stmt);
	$result = mysqli_stmt_get_result($stmt);
	while($data = mysqli_fetch_assoc($result)){
		$mainarr['data'][] = array("id"=>$data['s_role_id'],
			"name"=>$data['s_role_name']
		);
	}
}else if($formtype == "Holiday"){

	$sql = "SELECT * from s_holiday_master where s_h_activestatus = 'Active' and accountId = ? ";

	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "i",$accountId);
	mysqli_stmt_execute($stmt);
	$result = mysqli_stmt_get_result($stmt);
	while($data = mysqli_fetch_assoc($result)){
		$mainarr['data'][] = array("id"=>$data['s_h_id'],
			"name"=>$data['s_h_name'],
			"clientId"=>$data['clientId'],
			"date"=>$data['s_h_date']
		);
	}
}else if($formtype == "FilterRelease"){

	$sql = "SELECT * from s_release where  s_r_activestatus = 'Active' and accountId =? $where";

	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "i",$accountId);
	mysqli_stmt_execute($stmt);
	$result = mysqli_stmt_get_result($stmt);
	while($data = mysqli_fetch_assoc($result)){
		$mainarr['data'][] = array("id"=>$data['s_r_id'],
			"releaseId"=>$data['s_r_name']
		);
	}
}else if($formtype == "FilterActivity"){

	$sql = "SELECT * from s_activitymaster where s_a_activestatus = 'Active' and s_a_type = 'Execution' and s_a_id in ( Select activityId from s_project_activity where  accountId =? $where) and accountId =? ";

	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "ii",$accountId,$accountId);
	mysqli_stmt_execute($stmt);
	$result = mysqli_stmt_get_result($stmt);
	while($data = mysqli_fetch_assoc($result)){
		$mainarr['data'][] = array("id"=>$data['s_a_id'],
			"activityId"=>$data['s_a_name']
		);
	}
	
}else if($formtype == "allFilterRelease"){
	$where1 = "";
	if(isset($_POST['projectId']) && !empty($_POST['projectId'])){
		if(is_array($_POST['projectId'])){
			if(count($_POST['projectId']) >0){
				$projstr = implode(",", $_POST['projectId']);
				$where1 = " and projectId in ($projstr) ";
			}
		}else{
			$where1 .= " and projectId in (".$_POST['projectId'].") ";
		}
	}
	$sql = "SELECT * from s_release where  s_r_activestatus = 'Active' and accountId =? $where $where1";

	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "i",$accountId);
	mysqli_stmt_execute($stmt);
	$result = mysqli_stmt_get_result($stmt);
	while($data = mysqli_fetch_assoc($result)){
		$mainarr['data'][] = array("id"=>$data['s_r_id'],
			"releaseId"=>$data['s_r_name']
		);
	}
}else if($formtype == "allFilterActivity"){

	$where1 = "";
	if(isset($_POST['projectId']) && !empty($_POST['projectId'])){
		if(is_array($_POST['projectId'])){
			if(count($_POST['projectId']) >0){
				$projstr = implode(",", $_POST['projectId']);
				$where1 .= " and projectId in ($projstr) ";
			}
		}else{
			$where1 .= " and projectId in (".$_POST['projectId'].") ";
		}
	}
	if(isset($_POST['releaseId']) && !empty($_POST['releaseId'])){
		if(is_array($_POST['releaseId'])){
			if(count($_POST['releaseId']) >0){
				$releasestr = implode(",", $_POST['releaseId']);
				$where1 .= " and releaseId in ($releasestr) ";
			}
		}else{
			$where1 .= " and releaseId in (".$_POST['releaseId'].") ";
		}
	}

	$exewhere = " and s_a_type = 'Execution' ";
	if(isset($_POST['type']) && $_POST['type'] == "DSR"){		
			$exewhere = "";		
	}
	$sql = "SELECT * from s_activitymaster where s_a_activestatus = 'Active' ".$exewhere."  and s_a_id in ( Select activityId from s_project_activity where  accountId ='".$accountId."' $where $where1) and accountId =? ";

	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "i",$accountId);
	mysqli_stmt_execute($stmt);
	$result = mysqli_stmt_get_result($stmt);
	while($data = mysqli_fetch_assoc($result)){
		$mainarr['data'][] = array("id"=>$data['s_a_id'],
			"activityId"=>$data['s_a_name']
		);
	}
	
}else if($formtype == "allFilterTestsuite"){

	$where1 = "";
	if(isset($_POST['projectId']) && !empty($_POST['projectId'])){
		if(is_array($_POST['projectId'])){
			if(count($_POST['projectId']) >0){
				$projstr = implode(",", $_POST['projectId']);
				$where1 .= " and projectId in ($projstr) ";
			}
		}
	}
	if(isset($_POST['releaseId']) && !empty($_POST['releaseId'])){
		if(is_array($_POST['releaseId'])){
			if(count($_POST['releaseId']) >0){
				$releasestr = implode(",", $_POST['releaseId']);
				$where1 .= " and releaseId in ($releasestr) ";
			}
		}
	}
	if(isset($_POST['activityId']) && !empty($_POST['activityId'])){
		if(is_array($_POST['activityId'])){
			if(count($_POST['activityId']) >0){
				$releasestr = implode(",", $_POST['activityId']);
				$where1 .= " and activityId in ($activityId) ";
			}
		}
	}
	$sql = "SELECT * from s_testsuite where  accountId =? $where $where1 ";

	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "i",$accountId);
	mysqli_stmt_execute($stmt);
	$result = mysqli_stmt_get_result($stmt);
	while($data = mysqli_fetch_assoc($result)){
		$mainarr['data'][] = array("id"=>$data['s_ts_id'],
			"testsuiteId"=>$data['s_ts_name']
		);
	}
	
}else if($formtype == "allFilterOwner"){
	$where1 = "";
	if(isset($_POST['projectId']) && !empty($_POST['projectId'])){
		if(is_array($_POST['projectId'])){
			if(count($_POST['projectId']) >0){
				$projstr = implode(",", $_POST['projectId']);
				$where1 .= "  and s_e_id in (select s_p_owner from s_project where accountId = '".$accountId."' and s_p_id in ($projstr) )";
			}
		}
	}
	if(isset($_SESSION["usertype"]) && $_SESSION["usertype"] != "Admin"){
	
		$where1 .= " and s_p_id in (select s_p_id from s_project where s_p_id in (select projectId from s_project_members where employeeId = '".$userempid."'  and accountId = '".$accountId."') or s_p_enteredby = '".$enteredby."' and accountId = '".$accountId."')";
	}
	$sql = "SELECT * from  s_employees where s_e_activestatus = 'Active' and accountId =? $where1   ";

	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "i",$accountId);
	mysqli_stmt_execute($stmt);
	$result = mysqli_stmt_get_result($stmt);
	while($data = mysqli_fetch_assoc($result)){
		$mainarr['data'][] = array("id"=>$data['s_e_id'],
			"name"=>$data['s_e_fname']." ".$data['s_e_mname']." ".$data['s_e_lname']
		);
	}
}else if($formtype == "allFilterStatus"){
	$where1 = "";
	if(isset($_POST['projectId']) && !empty($_POST['projectId'])){
		if(is_array($_POST['projectId'])){
			if(count($_POST['projectId']) >0){
				$projstr = implode(",", $_POST['projectId']);
				$where1 = " and s_p_id in ($projstr) ";
			}
		}
	}
	if(isset($_SESSION["usertype"]) && $_SESSION["usertype"] != "Admin"){
		$where1 .= " and s_p_id in (select s_p_id from s_project where s_p_id in (select projectId from s_project_members where employeeId = '".$userempid."'  and accountId = '".$accountId."') or s_p_enteredby = '".$enteredby."' and accountId = '".$accountId."')";
	}
	$sql = "SELECT s_p_status,s_p_id from  s_project where s_p_activestatus = 'Active' and accountId = ?  $where1   ";

	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "i",$accountId);
	mysqli_stmt_execute($stmt);
	$result = mysqli_stmt_get_result($stmt);
	while($data = mysqli_fetch_assoc($result)){
		$mainarr['data'][] = array("id"=>$data['s_p_id'],
			"name"=>$data['s_p_status']
		);
	}
}else if($formtype == "allFilterTestcase"){

	$where1 = "";
	if(isset($_POST['projectId']) && !empty($_POST['projectId'])){
		if(is_array($_POST['projectId'])){
			if(count($_POST['projectId']) >0){
				$projstr = implode(",", $_POST['projectId']);
				$where1 .= " and projectId in ($projstr) ";
			}
		}
	}
	if(isset($_POST['releaseId']) && !empty($_POST['releaseId'])){
		if(is_array($_POST['releaseId'])){
			if(count($_POST['releaseId']) >0){
				$releasestr = implode(",", $_POST['releaseId']);
				$where1 .= " and releaseId in ($releasestr) ";
			}
		}
	}
	if(isset($_POST['module']) && !empty($_POST['module'])){
		if(is_array($_POST['module'])){
			if(count($_POST['module']) >0){
				$modulestr = "'" . implode ( "', '", $_POST['module'] ) . "'";
				$where1 .= " and s_t_module in ($modulestr) ";
			}
		}
	}

	if(isset($_POST['submodule']) && !empty($_POST['submodule'])){
		if(is_array($_POST['submodule'])){
			if(count($_POST['submodule']) >0){

				$submodulestr = "'" . implode ( "', '", $_POST['submodule'] ) . "'";
				$where1 .= " and s_t_submodule in ($submodulestr) ";
			}
		}
	}

	$sql = "SELECT * from s_testcase where  accountId = ?  $where $where1 ";

	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "i",$accountId);
	mysqli_stmt_execute($stmt);
	$result = mysqli_stmt_get_result($stmt);
	while($data = mysqli_fetch_assoc($result)){
		$mainarr['data'][] = array("testcaseid"=>$data['s_t_id'],
			"testcasename"=>$data['s_t_testcasenum'],
			"modulename"=>$data['s_t_module'],
			"submodulename"=>$data['s_t_submodule']
		);
	}
	
}else if($formtype == "allFilterDefect"){

	$where1 = "";
	if(isset($_POST['projectId']) && !empty($_POST['projectId'])){
		if(is_array($_POST['projectId'])){
			if(count($_POST['projectId']) >0){
				$projstr = implode(",", $_POST['projectId']);
				$where1 .= " and projectId in ($projstr) ";
			}
		}
	}
	if(isset($_POST['releaseId']) && !empty($_POST['releaseId'])){
		if(is_array($_POST['releaseId'])){
			if(count($_POST['releaseId']) >0){
				$releasestr = implode(",", $_POST['releaseId']);
				$where1 .= " and releaseId in ($releasestr) ";
			}
		}
	}
	
	$sql = "SELECT s_d_id,s_d_defectnum from s_defect where  accountId = ?  $where $where1 ";

	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "i",$accountId);
	mysqli_stmt_execute($stmt);
	$result = mysqli_stmt_get_result($stmt);
	while($data = mysqli_fetch_assoc($result)){
		$mainarr['data'][] = array("id"=>$data['s_d_id'],
			"defectId"=>$data['s_d_defectnum']
		);
	}
	
}else if($formtype == "allFilterTCRepository"){

	$table = "s_tcrepository";
	$tctype = (isset($_POST['type']) ? mysqli_real_escape_string($conn,$_POST['type']) : "Banking");
	switch ($tctype) {
	    case 'Banking':
	        $table = "s_tcrepository";
	        break;
	    case 'Automative':
	        $table = "s_tcrepository1";
	        break;
	    case 'HR':
	        $table = "s_tcrepository2";
	        break;
	    case 'Insurance':
	        $table = "s_tcrepository3";
	        break;
	    
	    default:
	        $table = "s_tcrepository";
	        break;
	}
	$where1 = "";
	if(isset($_POST['application']) && !empty($_POST['application'])){
		if(is_array($_POST['application'])){
			if(count($_POST['application']) >0){
				$apptr = "'" . implode ( "', '", $_POST['application'] ) . "'";
				$where1 .= " and s_t_application in ($apptr) ";
			}
		}
	}


	$sql = "SELECT s_t_id,s_t_application,s_t_module from ".$table." where  accountId = ?  $where1 ";

	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "i",$accountId);
	mysqli_stmt_execute($stmt);
	$result = mysqli_stmt_get_result($stmt);
	while($data = mysqli_fetch_assoc($result)){
		$mainarr['data'][] = array("tcrepositoryid"=>$data['s_t_id'],
			"application"=>$data['s_t_application'],
			"modulename"=>$data['s_t_module']
		);
	}
	
}else if($formtype == "TestcaseScenario_repository"){


	$table = "s_tcrepository";
	$tctype = (isset($_POST['type']) ? mysqli_real_escape_string($conn,$_POST['type']) : "Banking");
	switch ($tctype) {
	    case 'Banking':
	        $table = "s_tcrepository";
	        break;
	    case 'Automative':
	        $table = "s_tcrepository1";
	        break;
	    case 'HR':
	        $table = "s_tcrepository2";
	        break;
	    case 'Insurance':
	        $table = "s_tcrepository3";
	        break;
	    
	    default:
	        $table = "s_tcrepository";
	        break;
	}
	$sql = "SELECT * from ".$table." where accountId = ? group by s_d_tempscenarioId ";

	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "i",$accountId);
	mysqli_stmt_execute($stmt);
	$result = mysqli_stmt_get_result($stmt);
	while($data = mysqli_fetch_assoc($result)){
		$mainarr['data'][] = array("id"=>$data['s_d_tempscenarioId'],
			"name"=>$data['s_t_testscenarionum']
		);
	}
}else if($formtype == "ProjectEmailSetting"){
	$where = "";
	$id = isset($_POST['id'])  && !empty($_POST['id'])? intval($_POST['id']) :0;
	
	$sql = "SELECT * from s_project where  s_p_id  =  (select projectId from s_projemailsetting where s_projemailsetting.accountId = ?  and s_projes_id = ? ) ";
	
	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "ii",$accountId,$id);
	mysqli_stmt_execute($stmt);
	$result = mysqli_stmt_get_result($stmt);
	while($data = mysqli_fetch_assoc($result)){
		$mainarr['data'][] = array("id"=>$data['s_p_id'],
			"projectname"=>$data['s_p_name']
		);
	}
}else if($formtype == "allFilterRTM"){

	$where1 = "";
	if(isset($_POST['projectId']) && !empty($_POST['projectId'])){
		if(is_array($_POST['projectId'])){
			if(count($_POST['projectId']) >0){
				$projstr = implode(",", $_POST['projectId']);
				$where1 .= " and projectId in ($projstr) ";
			}
		}
	}
	if(isset($_POST['releaseId']) && !empty($_POST['releaseId'])){
		if(is_array($_POST['releaseId'])){
			if(count($_POST['releaseId']) >0){
				$releasestr = implode(",", $_POST['releaseId']);
				$where1 .= " and releaseId in ($releasestr) ";
			}
		}
	}
	
	$sql = "SELECT * from s_rtm where  accountId =? $where $where1 ";

	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "i",$accountId);
	mysqli_stmt_execute($stmt);
	$result = mysqli_stmt_get_result($stmt);
	while($data = mysqli_fetch_assoc($result)){
		$mainarr['data'][] = array("id"=>$data['s_rtm_id'],
			"rtmId"=>$data['s_rtm_reqnum']
		);
	}
	
}else if($formtype == "Group"){
	$sqldata = mysqli_query($conn,"SELECT * from s_group where s_group_activestatus = 'Active' and accountId ='".$accountId."' ");
	while($data = mysqli_fetch_assoc($sqldata)){
		$mainarr['data'][] = array("id"=>$data['s_group_id'],"name"=>$data['s_group_name']);
	}

}else if($formtype == "GroupwiseAssignee"){

	$groupId = isset($_POST['groupId']) && $_POST['groupId'] != "" ? implode(",",$_POST['groupId']) :"";
//	echo "SELECT * from  s_employees where s_e_activestatus = 'Active'  and find_in_set(groupId , '".$groupId."')  and accountId ='".$accountId."'   Order by s_e_id desc";
	$sqldata = mysqli_query($conn,"SELECT * from  s_employees where s_e_activestatus = 'Active'  and find_in_set( groupId , '".$groupId."')  and accountId ='".$accountId."'   Order by s_e_id desc");

	while($data = mysqli_fetch_assoc($sqldata)){
		$mainarr['data'][] = array("id"=>$data['s_e_id'],"name"=>$data['s_e_fname']." ".$data['s_e_mname']." ".$data['s_e_lname']);
	}
}else if($formtype == "TestSuite"){
	$sqldata=mysqli_query($conn,"SELECT * from s_testsuite where accountId='".$accountId."'$where");
	while($data = mysqli_fetch_assoc($sqldata)){
		$mainarr['data'][]=array("id"=>$data['s_ts_id'],"testsuiteId"=>$data['s_ts_name']);
	}
}else if($formtype == "allFilterModule"){
	$sqldata = mysqli_query($conn,"SELECT DISTINCT s_rtm_module as module FROM s_rtm WHERE s_rtm_module IS NOT NULL AND accountId = '".$accountId."'");
	while($data = mysqli_fetch_assoc($sqldata)){
		$mainarr['data'][] = array("module"=> $data['module']);
	}
}else if($formtype == "Reason"){
 
    $sqldata = mysqli_query($conn,"SELECT * from s_reason where s_r_activestatus = 'Active' and accountId ='".$accountId."' ");
 
    while($data = mysqli_fetch_assoc($sqldata)){
        $mainarr['data'][] = array("id"=>$data['s_r_id'],
            "name"=>$data['s_r_name']
        );
    }
}else if ($formtype == "Version") {
 $where1 = "";
 if(isset($_POST['projectId']) && !empty($_POST['projectId'])){
 		if(is_array($_POST['projectId'])){
 			if(count($_POST['projectId']) >0){
 				$projstr = implode(",", $_POST['projectId']);
 				$where1 .= " and projectId in ($projstr) ";
 			}
 		}
 	}
 	if(isset($_POST['releaseId']) && !empty($_POST['releaseId'])){
 		if(is_array($_POST['releaseId'])){
 			if(count($_POST['releaseId']) >0){
 				$releasestr = implode(",", $_POST['releaseId']);
 				$where1 .= " and releaseId in ($releasestr) ";
 			}
 		}
 	}
 // Construct the query
 $query = "SELECT DISTINCT s_d_version AS version FROM s_defect WHERE accountId = '$accountId' $where1";
 // Log the query for debugging purposes
 //error_log($query);
 
 // Execute the query
 $sqldata = mysqli_query($conn, $query);
 
 // Check for query execution errors
 if (!$sqldata) {
 error_log("Query failed: " . mysqli_error($conn));
 $mainarr['data'] = []; // Ensure data is an empty array if query fails
 } else {
 // Fetch and process the data
 $mainarr['data'] = array(); // Initialize the data array
 while ($data = mysqli_fetch_assoc($sqldata)) {
 			if ($data['version'] != '0') {
 $mainarr['data'][] = array(
 "id" => $data['version'],
 "version" => $data['version']
 );
 }
 	}
 }
 }else if ($formtype == "Reporter") {
 	$where1 = "";
 if(isset($_POST['projectId']) && !empty($_POST['projectId'])){
 		if(is_array($_POST['projectId'])){
 			if(count($_POST['projectId']) >0){
 				$projstr = implode(",", $_POST['projectId']);
 				$where1 .= " and projectId in ($projstr) ";
 			}
 		}
 	}
 	if(isset($_POST['releaseId']) && !empty($_POST['releaseId'])){
 		if(is_array($_POST['releaseId'])){
 			if(count($_POST['releaseId']) >0){
 				$releasestr = implode(",", $_POST['releaseId']);
 				$where1 .= " and releaseId in ($releasestr) ";
 			}
 		}
 	}
 
 // Updated query: select s_d_enterby and full name, group by s_d_enterby
$query = "SELECT    d.s_d_enteredby AS id,  case when d.s_d_enteredby = '$accountId' then 'Admin' else (SELECT CONCAT(e.s_e_fname, ' ', e.s_e_lname)     FROM s_employees e     WHERE e.userId = d.s_d_enteredby and e.userId !=0     LIMIT 1) end AS reporter FROM    s_defect d  WHERE    d.accountId = 206 and d.s_d_enteredby !=0  GROUP BY    d.s_d_enteredby";
 
//echo $query;
 
 $sqldata = mysqli_query($conn, $query);
 
 if (!$sqldata) {
 error_log("Query failed: " . mysqli_error($conn));
 $mainarr['data'] = [];
 } else {
 $mainarr['data'] = array();
 while ($data = mysqli_fetch_assoc($sqldata)) {
 if (!empty($data['id'])) {
 $mainarr['data'][] = array(
 "id" => $data['id'],
 "reporter" => $data['reporter']
 );
 }
 }
 }
 }


}

echo json_encode($mainarr);
