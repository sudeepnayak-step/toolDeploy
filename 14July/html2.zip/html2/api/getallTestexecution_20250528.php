<?php
include('config.php');
session_start();
 
$enteredby = 0;$accountId=0;
 
 /** This PHP script retrieves the testcase execution data from a database. 
 * It formats the data and returns it in JSON format. */


if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
}

$temp_testsuiteId = isset($_GET['id']) ? intval($_GET['id']) : 0;
$sql = "SELECT temp.*,
	IFNULL(tc.s_t_testscenarionum,'') as testscenarioId,
	IFNULL(tc.s_t_testcasenum,'') as testcaseId,
	IFNULL(tc.s_t_id,'') as testcaseautoId,
	IFNULL(tc.s_t_module,'-') as module,
	IFNULL(tc.s_t_submodule,'') as submodule,
	IFNULL(tc.s_t_testcasenum,'') as testcaseId,
	IFNULL(tc.s_t_testcasedesc,'') as testcasedesc,
	IFNULL(temp.s_st_filepath,'') as s_st_filepath,
	IFNULL(temp.s_st_testresult,'') as s_st_testresult,
	IFNULL(temp.s_st_actualresult,'') as s_st_actualresult,
	IFNULL(temp.s_st_executionstatus,'') as executionstatus,
	IFNULL(d.s_d_defectnum,'') as defectnum
	 from s_testexecution temp 
	join s_testcase tc on tc.s_t_id = temp.testcaseId 
	left join s_defect d on d.s_d_id = temp.defectId 
	where temp.testsuiteId = ? and temp.accountId = ? order by temp.s_st_id asc";

//$sql = "SELECT temp.s_st_id,temp.testcaseId,temp.defectId,temp.testsuiteId,temp.accountId,IFNULL(tc.s_t_testscenarionum, '') AS testscenarioId,IFNULL(tc.s_t_testcasenum, '') AS testcaseId,IFNULL(tc.s_t_id, '') AS testcaseautoId,IFNULL(tc.s_t_module, '-') AS module,IFNULL(tc.s_t_submodule, '') AS submodule,
//IFNULL(tc.s_t_testcasedesc, '') AS testcasedesc,IFNULL(temp.s_st_filepath, '') AS s_st_filepath,IFNULL(temp.s_st_testresult, '') AS s_st_testresult,IFNULL(temp.s_st_actualresult, '') AS s_st_actualresult,IFNULL(temp.s_st_executionstatus, '') AS executionstatus,IFNULL(d.s_d_defectnum, '') AS defectnum
//FROM s_testexecution temp JOIN s_testcase tc ON tc.s_t_id = temp.testcaseId LEFT JOIN s_defect d ON d.s_d_id = temp.defectId WHERE temp.testsuiteId = ? AND temp.accountId = ? ORDER BY temp.s_st_id ASC;";

//echo $sql;die;
	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "ii",$temp_testsuiteId,$accountId);
	mysqli_stmt_execute($stmt);
	$result = mysqli_stmt_get_result($stmt);

$projarr['data'] = array();
while($data = mysqli_fetch_assoc($result)){
	$iterationsqldata = mysqli_query($conn,"SELECT * from s_testcaserun where testexecutionId = '".$data['s_st_id']."' and accountId = '".$accountId."'  order by s_st_id desc ");
	$iterationcount = mysqli_num_rows($iterationsqldata);

	$exedate = "-";
	$executiondata = mysqli_query($conn,"SELECT IFNULL(s_st_createdtime,'') as s_st_createdtime from s_testcaserun where testexecutionId = '".$data['s_st_id']."' and accountId = '".$accountId."'  order by s_st_id desc limit 1");

	while($edata = mysqli_fetch_assoc($executiondata)){
		$exedate = (isset($edata['s_st_createdtime']) && ($edata['s_st_createdtime'] != "0000-00-00 00:00:00") ? date("d/m/Y",strtotime($edata['s_st_createdtime'])) : "-");
	}
	
	$filepath = $data['s_st_filepath'];
	$filepath = str_replace("http://13.127.150.155","http://65.0.186.156",$filepath);
	$filepath = str_replace("https://65.0.186.156","http://65.0.186.156",$filepath);
	//$filepath = str_replace("/var/www/html","https://www.testcalibre.com",$filepath);
	$filepath = str_replace("/var/www/html",$CFG['wwwroot'],$filepath);


	$projarr['data'][] = array($data['s_st_id'],//0
		(!empty($data['module']) ? $data['module'] : "-"),//
		$data['testscenarioId'],//2
		$data['testcaseId'],//3
		$data['testcaseautoId'],//4
		(!empty($data['testcasedesc']) ? $data['testcasedesc'] : "-"),//5
		$data['s_st_testresult'],//6
		$data['s_st_id'],//7 stesp
		$data['defectId'],//8
		$data['defectnum'],//9
		$filepath ,//10
		$iterationcount,//11
		(!empty($data['s_st_exectionstart']) ? $data['s_st_exectionstart'] : "-"),//12
		(!empty($data['s_st_executionend']) ? $data['s_st_executionend'] : "-"),//13
		(!empty($data['s_st_executiontime']) ? $data['s_st_executiontime'] : "-"),//14
		$data['executionstatus'],//15
		$exedate,
		$data['s_st_id']);//16
}

echo json_encode($projarr);
?>
