<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include('config.php');
session_start();
 
$enteredby = 0;$accountId = 0;$userempid = 0;
 

$msgarr = array();
if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
    $userempid = $_SESSION["userempid"];
}

$updateRecords = "";$auditlogDesc = "";$attachmentsLogs =array();$attachfilename = array();
if($_SERVER['REQUEST_METHOD'] === 'POST'){

$id = (isset($_POST['projId']) && !empty($_POST['projId']) ? $_POST['projId'] : "0");
$projectname = (isset($_POST['projectname']) && !empty($_POST['projectname'])  ? mysqli_real_escape_string($conn,sanitize($_POST['projectname'])) : "");
$projectname_change = (isset($_POST['projectname_change']) && !empty($_POST['projectname_change']) ? $_POST['projectname_change'] : "0");
if($projectname_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "Project name";
	}else{
		$auditlogDesc .= ", Project name";
	}
	if($updateRecords == ""){
		$updateRecords = "s_p_name = '".$projectname."'";
	}else{
		$updateRecords .= ", s_p_name = '".$projectname."'";
	}
}

$projectcode = (isset($_POST['projectcode']) && !empty($_POST['projectcode'])  ? mysqli_real_escape_string($conn,sanitize($_POST['projectcode'])) : "");
$projectcode_change = (isset($_POST['projectcode_change']) && !empty($_POST['projectcode_change']) ? $_POST['projectcode_change'] : "0");
if($projectcode_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "Project code";
	}else{
		$auditlogDesc .= ", Project code";
	}
	if($updateRecords == ""){
		$updateRecords = "s_p_code = '".$projectcode."'";
	}else{
		$updateRecords .= ", s_p_code = '".$projectcode."'";
	}
}

$projectstatus = (isset($_POST['projectstatus']) && !empty($_POST['projectstatus']) ? $_POST['projectstatus'] : "");
$projectstatus_change = (isset($_POST['projectstatus_change']) && !empty($_POST['projectstatus_change']) ? $_POST['projectstatus_change'] : "0");
if($projectstatus_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "Status";
	}else{
		$auditlogDesc .= ", Status";
	}
	if($updateRecords == ""){
		$updateRecords = "s_p_status = '".$projectstatus."'";
	}else{
		$updateRecords .= ", s_p_status = '".$projectstatus."'";
	}
}


$planstartdate = (isset($_POST['planstartdate']) && !empty($_POST['planstartdate']) ?  date('Y-m-d', strtotime(str_replace('/', '-', $_POST['planstartdate']))) : null);
$planstartdate_change = (isset($_POST['planstartdate_change']) && !empty($_POST['planstartdate_change']) ? $_POST['planstartdate_change'] : "0");
if($planstartdate_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "Plan start date";
	}else{
		$auditlogDesc .= ", Plan start date";
	}
	if($updateRecords == ""){
		//$updateRecords = "s_p_planstartdate = '".$planstartdate."'";
		$updateRecords = isset($planstartdate)?"s_p_planstartdate='".$planstartdate."'":"s_p_planstartdate = null";
	}else{
		//$updateRecords .= ", s_p_planstartdate = '".$planstartdate."'";
		$updateRecords .= isset($planstartdate)?", s_p_planstartdate='".$planstartdate."'":"s_p_planstartdate = null";
	}
}

$planenddate = (isset($_POST['planenddate']) && !empty($_POST['planenddate']) ? date('Y-m-d', strtotime(str_replace('/', '-', $_POST['planenddate']))) : null);
$planenddate_change = (isset($_POST['planenddate_change']) && !empty($_POST['planenddate_change']) ? $_POST['planenddate_change'] : "0");
if($planenddate_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "Plan end date";
	}else{
		$auditlogDesc .= ", Plan end date";
	}
	if($updateRecords == ""){
		//$updateRecords = "s_p_planenddate = '".$planenddate."'";
		$updateRecords = isset($planenddate)?"s_p_planenddate='".$planenddate."'":"s_p_planenddate = null";
	}else{
		//$updateRecords .= ", s_p_planenddate = '".$planenddate."'";
		$updateRecords .= isset($planenddate)?", s_p_planenddate='".$planenddate."'":"s_p_planenddate = null";
	}
}

$revisedstartdate = (isset($_POST['revisedstartdate']) && !empty($_POST['revisedstartdate']) ?  date('Y-m-d', strtotime(str_replace('/', '-', $_POST['revisedstartdate']))) : null);
$revisedstartdate_change = (isset($_POST['revisedstartdate_change']) && !empty($_POST['revisedstartdate_change']) ? $_POST['revisedstartdate_change'] : "0");
if($revisedstartdate_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "Revised start date";
	}else{
		$auditlogDesc .= ", Revised start date";
	}
	if($updateRecords == ""){
		//$updateRecords = "s_p_revisedstartdate = '".$revisedstartdate."'";
		$updateRecords = isset($revisedstartdate)?"s_p_revisedstartdate='".$revisedstartdate."'":"s_p_revisedstartdate = null";
	}else{
		//$updateRecords .= ", s_p_revisedstartdate = '".$revisedstartdate."'";
		$updateRecords .= isset($revisedstartdate)?", s_p_revisedstartdate='".$revisedstartdate."'":"s_p_revisedstartdate = null";
	}
}

$revisedenddate = (isset($_POST['revisedenddate']) && !empty($_POST['revisedenddate']) ? date('Y-m-d', strtotime(str_replace('/', '-', $_POST['revisedenddate']))): null);
$revisedenddate_change = (isset($_POST['revisedenddate_change']) && !empty($_POST['revisedenddate_change']) ? $_POST['revisedenddate_change'] : "0");
if($revisedenddate_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "Revised end date";
	}else{
		$auditlogDesc .= ", Revised end date";
	}
	if($updateRecords == ""){
		//$updateRecords = "s_p_revisedenddate = '".$revisedenddate."'";
		$updateRecords = isset($revisedenddate)?"s_p_revisedenddate='".$revisedenddate."'":"s_p_revisedenddate = null";
	}else{
		//$updateRecords .= ", s_p_revisedenddate = '".$revisedenddate."'";
		 $updateRecords .= isset($revisedenddate)?", s_p_revisedenddate='".$revisedenddate."'":"s_p_revisedenddate = null";
	}
}

$actualstartdate = (isset($_POST['actualstartdate']) && !empty($_POST['actualstartdate']) ? date('Y-m-d', strtotime(str_replace('/', '-', $_POST['actualstartdate']))) : null);
$actualstartdate_change = (isset($_POST['actualstartdate_change']) && !empty($_POST['actualstartdate_change']) ? $_POST['actualstartdate_change'] : "0");
if($actualstartdate_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "Actual start date";
	}else{
		$auditlogDesc .= ", Actual start date";
	}
	if($updateRecords == ""){
		//$updateRecords = "s_p_actualstartdate = '".$actualstartdate."'";
		$updateRecords = isset($actualstartdate)?"s_p_actualstartdate='".$actualstartdate."'":"s_p_actualstartdate = null";
	}else{
		//$updateRecords .= ", s_p_actualstartdate = '".$actualstartdate."'";
		 $updateRecords .= isset($actualstartdate)?", s_p_actualstartdate='".$actualstartdate."'":"s_p_actualstartdate = null";
	}
}

$actualenddate = (isset($_POST['actualenddate']) && !empty($_POST['actualenddate']) ? date('Y-m-d', strtotime(str_replace('/', '-', $_POST['actualenddate'] ))): null);
$actualenddate_change = (isset($_POST['actualenddate_change']) && !empty($_POST['actualenddate_change']) ? $_POST['actualenddate_change'] : "0");
if($actualenddate_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "Actual end date";
	}else{
		$auditlogDesc .= ", Actual end date";
	}
	
	if($updateRecords == ""){
		$updateRecords = isset($actualenddate)?"s_p_actualenddate='".$actualenddate."'":"s_p_actualenddate = null";
	}else{
		$updateRecords .= isset($actualenddate)?", s_p_actualenddate='".$actualenddate."'":"s_p_actualenddate = null";
	}
}

$activestatus = (isset($_POST['activestatus']) && !empty($_POST['activestatus'])? $_POST['activestatus'] : "Active");
$activestatus_change = (isset($_POST['activestatus_change']) && !empty($_POST['activestatus_change']) ? $_POST['activestatus_change'] : "0");
if($activestatus_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "Active status";
	}else{
		$auditlogDesc .= ", Active status";
	}
	if($updateRecords == ""){
		$updateRecords = "s_p_activestatus = '".$activestatus."'";
	}else{
		$updateRecords .= ", s_p_activestatus = '".$activestatus."'";
	}
}

$teammember = (isset($_POST['teammember']) && !empty($_POST['teammember'])?  $_POST['teammember'] : array());
$teammember_change = (isset($_POST['teammember_change']) && !empty($_POST['teammember_change']) ? $_POST['teammember_change'] : "0");
if($teammember_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "Team member";
	}else{
		$auditlogDesc .= ", Team member";
	}
	if($updateRecords == ""){
		$updateRecords = "s_p_activestatus = '".$activestatus."'";
	}else{
		$updateRecords .= ", s_p_activestatus = '".$activestatus."'";
	}
}

$group = (isset($_POST['group']) && !empty($_POST['group']) ? implode(",",$_POST['group']) : "");
$group_change = (isset($_POST['group_change']) && !empty($_POST['group_change']) ? $_POST['group_change'] : "");
if($group_change == "1"){
    if($auditlogDesc == ""){
        $auditlogDesc = "Group";
    }else{
        $auditlogDesc .= ", Group";
    }
    if($updateRecords == ""){
        $updateRecords = "s_p_group = '".$group."'";
    }else{
        $updateRecords .= ", s_p_group = '".$group."'";
    }
}

$projectowner = (isset($_POST['projectowner']) && !empty($_POST['projectowner']) ? $_POST['projectowner'] : "0");
$projectowner_change = (isset($_POST['projectowner_change']) && !empty($_POST['projectowner_change']) ? $_POST['projectowner_change'] : "0");
if($projectowner_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "Owner";
	}else{
		$auditlogDesc .= ", Owner";
	}
	if($updateRecords == ""){
		$updateRecords = "s_p_owner = '".$projectowner."'";
	}else{
		$updateRecords .= ", s_p_owner = '".$projectowner."'";
	}
}

$projectclient = (isset($_POST['projectclient']) && !empty($_POST['projectclient']) ? $_POST['projectclient'] : "0");
$projectclient_change = (isset($_POST['projectclient_change']) && !empty($_POST['projectclient_change']) ? $_POST['projectclient_change'] : "0");
if($projectclient_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "Client";
	}else{
		$auditlogDesc .= ", Client";
	}
	if($updateRecords == ""){
		$updateRecords = "clientId = '".$projectclient."'";
	}else{
		$updateRecords .= ", clientId = '".$projectclient."'";
	}
}

$projectdesc = (isset($_POST['projectdesc']) && !empty($_POST['projectdesc'])? mysqli_real_escape_string($conn,sanitize($_POST['projectdesc'])) : "");
$projectdesc_change = (isset($_POST['projectdesc_change']) && !empty($_POST['projectdesc_change']) ? $_POST['projectdesc_change'] : "0");
if($projectdesc_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "Description";
	}else{
		$auditlogDesc .= ", Description";
	}
	if($updateRecords == ""){
		$updateRecords = "s_p_desc = '".$projectdesc."'";
	}else{
		$updateRecords .= ", s_p_desc = '".$projectdesc."'";
	}
}

$ragstatus = (isset($_POST['ragstatus']) && !empty($_POST['ragstatus']) ? $_POST['ragstatus'] : "");
$ragstatus_change = (isset($_POST['ragstatus_change']) && !empty($_POST['ragstatus_change']) ? $_POST['ragstatus_change'] : "0");
if($ragstatus_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "RAG status";
	}else{
		$auditlogDesc .= ", RAG status";
	}
	if($updateRecords == ""){
		$updateRecords = "s_p_ragstatus = '".$ragstatus."'";
	}else{
		$updateRecords .= ", s_p_ragstatus = '".$ragstatus."'";
	}
}

$filename = "";
$filepath = "";

if(!empty($id) && $id !="0") {
	$projectId = $id;



	if(isset($_FILES['fileToUpload']['name'])){
		
		if (!file_exists($CFG['dirroot'].'attachments/'.$accountId.'/project/'.$projectId)) {
			mkdir($CFG['dirroot'].'attachments/'.$accountId.'/project/'.$projectId, 0777, true);
		}
					
		// Count # of uploaded files in array
		$total = count($_FILES['fileToUpload']['name']);

		// Loop through each file
		for( $i=0 ; $i < $total ; $i++ ) {

		  //Get the temp file path
		  $tmpFilePath = $_FILES['fileToUpload']['tmp_name'][$i];

		  //Make sure we have a file path
		  if ($tmpFilePath != ""){
			//Setup our new file path
			$newFilePath = $CFG['dirroot'].'attachments/'.$accountId.'/project/'.$projectId."/" . $_FILES['fileToUpload']['name'][$i];

			//Upload the file into the temp dir
			if(move_uploaded_file($tmpFilePath, $newFilePath)) {

			  //Handle other code here

			}
		  }
		}
		if(isset($attachmentsLogs) && !empty($attachmentsLogs)){

		  if($auditlogDesc == ""){
				$auditlogDesc = "Attachments";
			}else{
				$auditlogDesc .= ", Attachments";
			}
		}
	}
	

if($updateRecords !="" || (isset($attachmentsLogs) && !empty($attachmentsLogs)) ){
		if($updateRecords !=""){
			$sql = "UPDATE s_project SET $updateRecords WHERE s_p_id = ?";
			//echo $sql; die;
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "s", $id);
            $result = mysqli_stmt_execute($stmt);
            // mysqli_stmt_close($stmt);
		}

		if((isset($result) && $result) || (isset($attachmentsLogs) && !empty($attachmentsLogs))){
			$newFlag = 0;
			$msgarr["status"] = "Success";
			$msgarr["message"] = "Project updated successfully.";
			
			
			if($teammember_change == "1"){

				if(isset($teammember) && !empty($teammember) && count($teammember) >0){

					$dsql = "DELETE FROM s_project_members WHERE projectId = ? AND employeeId not in (".(implode(",", $teammember)).") AND accountId = ?";
					$memstmt = mysqli_prepare($conn, $dsql);
					mysqli_stmt_bind_param($memstmt, "si",$projectId,$accountId);
					mysqli_stmt_execute($memstmt);
					mysqli_stmt_close($memstmt);

					foreach ($teammember as $key => $value) {
						
						$chksql = "select * from s_project_members where projectId = '".$projectId."' and employeeId = '".$value."' and accountId = '".$accountId."'  ";
						$chkstmt = mysqli_query( $conn, $chksql);
						if(mysqli_num_rows($chkstmt) <=0){
							$msql = "insert into s_project_members(projectId,employeeId,accountId) values('".$projectId."','".$value."','".$accountId."')";
				
							$mstmt = mysqli_query( $conn, $msql);				
						}
					}
				}else {

						$dsql = "delete from s_project_members where projectId = '".$projectId."'  and accountId = '".$accountId."' ";
					
						$dstmt = mysqli_query( $conn, $dsql);
					}
			}
			if($auditlogDesc != ""){
				$auditlogSql = "insert into s_auditlogs (`s_a_desc`, `s_a_module`, `s_a_enteredby`,`accountId`,`s_a_recordId`,`s_a_recordnum` ) values ('".$auditlogDesc."','Project','".$enteredby."','".$accountId."','".$id."','') ";
				
				mysqli_query( $conn, $auditlogSql);


			}
		}else{
			$msgarr["status"] = "Error";
			$msgarr["message"] = "Something went wrong. Please try again.";
		}
		if(isset($stmt)) mysqli_stmt_close($stmt);
	}else{

			$msgarr["status"] = "Success";
			$msgarr["message"] = "Project updated successfully.";
	}

}else{

	// Insert new project
	$sql = "INSERT INTO s_project (s_p_name, s_p_code, s_p_status, s_p_planstartdate, s_p_planenddate, s_p_revisedstartdate, s_p_revisedenddate, s_p_actualstartdate, s_p_actualenddate, s_p_desc, s_p_owner, clientId, s_p_enteredby, s_p_ragstatus, s_p_activestatus, accountId, s_p_group) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "sssssssssssssssss", $projectname, $projectcode, $projectstatus, $planstartdate, $planenddate, $revisedstartdate, $revisedenddate, $actualstartdate, $actualenddate, $projectdesc, $projectowner, $projectclient, $enteredby, $ragstatus, $activestatus, $accountId, $group);
	$result = mysqli_stmt_execute($stmt);

		if($result)
		{
			$projectId = mysqli_insert_id($conn);
			mysqli_stmt_close($stmt);
			$msgarr["status"] = "Success";
			$msgarr["message"] = "Project added successfully.";

			if(isset($_SESSION["usertype"]) && $_SESSION["usertype"] != "Admin"){
				array_push($teammember, $userempid);
			}
			if(isset($teammember) && !empty($teammember) && count($teammember) >0){

					$dsql = "delete from s_project_members where projectId = '".$projectId."' and employeeId not in (".(implode(",", $teammember)).") and accountId = '".$accountId."' ";

					$dstmt = mysqli_query( $conn, $dsql);
					foreach ($teammember as $key => $value) {
				
						$chksql = "select * from s_project_members where projectId = '".$projectId."' and employeeId = '".$value."' and accountId = '".$accountId."'  ";
		
						$chkstmt = mysqli_query( $conn, $chksql);
						if(mysqli_num_rows($chkstmt) <=0){
							$msql = "insert into s_project_members(projectId,employeeId,accountId) values('".$projectId."','".$value."','".$accountId."')";
		
							$mstmt = mysqli_query( $conn, $msql);				
						}
					}
			}

			if(isset($_FILES['fileToUpload']['name'])){

				if (!file_exists($CFG['dirroot'].'attachments/'.$accountId.'/project/'.$projectId)) {
					mkdir($CFG['dirroot'].'attachments/'.$accountId.'/project/'.$projectId, 0777, true);
				}
							
				// Count # of uploaded files in array
				$total = count($_FILES['fileToUpload']['name']);

				// Loop through each file
				for( $i=0 ; $i < $total ; $i++ ) {

				//Get the temp file path
				$tmpFilePath = $_FILES['fileToUpload']['tmp_name'][$i];

				//Make sure we have a file path
				if ($tmpFilePath != ""){
					//Setup our new file path
					$newFilePath = $CFG['dirroot'].'attachments/'.$accountId.'/project/'.$projectId."/" . $_FILES['fileToUpload']['name'][$i];

					//Upload the file into the temp dir
					if(move_uploaded_file($tmpFilePath, $newFilePath)) {

					//Handle other code here

					}
				}
				}
			}
		}
		else
		{
			$msgarr["status"] = "Error";
			$msgarr["message"] = "Something went wrong. Please try again.";
		}
	}
}
echo json_encode($msgarr);
