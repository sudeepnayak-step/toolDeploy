<?php
$type = isset($_GET['type']) ? $_GET['type'] : "";
/** sample formatted excel download for uploading the data */
$filename = "$type.xlsx";

include_once("xlsxwriter.class.php");
ini_set('display_errors', 0);
ini_set('log_errors', 1);
error_reporting(E_ALL & ~E_NOTICE);

header('Content-disposition: attachment; filename="'.XLSXWriter::sanitize_filename($filename).'"');
header("Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
header('Content-Transfer-Encoding: binary');
header('Cache-Control: must-revalidate');
header('Pragma: public');
if($type == "Testcase"){
	$rows = array(array('Test Scenario ID','Flag','Test Type','Module','Sub module','Test Scenario Description','Test Case Description','Steps','Expected Result',
		'Pre-Condition','Test Data','Test Mode'));
}else if($type  == "Defect"){
	$rows = array(array('Test Case ID','Module','Sub module','Defect Type','Severity','Priority','Status','Assign to','Short Description','Detailed Description','Test Data','Steps','Expected Result','Actual Result'));
}else if($type == "Repository"){
	$rows = array(array('Test Scenario ID','Flag','Application','Test Type','Module','Sub module','Test Scenario Description','Test Case Description','Steps','Expected Result',
		'Pre-Condition','Test Data','Test Mode'));
}

$writer = new XLSXWriter();
$writer->setAuthor('STEP'); 
foreach($rows as $row)
	$writer->writeSheetRow('Sheet1', $row);
$writer->writeToStdOut();

exit(0);



?>