﻿<?php
header('Access-Control-Allow-Origin: *');
include('config.php');

require 'vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;


/**this script resend the activation mail to user */
$msg = "Oops! Something went wrong. Please try again later.";

$msgarr = array();

$msgarr["status"] = "Error";
$msgarr["message"] = "Something went wrong. Please try again.";
if($_SERVER['REQUEST_METHOD'] === 'POST'){

$userId = (isset($_POST['userId']) && !empty($_POST['userId']) ? $_POST['userId'] : "");
$local = (isset($_POST['local']) && !empty($_POST['local']) ? $_POST['local'] : "");
$accountId = (isset($_POST['accountId']) && !empty($_POST['accountId']) ? $_POST['accountId'] : "0");
$empname = (isset($_POST['empname']) && !empty($_POST['empname']) ? $_POST['empname'] : "User");

    if(!empty($userId)){
    	
         $sql = "SELECT s_u_id, s_u_username, s_u_activationnum,s_u_type,s_u_employeeId,accountId,s_u_licno,s_u_expirytime FROM s_users
         WHERE s_u_id = ? and accountId = ? ";
         
        if($stmt = mysqli_prepare($conn, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "ss", $param_username,$param_accountid);
            
            // Set parameters
            $param_username = $userId;
            $param_accountid = $accountId;
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Store result
                mysqli_stmt_store_result($stmt);
                
                // Check if username exists, if yes then verify password
                if(mysqli_stmt_num_rows($stmt) == 1){                    
                    // Bind result variables
                    mysqli_stmt_bind_result($stmt, $id, $username, $activationnum,$type,$empid,$accountId,$liccount,$expiry,);
                    if(mysqli_stmt_fetch($stmt)){
                       $sendFlag =  sendEmail($activationnum,$username);
                       if($sendFlag == 0){
                        $msgarr["status"] = "Success";
                        $msgarr["message"] = "Email sent successfully.";
                       }else{

                        $msgarr["status"] = "Error";
                        $msgarr["message"] = "Email sending failed.";

                       }

                    }
                } else{
                    // Display an error message if username doesn't exist
                    $msg = "No account found with this email id.";

                    $msgarr["status"] = "Error";
                    $msgarr["message"] = "No account found with this email id.";
                }
            } else{
                $msg =  "Oops! Something went wrong. Please try again later.";

                $msgarr["status"] = "Error";
                $msgarr["message"] = "Something went wrong. Please try again.";
            }
            // Close statement
            mysqli_stmt_close($stmt);
        }
        
    }
}else{
    $msgarr["status"] = "Error";
    $msgarr["message"] = "Something went wrong. Please try again.";
}

function sendEmail($nActivationNum,$emailid){
    global $conn,$accountId,$local,$empname;
    
    $emailsqldata = mysqli_query($conn,"SELECT *  from s_emailsetting where accountId = '$accountId' order by s_es_id desc limit 1");
    $e_host = "";
    $e_port = "";
    $e_fromname = "";
    $e_username = "";
    $e_password = "";
    $e_id = 0;

    while($data = mysqli_fetch_assoc($emailsqldata)){
    $e_host = $data['s_es_host'];
    $e_port =  $data['s_es_port'];
    $e_fromname =  $data['s_es_fromname'];
    $e_username =  $data['s_es_username'];
    $e_password =  $data['s_es_password'];
    $e_id =  $data['s_es_id'];
    }
    $subject = "TestCalibre - Account Activation";
$mail             = new PHPMailer(); // defaults to using php "mail()"
 
    $mail->IsSMTP(); // enable SMTP
    $mail->IsHTML(true);
    $mail->SMTPDebug  = 0;                     // enables SMTP debug information (for testing)
    $mail->SMTPAuth   = true;                  // enable SMTP authentication
    $mail->SMTPSecure = "tls";                 // sets the prefix to the servier
    $mail->Host       = "$e_host";      // sets GMAIL as the SMTP server
    $mail->Port       = $e_port;   // set the SMTP port for the GMAIL server
    $mail->SMTPKeepAlive = true;
    $mail->Mailer = "smtp";
    $body             = $emaildsrbody;
    $mail->Username   = $e_username;  // GMAIL username
    $mail->Password   = $e_password    ;   
    $mail->SetFrom($e_username, $e_fromname);
    $mail->AddEmbeddedImage('D:/xampp/htdocs/SOSA/step-tool/images/tc-logo.png','logoimg');
   // $mail->Mailer = "smtp";
    $body             = "Dear $empname,<br/><br/>Your account has been created on TestCalibre. Please click on the following link and activate your account to login.<br/><br/>
        <a href='".$local."accountactivation.php?token=".$nActivationNum."' >Activate</a>";


        
    $body = '<!DOCTYPE html>
    <html>

    <head>
        <title></title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <style type="text/css">
            body,
            table,
            td,
            a {
                -webkit-text-size-adjust: 100%;
                -ms-text-size-adjust: 100%;
            }

            table,
            td {
                mso-table-lspace: 0pt;
                mso-table-rspace: 0pt;
            }

            img {
                -ms-interpolation-mode: bicubic;
            }
            img {
                border: 0;
                height: auto;
                line-height: 100%;
                outline: none;
                text-decoration: none;
            }

            table {
                border-collapse: collapse !important;
            }

            body {
                height: 100% !important;
                margin: 0 !important;
                padding: 0 !important;
                width: 100% !important;
            }

            a[x-apple-data-detectors] {
                color: inherit !important;
                text-decoration: none !important;
                font-size: inherit !important;
                font-family: inherit !important;
                font-weight: inherit !important;
                line-height: inherit !important;
            }

            /* MOBILE STYLES */
            @media screen and (max-width:600px) {
                h1 {
                    font-size: 32px !important;
                    line-height: 32px !important;
                }
            }

            div[style*="margin: 16px 0;"] {
                margin: 0 !important;
            }
        </style>
    </head>

    <body style="background-color: #f4f4f4; margin: 0 !important; padding: 0 !important;">
        <div style="display: none; font-size: 1px; color: #fefefe; line-height: 1px; max-height: 0px; max-width: 0px; opacity: 0; overflow: hidden;"> </div>
        <table border="0" cellpadding="0" cellspacing="0" width="100%">
            <tr>
                <td bgcolor="#f4f4f4" align="center">
                    <table border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width: 600px;">
                        <tr>
                            <td align="center" valign="top" style="padding: 40px 10px 40px 10px;"> </td>
                        </tr>
                    </table>
                </td>
            </tr>
            <tr>
                <td bgcolor="#f4f4f4" align="center" style="padding: 0px 10px 0px 10px;">
                    <table border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width: 600px;">
                        <tr>
                            <td bgcolor="#f4f4f4" align="center" valign="top" style="padding: 40px 20px 20px 20px; border-radius: 4px 4px 0px 0px; color: #111111;  font-size: 48px; font-weight: 400; letter-spacing: 4px; line-height: 48px;">
                                <img src="cid:logoimg" alt="Test Calibre" width="125" height="120" style="display: block; border: 0px;" />  
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
            <tr>
                <td bgcolor="#f4f4f4" align="center" style="padding: 0px 10px 0px 10px;">
                    <table border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width: 600px;">
                        <tr>
                            <td bgcolor="#ffffff" align="left" style="padding: 20px 30px 40px 30px; color: #666666;  font-size: 16px; font-weight: 400; line-height: 25px;">

                                <h1 style="font-size: 28px; font-weight: 400; margin: 2;">Account Activation</h1><br/>
                                <p style="margin: 0;">Hi,<br/><br/>

                    Welcome to TestCalibre!!<br/><br/>

                    Your account has been created on TestCalibre. Please click on the following link and activate your account to login.</p>
                            </td>
                        </tr>
                        <tr>
                            <td bgcolor="#ffffff" align="left">
                                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                    <tr>
                                        <td bgcolor="#ffffff" align="center" style="padding: 20px 30px 60px 30px;">
                                            <table border="0" cellspacing="0" cellpadding="0">
                                                <tr>
                                                    <td align="center" style="border-radius: 3px;" bgcolor="#1E73B6"><a href="'.$local.'accountactivation.php?token='.$nActivationNum.'" target="_blank" style="font-size: 20px; font-family: Helvetica, Arial, sans-serif; color: #ffffff; text-decoration: none; color: #ffffff; text-decoration: none; padding: 15px 25px; border-radius: 2px; border: 1px solid #1E73B6; display: inline-block;">Activate</a></td>
                                                </tr>
                                            </table>
                                        </td>
                                    </tr>
                                </table>
                            </td>
                        </tr> 
                        <tr>
                            <td bgcolor="#ffffff" align="left" style="padding: 0px 30px 0px 30px; color: #666666; font-size: 16px; font-weight: 400; line-height: 25px;">
                                <p style="margin: 0;">Happy Testing ><br/>

    TestCalibre Team,

    </p>
                            </td>
                        </tr> 
                        <tr>
                            <td bgcolor="#ffffff" align="left" style="padding: 20px 30px 20px 30px; color: #666666;  font-size: 16px; font-weight: 400; line-height: 25px;">
                                <p style="margin: 0;"><a href="http://localhost/SOSA/step-tool/" target="_blank" style="color: #1E73B6;">testcalibreuat.ratnakarbank.in</a></p>
                            </td>
                        </tr>
                       <tr>
                            <td bgcolor="#ffffff" align="center" style="padding: 30px 30px 30px 30px; border-radius: 4px 4px 4px 4px; color: #666666;  font-size: 18px; font-weight: 400; line-height: 25px;">
                                <h2 style="font-size: 13px; font-weight: 400; color: #1E73B6; margin: 0;">STEP one step ahead<br/>
<!--
    B Wing, Shah Industrial Estate, Andheri (East ), Mumbai, Maharashtra, India</h2>
                                <p style="margin: 0;">
                                <a href="https://www.uipath.com/legal/privacy-policy" target="_blank"  style="font-size: 13px; font-weight: 400; color: #666666; margin: 0;">Privacy Policy</a>
                                | 
                                <a href="https://www.uipath.com/company/contact-us" target="_blank"  style="font-size: 13px; font-weight: 400; color: #666666; margin: 0;">Contact Us</a>
                                </p>
                                <table border="0" cellspacing="0" cellpadding="0" align="center" style="margin-top: 20px;">
                        <tbody><tr>
                            <td valign="top"><a href="https://www.facebook.com/UiPath" target="_blank" style="text-decoration:none;"><img src="https://www.testcalibre.com/images/fb.png" width="26" height="26" style="display:block;font-family: Arial, sans-serif; font-size:10px; line-height:18px; color:#feae39; " border="0" alt="Fb"></a></td>
                            <td width="7">&nbsp;</td>
                            <td valign="top"><a href="https://twitter.com/UiPath" target="_blank" style="text-decoration:none;"><img src="https://www.testcalibre.com/images/twitter.png" width="26" height="26" style="display:block;font-family: Arial, sans-serif; font-size:10px; line-height:18px; color:#feae39; " border="0" alt="Tw"></a></td>
                            <td width="7">&nbsp;</td>
                            <td valign="top"><a href="#" target="_blank" style="text-decoration:none;"><img src="https://www.testcalibre.com/images/linkedin.png" width="26" height="26" style="display:block;font-family: Arial, sans-serif; font-size:10px; line-height:18px; color:#feae39; " border="0" alt="linkedin"></a></td>
                            <td width="7">&nbsp;</td>
                            <td valign="top"><a href="https://www.youtube.com/user/UiPath" target="_blank" style="text-decoration:none;"><img src="https://www.testcalibre.com/images/youtube.png" width="26" height="26" style="display:block;font-family: Arial, sans-serif; font-size:10px; line-height:18px; color:#feae39; " border="0" alt="Yt"></a></td>
                            </tr> -->
                        </tbody>
                    </table>
                            </td>
                        </tr>
                        
                    </table>
                </td>
            </tr>
            
        </table>
    </body>

    </html>';


   // $mail->Username   = "$e_username";  // GMAIL username
   // $mail->Password   = "$e_password"     ;       // GMAIL password


    // $mail->AddReplyTo('test@gmail.com', 'Dipika');


    $mail->AddAddress(trim($emailid));
    // $mail->Subject    = "Daily Status Report -".$dsrdate;
    $mail->Subject    = "$subject";

    $mail->AltBody    = "To view the message, please use an HTML compatible email viewer!"; // optional, comment out and test

    $mail->MsgHTML($body);

    if(!$mail->Send()) {
        return 1;
    // echo "Mailer Error: " . $mail->ErrorInfo;
    } else {
        return 0;
    // echo "Message sent!";
    }


}

echo json_encode($msgarr);
?>
