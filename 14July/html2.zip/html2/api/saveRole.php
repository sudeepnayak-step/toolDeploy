<?php
header('Access-Control-Allow-Origin: *');
include('config.php');

$msgarr = array();
$msgarr["status"] = "Error";
$msgarr["message"] = "Something went wrong. Please try again.";

$enteredby = (isset($_POST["enteredby"]) && !empty($_POST["enteredby"]) ? $_POST["enteredby"] : 0);
$accountId = (isset($_POST["accountId"]) && !empty($_POST["accountId"]) ? $_POST["accountId"] : 0);
$userempid = (isset($_POST["userempid"]) && !empty($_POST["userempid"])  ? $_POST["userempid"] : 0);

if($_SERVER['REQUEST_METHOD'] === 'POST'){

$id = (isset($_POST['roleId']) ? $_POST['roleId'] : "0");
$rolename = (isset($_POST['rolename']) ? sanitize($_POST['rolename']) : "");
$activestatus = (isset($_POST['activestatus']) ? $_POST['activestatus'] : "");

if (!empty($id) && $id != "0") {
	// Update query using prepared statements
	$sql = "UPDATE s_role SET s_role_name = ?, s_role_activestatus = ? WHERE s_role_id = ? AND accountId = ?";
	$stmt = mysqli_prepare($conn, $sql);
	if ($stmt) {
		mysqli_stmt_bind_param($stmt, "sssi", $rolename, $activestatus, $id, $accountId);
		mysqli_stmt_execute($stmt);

		if (mysqli_stmt_affected_rows($stmt) > 0) {
			$msgarr["status"] = "Success";
			$msgarr["message"] = "User  role updated successfully.";
		} else {
			$msgarr["status"] = "Error";
			$msgarr["message"] = "No changes made or role not found.";
		}
		mysqli_stmt_close($stmt);
	} else {
		$msgarr["status"] = "Error";
		$msgarr["message"] = "Database error. Please try again.";
	}
} else {
	// Insert query using prepared statements
	$sql = "INSERT INTO s_role (s_role_name, s_role_activestatus, accountId, s_role_enteredby) VALUES (?, ?, ?, ?)";
	$stmt = mysqli_prepare($conn, $sql);
	if ($stmt) {
		mysqli_stmt_bind_param($stmt, "ssii", $rolename, $activestatus, $accountId, $enteredby);
		mysqli_stmt_execute($stmt);

		if (mysqli_stmt_affected_rows($stmt) > 0) {
			$msgarr["status"] = "Success";
			$msgarr["message"] = "User  role added successfully.";
		} else {
			$msgarr["status"] = "Error";
			$msgarr["message"] = "Failed to add user role.";
		}
		mysqli_stmt_close($stmt);
	} else {
		$msgarr["status"] = "Error";
		$msgarr["message"] = "Database error. Please try again.";
	}
}
}

echo json_encode($msgarr);
?>
