<?php
include('config.php');
session_start();
 
$enteredby = 0;$accountId = 0;
/** delete the project with its dependencies */ 

if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
}

$msgarr = array();
if($_SERVER['REQUEST_METHOD'] === 'POST'){

$id = (isset($_POST['id']) && !empty($_POST['id']) ? $_POST['id'] : "0");

if(!empty($id) && $id !="0") {


$sql = "DELETE FROM s_project WHERE s_p_id = ? AND accountId = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "ss", $id, $accountId);
mysqli_stmt_execute($stmt);
if($stmt)
	{
		$msgarr["status"] = "Success";
		$msgarr["message"] = "Project deleted successfully.";

		$sql1 = "DELETE FROM s_project_members  where projectId = '".$id."' and accountId = '".$accountId."' ";
		$stmt1 = mysqli_query( $conn, $sql1);

		$sql2 = "DELETE FROM s_defect  where projectId = '".$id."' and accountId = '".$accountId."' ";
		$stmt2 = mysqli_query( $conn, $sql2);

		$sql3 = "DELETE FROM s_release  where projectId = '".$id."' and accountId = '".$accountId."' ";
		$stmt3 = mysqli_query( $conn, $sql3);

		$sql3 = "DELETE FROM s_project_activity  where projectId = '".$id."' and accountId = '".$accountId."' ";
		$stmt3 = mysqli_query( $conn, $sql3);

		$sql4 = "DELETE FROM s_rtm_testcase  where rtmId in (select s_rtm_id from s_rtm  where projectId = '".$id."' and accountId = '".$accountId."') and accountId = '".$accountId."' ";
		$stmt4 = mysqli_query( $conn, $sql4);

		$sql4 = "DELETE FROM s_rtm  where projectId = '".$id."' and accountId = '".$accountId."' ";
		$stmt4 = mysqli_query( $conn, $sql4);


		$sql4 = "DELETE FROM s_testcaserun  where testcaseId in (select s_t_id from s_testcase  where projectId = '".$id."' and accountId = '".$accountId."') and accountId = '".$accountId."' ";
		$stmt4 = mysqli_query( $conn, $sql4);


		$sql4 = "DELETE FROM s_testexecution  where testcaseId in (select s_t_id from s_testcase  where projectId = '".$id."' and accountId = '".$accountId."') and accountId = '".$accountId."' ";
		$stmt4 = mysqli_query( $conn, $sql4);
		
		$sql5 = "DELETE FROM s_testsuite  where projectId = '".$id."' and accountId = '".$accountId."' ";
		$stmt5 = mysqli_query( $conn, $sql5);

		$sql6 = "DELETE FROM s_testcasefinal  where projectId = '".$id."' and accountId = '".$accountId."' ";
		$stmt6 = mysqli_query( $conn, $sql6);

		$sql7 = "DELETE FROM s_testcase  where projectId = '".$id."' and accountId = '".$accountId."' ";
		$stmt7 = mysqli_query( $conn, $sql7);

		$target = STEP_dir."attachments/".$accountId."/project/".$id."/";
                    // echo $dir;
        if(is_dir($target)){
	        $files = glob( $target . '*', GLOB_MARK ); //GLOB_MARK adds a slash to directories returned

	        foreach( $files as $file ){
	            unlink( $file );    
	        }

	        rmdir( $target );
	    } elseif(is_file($target)) {
	        unlink( $target );  
	    }
	}
	else
	{
		$msgarr["status"] = "Error";
		$msgarr["message"] = "Something went wrong. Please try again.";
	}
}
}
echo json_encode($msgarr);