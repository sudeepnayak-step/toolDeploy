<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
include('config.php');
session_start();
 
$enteredby = 0;$accountId=0;$userempid = 0;
/** This PHP script retrieves the testcase data from a database. 
 * It formats the data and returns it in JSON format. */


if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
    $userempid = $_SESSION["userempid"];
}


$projectId = (isset($_POST['projectId']) ? $_POST['projectId'] : "0");
$releaseId = (isset($_POST['releaseId']) ? $_POST['releaseId'] : "0");
$activityId = (isset($_POST['activityId']) ? $_POST['activityId'] : "0");
$testcaseId = (isset($_POST['testcaseId']) ? $_POST['testcaseId'] : "0");
$testsuiteId = (isset($_POST['testsuiteId']) ? $_POST['testsuiteId'] : "0");
$type = (isset($_POST['type']) ? $_POST['type'] : "");
$rtmId = (isset($_POST['rtmId']) ? $_POST['rtmId'] : "0");
$module = (isset($_POST['module']) ? $_POST['module'] : "");
$where = "";
if($projectId !="0" && $projectId !=""){
	$where = " AND tc.projectId  = '".$projectId."' ";
}
if($releaseId !="0" && $releaseId !=""){
	if($where == ""){
		$where = " AND tc.releaseId  = '".$releaseId."' ";
	}else{
		$where .=" and tc.releaseId  = '".$releaseId."' ";
	}
}

if($activityId !="0" && $activityId !=""){
	if($where == ""){
		$where = " AND find_in_set('".$activityId."',s_t_activityIds)  ";
	}else{
		$where .=" and find_in_set('".$activityId."',s_t_activityIds) ";
	}
}
if($module !="0" && $module !=""){
	if($where == ""){
		$where = " AND tc.s_t_module  = '".$module."' ";
	}else{
		$where .=" and tc.s_t_module  = '".$module."' ";
	}
}

if($testcaseId !="0" && $testcaseId !=""){
	if($where == ""){
		$where = " AND tc.s_t_id  = '".$testcaseId."' ";
	}else{
		$where .=" and tc.s_t_id  = '".$testcaseId."' ";
	}
}

if($type !="0" && $type !=""){
	if($where == ""){
		$where = " AND tc.s_t_testmode  = '".$type."' ";
	}else{
		$where .=" and tc.s_t_testmode  = '".$type."' ";
	}
}
if($testsuiteId !="0" && $testsuiteId !=""){
		$where .= " AND tc.s_t_id  not in (select testcaseId from s_testexecution where testsuiteId =  '".$testsuiteId."' and accountId='".$accountId."'  )";
}

if($rtmId !="0" && $rtmId !=""){
		$where .= " AND tc.s_t_id  not in (select testcaseId from s_rtm_testcase where rtmId =  '".$rtmId."' and accountId='".$accountId."' )";
}

// $where = "";
if(isset($_SESSION["usertype"]) && $_SESSION["usertype"] != "Admin"){
	if($where == ""){
		$where = " AND tc.projectId in (select s_p_id from s_project where s_p_id in (select projectId from s_project_members where employeeId = '".$userempid."' ) or s_p_enteredby = '".$enteredby."' )";
	}else{
		$where .= " and tc.projectId in (select s_p_id from s_project where s_p_id in (select projectId from s_project_members where employeeId = '".$userempid."' ) or s_p_enteredby = '".$enteredby."' )";
	}
}

$sql = "SELECT tc.*,
concat(IFNULL(a1.s_e_fname,''),' ',IFNULL(a1.s_e_mname,''),' ',IFNULL(a1.s_e_lname,'')) as assignto,
concat(IFNULL(a2.s_e_fname,''),' ',IFNULL(a2.s_e_mname,''),' ',IFNULL(a2.s_e_lname,'')) as author,
concat(IFNULL(a3.s_e_fname,''),' ',IFNULL(a3.s_e_mname,''),' ',IFNULL(a3.s_e_lname,'')) as reviewer,
IFNULL(p.s_p_name,'') as projectname,
IFNULL(r.s_r_name,'') as releaseNum,
IFNULL(c.s_cat_name,'') as categoryname 
from s_testcase tc 
join s_project p on p.s_p_id = tc.projectId 
join s_release r on r.s_r_id = tc.releaseId  
left join s_tccategorymaster c on c.s_cat_id = tc.s_t_category 
left JOIN s_employees a1 on a1.s_e_id = tc.s_t_assignto and tc.s_t_assignto !='0'
left JOIN s_employees a2 on a2.userId = tc.s_t_author and tc.s_t_author !='0'
left JOIN s_employees a3 on a3.s_e_id = tc.s_t_reviewer and tc.s_t_author !='0' 
where tc.accountId = ? ".$where."  
order by tc.s_t_id asc";
//echo $sql;die;
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $accountId);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$projarr['data'] = array();
while($data = mysqli_fetch_assoc($result)){

	$activityname = "";
	if($data['s_t_activityIds'] !=""){
		
		$activityIds = mysqli_real_escape_string($conn, $data['s_t_activityIds']);
		$chksql = "SELECT IFNULL(GROUP_CONCAT(s_a_name),'') AS activityname FROM s_activitymaster WHERE s_a_id IN ($activityIds) AND accountId = ?";
		$chkstmt = mysqli_prepare($conn, $chksql);
		mysqli_stmt_bind_param($chkstmt, "i", $accountId);
		mysqli_stmt_execute($chkstmt);
		$chkresult = mysqli_stmt_get_result($chkstmt);

		while($actdata = mysqli_fetch_assoc($chkresult)){
			$activityname = $actdata['activityname'];
		}
		mysqli_stmt_close($chkstmt);
	}

	$author = "Admin";
	if(trim($data['author']) !=""){
		$author = $data['author'];
	}
	$projarr['data'][] = array($data['s_t_id'],$data['s_t_testcasenum'],$data['s_t_testscenarionum'],$data['projectname'],$data['releaseNum'],$activityname,$data['s_t_testmode'],$data['s_t_module'],$data['s_t_submodule'],		
		$data['assignto'],
		$author,
		$data['reviewer'],
		$data['s_t_testcasedesc'],
		$data['s_t_testscenariodesc'],
		$data['s_t_steps'],
		$data['s_t_expectedresult'],
		$data['s_t_precondition'],
		$data['s_t_testdata'],
		$data['s_t_comment'],
		$data['categoryname'],
		$data['s_t_id']);
}
mysqli_stmt_close($stmt);

echo json_encode($projarr);
?>
