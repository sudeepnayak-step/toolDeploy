<?php
header('Access-Control-Allow-Origin: *');
include('config.php');
// session_start();
/** delete master table records based on id  */ 
$enteredby = 0;$accountId = 0;
 
$enteredby = (isset($_POST["enteredby"]) && !empty($_POST["enteredby"]) ? $_POST["enteredby"] : 0);
$accountId = (isset($_POST["accountId"]) && !empty($_POST["accountId"]) ? $_POST["accountId"] : 0);
$userempid = (isset($_POST["userempid"]) && !empty($_POST["userempid"])  ? $_POST["userempid"] : 0);
$msgarr = array();


if($_SERVER['REQUEST_METHOD'] === 'POST'){

$id = (isset($_POST['id']) ? $_POST['id'] : "0");
$formtype = isset($_POST['formtype']) ? $_POST['formtype'] :"";

if(!empty($id) && $id !="0") {


	if($formtype == "Ticket"){

		$sql = "DELETE FROM s_tickets WHERE s_t_id = ? AND accountId = ?";
		$stmt = mysqli_prepare($conn, $sql);
		mysqli_stmt_bind_param($stmt, "ss", $id, $accountId);
		mysqli_stmt_execute($stmt);
		if($stmt)
		{
			$msgarr["status"] = "Success";
			$msgarr["message"] = "Ticket deleted successfully.";
		}
		else
		{
			$msgarr["status"] = "Error";
			$msgarr["message"] = "Something went wrong. Please try again.";
		}
	}else if($formtype == "Activity"){

	$sql = "DELETE FROM s_activitymaster WHERE s_a_id = ? AND accountId = ?";
	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "ss", $id, $accountId);
	mysqli_stmt_execute($stmt);
	if($stmt)
	{
		$msgarr["status"] = "Success";
		$msgarr["message"] = "Activity deleted successfully.";
	}
	else
	{
		$msgarr["status"] = "Error";
		$msgarr["message"] = "Something went wrong. Please try again.";
	}
}else if($formtype == "Client"){

	$sql = "DELETE FROM s_client WHERE s_c_id = ? AND accountId = ?";
	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "ss", $id, $accountId);
	mysqli_stmt_execute($stmt);
	if($stmt)
	{
		$msgarr["status"] = "Success";
		$msgarr["message"] = "Client deleted successfully.";
	}
	else
	{
		$msgarr["status"] = "Error";
		$msgarr["message"] = "Something went wrong. Please try again.";
	}
}else if($formtype == "DefectStatus"){

	$sql = "DELETE FROM s_defectstatusmaster WHERE s_ds_id = ? AND accountId = ?";
	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "ss", $id, $accountId);
	mysqli_stmt_execute($stmt);
	if($stmt)
	{
		$msgarr["status"] = "Success";
		$msgarr["message"] = "Defect status deleted successfully.";
	}
	else
	{
		$msgarr["status"] = "Error";
		$msgarr["message"] = "Something went wrong. Please try again.";
	}
}else if($formtype == "DefectType"){

	$sql = "DELETE FROM s_defecttypemaster WHERE s_dt_id = ? AND accountId = ?";
	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "ss", $id, $accountId);
	mysqli_stmt_execute($stmt);
	if($stmt)
	{
		$msgarr["status"] = "Success";
		$msgarr["message"] = "Defect type deleted successfully.";
	}
	else
	{
		$msgarr["status"] = "Error";
		$msgarr["message"] = "Something went wrong. Please try again.";
	}
}else if($formtype == "TCCategory"){

	$sql = "DELETE FROM s_tccategorymaster WHERE s_cat_id = ? AND accountId = ?";
	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "ss", $id, $accountId);
	mysqli_stmt_execute($stmt);
	if($stmt)
	{
		$msgarr["status"] = "Success";
		$msgarr["message"] = "Cateogry deleted successfully.";
	}
	else
	{
		$msgarr["status"] = "Error";
		$msgarr["message"] = "Something went wrong. Please try again.";
	}
}else if($formtype == "RuleModule"){
	$sql = "DELETE FROM s_rule_module WHERE s_rm_id = ? ";
	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "s", $id);
	mysqli_stmt_execute($stmt);
	if($stmt)
	{
		$msgarr["status"] = "Success";
		$msgarr["message"] = "Rule module deleted successfully.";
	}
	else
	{
		$msgarr["status"] = "Error";
		$msgarr["message"] = "Something went wrong. Please try again.";
	}
}else if($formtype == "BasicRules"){

	$sql = "DELETE FROM s_basic_rules WHERE s_br_id = ? ";
	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "s", $id);
	mysqli_stmt_execute($stmt);
	if($stmt)
	{
		$msgarr["status"] = "Success";
		$msgarr["message"] = "Rule deleted successfully.";
	}
	else
	{
		$msgarr["status"] = "Error";
		$msgarr["message"] = "Something went wrong. Please try again.";
	}
}else if($formtype == "Role"){

	$sql = "DELETE FROM s_role WHERE s_role_id = ? and accountId = ?";
	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "ss", $id,$accountId);
	mysqli_stmt_execute($stmt);
	if($stmt)
	{
		$msgarr["status"] = "Success";
		$msgarr["message"] = "Role deleted successfully.";
	}
	else
	{
		$msgarr["status"] = "Error";
		$msgarr["message"] = "Something went wrong. Please try again.";
	}
}else if($formtype == "Holiday"){

	$sql = "DELETE FROM s_holiday_master WHERE s_h_id = ? and accountId = ?";
	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "ss", $id,$accountId);
	mysqli_stmt_execute($stmt);
	if($stmt)
	{
		$msgarr["status"] = "Success";
		$msgarr["message"] = "Holiday deleted successfully.";
	}
	else
	{
		$msgarr["status"] = "Error";
		$msgarr["message"] = "Something went wrong. Please try again.";
	}
}else if($formtype == "Chart"){

	$sql = "DELETE FROM s_chartsetting WHERE s_c_id = ? and accountId = ?";
	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "ss", $id,$accountId);
	mysqli_stmt_execute($stmt);
	if($stmt)
	{
		$msgarr["status"] = "Success";
		$msgarr["message"] = "Chart setting deleted successfully.";
	}
	else
	{
		$msgarr["status"] = "Error";
		$msgarr["message"] = "Something went wrong. Please try again.";
	}
}else if($formtype == "ProjetEmailSetting"){

	$sql = "DELETE FROM s_projemailsetting WHERE s_projes_id = ? and accountId = ?";
	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "ss", $id,$accountId);
	mysqli_stmt_execute($stmt);
	if($stmt)
	{
		$msgarr["status"] = "Success";
		$msgarr["message"] = "Email setting deleted successfully.";
	}
	else
	{
		$msgarr["status"] = "Error";
		$msgarr["message"] = "Something went wrong. Please try again.";
	}
}

}
}
echo json_encode($msgarr);