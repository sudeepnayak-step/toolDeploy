<?php
header('Access-Control-Allow-Origin: *');
include('config.php');
session_start();

// Sanitize and validate inputs
//$enteredby = isset($_POST["enteredby"]) ? intval($_POST["enteredby"]) : 0;
//$accountId = isset($_POST["accountId"]) ? intval($_POST["accountId"]) : 0;
//$userempid = isset($_POST["userempid"]) ? intval($_POST["userempid"]) : 0;


$userempid = 0;$accountId = 0;$enteredby =0;
 
if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
}
 
if(isset($_SESSION["usertype"]) && $_SESSION["usertype"] == "Employee"){
    if(isset($_SESSION["userempid"])){
    $userempid = $_SESSION["userempid"];
}
}
/** This PHP script handles various types of form requests (formtype) 
 * and retrieves data from the database based on the provided inputs. 
 * It returns the data in JSON format */

$projarr['data'] = array();
$formtype = isset($_POST['formtype']) ? $_POST['formtype'] :"";

if($formtype == "Ticket"){
	$where = "";
	if(isset($_SESSION["usertype"]) && $_SESSION["usertype"] != "Admin" && $_SESSION["usertype"] != "Systemuser"){
		$where .= " and t.s_t_enteredby = '".$enteredby."' ";
	}else if(isset($_SESSION["usertype"]) && $_SESSION["usertype"] == "Admin"){
		$where .= " and t.accountId = '".$accountId."' ";
	}
	$query = "SELECT t.*,CONCAT(IFNULL(a1.s_e_fname,''),' ',IFNULL(a1.s_e_mname,''),' ',IFNULL(a1.s_e_lname,'')) as raisedby 
	FROM s_tickets t 
	LEFT JOIN s_employees a1 ON a1.userId = t.s_t_enteredby 
	WHERE t.s_t_id !=0 $where ORDER BY t.s_t_id DESC";
	// echo $query;
    $stmt = mysqli_prepare($conn, $query);
    // mysqli_stmt_bind_param($stmt, "i", $accountId);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

	while($data = mysqli_fetch_assoc($result)){
		$createdat = (isset($data['s_t_createdtime']) && ($data['s_t_createdtime'] != "0000-00-00 00:00:00") ? date("d/m/Y H:i a",strtotime($data['s_t_createdtime'])) : "");
		$updatedat = (isset($data['s_t_updatetime']) && ($data['s_t_updatetime'] != "0000-00-00 00:00:00") ? date("d/m/Y H:i a",strtotime($data['s_t_updatetime'])) : "");
		
		// $replyFLag = 0;			
		// if(isset($_SESSION["usertype"]) && $_SESSION["usertype"] == "Systemuser" && $data['s_t_status'] !="Closed"){
		// 	if($data['s_t_assigned_to'] == $enteredby){
		// 		$replyFLag = 1;
		// 	}

		// }

		$replyFLag = 0;			
		if (isset($_SESSION["usertype"]) && $_SESSION["usertype"] == "Systemuser" && $data['s_t_status'] != "2") {
			if ($data['s_t_assigned_to'] == $enteredby) {
				$replyFLag = 1;
			}
		}

		$projarr['data'][] = array($data['s_t_id'],$data['s_t_number'],$data['s_t_problem'],$data['s_t_module'],$data['s_t_description'],
			$data['raisedby'],
			$createdat,$updatedat,$replyFLag,
			$data['s_t_status'],
			$data['s_t_id']
		);
	}
}else if($formtype == "Activity"){
	$query = "SELECT * FROM s_activitymaster WHERE accountId = ? ORDER BY s_a_id DESC";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "i", $accountId);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

	while($data = mysqli_fetch_assoc($result)){
		$projarr['data'][] = array($data['s_a_id'],$data['s_a_name'],$data['s_a_code'],$data['s_a_type'],
			$data['s_a_activestatus'],$data['s_a_id']);
	}
}else if($formtype == "Client"){
	$query = "SELECT * FROM s_client WHERE accountId = ? ORDER BY s_c_id DESC";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "i", $accountId);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

	while($data = mysqli_fetch_assoc($result)){
		$projarr['data'][] = array($data['s_c_id'],$data['s_c_name'],$data['s_c_activestatus'],$data['s_c_id']);
	}
}else if($formtype == "DefectStatus"){
	$query = "SELECT * FROM s_defectstatusmaster WHERE accountId = ? ORDER BY s_ds_id DESC";
	$stmt = mysqli_prepare($conn, $query);
	mysqli_stmt_bind_param($stmt, "i", $accountId);
	mysqli_stmt_execute($stmt);
	$result = mysqli_stmt_get_result($stmt);

	while ($data = mysqli_fetch_assoc($result)) {
		$projarr['data'][] = array($data['s_ds_id'],$data['s_ds_name'],$data['s_ds_activestatus'],$data['s_ds_id']);
	}
}else if($formtype == "DefectType"){
	$query = "SELECT * FROM s_defecttypemaster WHERE accountId = ? ORDER BY s_dt_id DESC";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "i", $accountId);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    while ($data = mysqli_fetch_assoc($result)) {
		$projarr['data'][] = array($data['s_dt_id'],$data['s_dt_name'],$data['s_dt_activestatus'],$data['s_dt_id']);
	}
}else if($formtype == "TCCategory"){
	$query = "SELECT * FROM s_tccategorymaster WHERE accountId = ? ORDER BY s_cat_id DESC";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "i", $accountId);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

	while($data = mysqli_fetch_assoc($result)){
		$projarr['data'][] = array($data['s_cat_id'],$data['s_cat_name'],$data['s_cat_activestatus'],$data['s_cat_id']);
	}
}else if($formtype == "RuleModule"){
	$query = "SELECT * FROM s_rule_module ORDER BY s_rm_id DESC";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    while ($data = mysqli_fetch_assoc($result)) {
		$projarr['data'][] = array($data['s_rm_id'],$data['s_rm_name'],$data['s_rm_activestatus'],$data['s_rm_id']);
	}
}else if($formtype == "BasicRules"){
	$query = "SELECT b.*, IFNULL(s_rm_name, '') as modulename FROM s_basic_rules b JOIN s_rule_module m ON m.s_rm_id = b.moduleId ORDER BY s_br_id DESC";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    while ($data = mysqli_fetch_assoc($result)) {
		$projarr['data'][] = array($data['s_br_id'],$data['modulename'],$data['s_br_name'],$data['s_br_activestatus'],$data['s_br_id']);
	}
}else if($formtype == "Role"){
	$query = "SELECT * FROM s_role WHERE accountId = ? ORDER BY s_role_id DESC";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "i", $accountId);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    while ($data = mysqli_fetch_assoc($result)) {
		$projarr['data'][] = array($data['s_role_id'],$data['s_role_name'],'Permission',$data['s_role_activestatus'],$data['s_role_id']);
	}
}else if($formtype == "Holiday"){

	$clientId = isset($_POST["clientId"]) ? intval($_POST["clientId"]) : 0;
    $query = "SELECT * FROM s_holiday_master WHERE accountId = ? AND clientId = ? ORDER BY s_h_id DESC";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "ii", $accountId, $clientId);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    while ($data = mysqli_fetch_assoc($result)) {
		$hdate = (isset($data['s_h_date']) && ($data['s_h_date'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_h_date'])) : "");
		$projarr['data'][] = array($data['s_h_id'],$data['s_h_name'],$hdate,$data['s_h_activestatus'],$data['s_h_id']);
	}
}else if($formtype == "Chart"){
	$query = "SELECT * FROM s_chartsetting WHERE accountId = ? AND s_c_enteredby = ? ORDER BY s_c_id DESC";
	//echo $query." ".$accountId." ".$enteredby;
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "ii", $accountId, $enteredby);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    while ($data = mysqli_fetch_assoc($result)) {
		$xaxis = "";$yaxis = "";
		if($data['s_c_tablename'] == "Project"){
			switch ($data['s_c_xaxis']) {
				case 's_p_name':
					$xaxis = "Project Name";
					break;
				case 's_p_code':
					$xaxis = "Project Code";
					break;
				case 's_p_status':
					$xaxis = "Project Status";
					break;
				case 's_p_owner':
					$xaxis = "Project Owner";
					break;
				case 'clientId':
					$xaxis = "Project Client";
					break;
				case 's_p_ragstatus':
					$xaxis = "RAG Status";
					break;	
			}
			switch ($data['s_c_yaxis']) {
				case 's_p_name':
					$yaxis = "Project Name";
					break;
				case 's_p_code':
					$yaxis = "Project Code";
					break;
				case 's_p_status':
					$yaxis = "Project Status";
					break;
				case 's_p_owner':
					$yaxis = "Project Owner";
					break;
				case 'clientId':
					$yaxis = "Project Client";
					break;
				case 's_p_ragstatus':
					$yaxis = "RAG Status";
					break;	
			}
		}else if($data['s_c_tablename'] == "Defect"){
			switch ($data['s_c_xaxis']) {
				case 'projectId':
					$xaxis = "Project Name";
					break;
				case 'releaseId':
					$xaxis = "Release ID";
					break;
				case 'testcaseId':
					$xaxis = "Testcase ID";
					break;
				case 's_d_defectnum':
					$xaxis = "Defect ID";
					break;
				case 'clientId':
					$xaxis = "Project Client";
					break;
				case 's_d_module':
					$xaxis = "Module";
					break;
				case 's_d_submodule':
					$xaxis = "Submodule";
					break;	
				case 'defecttypeId':
					$xaxis = "Defect Type";
					break;	
				case 's_d_severity':
					$xaxis = "Severity";
					break;	
				case 's_d_priority':
					$xaxis = "Priority";
					break;	
				case 'defectstatusId':
					$xaxis = "Defect Status";
					break;	
				case 's_d_assignto':
					$xaxis = "Assign To";
					break;	
				case 's_d_reportedby':
					$xaxis = "Reported By";
					break;		
			}
			switch ($data['s_c_yaxis']) {
				case 'projectId':
					$yaxis = "Project Name";
					break;
				case 'releaseId':
					$yaxis = "Release ID";
					break;
				case 'testcaseId':
					$yaxis = "Testcase ID";
					break;
				case 's_d_defectnum':
					$yaxis = "Defect ID";
					break;
				case 'clientId':
					$yaxis = "Project Client";
					break;
				case 's_d_module':
					$yaxis = "Module";
					break;
				case 's_d_submodule':
					$yaxis = "Submodule";
					break;	
				case 'defecttypeId':
					$yaxis = "Defect Type";
					break;	
				case 's_d_severity':
					$yaxis = "Severity";
					break;	
				case 's_d_priority':
					$yaxis = "Priority";
					break;	
				case 'defectstatusId':
					$yaxis = "Defect Status";
					break;	
				case 's_d_assignto':
					$yaxis = "Assign To";
					break;	
				case 's_d_reportedby':
					$yaxis = "Reported By";
					break;		
			}
		}else if($data['s_c_tablename']=="Test Execution"){
			$xaxis = $data['s_c_xaxis'];
			$yaxis = $data['s_c_yaxis'];
		}

		$projarr['data'][] = array($data['s_c_id'],$data['s_c_title'],$data['s_c_subtitle'],$data['s_c_charttype'],$data['s_c_tablename'],$xaxis,$yaxis,$data['s_c_type'],$data['s_c_activestatus'],$data['s_c_id']);
	}
}else if($formtype == "Audit Logs"){
	$srno=0;
	$query = "SELECT a.*, CONCAT(IFNULL(enteredbyTBl.s_e_fname, ''), ' ', IFNULL(enteredbyTBl.s_e_mname, ''), ' ', IFNULL(enteredbyTBl.s_e_lname, '')) as entered_by FROM s_auditlogs a LEFT JOIN s_employees as enteredbyTBl ON enteredbyTBl.userId = a.s_a_enteredby WHERE a.accountId = ? ORDER BY a.s_a_id DESC";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "i", $accountId);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    while ($data = mysqli_fetch_assoc($result)) {

		$entered_by = (trim($data['entered_by'])  == "" ? "Admin" : $data['entered_by'] );

		$hdate = (isset($data['s_a_createdtime']) && ($data['s_a_createdtime'] != "0000-00-00 00:00:00") ? date("d/m/Y H:i a",strtotime($data['s_a_createdtime'])) : "");
		$recordNum = "";

		switch ($data['s_a_module']) {
			case 'Defect':
				$numsqldata = mysqli_prepare($conn, "SELECT IFNULL(s_d_defectnum, '') as recordnum FROM s_defect WHERE accountId = ? AND s_d_id = ?");
                mysqli_stmt_bind_param($numsqldata, "ii", $accountId, $data['s_a_recordId']);
                mysqli_stmt_execute($numsqldata);
                $numresult = mysqli_stmt_get_result($numsqldata);
                while ($numdata = mysqli_fetch_assoc($numresult)) {
                	$recordNum = '<a href="'.STEP_root.'master/defectdetails.php?id='.$data['s_a_recordId'].'" class="text-step"><b>'.$numdata['recordnum'].'</b> </a>';
				}

				break;
			case 'Project':
				$numsqldata = mysqli_prepare($conn, "SELECT IFNULL(s_p_code, '') as recordnum FROM s_project WHERE accountId = ? AND s_p_id = ?");
                mysqli_stmt_bind_param($numsqldata, "ii", $accountId, $data['s_a_recordId']);
                mysqli_stmt_execute($numsqldata);
                $numresult = mysqli_stmt_get_result($numsqldata);
                while ($numdata = mysqli_fetch_assoc($numresult)) {
					$recordNum = '<a href="'.STEP_root.'master/projects.php" class="text-step"><b>'.$numdata['recordnum'].'</b> </a>';
				}

				break;
			case 'Release':
				$numsqldata = mysqli_prepare($conn, "SELECT IFNULL(s_r_releaseId, '') as recordnum FROM s_release WHERE accountId = ? AND s_r_id = ?");
                mysqli_stmt_bind_param($numsqldata, "ii", $accountId, $data['s_a_recordId']);
                mysqli_stmt_execute($numsqldata);
                $numresult = mysqli_stmt_get_result($numsqldata);
                while ($numdata = mysqli_fetch_assoc($numresult)) {
				
					$recordNum = '<a href="'.STEP_root.'master/release.php" class="text-step"><b>'.$numdata['recordnum'].'</b> </a>';
				}

				break;
			case 'Project Activity':
				$numsqldata = mysqli_prepare($conn, "SELECT IFNULL(a.s_a_name, '') as recordnum FROM s_project_activity pa 
				join s_activitymaster a on a.s_a_id = pa.activityId   where pa.accountId  = ? AND pa.s_pa_id = ?");
                mysqli_stmt_bind_param($numsqldata, "ii", $accountId, $data['s_a_recordId']);
                mysqli_stmt_execute($numsqldata);
                $numresult = mysqli_stmt_get_result($numsqldata);
                while ($numdata = mysqli_fetch_assoc($numresult)) {
				
					$recordNum = '<a href="'.STEP_root.'master/activity.php" class="text-step"><b>'.$numdata['recordnum'].'</b> </a>';
				}

				break;
			case 'Testcase':
				$numsqldata = mysqli_prepare($conn, "SELECT IFNULL(s_t_testcasenum, '') as recordnum FROM s_testcase WHERE accountId = ? AND s_t_id = ?");
                mysqli_stmt_bind_param($numsqldata, "ii", $accountId, $data['s_a_recordId']);
                mysqli_stmt_execute($numsqldata);
                $numresult = mysqli_stmt_get_result($numsqldata);
                while ($numdata = mysqli_fetch_assoc($numresult)) {
				
					$recordNum = '<a href="'.STEP_root.'master/testcase.php" class="text-step"><b>'.$numdata['recordnum'].'</b> </a>';
				}

				break;
			case 'Testsuite':
				$numsqldata = mysqli_prepare($conn, "SELECT IFNULL(s_ts_testsuitenum, '') as recordnum FROM s_testsuite WHERE accountId = ? AND s_ts_id = ?");
                mysqli_stmt_bind_param($numsqldata, "ii", $accountId, $data['s_a_recordId']);
                mysqli_stmt_execute($numsqldata);
                $numresult = mysqli_stmt_get_result($numsqldata);
                while ($numdata = mysqli_fetch_assoc($numresult)) {
				
					$recordNum = '<a href="'.STEP_root.'master/testsuite.php" class="text-step"><b>'.$numdata['recordnum'].'</b> </a>';
				}

				break;
			case 'Requirement':
				$numsqldata = mysqli_prepare($conn, "SELECT IFNULL(s_rtm_reqnum, '') as recordnum FROM s_rtm WHERE accountId = ? AND s_rtm_id = ?");
                mysqli_stmt_bind_param($numsqldata, "ii", $accountId, $data['s_a_recordId']);
                mysqli_stmt_execute($numsqldata);
                $numresult = mysqli_stmt_get_result($numsqldata);
                while ($numdata = mysqli_fetch_assoc($numresult)) {
				
					$recordNum = '<a href="'.STEP_root.'master/rtmtestcase.php?id='.$data['s_a_recordId'].'" class="text-step"><b>'.$numdata['recordnum'].'</b> </a>';
				}

				break;
			
			default:
				# code...
				break;
		}
		$projarr['data'][] = array(++$srno,$data['s_a_desc'],$data['s_a_module'],$recordNum,$entered_by,$hdate);
	}
}else if($formtype == "Error Logs"){
	$srno=0;
	$query = "SELECT * FROM myerror_log ORDER BY s_id DESC LIMIT 1000";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    while ($data = mysqli_fetch_assoc($result)) {

		$hdate = (isset($data['s_createtime']) && ($data['s_createtime'] != "0000-00-00 00:00:00") ? date("d/m/Y H:i a",strtotime($data['s_createtime'])) : "");
		
		$projarr['data'][] = array(++$srno,$data['s_errno'],$data['s_errstr'],$data['s_errfile'],$data['s_errlineno'],$hdate);
	}
}else if($formtype == "ProjetEmailSetting"){
	$query = "SELECT s_projemailsetting.*, IFNULL(s_p_name, '') as projectname FROM s_projemailsetting JOIN s_project ON s_project.s_p_id = s_projemailsetting.projectId WHERE s_projemailsetting.accountId = ? ORDER BY s_projes_id DESC";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, "i", $accountId);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    while ($data = mysqli_fetch_assoc($result)) {
		$projarr['data'][] = array($data['s_projes_id'],$data['projectname'],$data['s_projes_subject'],$data['s_projes_username'],
			$data['s_projes_receiver'],$data['s_projes_cc'],$data['s_projes_bcc'],$data['s_projes_id']);
	}
}

echo json_encode($projarr);
?>
