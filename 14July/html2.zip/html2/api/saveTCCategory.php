<?php
include('config.php');
session_start();
 
$enteredby = 0;$accountId = 0;
 
$msgarr = array();

if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
}
if($_SERVER['REQUEST_METHOD'] === 'POST'){

	$id = (isset($_POST['categoryId']) ? intval($_POST['categoryId']) : 0);
	$categoryname = (isset($_POST['categoryname']) ? mysqli_real_escape_string($conn,$_POST['categoryname']) : "");
	$activestatus = (isset($_POST['activestatus']) ? $_POST['activestatus'] : "Active");

	if(!empty($id) && $id !="0") {
		$sql = "UPDATE s_tccategorymaster SET s_cat_name = ?, s_cat_activestatus = ? WHERE s_cat_id = ? AND accountId = ?";
		$stmt = mysqli_prepare($conn, $sql);
		mysqli_stmt_bind_param($stmt, "ssii", $categoryname, $activestatus, $id, $accountId);
		$result = mysqli_stmt_execute($stmt);
		if($result)
		{
			$msgarr["status"] = "Success";
			$msgarr["message"] = "Category updated successfully.";
		}
		else
		{
			$msgarr["status"] = "Error";
			$msgarr["message"] = "Something went wrong. Please try again.";
		}
		if ($stmt) mysqli_stmt_close($stmt);
	}else{


		$sql = "INSERT INTO s_tccategorymaster (s_cat_name, s_cat_enteredby, accountId, s_cat_activestatus) VALUES (?, ?, ?, ?)";
		$stmt = mysqli_prepare($conn, $sql);
		mysqli_stmt_bind_param($stmt, "siis", $categoryname, $enteredby, $accountId, $activestatus);
		$result = mysqli_stmt_execute($stmt);
		if($result)
		{
			$msgarr["status"] = "Success";
			$msgarr["message"] = "Category added successfully.";
		}
		else
		{
			$msgarr["status"] = "Error";
			$msgarr["message"] = "Something went wrong. Please try again.";
		}
		if ($stmt) mysqli_stmt_close($stmt);

	}
}
echo json_encode($msgarr);