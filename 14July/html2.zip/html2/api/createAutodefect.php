
<?php
include('config.php');
session_start();
 
$enteredby = 0;$accountId = 0;
 

$msgarr = array();

	$msgarr["status"] = "Error";
	$msgarr["message"] = "Something went wrong. Please try again.";
if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
}
if($_SERVER['REQUEST_METHOD'] === 'POST'){



$id = (isset($_POST['id']) ? intval($_POST['id']) : "0");
$query = "SELECT * from s_testexecution temp 
    join s_testcase tc on tc.s_t_id = temp.testcaseId 
    where temp.s_st_id = ? and temp.accountId = ?";
$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "ii", $id, $accountId);
mysqli_stmt_execute($stmt);
$sqldata = mysqli_stmt_get_result($stmt);


while($data = mysqli_fetch_assoc($sqldata)){

	$projectId = (isset($data['projectId']) ? $data['projectId'] : "0");
	$releaseId = (isset($data['releaseId']) ? $data['releaseId'] : "0");
	$testcaseId = (isset($data['s_t_id']) ? $data['s_t_id'] : "0");
	$module = (isset($data['s_t_module']) ? $data['s_t_module'] : "");
	$submodule = (isset($data['s_t_submodule']) ? $data['s_t_submodule'] : "");
	$actualresult = (isset($data['s_st_actualresult']) ? $data['s_st_actualresult'] : "");
	$shortdesc = (isset($data['s_st_actualresult']) ? $data['s_st_actualresult'] : "");
	$longdesc = (isset($data['s_st_actualresult']) ? $data['s_st_actualresult'] : "");
	$testdata = (isset($data['s_t_testdata']) ? $data['s_t_testdata'] : "");
	$steps = (isset($data['s_t_steps']) ? $data['s_t_steps'] : "");
	$expectedresult = (isset($data['s_t_expectedresult']) ? $data['s_t_expectedresult'] : "");
	$docfile = (isset($data['s_st_filepath']) ? $data['s_st_filepath'] : "");

	$query = "SELECT 
	IFNULL(s_tss_steps,'') as stepdata,
	IFNULL(s_tss_expectedresult,'') as stepexpdata,
	IFNULL(s_se_actualresult,'') as stepactualresult
	from s_tcstep_execution temp 
	join s_testcase_steps tc on tc.s_tss_id = temp.stepId 
	where temp.s_se_executionId = ? and temp.accountId = ? and temp.s_se_testresult = 'Fail'";
	$stmt = mysqli_prepare($conn, $query);
	mysqli_stmt_bind_param($stmt, "ii", $id, $accountId);
	mysqli_stmt_execute($stmt);
	$stepresult = mysqli_stmt_get_result($stmt);
		
	$stepdata = "";$stepactualresult ="";$stepexpdata = "";
	while($sdata = mysqli_fetch_assoc($stepresult)){
		if(!empty($sdata['stepdata'])){
			$stepdata .= (empty($stepdata) ? $sdata['stepdata'] : ", ".$sdata['stepdata']);
		}

		if(!empty($sdata['stepactualresult'])){
			$stepactualresult .= (empty($stepactualresult) ? $sdata['stepactualresult'] : ", ".$sdata['stepactualresult']);
		}

		if(!empty($sdata['stepexpdata'])){
			$stepexpdata .= (empty($stepexpdata) ? $sdata['stepexpdata'] : ", ".$sdata['stepexpdata']);
		}
	}

	$steps = $stepdata;
	$actualresult = $stepactualresult;
	$shortdesc = $stepactualresult;
	$longdesc = $stepactualresult;
	$expectedresult = $stepexpdata;
}
	
$assignto = (isset($_POST['assignto']) ? $_POST['assignto'] : "0");
$severity = (isset($_POST['severity']) ? $_POST['severity'] : "");
$priority = (isset($_POST['priority']) ? $_POST['priority'] : "");
$defecttypeId = (isset($_POST['defecttypeId']) ? $_POST['defecttypeId'] : "0");
$defectstatusId = (isset($_POST['defectstatusId']) ? $_POST['defectstatusId'] : "0");
$comment = (isset($_POST['comment']) ? $_POST['comment'] : "");

$filename = "";
$filepath = "";

$defectId = 0;
$defectIdstr = "";
$projcode = "";

$query = "SELECT * from s_project where s_p_id = ? and accountId = ? order by s_p_id desc limit 1";
$stmt = mysqli_prepare($conn, $query);
mysqli_stmt_bind_param($stmt, "ii", $projectId, $accountId);
mysqli_stmt_execute($stmt);
$projsqldata = mysqli_stmt_get_result($stmt);
if(mysqli_num_rows($projsqldata)>0){

	while($pdata = mysqli_fetch_assoc($projsqldata)){
		$projcode = $pdata['s_p_code'];
	}


	$query = "SELECT * from s_defect where projectId = ? and accountId = ? order by s_d_tempid desc limit 1";
	$stmt = mysqli_prepare($conn, $query);
	mysqli_stmt_bind_param($stmt, "ii", $projectId, $accountId);
	mysqli_stmt_execute($stmt);
	$defectsqldata = mysqli_stmt_get_result($stmt);
	if(mysqli_num_rows($defectsqldata)>0){

		while($rdata = mysqli_fetch_assoc($defectsqldata)){
			$defectId = (int)$rdata['s_d_tempid'] +1;
		}
	}else{
		$defectId = 1;
	}
	$defectIdstr = "$projcode-D$defectId";
}


$sql = "INSERT INTO s_defect(projectId, releaseId, testcaseId, s_d_tempid, s_d_defectnum, s_d_module, s_d_submodule, defecttypeId, s_d_severity, s_d_priority, defectstatusId, s_d_assignto, s_d_shortdesc, s_d_longdesc, s_d_testdata, s_d_steps, s_d_expectedresult, s_d_actualresult, s_d_comment, s_d_enteredby, accountId) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?)";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "iisisssisssssssssssii", $projectId, $releaseId, $testcaseId, $defectId, $defectIdstr, $module, $submodule, $defecttypeId, $severity, $priority, $defectstatusId, $assignto, $shortdesc, $longdesc, $testdata, $steps, $expectedresult, $actualresult, $comment, $enteredby, $accountId);
mysqli_stmt_execute($stmt);

if($stmt){

	$msgarr["status"] = "Success";
	$msgarr["message"] = "Defect created successfully.";
	$insertid = mysqli_insert_id($conn);
	$updateExecution = "update s_testexecution set defectId = '".$insertid."' where s_st_id = '".$id."' ";
	mysqli_query( $conn, $updateExecution);

	if (!file_exists($CFG['dirroot'].'defectdata/'.$accountId."/".$insertid)) {
		mkdir($CFG['dirroot'].'defectdata/'.$accountId."/".$insertid, 0777, true);
	}

	if($docfile != ""){
		$fArr = explode("/", $docfile);
		$len = count($fArr);
		$file = isset($fArr[$len -1]) ? $fArr[$len - 1] : "";
		if($file !=""){
			$newfile = $CFG['dirroot'].'defectdata/'.$accountId."/".$insertid."/" . $file;

			if ( copy($docfile, $newfile) ) {
			    // echo "Copy success!";
			}else{
			    // echo "Copy failed.";
			}
		}
	}
	if(isset($_FILES['fileToUpload']['name'])){
		//echo "aditya";exit;
		if (!file_exists($CFG['dirroot'].'defectdata/'.$accountId."/".$insertid)) {
			mkdir($CFG['dirroot'].'defectdata/'.$accountId."/".$insertid, 0777, true);
		}
					
		// Count # of uploaded files in array
		$total = count($_FILES['fileToUpload']['name']);

		// Loop through each file
		for( $i=0 ; $i < $total ; $i++ ) {

		  //Get the temp file path
		  $tmpFilePath = $_FILES['fileToUpload']['tmp_name'][$i];

		  //Make sure we have a file path
		  if ($tmpFilePath != ""){
			//Setup our new file path
			$newFilePath = $CFG['dirroot'].'defectdata/'.$accountId."/".$insertid."/" . $_FILES['fileToUpload']['name'][$i];

			//Upload the file into the temp dir
			if(move_uploaded_file($tmpFilePath, $newFilePath)) {

			  //Handle other code here

			}
		  }
		}
	}
}
else
{
	$msgarr["status"] = "Error";
	$msgarr["message"] = "Something went wrong. Please try again.";
}
}

echo json_encode($msgarr);
