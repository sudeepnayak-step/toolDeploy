<?php
include('../config.php');
$enteredby = 0;$accountId = 0;$userempid = 0;

$where = "";

$accountId = (isset($_GET['accountId']) && !empty($_GET['accountId']) && !is_null($_GET['accountId']) ? $_GET['accountId'] : 0);
$userempid = (isset($_GET['userempid']) && !empty($_GET['userempid']) && !is_null($_GET['userempid']) ? $_GET['userempid'] : 0);
$usertype = (isset($_GET['usertype']) && !empty($_GET['usertype']) && !is_null($_GET['usertype']) ? $_GET['usertype'] : "");


if(isset($usertype) && $usertype != "Admin"){
	$where .= " and (s_p_id in (select projectId from s_project_members where employeeId = '".$userempid."'  and accountId = '".$accountId."') or s_p_enteredby = '".$enteredby."' ) ";
}

$sql = "SELECT s_p_id,s_p_name,s_p_code from  s_project where s_p_activestatus = 'Active' and accountId = ?  $where   ";

$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $accountId);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$projarr = array();
while($data = mysqli_fetch_assoc($result)){
		$projectId = $data['s_p_id'];
		
		$releasesql = "SELECT s_r_id,s_r_name from s_release where projectId = ? and  s_r_activestatus = 'Active' and accountId =?  ";


		$releasestmt = mysqli_prepare($conn, $releasesql);
		mysqli_stmt_bind_param($releasestmt, "ii", $projectId,$accountId);
		mysqli_stmt_execute($releasestmt);
		$releaseresult = mysqli_stmt_get_result($releasestmt);

		$releasearr = array();
		while($rdata = mysqli_fetch_assoc($releaseresult)){
				$releaseId = $rdata['s_r_id'];

				$activityarr = array();
				$actsql = "SELECT s_a_id,s_a_name from s_activitymaster where s_a_activestatus = 'Active' and s_a_type = 'Execution' and s_a_id in ( Select activityId from s_project_activity where  projectId = ? and releaseId = ?  and accountId =? ) and accountId =? ";
				$actstmt = mysqli_prepare($conn, $actsql);
				mysqli_stmt_bind_param($actstmt, "iiii",$projectId,$releaseId,$accountId,$accountId);
				mysqli_stmt_execute($actstmt);
				$actresult = mysqli_stmt_get_result($actstmt);
				while($actdata = mysqli_fetch_assoc($actresult)){
					$activityId = $actdata['s_a_id'];
					

					$tsarr = array();
					$tssql = "SELECT s_ts_id,s_ts_name,s_ts_testsuitenum from s_testsuite where projectId = ? and releaseId = ? and activityId = ? and  accountId =?  ".(isset($usertype) && $usertype != "Admin" ? " and s_ts_assignto = '".$userempid."'  " : "");

					$tsstmt = mysqli_prepare($conn, $tssql);
					mysqli_stmt_bind_param($tsstmt, "iiii",$projectId,$releaseId,$activityId,$accountId);
					mysqli_stmt_execute($tsstmt);
					$tsresult = mysqli_stmt_get_result($tsstmt);
					while($tsdata = mysqli_fetch_assoc($tsresult)){
						$testsuiteId = $tsdata['s_ts_id'];
						

						// $tcarr = array();
						// $tcsql = "SELECT temp.*,
						// IFNULL(tc.s_t_testscenarionum,'') as testscenarioId,
						// IFNULL(tc.s_t_id,'') as testcaseautoId,
						// IFNULL(tc.s_t_module,'-') as module,
						// IFNULL(tc.s_t_submodule,'') as submodule,
						// IFNULL(tc.s_t_testcasenum,'') as testcasenumber,
						// IFNULL(tc.s_t_testcasedesc,'') as testcasedesc,
						// IFNULL(tc.s_t_testdata,'') as testdata,
						// IFNULL(tc.s_t_precondition,'') as precondition,
						// IFNULL(tc.s_t_testscenariodesc,'') as testscenariodesc,
						// IFNULL(tc.s_t_comment,'') as comment,
						// IFNULL(temp.s_st_testresult,'') as s_st_testresult,
						// IFNULL(temp.s_st_actualresult,'') as s_st_actualresult,
						// IFNULL(temp.s_st_executionstatus,'') as executionstatus from s_testcaserun temp 
						// left join s_testcase tc on tc.s_t_id = temp.testcaseId  
						// where temp.testsuiteId = ? and  temp.accountId =? and temp.s_st_executionstatus = '1' ";

						// $tcstmt = mysqli_prepare($conn, $tcsql);
						// mysqli_stmt_bind_param($tcstmt, "ii",$testsuiteId,$accountId);
						// mysqli_stmt_execute($tcstmt);
						// $tcresult = mysqli_stmt_get_result($tcstmt);
						// while($tcdata = mysqli_fetch_assoc($tcresult)){
						// 	$tcexecId = $tcdata['s_st_id'];

						// 	$tcsteparr = array();
						// 	$tcstepsql = "SELECT temp.*,
						// 	IFNULL(tc.s_tss_num,'') as stepnum,
						// 	IFNULL(tc.s_tss_steps,'') as steps,
						// 	IFNULL(tc.s_tss_expectedresult,'-') as expectedresult
						// 	 from s_tcstep_iteration temp 
						// 	left join s_testcase_steps tc on tc.s_tss_id = temp.stepId  
						// 	where temp.s_se_runid = ? and  temp.accountId =?  ";

						// 	$tcstepstmt = mysqli_prepare($conn, $tcstepsql);
						// 	mysqli_stmt_bind_param($tcstepstmt, "ii",$tcexecId,$accountId);
						// 	mysqli_stmt_execute($tcstepstmt);
						// 	$tcstepresult = mysqli_stmt_get_result($tcstepstmt);
						// 	while($tcstepdata = mysqli_fetch_assoc($tcstepresult)){

						// 		$tcsteparr[] = array(
						// 			"id"=>$tcstepdata['s_se_id'],
						// 			"stepexecutionId"=>$tcstepdata['stepexecutionId'],
						// 			"stepId"=>$tcstepdata['stepId'],
						// 			"stepnum"=>$tcstepdata['stepnum'],
						// 			"steps"=>$tcstepdata['steps'],
						// 			"expectedresult"=>$tcstepdata['expectedresult']
						// 		);
						// 	}
						// 	$tcarr[] = array(
						// 		"id"=>$tcexecId,
						// 		// "testexecutionId"=>$tcdata['testexecutionId'],
						// 		"testcase-number"=>$tcdata['testcasenumber'],
						// 		"iteration"=>$tcdata['s_st_iteration'],
						// 		"testscenarioId"=>$tcdata['testscenarioId'],
						// 		"module"=>(!empty($tcdata['module']) ? $tcdata['module'] : "-"),
						// 		"submodule"=>(!empty($tcdata['submodule']) ? $tcdata['submodule'] : "-"),
						// 		"testcaseId"=>$tcdata['testcaseId'],
						// 		"testscenariodesc"=>$tcdata['testscenariodesc'] ? $tcdata['testscenariodesc'] : "-",
						// 		"precondition"=>$tcdata['precondition'] ? $tcdata['precondition'] : "-",
						// 		"testdata"=>$tcdata['testdata'] ? $tcdata['testdata'] : "-",
						// 		"comment"=>$tcdata['comment'] ? $tcdata['comment'] : "-",
						// 		"testcasedesc"=>$tcdata['testcasedesc'] ? $tcdata['testcasedesc'] : "-",
						// 		"testcase-steps" =>$tcsteparr
						// 	);
						// 	mysqli_stmt_close($tcstepstmt);
						// }
						$tsarr[] = array("id"=>$testsuiteId,
							"name"=>$tsdata['s_ts_name'],
							"testsuitenum"=>$tsdata['s_ts_testsuitenum']
						);
//						mysqli_stmt_close($tcstmt);
					}
					mysqli_stmt_close($tsstmt);

					$activityarr[] = array("id"=>$activityId,
						"activityId"=>$actdata['s_a_name'],
						"testsuite"=>$tsarr
					);
				}
				mysqli_stmt_close($actstmt);

				$releasearr[] = array(
					"id"=>$releaseId,
					"name"=>$rdata['s_r_name'],
					"activity"=>$activityarr
				);
		}
		mysqli_stmt_close($releasestmt);


		$projarr[]= array(
			"id"=>$projectId,
			"name"=>$data['s_p_name'],
			"code"=>$data['s_p_code'],
			"release"=>$releasearr
		);
}
mysqli_stmt_close($stmt);

echo json_encode($projarr);
?>
