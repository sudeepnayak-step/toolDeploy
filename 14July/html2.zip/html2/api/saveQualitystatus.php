<?php
include('config.php');
session_start();
 /** this saves the quality status master data */
$enteredby = 0;
$accountId = 0;
 
$msgarr = array();

if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = (isset($_SESSION["accountId"]) ? $_SESSION["accountId"] : 0);
}
if($_SERVER['REQUEST_METHOD'] === 'POST'){

$id = (isset($_POST['qId']) ? $_POST['qId'] : "0");
$excellent = (isset($_POST['excellent']) ? $_POST['excellent'] : "0");
$good = (isset($_POST['good']) ? $_POST['good'] : "0");
$normal = (isset($_POST['normal']) ? $_POST['normal'] : "0");
$username = (isset($_POST['username']) ? $_POST['username'] : "");
$password = (isset($_POST['password']) ? $_POST['password'] : "");

if(!empty($id) && $id !="0") {
	// Update query using prepared statements
	$sql = "UPDATE s_qualitystatus SET s_q_excellent = ?, s_q_good = ?, s_q_normal = ? WHERE s_q_id = ? AND accountId = ?";
	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "iiiis", $excellent, $good, $normal, $id, $accountId);
	
	if(mysqli_stmt_execute($stmt)) {
		$msgarr["status"] = "Success";
		$msgarr["message"] = "Quality status updated successfully.";
	}
	else
	{
		$msgarr["status"] = "Error";
		$msgarr["message"] = "Something went wrong. Please try again.";
	}
	mysqli_stmt_close($stmt);

}else{


	// Insert query using prepared statements
	$sql = "INSERT INTO s_qualitystatus(s_q_excellent, s_q_good, s_q_normal, accountId, s_q_enteredby) VALUES (?, ?, ?, ?, ?)";
	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "iiiis", $excellent, $good, $normal, $accountId, $enteredby);
	
	if(mysqli_stmt_execute($stmt)) {
		$msgarr["status"] = "Success";
		$msgarr["message"] = "Quality status added successfully.";
	}
	else
	{
		$msgarr["status"] = "Error";
		$msgarr["message"] = "Something went wrong. Please try again.";
	}
	mysqli_stmt_close($stmt);

}
}
echo json_encode($msgarr);