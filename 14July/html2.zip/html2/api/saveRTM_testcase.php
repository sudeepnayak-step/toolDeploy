
<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include('config.php');
session_start();
 /** this script mapped the testcases to RTM */
$enteredby = 0;
$accountId = 0;
 
$msgarr = array();
$msgarr["status"] = "Error";
$msgarr["message"] = "Something went wrong. Please try again.";


if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
}
if($_SERVER['REQUEST_METHOD'] === 'POST'){

	$rtmId = (isset($_POST['rtmId']) ? intval($_POST['rtmId']) : 0);
	$testcaseIds = (isset($_POST['testcaseIds']) ? $_POST['testcaseIds'] : "0");

	$testcasesql = "insert into s_rtm_testcase(rtmId,testcaseId,defectId,s_rt_enteredby,accountId)  select '".$rtmId."', s_t_id,'0','".$enteredby."','".$accountId."' from s_testcase where s_t_id in(".$testcaseIds.") and accountId = '".$accountId."' ";
	// Prepare the SQL query using a prepared statement
    $sql = "INSERT INTO s_rtm_testcase (rtmId, defectId, testcaseId, s_rt_enteredby, accountId) 
            SELECT ?,'0', s_t_id,  ?, ? 
            FROM s_testcase 
            WHERE FIND_IN_SET(s_t_id,?) AND accountId = ?";

    $stmt = mysqli_prepare($conn, $sql);

	// Bind parameters to the prepared statement
	mysqli_stmt_bind_param($stmt, "sssss", $rtmId, $enteredby, $accountId,$testcaseIds, $accountId);

	// Execute the prepared statement
	if (mysqli_stmt_execute($stmt)) {

		$msgarr["status"] = "Success";
		$msgarr["message"] = "Testcases added successfully.";
		
		$rtmtcsql = "SELECT 
						`s_f_testresult`  as result,
						COUNT(*) as count
					FROM
						s_testcasefinal where `testcaseId` in (select testcaseId from s_rtm_testcase where rtmId = '".$rtmId."') 
						and s_f_testresult !='' and s_f_testresult IS NOT NULL 
					GROUP BY s_f_testresult

					ORDER BY COUNT(*) asc";
					// echo $rtmtcsql."<br/>";
		$rtmtcsqldata = mysqli_query($conn,$rtmtcsql);
					$passCount = 0;$failCount = 0;$inprogressCount = 0;$pendingCOunt = 0;$blockCount = 0;$naCount= 0 ;
		while($tdata = mysqli_fetch_assoc($rtmtcsqldata)){
			if($tdata['result'] == "Pass"){ $passCount = $tdata['count'];}
			else if($tdata['result'] == "Fail") {$failCount = $tdata['count'];}
			else if($tdata['result'] == "In Progress") {$inprogressCount = $tdata['count'];}
			else if($tdata['result'] == "Pending"){ $pendingCOunt = $tdata['count'];}
			else if($tdata['result'] == "Block"){ $blockCount = $tdata['count'];}
			else if($tdata['result'] == "NA"){ $naCount = $tdata['count'];}

		}
		
		if($failCount > 0){
			$rtmupdatesql = "UPDATE s_rtm SET s_rtm_status = 'Fail'  where s_rtm_id =  '".$rtmId."' ";
			mysqli_query( $conn, $rtmupdatesql);
		}else if($naCount >0 && ($blockCount == 0 && $inprogressCount == 0 && $pendingCOunt ==0 && $passCount ==0)){
			$rtmupdatesql = "UPDATE s_rtm SET s_rtm_status = 'Out of scope'  where s_rtm_id =  '".$rtmId."' ";
			mysqli_query( $conn, $rtmupdatesql);
		}else if($blockCount > 0 || $naCount >0 || $inprogressCount>0 || $pendingCOunt >0){
			$rtmupdatesql = "UPDATE s_rtm SET s_rtm_status = 'In Progress'  where s_rtm_id =  '".$rtmId."' ";
			mysqli_query( $conn, $rtmupdatesql);
		}else if($passCount >= 0){
			$rtmupdatesql = "UPDATE s_rtm SET s_rtm_status = 'Pass'  where s_rtm_id =  '".$rtmId."' ";
			mysqli_query( $conn, $rtmupdatesql);
		}
	}
	else
	{
		$msgarr["status"] = "Error";
		$msgarr["message"] = "Something went wrong. Please try again.";
	}
	// Close the prepared statement
	mysqli_stmt_close($stmt);

}

echo json_encode($msgarr);
