
<?php
include('config.php');
session_start();
 
$enteredby = 0;
$accountId = 0;
 

if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
}
if($_SERVER['REQUEST_METHOD'] === 'POST'){

$suiteId = (isset($_POST['testsuiteDBId']) && !empty($_POST['testsuiteDBId']) ? $_POST['testsuiteDBId'] : "0");
$testcaseIds = (isset($_POST['testcaseIds']) && !empty($_POST['testcaseIds']) ? $_POST['testcaseIds'] : "0");

$testcasesql = "insert into s_testexecution(testsuiteId,testcaseId,s_st_testresult,s_st_actualresult,s_st_executiontime,s_st_exectionstart,s_st_executionend,s_st_filename,s_st_filepath,s_st_enteredby,accountId,s_st_executionstatus,defectId)  select '".$suiteId."', s_t_id,'',NULL,NULL,NULL,NULL,'',NULL,'".$enteredby."','".$accountId."',0,0 from s_testcase where s_t_id in(".$testcaseIds.") and accountId = '".$accountId."' ";

mysqli_query( $conn, $testcasesql);


}