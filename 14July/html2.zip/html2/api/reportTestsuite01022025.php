<?php

header('Access-Control-Allow-Origin: *');
// this script create the testsuite report
// set to the user defined error handler
include('config.php');
$old_error_handler = set_error_handler("myErrorHandler");
session_start();
 
$enteredby = 0;$accountId = 0;$userempid = 0;
 

if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
    $userempid = $_SESSION["userempid"];
}

$where = "";

$projectId = (isset($_GET['projectId']) && !empty($_GET['projectId'])? $_GET['projectId'] : "");
$releaseId = (isset($_GET['releaseId'])  && !empty($_GET['releaseId'])? $_GET['releaseId'] : "");
$activityId = (isset($_GET['activityId'])  && !empty($_GET['activityId'])? $_GET['activityId'] : "");

if($projectId !=""){
		$where = $where." and ts.projectId in ($projectId) ";
}

if($releaseId !=""){
		$where = $where." and ts.releaseId in ($releaseId) ";
}
if($activityId !=""){
		$where = $where." and ts.activityId in ($activityId) ";
}

if(isset($_SESSION["usertype"]) && $_SESSION["usertype"] != "Admin"){
	$where .= " and ts.projectId in (select s_p_id from s_project where s_p_id in (select projectId from s_project_members where employeeId = '".$userempid."'  and accountId = '".$accountId."') or s_p_enteredby = '".$enteredby."' and accountId = '".$accountId."')";
}

$styleArray = array(
    'font'  => array(
        'bold'  => true,
        'color' => array('rgb' => 'ffffff'),
        // 'size'  => 15,
        // 'name'  => 'Verdana'
    ));

    
require_once dirname(__FILE__) . '/PHPExcel/Classes/PHPExcel.php';

// Create new PHPExcel object
$objPHPExcel = new PHPExcel();

//////////////////// Application
$activeapp = array();
//Write cells
$objPHPExcel->setActiveSheetIndex(0)->setCellValue('A1', 'Project')
            ->setCellValue('B1', 'Release')
            ->setCellValue('C1', 'Activity')
            ->setCellValue('D1', 'Test Suite Name')
            ->setCellValue('E1', 'Module')
            ->setCellValue('F1', 'Test Scenario ID')
            ->setCellValue('G1', 'Testcase ID')
            ->setCellValue('H1', 'TC Description')
            ->setCellValue('I1', 'Test Result')
            ->setCellValue('J1', 'Actual Result')
            ->setCellValue('K1', 'Defect')
            ->setCellValue('L1', 'Iteration')
            ->setCellValue('M1', 'Execution Starttime')
            ->setCellValue('N1', 'Execution Endtime')
            ->setCellValue('O1', 'Execution Time')
            ;

$from = "A1"; // or any value
$to = "O1"; // or any value

$objPHPExcel->getActiveSheet()->getStyle("$from:$to")->applyFromArray($styleArray);

$objPHPExcel->getActiveSheet()->getStyle("$from:$to")->getFill()->applyFromArray(array(
'type' => PHPExcel_Style_Fill::FILL_SOLID,
'startcolor' => array(
        'rgb' => "1a6199"
)
));
$stml = mysqli_prepare($conn,"SELECT temp.*,
IFNULL(p.s_p_name,'') as projectname,
IFNULL(r.s_r_name,'') as releaseNum,
IFNULL(a.s_a_name,'') as activityname,
IFNULL(ts.s_ts_name,'') as testsuitename,
IFNULL(tc.s_t_testscenarionum,'') as testscenarioId,
IFNULL(tc.s_t_testcasenum,'') as testcaseId,
IFNULL(tc.s_t_id,'') as testcaseautoId,
IFNULL(tc.s_t_module,'-') as module,
IFNULL(tc.s_t_submodule,'') as submodule,
IFNULL(tc.s_t_testcasenum,'') as testcaseId,
IFNULL(tc.s_t_testcasedesc,'') as testcasedesc,
IFNULL(temp.s_st_testresult,'') as s_st_testresult,
IFNULL(temp.s_st_actualresult,'') as s_st_actualresult,
IFNULL(temp.s_st_executionstatus,'') as executionstatus,
IFNULL(d.s_d_defectnum,'') as defectnum
from s_testexecution temp 
inner join s_testsuite ts on ts.s_ts_id = temp.testsuiteId 
LEFT join s_project p on p.s_p_id = ts.projectId 
LEFT join s_activitymaster a on a.s_a_id = ts.activityId 
LEFT join s_release r on r.s_r_id = ts.releaseId 

inner join s_testcase tc on tc.s_t_id = temp.testcaseId 
left join s_defect d on d.s_d_id = temp.defectId 
where 
temp.accountId = ? $where

order by temp.s_st_id desc");

mysqli_stmt_bind_param($stmt, "i",$accountId);
mysqli_stmt_execute($stmt);
$sqldata = mysqli_stmt_get_result($stmt);

$ai = 1;

while($data = mysqli_fetch_assoc($sqldata)){

    $iterationsqldata = mysqli_query($conn,"SELECT * from s_testcaserun where testexecutionId = '".$data['s_st_id']."' and accountId = '".$accountId."'  order by s_st_id desc ");
    $iterationcount = mysqli_num_rows($iterationsqldata);

    $ai = $ai + 1;
    $sh_starttime = (isset($data['s_app_starttime']) && !empty($data['s_app_starttime']) && ($data['s_app_starttime'] != "00:00:00") ? date("h:i a",strtotime($data['s_app_starttime'])) : "");

    array_push($activeapp, $data['s_app_id']);

    $objPHPExcel->setActiveSheetIndex(0)->setCellValue('A'.$ai, $data['projectname'])
            ->setCellValue('B'.$ai, $data['releaseNum'])
            ->setCellValue('C'.$ai, $data['activityname'])
            ->setCellValue('D'.$ai, $data['testsuitename'])
            ->setCellValue('E'.$ai, $data['module'])
            ->setCellValue('F'.$ai, $data['testscenarioId'])
            ->setCellValue('G'.$ai, $data['testcaseId'])
            ->setCellValue('H'.$ai, $data['testcasedesc'])
            ->setCellValue('I'.$ai, $data['s_st_testresult'])
            ->setCellValue('J'.$ai, $data['s_st_actualresult'])
            ->setCellValue('K'.$ai, $data['defectnum'])
            ->setCellValue('L'.$ai, $iterationcount)
            ->setCellValue('M'.$ai, (!empty($data['s_st_exectionstart']) ? $data['s_st_exectionstart'] : "-"))
            ->setCellValue('N'.$ai, (!empty($data['s_st_executionend']) ? $data['s_st_executionend'] : "-"))
            ->setCellValue('O'.$ai, (!empty($data['s_st_executiontime']) ? $data['s_st_executiontime'] : "-"))
            ;

}

// Rename sheet
$objPHPExcel->setActiveSheetIndex(0)->setTitle("Test Execution Report");


// $objPHPExcel->setActiveSheetIndex(0);
// Redirect output to a client’s web browser (Excel2007)
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="Test Execution Report '.gmdate('D, d M Y H:i:s').'.xlsx"');
header('Cache-Control: max-age=0');
// If you're serving to IE 9, then the following may be needed
header('Cache-Control: max-age=1');

// If you're serving to IE over SSL, then the following may be needed
header ('Expires: Mon, 26 Jul 1997 05:00:00 GMT'); // Date in the past
header ('Last-Modified: '.gmdate('D, d M Y H:i:s').' GMT'); // always modified
header ('Cache-Control: cache, must-revalidate'); // HTTP/1.1
header ('Pragma: public'); // HTTP/1.0

$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
$objWriter->save('php://output');


function cellColor($cells,$color){
    global $objPHPExcel;

    $objPHPExcel->getActiveSheet()->getStyle($cells)->getFill()->applyFromArray(array(
        'type' => PHPExcel_Style_Fill::FILL_SOLID,
        'startcolor' => array(
             'rgb' => $color
        )
    ));
}
