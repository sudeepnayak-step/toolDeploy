<?php
include('config.php');
session_start();
 
$enteredby = 0;$accountId=0;
 

if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
}

if($_SERVER['REQUEST_METHOD'] === 'POST'){

$ids = (isset($_POST['ids']) ? $_POST['ids'] : "0");
$type = (isset($_POST['type']) ? $_POST['type'] : "");

if(in_array($type, array("Active","Inactive"))){

    // bulk action to update the status of release for multiple records
    $sql = "UPDATE s_release SET s_r_activestatus = ? where s_r_id in (?) and accountId = ?";

    $stmt = mysqli_prepare( $conn, $sql);
    mysqli_stmt_bind_param($stmt, "ssi", $type, $ids, $accountId);
    
    // Execute the statement
    mysqli_stmt_execute($stmt);

    // Close the statement
    mysqli_stmt_close($stmt);
}else if(in_array($type, array("Delete"))){
    // bulk action to delete multiple release

    $sql = "DELETE FROM s_release  where s_r_id in (?) and accountId = ? ";

    $stmt = mysqli_prepare( $conn, $sql);
    mysqli_stmt_bind_param($stmt, "si", $ids, $accountId);
            
    // Execute the statement
    mysqli_stmt_execute($stmt);

    // Close the statement
    mysqli_stmt_close($stmt);

}
}