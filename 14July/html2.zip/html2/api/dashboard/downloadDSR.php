<?php
header('Access-Control-Allow-Origin: *');
include('../config.php');
session_start();
 
$enteredby = 0;$accountId=0;$userempid = 0;
 
/** this script download the dsr in excel shhet */
if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
    $userempid = $_SESSION["userempid"];
}
$projarr['data'] = array();


$projectId = (isset($_GET['projectId']) && !empty($_GET['projectId'])?  $_GET['projectId'] : "");
$releaseId = (isset($_GET['releaseId'])  && !empty($_GET['releaseId'])? $_GET['releaseId'] : "");
$activityId = (isset($_GET['activityId'])  && !empty($_GET['activityId'])? $_GET['activityId'] : "");
$overallsummary = (isset($_GET['overallsummery'])  && !empty($_GET['overallsummery'])? mysqli_real_escape_string($conn,$_GET['overallsummery']) : "");
$prodlosssummary = (isset($_GET['prodlosssummery'])  && !empty($_GET['prodlosssummery'])? mysqli_real_escape_string($conn,$_GET['prodlosssummery']) : "");
$dsrdate = (isset($_GET['dsrdate']) && !empty($_GET['dsrdate']) ?  date('Y-m-d 23:59:59', strtotime(str_replace('/', '-', $_GET['dsrdate']))) : date('Y-m-d 23:59:59'));
$dsrdmy = (isset($_GET['dsrdate']) && !empty($_GET['dsrdate']) ?  date('Y-m-d', strtotime(str_replace('/', '-', $_GET['dsrdate']))) : date('Y-m-d'));

$where = "";
if($projectId !=""){
	$where = $where." and projectId in ($projectId) ";
}

if($releaseId !=""){
	$where = $where." and s_r_id in ($releaseId) ";
}


if($projectId != "" && $releaseId !=""){

	$part1 = "";
	$stmt = mysqli_prepare($conn,"SELECT r.*,
	IFNULL(p.s_p_name,'') as projectname,
	IFNULL(p.clientId,'0') as projectclient

	from s_release r 
	join s_project p on p.s_p_id = r.projectId 
	where r.accountId = ?   $where 
	order by r.s_r_id desc");
	mysqli_stmt_bind_param($stmt, 's', $accountId);
	mysqli_stmt_execute($stmt);
	$sqldata = mysqli_stmt_get_result($stmt);

	while($mdata = mysqli_fetch_assoc($sqldata)){
		$dsrstmt = mysqli_prepare($conn,"SELECT * from s_dsrtbl where 
		projectId = ? and 
		releaseId = ? and 
		s_dsr_date = ? and
		accountId = ?  order by s_dsr_id desc limit 1 
			");
		mysqli_stmt_bind_param($dsrstmt, 'ssss',$projectId,$releaseId,$dsrdmy,$accountId);
		mysqli_stmt_execute($dsrstmt);
		$dsrdata = mysqli_stmt_get_result($dsrstmt);
		
		while($ddata = mysqli_fetch_assoc($dsrdata)){
				$overallsummary = $ddata['s_dsr_overallsummary'];
				$prodlosssummary = $ddata['s_dsr_prodlosssummary'];
		}
		// Close the statement
		mysqli_stmt_close($dsrstmt);
		

		$duration = 0;
		$elapseddays = 0;
		$remainingdays = 0;
		$timeelapsed = 0;
		$planstartdate = (isset($mdata['s_r_planstartdate']) && ($mdata['s_r_planstartdate'] != "0000-00-00") ? date("d/m/Y",strtotime($mdata['s_r_planstartdate'])) : "-");

		$planenddate = (isset($mdata['s_r_planenddate']) && ($mdata['s_r_planenddate'] != "0000-00-00") ? date("d/m/Y",strtotime($mdata['s_r_planenddate'])) : "-");

		$revisedstartdate = (isset($mdata['s_r_revisedstartdate']) && ($mdata['s_r_revisedstartdate'] != "0000-00-00") ? date("d/m/Y",strtotime($mdata['s_r_revisedstartdate'])) : "-");

		$revisedenddate = (isset($mdata['s_r_revisedenddate']) && ($mdata['s_r_revisedenddate'] != "0000-00-00") ? date("d/m/Y",strtotime($mdata['s_r_revisedenddate'])) : "-");
			
		$actualstartdate = (isset($mdata['s_r_actualstartdate']) && ($mdata['s_r_actualstartdate'] != "0000-00-00") ? date("d/m/Y",strtotime($mdata['s_r_actualstartdate'])) : "-");

		$actualenddate = (isset($mdata['s_r_actualenddate']) && ($mdata['s_r_actualenddate'] != "0000-00-00") ? date("d/m/Y",strtotime($mdata['s_r_actualenddate'])) : "-");

		$projarr['data'] = array("Project"=>$mdata['projectname'],
			"Release"=>$mdata['s_r_name'],
			"Plan Start Date"=>$planstartdate,"Plan End Date"=>$planenddate,
			"Revised Start Date"=>$revisedstartdate,"Revised End Date"=>$revisedenddate,
			"overallsummary"=>$overallsummary,
			"prodlosssummary"=>$prodlosssummary,
		);

		if($revisedstartdate != "-"){
			$startdate = $revisedstartdate;
			$enddate = date("d/m/Y");
			$elapseddays = GetDateDuration($projectclient,$startdate,$enddate);
		}else if($planstartdate != "-"){
			$startdate = $planstartdate;
			$enddate = date("d/m/Y");
			$elapseddays = GetDateDuration($projectclient,$startdate,$enddate);
		}

		if($revisedstartdate != "-" && $revisedenddate != "-"){

			$startdate =$revisedstartdate;
			$enddate = $revisedenddate;
			$duration = GetDateDuration($projectclient,$startdate,$enddate);

		}else if($planstartdate != "-" && $planenddate != "-"){
			$startdate = $planstartdate;
			$enddate = $planenddate;
			$duration = GetDateDuration($projectclient,$startdate,$enddate);
		}
        $remainingdays = ($duration >$elapseddays ? ($duration - $elapseddays) : 0);
                

		$part1 = '<table   width="100%" >
					<thead>
						<tr class="thcss">
							<th colspan="3" align="center"><big>Daily Status Report</big></th> 
						</tr>
						<tr>
							<th colspan="3" >&nbsp;</th> 
						</tr>  
					</thead>
					<tbody>
					<tr>
						<td>Project : <b>'.$mdata['projectname'].'</b></td>
						<td>Release : <b>'.$mdata['s_r_name'].'</b></td>
						<td>Plan Start Date : <b>'.$planstartdate.'</b></td>
					</tr>
					<tr>
						<td>Plan End Date : <b>'.$planenddate.'</b></td>
						<td>Revised Start Date : <b>'.$revisedstartdate.'</b></td>
						<td>Revised End Date : <b>'.$revisedenddate.'</b></td>
					</tr>
					<tr>
						<td>Duration in Days : <b>'.$duration.'</b></td>
						<td>Elapsed Days : <b>'.$elapseddays.'</b></td>
						<td>Remaining Days : <b>'.$remainingdays.'</b></td>
					</tr>
					</tbody>
				</table>';
	}
	// Close the statement
	mysqli_stmt_close($stmt);

	///////////////////////////// risk isue

	$where = "";$part2_riskissue = "";
	if($projectId !=""){
		$where = $where." and projectId in ($projectId) ";
	}

	if($releaseId !=""){
		$where = $where." and releaseId in ($releaseId) ";
	}

	if($activityId !=""){
		$where = $where." and activityId in ($activityId) ";
	}
	if($projectId != "" && $releaseId !=""){


	$riskstmt = mysqli_prepare($conn,"SELECT r.*,IFNULL(a.s_a_name,'') as activityname,
		concat(IFNULL(a1.s_e_fname,''),' ',IFNULL(a1.s_e_mname,''),' ',IFNULL(a1.s_e_lname,'')) as actionableby,
		concat(IFNULL(a2.s_e_fname,''),' ',IFNULL(a2.s_e_mname,''),' ',IFNULL(a2.s_e_lname,'')) as raisedby from s_riskissue r
		left join s_project_activity pa on pa.s_pa_id = r.s_r_activityId
		left join s_activitymaster a on a.s_a_id = pa.activityId

 		left JOIN s_employees a1 on a1.userId = r.s_r_actionableby and r.s_r_actionableby !='0'
 		left JOIN s_employees a2 on a2.userId = r.s_r_enteredby and r.s_r_enteredby !='0'
		WHERE r.accountId = ? and s_r_activityId in (select p1.s_pa_id from s_project_activity p1 where p1.accountId = ? $where)
		 order by s_r_id desc");
	mysqli_stmt_bind_param($riskstmt, 'ss',$accountId,$accountId);
	mysqli_stmt_execute($riskstmt);
	$sqldata = mysqli_stmt_get_result($riskstmt);
	$srno = 0;
	while($data = mysqli_fetch_assoc($sqldata)){

		$raiseddate = (isset($data['s_r_raiseddate']) && ($data['s_r_raiseddate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_r_raiseddate'])) : "");

		$closuredate = (isset($data['s_r_closuredate']) && ($data['s_r_closuredate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_r_closuredate'])) : "");
		$projarr['data'][] = array(
			++$srno,
			$data['s_r_desc'],
			$data['s_r_status'],
			$data['activityname'],
			$data['s_r_type'],
			$data['s_r_plan'],	
			$data['s_r_impact'],
			$data['actionableby'],
			empty(trim($data['raisedby'])) ? "Admin":$data['raisedby'],
			$raiseddate
		);

		$part2_riskissue .='<tr>
			<td>'.$srno.'</td>
			<td>'.$data['s_r_desc'].'</td>
			<td>'.$data['s_r_status'].'</td>
			<td>'.$data['activityname'].'</td>
			<td>'.$data['s_r_type'].'</td>
			<td>'.$data['s_r_plan'].'</td>
			<td>'.$data['s_r_impact'].'</td>
			<td>'.$data['actionableby'].'</td>
			<td>'.(empty(trim($data['raisedby'])) ? "Admin":$data['raisedby']).'</td>
			<td>'.$raiseddate.'</td>

		</tr>';
	}
	// Close the statement
	mysqli_stmt_close($riskstmt);
}


$part2 = '<table id="dsrriskissueTbl" class="table  compact table-bordered"  width="100%">
		<thead>
			<tr class="thcss">
			<th colspan="10" align="center"><big>Executive Summary</big></th> 
			</tr>
			<tr>
			<th colspan="10" align="center">&nbsp;</th> 
			</tr>
			<tr>
				<td colspan="5"><b>Overall Summary : </b><br/>'.$overallsummary.'</td> 
				<td colspan="5" ><b>Productivity Loss Summary : </b><br/>'.$prodlosssummary.'</td> 
			</tr>
			<tr class="thcss">
			<th colspan="10" class="text-center">Risk / Issue : </th> 
			</tr> 
			<tr  class="thcss">
			<th>Sr. No.</th> 
			<th>Description</th> 
			<th>Status</th> 
			<th>Activity</th> 
			<th>Type</th> 
			<th>Action/<br/>Mitigation Plans</th> 
			<th>Impact</th>
			<th>Actionable</th> 
			<th>Raised By</th> 
			<th>Raised Date</th> 
			</tr> 
		</thead>
		<tbody align="center">'.$part2_riskissue.'</tbody>
	</table>';




///////////////////////////// Test Plan

$where = "";$part2_testplan = "";
if($projectId !=""){
	$where = $where." and pa.projectId in ($projectId) ";
}

if($releaseId !=""){
	$where = $where." and pa.releaseId in ($releaseId) ";
}

if($activityId !=""){
	$where = $where." and pa.activityId in ($activityId) ";
}
if($projectId != "" && $releaseId !=""){


	$actstmt = mysqli_prepare($conn,"SELECT pa.*,IFNULL(p.s_p_name,'') as projectname,IFNULL(r.s_r_name,'') as releaseNum,IFNULL(a.s_a_name,'') as activityname,
	IFNULL(a.s_a_code,'') as activitycode ,
	IFNULL(a.s_a_type,'') as activitytype 
	from s_project_activity pa 
	join s_project p on p.s_p_id = pa.projectId 
	join s_activitymaster a on a.s_a_id = pa.activityId 
	join s_release r on r.s_r_id = pa.releaseId 
	where pa.accountId = ? and pa.s_pa_activestatus = 'Active'  $where  
	order by pa.s_pa_id asc");
	mysqli_stmt_bind_param($actstmt, 's',$accountId);
	mysqli_stmt_execute($actstmt);
	$sqldata = mysqli_stmt_get_result($actstmt);

	$srno = 0;
	while($data = mysqli_fetch_assoc($sqldata)){

		$planstartdate = (isset($data['s_pa_planstartdate']) && ($data['s_pa_planstartdate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_pa_planstartdate'])) : "");

		$planenddate = (isset($data['s_pa_planenddate']) && ($data['s_pa_planenddate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_pa_planenddate'])) : "");

		$revisedstartdate = (isset($data['s_pa_revisedstartdate']) && ($data['s_pa_revisedstartdate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_pa_revisedstartdate'])) : "");

		$revisedenddate = (isset($data['s_pa_revisedenddate']) && ($data['s_pa_revisedenddate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_pa_revisedenddate'])) : "");
		
		$actualstartdate = (isset($data['s_pa_actualstartdate']) && ($data['s_pa_actualstartdate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_pa_actualstartdate'])) : "");

		$actualenddate = (isset($data['s_pa_actualenddate']) && ($data['s_pa_actualenddate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_pa_actualenddate'])) : "");
		


		$totexecution = 0;
		$perexecution = 0;
		$tottestcase = 0;
		$totPass = 0;
		$totPasspercent = 0;
		$tcids = "";
		if($data['activitytype'] == "Execution"){
			$testcasedata = mysqli_query($conn,"SELECT IFNULL(count(1),0) as totcount,IFNULL(GROUP_CONCAT(s_t_id),'') as tcids from s_testcase where projectId = '".$data['projectId']."'
										  and releaseId = '".$data['releaseId']."' and find_in_set('".$data['activityId']."',s_t_activityIds)   and accountId = '".$accountId."'  and  s_t_createdtime <= '".$dsrdate."' ");

			while($tdata = mysqli_fetch_assoc($testcasedata)){
				$tottestcase = $tdata['totcount'] ;
				$tcids = " and find_in_set(testcaseId,'".$tdata['tcids']."') " ;
			}

			$exedata = mysqli_query($conn, "SELECT  IFNULL(SUM(CASE WHEN s_f_testresult = 'Fail' THEN 1 ELSE 0 END),0) as Failcount,
										IFNULL(SUM(CASE WHEN s_f_testresult = 'Pass' THEN 1 ELSE 0 END),0) as Passcount from s_testcasefinal where projectId = '".$data['projectId']."'
										  and releaseId = '".$data['releaseId']."' and activityId = '".$data['activityId']."' and accountId = '".$accountId."' ".$tcids."  ");
			while($edata = mysqli_fetch_assoc($exedata)){
				$totexecution = $edata['Failcount'] + $edata['Passcount'];
				$totPass = $edata['Passcount'];
			}
			$perexecution = ($tottestcase >0) ?  round(($totexecution/$tottestcase * 100),2) : 0;
			$totPasspercent = ($tottestcase >0) ?  round(($totPass/$tottestcase * 100),2) : 0;
		}else{
			$perexecution = round($data['s_pa_completion'],2);
			$totPasspercent = round($data['s_pa_completion'],2);
		}


		$part2_testplan .='<tr>
			<td>'.$data['activityname'].'</td>
			<td>'.$data['s_pa_status'].'</td>
			<td>'. $perexecution." %" .'</td>
			<td>'.(!empty($planstartdate) ? $planstartdate : "-").'</td>
			<td>'.(!empty($planenddate) ? $planenddate : "-").'</td>
			<td>'.(!empty($revisedstartdate) ? $revisedstartdate : "-").'</td>
			<td>'.(!empty($revisedenddate) ? $revisedenddate : "-").'</td>
			<td>'.(!empty($actualstartdate) ? $actualstartdate : "-").'</td>
			<td>'.(!empty($actualenddate) ? $actualenddate : "-").'</td>
			<td>'.$data['s_pa_desc'].'</td>

		</tr>';
	}
	// Close the statement
	mysqli_stmt_close($actstmt);
}


$part2testplan = '<table id="dsrtestplanTbl" class="table  compact table-bordered"  width="100%">
		<thead>
			<tr class="thcss">
			<th colspan="10" align="center"><big>Activity Status Updates</big></th> 
			</tr>
			<tr>
			<th colspan="10" align="center">&nbsp;</th> 
			</tr>
			<tr  class="thcss">
			<th>Activity Name</th>
			<th>Status</th> 
			<th>Activity completion %</th> 
			<th>Plan Start Date</th> 
			<th>Plan End Date</th>
			<th>Revised Start Date</th> 
			<th>Revised End Date</th>
			<th>Actual Start Date</th> 
			<th>Actual End Date</th>                
			<th>Remark</th>
			</tr> 
		</thead>
		<tbody align="center">'.$part2_testplan.'</tbody>
	</table>';


//////////////////// Test Execution summary

	$where = "";$part3_exec = "";
	if($projectId !=""){
		$where = $where." and projectId in ($projectId) ";
	}

	if($releaseId !=""){
		$where = $where." and releaseId in ($releaseId) ";
	}

	if($activityId !=""){

		$actarr = explode(",", $activityId);
		if(isset($actarr) && !empty($actarr)){
			$actlen = count($actarr);
			for($i =0; $i<$actlen; $i++){
				$where = " AND find_in_set('".$actarr[$i]."',s_t_activityIds)  ";
			}
		}
	}
	$iterationwhere = "";

	if(isset($_SESSION["usertype"]) && $_SESSION["usertype"] != "Admin"){
		$where .= " and projectId in (select s_p_id from s_project where s_p_id in (select projectId from s_project_members where employeeId = '".$userempid."' ) or s_p_enteredby = '".$enteredby."' and accountId = '".$accountId."')";
	}
	$tcstmt = mysqli_prepare($conn,"SELECT distinct(s_t_module) as module from s_testcase where s_t_createdtime <= ? ".$where);

	mysqli_stmt_bind_param($tcstmt, 's',$dsrdate);
	mysqli_stmt_execute($tcstmt);
	$sqldata = mysqli_stmt_get_result($tcstmt);

	$grand_createdtc = 0;$grand_exectc = 0;$grand_tc=0; $grand_iteration= 0; $grand_pass = 0; $grand_fail = 0;
	$grand_inprogress= 0; $grand_norun = 0; $grand_block = 0; $grand_deferred = 0; $grand_na = 0; $grand_onhold = 0; 
	$grand_execpercent = 0; $grand_passpercent = 0; $grand_failpercent = 0; $grand_inprogresspercent = 0;
	$grand_norunpercent = 0; $grand_blockpercent = 0;$grand_ohholdpercent = 0; $grand_deferredpercent = 0; $grand_napercent = 0;
	while($mdata = mysqli_fetch_assoc($sqldata)){
		$totalexecution = 0;
		$totaltestcase = 0;
		$passCount = 0;
		$failCount = 0;
		$NACount = 0;
		$BlockedCount = 0;
		$No_RunCount = 0;
		$onholdCount = 0;
		$inprogressCount = 0;
		$deferredCount = 0;
		// get testcase
		$sqlexecutiondataarray = array();
		$module = $mdata['module'];
		$sqlalltc = mysqli_query($conn,"SELECT IFNULL(count(*),0) as cnt from s_testcase where  s_t_createdtime <= '".$dsrdate."' and s_t_module = '".$module."' ".$where);
		

		while($tcdata = mysqli_fetch_assoc($sqlalltc)){		
			$totaltestcase = $tcdata['cnt'];
		}

		$sql2 = mysqli_query($conn,"SELECT DISTINCT(s_t_id) as tId from s_testcase where s_t_createdtime <= '".$dsrdate."' and s_t_module = '".$module."' ".$where);

		
		$idstring = "";
		while($tdata = mysqli_fetch_assoc($sql2)){		
			array_push($sqlexecutiondataarray, $tdata['tId']);
			if($idstring == ""){
				$idstring = "'".$tdata['tId']."'";
			}else{
				$idstring = $idstring.",'".$tdata['tId']."'";
			}
		}

		$iterationcount = 0;
		$iterationsqldata = mysqli_query($conn,"SELECT IFNULL(max(s_st_iteration),0) as iteration from s_testcaserun where testcaseId in(".$idstring.") and accountId = '".$accountId."' and s_st_createdtime <= '".$dsrdate."'  $iterationwhere order by s_st_id desc ");
		while($itdata = mysqli_fetch_assoc($iterationsqldata)){
			$iterationcount = $itdata['iteration'];
		}
		
		///get test execution
		$sql3 = mysqli_query($conn,"SELECT  * from s_testcasefinal 
			where s_f_id in (select max(s_f_id) from s_testcasefinal where testcaseId in(".$idstring.") group by testcaseId)");
		while($tedata = mysqli_fetch_assoc($sql3)){		
			$totalexecution++;
			if($tedata['s_f_testresult'] == "Pass"){
				$passCount++;
			}else if($tedata['s_f_testresult'] == "Fail"){
				$failCount++;
			}else if(in_array($tedata['s_f_testresult'], array("NA","CE_NA"))){
				$NACount++;
			}else if(in_array($tedata['s_f_testresult'], array("Block","Blocked","CE_Bug"))){
				$BlockedCount++;
			}else if(in_array($tedata['s_f_testresult'], array("Pending","No Run","Yet to Begin","Not Executed"))){
				$No_RunCount++;
			}else if($tedata['s_f_testresult'] == "On Hold"){
				$onholdCount++;
			}else if($tedata['s_f_testresult'] == "In Progress"){
				$inprogressCount++;
			}else if(in_array($tedata['s_f_testresult'], array("Deferred","CE_FR"))){
				$deferredCount++;
			}
		}
		$totalexecuted = $passCount + $failCount;
		$Scoped_Test_cases = $totaltestcase-$NACount;

		$executedpercent = ($Scoped_Test_cases > 0 ? (round(($totalexecuted/$Scoped_Test_cases ) *100,2) ) : 0);
		$passedpercent = ($totalexecuted > 0 ? (round(($passCount/$totalexecuted ) *100,2) ) : 0);
		$failedpercent = ($totalexecuted > 0 ? (round(($failCount/$totalexecuted ) *100,2) ) : 0);
		$cebugpercent = ($Scoped_Test_cases > 0 ? (round((($BlockedCount)/$Scoped_Test_cases ) *100,2) ) : 0);
		$norunpercent = ($Scoped_Test_cases > 0 ? (round(($No_RunCount/$Scoped_Test_cases ) *100,2) ) : 0);
		$napercent = ($Scoped_Test_cases > 0 ? (round(($NACount/$totaltestcase ) *100,2) ) : 0);
		$deferredpercent = ($Scoped_Test_cases > 0 ? (round(($deferredCount/$Scoped_Test_cases ) *100,2) ) : 0);
		$block_percent = ($Scoped_Test_cases > 0 ? (round(($BlockedCount/$Scoped_Test_cases ) *100,2) ) : 0);
		$onhold_percent = ($Scoped_Test_cases > 0 ? (round(($onholdCount/$Scoped_Test_cases ) *100,2) ) : 0);
		$inprogress_percent = ($Scoped_Test_cases > 0 ? (round(($inprogressCount/$Scoped_Test_cases ) *100,2) ) : 0);

		$projarr['data'][] = array($module,$totaltestcase,$Scoped_Test_cases,$totalexecuted,$iterationcount,$passCount,$failCount,$inprogressCount,$No_RunCount,$BlockedCount,$deferredCount,$NACount,$onholdCount,$executedpercent,$passedpercent,$failedpercent,$inprogress_percent,$norunpercent,$block_percent,$onhold_percent,$deferredpercent,$napercent);



		$grand_createdtc +=$totaltestcase;
		$grand_exectc += $Scoped_Test_cases;
		$grand_tc +=$totalexecuted; 
		$grand_iteration = ($iterationcount >$grand_iteration ? $iterationcount : $grand_iteration);
		$grand_pass += $passCount; 
		$grand_fail += $failCount;
		$grand_inprogress +=$inprogressCount; 
		$grand_norun +=$No_RunCount; 
		$grand_block +=$BlockedCount; 
		$grand_deferred +=$deferredCount; 
		$grand_na +=$NACount; 
		$grand_onhold +=$onholdCount; 
		
		$part3_exec .= '<tr>
			<td>'.$module.'</td>
			<td>'.$totaltestcase.'</td>
			<td>'.$Scoped_Test_cases.'</td>
			<td>'.$totalexecuted.'</td>
			<td>'.$iterationcount.'</td>
			<td>'.$passCount.'</td>
			<td>'.$failCount.'</td>
			<td>'.$inprogressCount.'</td>
			<td>'.$No_RunCount.'</td>
			<td>'.$BlockedCount.'</td>
			<td>'.$deferredCount.'</td>
			<td>'.$NACount.'</td>
			<td>'.$onholdCount.'</td>
			<td>'.$executedpercent.'</td>
			<td>'.$passedpercent.'</td>
			<td>'.$failedpercent.'</td>
			<td>'.$inprogress_percent.'</td>
			<td>'.$norunpercent.'</td>
			<td>'.$block_percent.'</td>
			<td>'.$onhold_percent.'</td>
			<td>'.$deferredpercent.'</td>
			<td>'.$napercent.'</td>
		</tr>';
	}
	// Close the statement
	mysqli_stmt_close($tcstmt);

	$grand_execpercent =($grand_exectc > $grand_tc ? round(($grand_tc/$grand_exectc)*100,2) : 0); 
	$grand_passpercent =($grand_exectc > $grand_pass ? round(($grand_pass/$grand_exectc)*100,2) : 0);  
	$grand_failpercent =($grand_exectc > $grand_fail ? round(($grand_fail/$grand_exectc)*100,2) : 0); 
	$grand_inprogresspercent =($grand_exectc > $grand_inprogress ? round(($grand_inprogress/$grand_exectc)*100,2) : 0);
	$grand_norunpercent =($grand_exectc > $grand_norun ? round(($grand_norun/$grand_exectc)*100,2) : 0);
	$grand_blockpercent =($grand_exectc > $grand_block ? round(($grand_block/$grand_exectc)*100,2) : 0);
	$grand_ohholdpercent =($grand_exectc > $grand_onhold ? round(($grand_onhold/$grand_exectc)*100,2) : 0);
	$grand_deferredpercent =($grand_exectc > $grand_deferred ? round(($grand_deferred/$grand_exectc)*100,2) : 0); 
	$grand_napercent =($grand_exectc > $grand_na ? round(($grand_na/$grand_exectc)*100,2) : 0);

	$part3 = '<table class="table  compact table-bordered"  width="100%">
				<thead  >
					<tr class="thcss">
						<th colspan="22" align="center"><big>Test Execution Summary</big></th> 
					</tr>
					<tr>
						<th colspan="22" align="center">&nbsp;</th> 
					</tr>
					<tr class="thcss" align="center">
					<th>Module Name</th>
					<th>Total Created TC</th>
					<th>Executable Test Cases</th>
					<th>Total Executed</th>
					<th>Iteration</th> 
					<th>Passed</th>
					<th>Failed</th>
					<th>In Progress</th>
					<th>No Run</th>
					<th>Blocked</th>
					<th>Deferred</th>
					<th>NA</th>
					<th>On Hold</th>
					<th>% Executed</th>
					<th>Passed Rate %</th>
					<th>Failed Rate %</th>
					<th>% In Progress</th>
					<th>% No Run</th>
					<th>% Blocked</th>
					<th>% On Hold</th>
					<th>% Deferred</th>
					<th>% NA</th>                                        
					</tr> 
				</thead>
				<tbody  align="center">
					'.$part3_exec.'
					<tr class="thcss" align="center">
						<th>Grand Total</th>
						<th>'.$grand_createdtc.'</th>
						<th>'.$grand_exectc.'</th>
						<th>'.$grand_tc.'</th>
						<th>'.$grand_iteration.'</th>
						<th>'.$grand_pass.'</th>
						<th>'.$grand_fail.'</th>
						<th>'.$grand_inprogress.'</th>
						<th>'.$grand_norun.'</th>
						<th>'.$grand_block.'</th>
						<th>'.$grand_deferred.'</th>
						<th>'.$grand_na.'</th>
						<th>'.$grand_onhold.'</th>
						<th>'.$grand_execpercent.'</th>
						<th>'.$grand_passpercent.'</th>
						<th>'.$grand_failpercent.'</th>
						<th>'.$grand_inprogresspercent.'</th>
						<th>'.$grand_norunpercent.'</th>
						<th>'.$grand_blockpercent.'</th>
						<th>'.$grand_ohholdpercent.'</th>
						<th>'.$grand_deferredpercent.'</th>
						<th>'.$grand_napercent.'</th>
					</tr>
				</tbody>
			</table>';


      ////////////////////////////////////////////////// Defect


		$where = "";$part4_defect = "";
		if($projectId !=""){
				$where = $where." and projectId in ($projectId) ";
		}

		if($releaseId !=""){
				$where = $where." and releaseId in ($releaseId) ";
		}

		$projectExtra = "";
		if(isset($_SESSION["usertype"]) && $_SESSION["usertype"] != "Admin"){
			$projectExtra .= " and bugs.projectId in (select s_p_id from s_project where s_p_id in (select projectId from s_project_members where employeeId = '".$userempid."' ) or s_p_enteredby = '".$enteredby."' )";
		}


		$defectstmt = mysqli_prepare($conn,"SELECT bugs.*,
			concat(IFNULL(assignTBl.s_e_fname,''),' ',IFNULL(assignTBl.s_e_mname,''),' ',IFNULL(assignTBl.s_e_lname,'')) as assigned_to,
			concat(IFNULL(reporterTBl.s_e_fname,''),' ',IFNULL(reporterTBl.s_e_mname,''),' ',IFNULL(reporterTBl.s_e_lname,'')) as reported_by ,
			IFNULL(dstatus.s_ds_name,'') as defectstatus ,
			IFNULL(DATEDIFF('".$defectdate."',s_d_createdtime),0) as ageingdays 
			 from s_defect AS bugs
										LEFT JOIN s_employees as assignTBl on assignTBl.s_e_id = bugs.s_d_assignto
									 	LEFT JOIN s_employees as reporterTBl on reporterTBl.userId = bugs.s_d_enteredby
									 	LEFT JOIN s_defectstatusmaster as dstatus on dstatus.s_ds_id = bugs.defectstatusId
									  	where  bugs.accountId = ? and s_d_createdtime <= ? ".$where." ".$projectExtra ." order by s_d_id desc");

		mysqli_stmt_bind_param($defectstmt, 'ss',$accountId,$dsrdate);
		mysqli_stmt_execute($defectstmt);
		$sqldata = mysqli_stmt_get_result($defectstmt);

		while($mdata = mysqli_fetch_assoc($sqldata)){
			$reported_by = (trim($mdata['reported_by'])  == "" ? "Admin" : $mdata['reported_by'] );
			$projarr['data'][] = array($mdata['s_d_id'],$mdata['s_d_defectnum'],$mdata['s_d_shortdesc'],$mdata['defectstatus'],$mdata['s_d_severity'],$mdata['s_d_priority'],
			$reported_by,$mdata['assigned_to'],1,$mdata['ageingdays']);

			$part4_defect.='<tr>
								<td>'.$mdata['s_d_defectnum'].'</td>
								<td>'.$mdata['s_d_shortdesc'].'</td>
								<td>'.$mdata['defectstatus'].'</td>
								<td>'.$mdata['s_d_severity'].'</td>
								<td>'.$mdata['s_d_seveageingdaysrity'].'</td>
							</tr>';
		}
		// Close the statement
		mysqli_stmt_close($defectstmt);

		$part4 = '<table class="table  compact table-bordered"  width="100%">
                    <thead  >
                    	<tr class="thcss">
                        <th colspan="5" align="center"><big>Defect Details</big></th> 
                        </tr>
                        <tr class="bg-white">
                        <th colspan="5" class="text-center"></th> 
                        </tr>  
                        <tr  class="thcss">
                        <th>Defect ID</th>
                        <th>Defect Description</th>
                        <th>Defect Status</th>
                        <th>Severity</th> 
                        <th>Defect Ageing (In days)</th>                                      
                        </tr> 
                    </thead>
                    <tbody align="center">'.$part4_defect.'
                    </tbody>
                </table>';


	$emaildsrbody =  '<html><head>
	<style>
	
	body {
		font-family: Calibri,Candara,Segoe,Segoe UI,Optima,Arial,sans-serif; 
		font-size: 16px;
		width: 100%; 
	}

	table, td,th{
	border: 1px solid black;	
	}

	.thcss{
	border:1px solid black;text-align: center;background-color: '.$CFG['stepcolor'].';color:white;	
	}
	.alert-warning {
	    color: #8a6d3b;
	    background-color: #fcf8e3;
	    border-color: #faebcc;
	}

	
	</style>

	</head><body >  '.
	$part1.'<br/><br/>'.$part2.'<br/><br/>'.$part2testplan.'<br/><br/>'.$part3.'<br/><br/>'.$part4.'</body></html>';

	$my_excel_filename = "/".md5(session_id().microtime(TRUE)).".xls";
		
	$filename = "Daily Status Report - $dsrdate";
	header("Content-Type:   application/vnd.ms-excel; charset=utf-8");
	header("Content-Disposition: attachment; filename=".$filename.".xls");  
	header("Expires: 0");
	header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
	header("Cache-Control: private",false);

	echo $emaildsrbody;


}

?>
