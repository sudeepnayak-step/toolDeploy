<?php
include('../config.php');

session_start();
 
$enteredby = 0;$accountId = 0;$userempid = 0;
 /** This script return the rag status data to show it on chart */

if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
    $userempid = $_SESSION["userempid"];
}


$projectExtra = "";
if(isset($_SESSION["usertype"]) && $_SESSION["usertype"] != "Admin"){
	$projectExtra = " and s_p_id in (select projectId from s_project_members where employeeId = '".$userempid."' )";
}

	$gcount = 0;
	$acount = 0;
	$rcount = 0;

	$stmt = mysqli_prepare($conn,"SELECT
		-- *
	 IFNULL(sum(CASE WHEN s_p_ragstatus = 'G' THEN 1 else 0 end),0) as Green,
	 IFNULL(sum(CASE WHEN s_p_ragstatus = 'R' THEN 1 else 0 end),0) as Red,
	 IFNULL(sum(CASE WHEN s_p_ragstatus = 'A' THEN 1 else 0 end),0) as Amber
	 from s_project where  s_p_activestatus  = 'Active' and accountId = ? $projectExtra ");

	mysqli_stmt_bind_param($stmt, 's', $accountId);
	mysqli_stmt_execute($stmt);
	$sqldata = mysqli_stmt_get_result($stmt);


	while($tcdata = mysqli_fetch_assoc($sqldata)){		
		$gcount += $tcdata['Green'];
		$acount += $tcdata['Amber'];
		$rcount += $tcdata['Red'];
	}
	mysqli_stmt_close($stmt);


	$seriesdata[] = array("name"=>"G","y"=>$gcount,"color"=>"#28a745");
	$seriesdata[] = array("name"=>"A","y"=>$acount,"color"=>"#ffc107");
	$seriesdata[] = array("name"=>"R","y"=>$rcount,"color"=>"#dc3545");
	$rowarr['seriesdata'] = $seriesdata;

	echo json_encode($rowarr,JSON_NUMERIC_CHECK);
?>