<?php
include('../config.php');
session_start();
$enteredby = 0;$accountId=0;$userempid = 0;
/** script to get defect chart data */
if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
    $userempid = $_SESSION["userempid"];
}
$projarr['data'] = array();
 
 
$projectId = (isset($_GET['projectId']) && !empty($_GET['projectId'])? $_GET['projectId'] : "");
$releaseId = (isset($_GET['releaseId'])  && !empty($_GET['releaseId'])?  $_GET['releaseId'] : "");
$testsuiteId = (isset($_GET['testsuiteId'])  && !empty($_GET['testsuiteId'])? $_GET['testsuiteId'] : "");
 
 
$where = "";$fwhere="";
if($projectId !=""){
	$where = $where." and find_in_set(tc.projectId,'$projectId') ";
}
 
if($releaseId !=""){
	$where = $where." and find_in_set(tc.releaseId,'$releaseId') ";
}
 
// if(isset($_SESSION["usertype"]) && $_SESSION["usertype"] != "Admin"){
// 	$where .= " and r.projectId in (select s_p_id from s_project where s_p_id in (select projectId from s_project_members where employeeId = '".$userempid."' ) or s_p_enteredby = '".$enteredby."' and accountId = '".$accountId."')";
 
// }
 
////// defect report
$mainarr = array();
 
$sql = "SELECT 
    tc.s_t_module,
    COUNT(tc.s_t_id) AS total_testcases,
    COUNT(rt.testcaseId) AS mapped_testcases,
    COUNT(tc.s_t_id) - COUNT(rt.testcaseId) AS unmapped_testcases,
    ROUND(
        ((COUNT(tc.s_t_id) - COUNT(rt.testcaseId)) / COUNT(tc.s_t_id)) * 100,
        2
    ) AS unmapped_percentage
FROM 
    s_testcase tc
LEFT JOIN 
    s_rtm_testcase rt 
    ON rt.testcaseId = tc.s_t_id 
    AND rt.testcaseId IS NOT NULL 
    AND rt.testcaseId != '' 
    AND rt.testcaseId != '0'
WHERE 
    tc.accountId = ? $where
GROUP BY 
    tc.s_t_module";
//echo $sql;   
$stmt = mysqli_prepare($conn,$sql);
mysqli_stmt_bind_param($stmt, 's', $accountId);
mysqli_stmt_execute($stmt);
$sqlDefectmodule = mysqli_stmt_get_result($stmt);
 
 
$seriesdata = array();
 
$categories = [];
$totalarr = [];
$unmappedarr = [];
$unmappedperarr = [];
while($row = mysqli_fetch_assoc($sqlDefectmodule)){
    $mod = !empty($row['s_t_module']) ? $row['s_t_module'] : "Not Specified";
    $categories[] = $mod;
 
    $totalarr[] = (int)$row['total_testcases'];
    $unmappedarr[] = (int)$row['unmapped_testcases'];
    $unmappedperarr[] = (float)$row['unmapped_percentage'];
 
    
}
 
 
$seriesdata = [];
$seriesdata[] = array("name" => "Total Testcases", "data" => $totalarr);
$seriesdata[] = array("name" => "Not Covered Testcases", "data" => $unmappedarr);
$seriesdata[] = array("name" => "Not Covered Testcases (%)", "data" => $unmappedperarr);
 
 
// Close the statement
mysqli_stmt_close($stmt);
$mainarr = array("seriesdata"=>$seriesdata,"categories"=>$categories);
echo json_encode($mainarr,JSON_NUMERIC_CHECK);
 
?>
