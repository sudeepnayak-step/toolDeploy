<?php
include('../config.php');
session_start();
$enteredby = 0;$accountId=0;$userempid = 0;
/** script to get defect chart data */
if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
    $userempid = $_SESSION["userempid"];
}
$projarr['data'] = array();
 
 
$projectId = (isset($_GET['projectId']) && !empty($_GET['projectId'])? $_GET['projectId'] : "");
$releaseId = (isset($_GET['releaseId'])  && !empty($_GET['releaseId'])?  $_GET['releaseId'] : "");
$testsuiteId = (isset($_GET['testsuiteId'])  && !empty($_GET['testsuiteId'])? $_GET['testsuiteId'] : "");
 
 
$where = "";$fwhere="";
if($projectId !=""){
	$where = $where." and find_in_set(d.projectId,'$projectId') ";
}
 
if($releaseId !=""){
	$where = $where." and find_in_set(d.releaseId,'$releaseId') ";
}
 
// if(isset($_SESSION["usertype"]) && $_SESSION["usertype"] != "Admin"){
// 	$where .= " and r.projectId in (select s_p_id from s_project where s_p_id in (select projectId from s_project_members where employeeId = '".$userempid."' ) or s_p_enteredby = '".$enteredby."' and accountId = '".$accountId."')";
 
// }
 
////// defect report
$mainarr = array();
 
$sql = "SELECT 
    d.s_d_module,
    COUNT(d.s_d_id) AS total_defects,
    SUM(CASE WHEN d.testcaseId > 0 THEN 1 ELSE 0 END) AS mapped_defects,
    COUNT(d.s_d_id) - SUM(CASE WHEN d.testcaseId > 0 THEN 1 ELSE 0 END) AS unmapped_defects,
    ROUND(
        (SUM(CASE WHEN d.testcaseId > 0 THEN 1 ELSE 0 END) / COUNT(d.s_d_id)) * 100,
        2
    ) AS unmapped_percentage
FROM 
    s_defect d
WHERE 
    d.accountId = ? $where
GROUP BY 
    d.s_d_module";
//echo $sql;   
$stmt = mysqli_prepare($conn,$sql);
mysqli_stmt_bind_param($stmt, 's', $accountId);
mysqli_stmt_execute($stmt);
$sqlDefectmodule = mysqli_stmt_get_result($stmt);
 
 
$seriesdata = array();
 
$categories = [];
$totalarr = [];
$unmappedarr = [];
$unmappedperarr = [];
while($row = mysqli_fetch_assoc($sqlDefectmodule)){
    $mod = !empty($row['s_d_module']) ? $row['s_d_module'] : "Not Specified";
    $categories[] = $mod;
 
    $totalarr[] = (int)$row['total_defects'];
    $mappedarr[] = (int)$row['mapped_defects'];
    $unmappedarr[] = (int)$row['unmapped_defects'];
    $unmappedperarr[] = (float)$row['unmapped_percentage'];
 
    
}
 
 
$seriesdata = [];
$seriesdata[] = array("name" => "Total Defects", "data" => $totalarr);
$seriesdata[] = array("name" => "Mapped Defects", "data" => $mappedarr);
$seriesdata[] = array("name" => "Not Mapped Defects", "data" => $unmappedarr);
//$seriesdata[] = array("name" => "Not Mapped Defects (%)", "data" => $unmappedperarr);
 
 
// Close the statement
mysqli_stmt_close($stmt);
$mainarr = array("seriesdata"=>$seriesdata,"categories"=>$categories);
echo json_encode($mainarr,JSON_NUMERIC_CHECK);
 
?>
