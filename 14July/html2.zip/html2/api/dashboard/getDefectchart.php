<?php
include('../config.php');
session_start();
 
$enteredby = 0;$accountId=0;$userempid = 0;
 
/** script to get defect chart data */
if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
    $userempid = $_SESSION["userempid"];
}
$projarr['data'] = array();

$testResultColors = [
    "Critical" => "#e74c3c",  // Red
    "High" => "#e67e22",      // Orange
    "Medium" => "#f1c40f",    // Yelow
    "Low" => "#2ecc71"        // Green    
];

$projectId = (isset($_GET['projectId']) && !empty($_GET['projectId'])? $_GET['projectId'] : "0");
$releaseId = (isset($_GET['releaseId'])  && !empty($_GET['releaseId'])? $_GET['releaseId'] : "0");
$activityId = (isset($_GET['activityId'])  && !empty($_GET['activityId'])? $_GET['activityId'] : "0");
$defectstatusId = (isset($_GET['defectstatusId'])  && !empty($_GET['defectstatusId'])? $_GET['defectstatusId'] : "0");
$defectdate = (isset($_GET['defectdate']) && !empty($_GET['defectdate']) ?  "'".date('Y-m-d 23:59:59', strtotime(str_replace('/', '-', $_GET['defectdate'])))."'" : 'NULL');

$where = "";
if($projectId !="0"){
	if($where == ""){
			$where = " and find_in_set( projectId , '$projectId') ";

		}else{
		$where = $where." and find_in_set(projectId , '$projectId') ";
	}
}

if($releaseId !="0"){
		if($where == ""){
			$where = " and find_in_set( releaseId , '$releaseId') ";

		}else{			
		$where = $where." and find_in_set(releaseId , '$releaseId') ";
		}
}

if($activityId !="0"){
	if($where == ""){
			$where = " and  activityId = '$activityId' ";

		}else{
		$where = $where." and activityId = '$activityId' ";
	}
}

if($defectstatusId !="0"){
	if($where == ""){
			$where = " and  defectstatusId = '$defectstatusId' ";

		}else{
		$where = $where." and defectstatusId = '$defectstatusId' ";
	}
}

if(isset($_SESSION["usertype"]) && $_SESSION["usertype"] != "Admin"){
	if($where == ""){
		$where = " and projectId in (select projectId from s_project_members where employeeId = '".$userempid."' )";

	}else{
		$where = $where . " and projectId in (select projectId from s_project_members where employeeId = '".$userempid."' )";
	}
}
////// defect report
$mainarr = array();

//$stmt = mysqli_prepare($conn,"SELECT s_d_module as module FROM s_defect where  accountId = ?  ".$where." group by s_d_module ");
//$stmt = mysqli_prepare($conn,"SELECT s_d_severity as severity FROM s_defect where  accountId = ?  ".$where." group by s_d_severity ");

//mysqli_stmt_bind_param($stmt, 's', $accountId);
//mysqli_stmt_execute($stmt);
//$sqlDefectmodule = mysqli_stmt_get_result($stmt);

//$defectSeverityarr  = array();
			 	
//$category = array();$higharr = array();$lowarr = array();$mediumarr = array();
//$openarr = array(); $deferredarr = array(); $closearr = array();
//$openclosearr = array();
//$openCount = 0;$deferredCount = 0;$closeCount =0;$newCount = 0;
//$ageingarr = array();
//while($moddata = mysqli_fetch_assoc($sqlDefectmodule)){
//	$Modulename = $moddata['severity'];
//	$newwhere = $where;
//	if($newwhere == ""){
//			$newwhere = " and  s_d_severity = '".$Modulename."' ";
//
//		}else{
//		$newwhere = $newwhere." and s_d_severity = '".$Modulename."' ";
//	}
	//$newwhere = $newwhere." and defectstatusId in (select s_ds_id from s_defectstatusmaster where s_ds_name LIKE 'Open%') ";
//	 $newwhere = $newwhere." and defectstatusId in (select s_ds_id from s_defectstatusmaster where s_ds_name NOT IN('Closed','Not a Defect')) ";
//	$nDayscount  = 0;
//	$category[] = $Modulename;//$dsdata['Module'];
//	$sqlDefect = "SELECT  ROUND(AVG(IFNULL(DATEDIFF(".$defectdate.",s_d_createdtime),0) ),2) as ddays  FROM s_defect  where  accountId = '".$accountId."' ".$newwhere;

//	$sqlDefectData = mysqli_query($conn,$sqlDefect);
//	while($dsdata = mysqli_fetch_assoc($sqlDefectData)){
//		$nDayscount =  $dsdata['ddays'];
//	}
//	$ageingarr[] = $nDayscount;
//}

// Close the statement
//mysqli_stmt_close($stmt);
//$mainarr = array("categories"=>$category,"Ageing"=>$ageingarr);
//echo json_encode($mainarr,JSON_NUMERIC_CHECK);

$sql = "
    SELECT
    count(1) as defectcount,
        s_d_severity AS severity,
        ROUND(AVG(IFNULL(DATEDIFF($defectdate, s_d_createdtime), 0)),2) AS ddays
    FROM
        s_defect
    WHERE
        accountId = ?
        $where
        AND defectstatusId IN (
            SELECT s_ds_id
            FROM s_defectstatusmaster
            WHERE s_ds_name NOT IN ('Closed', 'Not a Defect')
        )
    GROUP BY
        s_d_severity ORDER BY
  FIELD(s_d_severity,'Shostopper', 'Critical', 'High', 'Medium', 'Low')
";
 
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, 's', $accountId);
mysqli_stmt_execute($stmt);
 
$result = mysqli_stmt_get_result($stmt);
 
$category = array();
$ageingarr = array();
$countarr = array();
 
$seriesdata = array();
while ($row = mysqli_fetch_assoc($result)) {
    $category[] = $row['severity'];
    $color = isset($testResultColors[$row['severity']]) ? $testResultColors[$row['severity']] : "#000000";
	$ageingarr[] = array("y"=>$row['ddays'],"color"=>$color);
    $countarr[] = $row['defectcount'];
//    $testresultcolor[] = isset($testResultColors[$row['severity']]) ? $testResultColors[$row['severity']] : "#000000";
}
 
//$seriesdata[] = array("name"=>"Defect Ageing","data"=>$ageingarr,"color"=>$testresultcolor);
//$seriesdata[] = array("name"=>"Total Defect","data"=>$countarr,"color"=>$testresultcolor);
$seriesdata[] = array("name"=>"Defect Ageing","data"=>$ageingarr);
$seriesdata[] = array("name"=>"Total Defect","data"=>$countarr);
mysqli_stmt_close($stmt);
 
$mainarr = array("categories" => $category, "Ageing" => $seriesdata);
 
echo json_encode($mainarr, JSON_NUMERIC_CHECK);
?>
