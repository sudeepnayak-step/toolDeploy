<?php
include('../config.php');
session_start();
 
$enteredby = 0;$accountId=0;$userempid = 0;
/** this script return the top defect data */ 

if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
    $userempid = $_SESSION["userempid"];
}
$projarr['data'] = array();


$projectId = (isset($_POST['projectId']) && !empty($_POST['projectId'])?  implode(",",$_POST['projectId']) : "");
$releaseId = (isset($_POST['releaseId'])  && !empty($_POST['releaseId'])? implode(",",$_POST['releaseId']) : "");
$activityId = (isset($_POST['activityId'])  && !empty($_POST['activityId'])? implode(",",$_POST['activityId']) : "");
$defectstatusId = (isset($_POST['defectstatusId'])  && !empty($_POST['defectstatusId'])? implode(",",$_POST['defectstatusId']) : "");
$defectdate = (isset($_POST['defectdate']) && !empty($_POST['defectdate']) ? date('Y-m-d 23:59:59', strtotime(str_replace('/', '-', $_POST['defectdate']))) : date('Y-m-d 23:59:59'));

// Build the WHERE clause dynamically
$params = [];
$types = "";
$where = "";
if($projectId !=""){
		// $where = $where." and projectId in ($projectId) ";
		
		$where .= " AND find_in_set(projectId,?) ";
		$params[] = $projectId;
		$types .= "s";
}else{

// echo json_encode($projarr);
echo json_encode([
	"draw" => intval($_POST['draw']),
	"recordsTotal" => 0,
	"recordsFiltered" => 0, // modify if search applied
	"data" => $projarr['data']
]);
exit;
}

if ($releaseId != "") {
    $where .= " AND find_in_set(releaseId,?) ";
    $params[] = $releaseId;
    $types .= "s";
}


if ($defectstatusId != "") {
    $where .= " AND find_in_set(defectstatusId,?) ";
    $params[] = $defectstatusId;
    $types .= "s";
}



// $projectExtra = "";
// if(isset($_SESSION["usertype"]) && $_SESSION["usertype"] != "Admin"){
// 	$projectExtra .= " and bugs.projectId in (select s_p_id from s_project where s_p_id in (select projectId from s_project_members where employeeId = '".$userempid."' ) or s_p_enteredby = '".$enteredby."' )";
// }

if (isset($_SESSION["usertype"]) && $_SESSION["usertype"] != "Admin") {
    $where .= " AND projectId IN (SELECT s_p_id FROM s_project WHERE s_p_id IN (SELECT projectId FROM s_project_members WHERE employeeId = ? AND accountId = ?) OR s_p_enteredby = ? AND accountId = ?)";
    $params[] = $userempid;
    $params[] = $accountId;
    $params[] = $enteredby;
    $params[] = $accountId;
    $types .= "ssss";
}


// Collect DataTables parameters
$start  = $_POST['start'];
$length = $_POST['length'];
$searchValue = $_POST['search']['value'] ?? '';
$orderColumn = $_POST['order'][0]['column'] ?? 0;
$orderDir    = $_POST['order'][0]['dir'] ?? 'asc';



// COUNT total records
$countSql = "SELECT COUNT(1) as total FROM s_defect d 
 WHERE d.accountId = ? $where ";
// Prepare statement
$countstmt = mysqli_prepare($conn, $countSql);
	
mysqli_stmt_bind_param($countstmt, "i" . $types, $accountId, ...$params);
mysqli_stmt_execute($countstmt);
$countResult = mysqli_stmt_get_result($countstmt);

$totalRecords = 0;
while($cdata = mysqli_fetch_assoc($countResult)){
$totalRecords = $cdata['total'];
}


// Prepare the SQL query for filter
$sql = "SELECT count(1) as filterrows
        FROM s_defect  
        WHERE accountId = ? $where 
        
        ";
        // DATE_FORMAT(CONVERT_TZ(s_d_createdtime, 'UTC', 'Asia/Kolkata'), '%Y-%m-%d %l:%i %p') as createdtime,
        // DATE_FORMAT(CONVERT_TZ(s_d_updatetime, 'UTC', 'Asia/Kolkata'), '%Y-%m-%d %l:%i %p') as updatetime 

// Prepare statement
$filterstmt = mysqli_prepare($conn, $sql);
	
mysqli_stmt_bind_param($filterstmt, "i" . $types, $accountId, ...$params);
mysqli_stmt_execute($filterstmt);
$filterresult = mysqli_stmt_get_result($filterstmt);

$filterrows = 0;
while($fdata = mysqli_fetch_assoc($filterresult)){
$filterrows = $fdata['filterrows'];
}


$defectsql = "SELECT bugs.*,
	concat(IFNULL(assignTBl.s_e_fname,''),' ',IFNULL(assignTBl.s_e_mname,''),' ',IFNULL(assignTBl.s_e_lname,'')) as assigned_to, role.s_role_name as rolename,
	concat(IFNULL(reporterTBl.s_e_fname,''),' ',IFNULL(reporterTBl.s_e_mname,''),' ',IFNULL(reporterTBl.s_e_lname,'')) as reported_by ,
	IFNULL(dstatus.s_ds_name,'') as defectstatus ,
	(case when dstatus.s_ds_name NOT IN('Closed','Not a Defect') then IFNULL(DATEDIFF('".$defectdate."',s_d_createdtime),0) else '-' end)as ageingdays 
	 from s_defect AS bugs
								LEFT JOIN s_employees as assignTBl on assignTBl.s_e_id = bugs.s_d_assignto
							 	LEFT JOIN s_employees as reporterTBl on (reporterTBl.userId = bugs.s_d_enteredby and  reporterTBl.accountId =  ? )
							 	LEFT JOIN s_defectstatusmaster as dstatus on dstatus.s_ds_id = bugs.defectstatusId
							  	LEFT JOIN s_role as role on  role.s_role_id =  assignTBl.roleid 
								where  bugs.accountId = ? and s_d_createdtime <= ? ".$where." 
								
								ORDER BY s_d_id $orderDir LIMIT $start, $length ";

$stmt = mysqli_prepare($conn,$defectsql);

// mysqli_stmt_bind_param($stmt, 'sss',$accountId, $accountId,$defectdate);

mysqli_stmt_bind_param($stmt, "iis" . $types, $accountId,$accountId,$defectdate, ...$params);
mysqli_stmt_execute($stmt);
$sqldata = mysqli_stmt_get_result($stmt);

while($mdata = mysqli_fetch_assoc($sqldata)){
	$reported_by = (trim($mdata['reported_by'])  == "" ? "Admin" : $mdata['reported_by'] );
	$projarr['data'][] = array($mdata['s_d_id'],$mdata['s_d_defectnum'],$mdata['s_d_shortdesc'],$mdata['defectstatus'],$mdata['s_d_severity'],$mdata['s_d_priority'],
	 $mdata['rolename'],$reported_by ,1,$mdata['ageingdays']);
}
mysqli_stmt_close($stmt);

// echo json_encode($projarr);
// Return JSON response
echo json_encode([
    "draw" => intval($_POST['draw']),
    "recordsTotal" => $totalRecords,
    "recordsFiltered" => $filterrows, // modify if search applied
    "data" => $projarr['data']
]);
?>
