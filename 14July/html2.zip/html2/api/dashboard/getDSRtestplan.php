<?php
include('../config.php');
session_start();
 
$enteredby = 0;$accountId = 0;$userempid = 0;
 
/** this script shows the data for test plan result in dsr */
if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $userempid = $_SESSION["userempid"];
    $accountId = $_SESSION["accountId"];
}


$projarr['data'] = array();

$projectId = (isset($_GET['projectId']) && !empty($_GET['projectId'])? $_GET['projectId'] : "");
$releaseId = (isset($_GET['releaseId'])  && !empty($_GET['releaseId'])? $_GET['releaseId'] : "");
$activityId = (isset($_GET['activityId'])  && !empty($_GET['activityId'])? $_GET['activityId'] : "");
$dsrdate = (isset($_GET['dsrdate']) && !empty($_GET['dsrdate']) ?  "'".date('Y-m-d 23:59:59', strtotime(str_replace('/', '-', $_GET['dsrdate'])))."'" : "'".date('Y-m-d 23:59:59')."'");

$where = "";
if($projectId !=""){
	$where = $where." and pa.projectId in ($projectId) ";
}

if($releaseId !=""){
	$where = $where." and pa.releaseId in ($releaseId) ";
}

if($activityId !=""){
	$where = $where." and pa.activityId in ($activityId) ";
}
if(isset($_SESSION["usertype"]) && $_SESSION["usertype"] != "Admin"){
	$where .= " and pa.projectId in (select s_p_id from s_project where s_p_id in (select projectId from s_project_members where employeeId = '".$userempid."'  and accountId = '".$accountId."') or s_p_enteredby = '".$enteredby."' and accountId = '".$accountId."')";
}

if($projectId != "" && $releaseId !=""){

	$stmt = mysqli_prepare($conn,"SELECT pa.*,IFNULL(p.s_p_name,'') as projectname,IFNULL(r.s_r_name,'') as releaseNum,IFNULL(a.s_a_name,'') as activityname,
	IFNULL(a.s_a_code,'') as activitycode ,
	IFNULL(a.s_a_type,'') as activitytype 
	from s_project_activity pa 
	join s_project p on p.s_p_id = pa.projectId 
	join s_activitymaster a on a.s_a_id = pa.activityId 
	join s_release r on r.s_r_id = pa.releaseId 
	where pa.accountId = ? and pa.s_pa_activestatus = 'Active'  $where  
	order by pa.s_pa_id asc");

	mysqli_stmt_bind_param($stmt, 's', $accountId);
	mysqli_stmt_execute($stmt);
	$sqldata = mysqli_stmt_get_result($stmt);

	$srno = 0;
	while($data = mysqli_fetch_assoc($sqldata)){

		
		$planstartdate = (isset($data['s_pa_planstartdate']) && ($data['s_pa_planstartdate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_pa_planstartdate'])) : "");

		$planenddate = (isset($data['s_pa_planenddate']) && ($data['s_pa_planenddate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_pa_planenddate'])) : "");

		$revisedstartdate = (isset($data['s_pa_revisedstartdate']) && ($data['s_pa_revisedstartdate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_pa_revisedstartdate'])) : "");

		$revisedenddate = (isset($data['s_pa_revisedenddate']) && ($data['s_pa_revisedenddate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_pa_revisedenddate'])) : "");
		
		$actualstartdate = (isset($data['s_pa_actualstartdate']) && ($data['s_pa_actualstartdate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_pa_actualstartdate'])) : "");

		$actualenddate = (isset($data['s_pa_actualenddate']) && ($data['s_pa_actualenddate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_pa_actualenddate'])) : "");
		


		$totexecution = 0;
		$perexecution = 0;
		$tottestcase = 0;
		$totPass = 0;
		$totPasspercent = 0;
		$tcids = "";
		if($data['activitytype'] == "Execution"){
			//$testcasedata = mysqli_query($conn,"SELECT IFNULL(count(1),0) as totcount,IFNULL(GROUP_CONCAT(s_t_id),'') as tcids from s_testcase where projectId = '".$data['projectId']."'
			//							  and releaseId = '".$data['releaseId']."' and find_in_set('".$data['activityId']."',s_t_activityIds)   and accountId = '".$accountId."' and  s_t_createdtime <= ".$dsrdate."  ");

			//while($tdata = mysqli_fetch_assoc($testcasedata)){
			//	$tottestcase = $tdata['totcount'] ;
			//	$tcids = " and find_in_set(testcaseId,'".$tdata['tcids']."') " ;
			//}

			//$exedata = mysqli_query($conn, "SELECT  IFNULL(SUM(CASE WHEN s_f_testresult = 'Fail' THEN 1 ELSE 0 END),0) as Failcount,
			//							IFNULL(SUM(CASE WHEN s_f_testresult = 'Pass' THEN 1 ELSE 0 END),0) as Passcount from s_testcasefinal where projectId = '".$data['projectId']."'
			//							  and releaseId = '".$data['releaseId']."' and activityId = '".$data['activityId']."' and accountId = '".$accountId."' ".$tcids." ");

			$exesql = "
            SELECT
                COUNT(DISTINCT st.s_t_id) AS totcount,
                SUM(CASE WHEN sf.s_f_testresult = 'Fail' THEN 1 ELSE 0 END) AS Failcount,
                SUM(CASE WHEN sf.s_f_testresult = 'Pass' THEN 1 ELSE 0 END) AS Passcount
            FROM s_testcase st
            LEFT JOIN (
                SELECT sf1.*
                FROM s_testcasefinal sf1
                INNER JOIN (
                    SELECT testcaseId, MAX(s_f_id) AS max_id
                    FROM s_testcasefinal
                    WHERE projectId = '".$data['projectId']."'
                      AND releaseId = '".$data['releaseId']."'
                      AND activityId = '".$data['activityId']."'
                      AND accountId = '".$accountId."'
                    GROUP BY testcaseId
                ) latest ON sf1.s_f_id = latest.max_id
            ) sf ON sf.testcaseId = st.s_t_id
            WHERE st.projectId = '".$data['projectId']."'
              AND st.releaseId = '".$data['releaseId']."'
              AND FIND_IN_SET('".$data['activityId']."', st.s_t_activityIds)
              AND st.accountId = '".$accountId."'
              AND st.s_t_createdtime <= ".$dsrdate."
        ";
        //echo $exesql;
            $exedata = mysqli_query($conn,$exesql);
			while($edata = mysqli_fetch_assoc($exedata)){
				$totexecution = $edata['Failcount'] + $edata['Passcount'];
				$totPass = $edata['Passcount'];
				$tottestcase = $edata['totcount'];
			}
			$perexecution = ($tottestcase >0) ?  round(($totexecution/$tottestcase * 100),2) : 0;
			$totPasspercent = ($tottestcase >0) ?  round(($totPass/$tottestcase * 100),2) : 0;
		}else{
			$perexecution = round($data['s_pa_completion'],2);
			$totPasspercent = round($data['s_pa_completion'],2);
		}


		$projarr['data'][] = array(
		$data['activityname'],
		$data['s_pa_status'],
		$perexecution." %",
		(!empty($planstartdate) ? $planstartdate : "-"),
		(!empty($planenddate) ? $planenddate : "-"),
		(!empty($revisedstartdate) ? $revisedstartdate : "-"),
		(!empty($revisedenddate) ? $revisedenddate : "-"),
		(!empty($actualstartdate) ? $actualstartdate : "-"),
		(!empty($actualenddate) ? $actualenddate : "-"),

		$data['s_pa_desc'],

		);
	}
	mysqli_stmt_close($stmt);
}

echo json_encode($projarr);
?>
