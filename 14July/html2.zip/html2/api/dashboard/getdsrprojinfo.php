<?php
include('../config.php');
session_start();
 
$enteredby = 0;$accountId=0;$userempid = 0;
 
/** this script insert or update the summary data into dsr table for specific date */
if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
    $userempid = $_SESSION["userempid"];
}
$projarr['data'] = array();


$projectId = (isset($_POST['projectId']) && !empty($_POST['projectId'])?  $_POST['projectId'] : "");
$releaseId = (isset($_POST['releaseId'])  && !empty($_POST['releaseId'])? $_POST['releaseId'] : "");
$overallsummary = (isset($_POST['overallsummery'])  && !empty($_POST['overallsummery'])? mysqli_real_escape_string($conn,$_POST['overallsummery']) : "");
$prodlosssummary = (isset($_POST['prodlosssummery'])  && !empty($_POST['prodlosssummery'])? mysqli_real_escape_string($conn,$_POST['prodlosssummery']) : "");
$dsrdate = (isset($_POST['dsrdate']) && !empty($_POST['dsrdate']) ?  date('Y-m-d', strtotime(str_replace('/', '-', $_POST['dsrdate']))) : date('Y-m-d'));

$where = "";
if($projectId !=""){
		$where = $where." and projectId in ($projectId) ";
}

if($releaseId !=""){
		$where = $where." and s_r_id in ($releaseId) ";
}

if($projectId != "" && $releaseId !=""){


	$stmt = mysqli_prepare($conn,"SELECT r.*,
	IFNULL(p.s_p_name,'') as projectname,
	IFNULL(p.clientId,'0') as projectclient

	from s_release r 
	join s_project p on p.s_p_id = r.projectId 
	where r.accountId = ?   $where 
	order by r.s_r_id desc");

	mysqli_stmt_bind_param($stmt, 's', $accountId);
	mysqli_stmt_execute($stmt);
	$sqldata = mysqli_stmt_get_result($stmt);

	while($mdata = mysqli_fetch_assoc($sqldata)){
		$dsrstmt = mysqli_prepare($conn,"SELECT * from s_dsrtbl where 
			projectId = ? and 
			releaseId = ? and 
			s_dsr_date = ? and
			accountId = ?  order by s_dsr_id desc limit 1 
				");
		mysqli_stmt_bind_param($dsrstmt, 'ssss',$projectId,$releaseId,$dsrdate, $accountId);
		mysqli_stmt_execute($dsrstmt);
		$dsrdata = mysqli_stmt_get_result($dsrstmt);
		$numcount = mysqli_num_rows($dsrdata);
		mysqli_stmt_close($dsrstmt);

		if($numcount <=0){

			///////////////////////
			$dsrstmt = mysqli_prepare($conn,"SELECT * from s_dsrtbl where 
				projectId = ? and 
				releaseId = ? and 
				s_dsr_date <= ? and
				accountId = ?  order by s_dsr_id desc limit 1 
					");
			
			mysqli_stmt_bind_param($dsrstmt, 'ssss',$projectId,$releaseId,$dsrdate, $accountId);
			mysqli_stmt_execute($dsrstmt);
			$dsrdata1 = mysqli_stmt_get_result($dsrstmt);
			$numcount1 = mysqli_num_rows($dsrdata1);
			mysqli_stmt_close($dsrstmt);
			
			$numcount1 = mysqli_num_rows($dsrdata1);
			if($numcount1 <=0){
				$insertstmt = mysqli_prepare($conn, "INSERT INTO `s_dsrtbl` (`s_dsr_date`, `projectId`, `releaseId`, `s_dsr_overallsummary`, `s_dsr_prodlosssummary`, `accountId`, `s_dsr_enteredby`) 
                               VALUES (?, ?, ?, ?, ?, ?, ?)");
				mysqli_stmt_bind_param($insertstmt, "sssssss", $dsrdate, $projectId, $releaseId, $overallsummary, $prodlosssummary, $accountId, $enteredby);
				mysqli_stmt_execute($insertstmt);
				mysqli_stmt_close($insertstmt);
			}else{
				while($ddata1 = mysqli_fetch_assoc($dsrdata1)){
						$overallsummary = $ddata1['s_dsr_overallsummary'];
						$prodlosssummary = $ddata1['s_dsr_prodlosssummary'];
						
						$insertstmt = mysqli_prepare($conn, "INSERT INTO `s_dsrtbl` (`s_dsr_date`, `projectId`, `releaseId`, `s_dsr_overallsummary`, `s_dsr_prodlosssummary`, `accountId`, `s_dsr_enteredby`) 
						VALUES (?, ?, ?, ?, ?, ?, ?)");
						mysqli_stmt_bind_param($insertstmt, "sssssss", $dsrdate, $projectId, $releaseId, $overallsummary, $prodlosssummary, $accountId, $enteredby);
						mysqli_stmt_execute($insertstmt);
						mysqli_stmt_close($insertstmt);
				}
			}
		}else{
			if(isset($_POST['overallsummery'])){
				$updatestmt = mysqli_prepare($conn, "UPDATE s_dsrtbl SET 
                               `s_dsr_overallsummary` = ?, 
                               `s_dsr_prodlosssummary` = ? 
                               WHERE 
                               projectId = ? AND 
                               releaseId = ? AND 
                               s_dsr_date = ? AND 
                               accountId = ?");
				mysqli_stmt_bind_param($updatestmt, "ssssss", $overallsummary, $prodlosssummary, $projectId, $releaseId, $dsrdate, $accountId);
				mysqli_stmt_execute($updatestmt);
				mysqli_stmt_close($updatestmt);
			}else{

				while($ddata = mysqli_fetch_assoc($dsrdata)){
						$overallsummary = $ddata['s_dsr_overallsummary'];
						$prodlosssummary = $ddata['s_dsr_prodlosssummary'];
				}
			}
		}

		$duration = 0;
		$elapseddays = 0;
		$remainingdays = 0;
		$timeelapsed = 0;
		$planstartdate = (isset($mdata['s_r_planstartdate']) && ($mdata['s_r_planstartdate'] != "0000-00-00") ? date("d/m/Y",strtotime($mdata['s_r_planstartdate'])) : "-");

		$planenddate = (isset($mdata['s_r_planenddate']) && ($mdata['s_r_planenddate'] != "0000-00-00") ? date("d/m/Y",strtotime($mdata['s_r_planenddate'])) : "-");

		$revisedstartdate = (isset($mdata['s_r_revisedstartdate']) && ($mdata['s_r_revisedstartdate'] != "0000-00-00") ? date("d/m/Y",strtotime($mdata['s_r_revisedstartdate'])) : "-");

		$revisedenddate = (isset($mdata['s_r_revisedenddate']) && ($mdata['s_r_revisedenddate'] != "0000-00-00") ? date("d/m/Y",strtotime($mdata['s_r_revisedenddate'])) : "-");
			
		$actualstartdate = (isset($mdata['s_r_actualstartdate']) && ($mdata['s_r_actualstartdate'] != "0000-00-00") ? date("d/m/Y",strtotime($mdata['s_r_actualstartdate'])) : "-");

		$actualenddate = (isset($mdata['s_r_actualenddate']) && ($mdata['s_r_actualenddate'] != "0000-00-00") ? date("d/m/Y",strtotime($mdata['s_r_actualenddate'])) : "-");

		$projarr['data'] = array("Project"=>$mdata['projectname'],
			"Release"=>$mdata['s_r_name'],
			"Plan Start Date"=>$planstartdate,"Plan End Date"=>$planenddate,
			"Revised Start Date"=>$revisedstartdate,"Revised End Date"=>$revisedenddate,
			"overallsummary"=>$overallsummary,
			"prodlosssummary"=>$prodlosssummary,
			"projectclient"=>$mdata['projectclient'],
		);
	}
	// Close the statement
	mysqli_stmt_close($stmt);
}

echo json_encode($projarr);
?>
