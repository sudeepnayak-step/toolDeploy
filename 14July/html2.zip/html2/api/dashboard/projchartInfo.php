<?php
include('../config.php');

session_start();
 
$enteredby = 0;$accountId = 0;$userempid = 0;
/** this script work when user click on chart data
 * this script show the drilldown view for chart */ 

if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
    $userempid = $_SESSION["userempid"];
}


$projectExtra = "";
if(isset($_SESSION["usertype"]) && $_SESSION["usertype"] != "Admin"){
    $projectExtra = " and s_p_id in (select projectId from s_project_members where employeeId = '".$userempid."' )";
}
$xVal = isset($_POST['xVal']) ? $_POST['xVal']: "";
$type = isset($_POST['type']) ? $_POST['type']: "";

$xAxis = "";$yAxis ="";$chart_type = "";$title = "";
$where = "";
if($type == "RAG"){
    $where = " AND s_p_ragstatus = '".$xVal."' ";
}else if($type == "Status"){
    $where = " AND s_p_name = '".$xVal."' ";
}
$sqldata = mysqli_query($conn,"select * from s_project where  s_p_activestatus = 'Active' ".$where  ); // get all active project

	 	
echo '  
      	<table id="projectTbl" class="table compact " style="width:100%;">
        <thead  class="bg-step text-white">
            <tr>
            <th>Project Name</th>
            <th>Project Code</th>
            <th>RAG Status</th> 
            <th>Members</th> 
            <th>Status</th> 
            <th>Plan Start Date</th> 
            <th>Plan End Date</th>
            <th>Actual Start Date</th> 
            <th>Actual End Date</th> 
            <th>Active Status</th> 
            </tr> 
        </thead>	<tbody> 
';

while($data = mysqli_fetch_assoc($sqldata)){

$membersarr = array();
$membersnamearr = array();

$chksql = "select mem.*, concat(IFNULL(s_e_fname,''),' ',IFNULL(s_e_mname,''),' ',IFNULL(s_e_lname,'')) as membersname from s_project_members mem join s_employees emp on emp.s_e_id = mem.employeeId where projectId = '".$data['s_p_id']."'  ";

$chkstmt = mysqli_query( $conn, $chksql);

while($mdata = mysqli_fetch_assoc($chkstmt)){
if(!in_array($mdata['employeeId'], $membersarr)){
array_push($membersnamearr, $mdata['membersname']);
array_push($membersarr, $mdata['employeeId']);
}

}
$mname = implode(",", $membersnamearr);

echo '<tr>
<th>'.$data['s_p_name'].'</th>
<th>'.$data['s_p_code'].'</th>
<th>'.$data['s_p_ragstatus'].'</th>
<th>'.$mname.'</th>
<th>'.$data['s_p_status'].'</th>
<th>'.(isset($data['s_p_planstartdate']) && ($data['s_p_planstartdate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_p_planstartdate'])) : "").'</th>
<th>'.(isset($data['s_p_planenddate']) && ($data['s_p_planenddate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_p_planenddate'])) : "").'</th>
<th>'.(isset($data['s_p_actualstartdate']) && ($data['s_p_actualstartdate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_p_actualstartdate'])) : "").'</th>
<th>'.(isset($data['s_p_actualenddate']) && ($data['s_p_actualenddate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_p_actualenddate'])) : "").'</th>
<th>'.$data['s_p_activestatus'].'</th>
</tr>';

}
echo '</tbody>
						</table>';				

