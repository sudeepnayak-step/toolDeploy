<?php
include('../config.php');
session_start();
 
$enteredby = $_SESSION["id"] ?? 0;
$userempid = $_SESSION["userempid"] ?? 0;
$accountId = $_SESSION["accountId"] ?? 0;
$usertype = $_SESSION["usertype"] ?? '';
 
$projectId = $_GET['projectId'] ?? "";
$releaseId = $_GET['releaseId'] ?? "";
$activityId = $_GET['activityId'] ?? "";
$testsuiteId = $_GET['testsuiteId'] ?? "";
$testcasedate = isset($_GET['testcasedate']) && !empty($_GET['testcasedate'])
    ? date('Y-m-d 23:59:59', strtotime(str_replace('/', '-', $_GET['testcasedate'])))
    : date('Y-m-d 23:59:59');
 
$projarr['data'] = [];
 
 
$where = "";
$whereParams = [];
$whereTypes = "ssss";
 
if (empty($projectId)) {
    echo json_encode($projarr);
    exit();
}
if (!empty($releaseId)) {
    $where .= " AND tc.releaseId IN ($releaseId) ";
}
 
// if (!empty($activityId)) {
//     $actarr = explode(",", $activityId);
//     $activityFilters = array_map(fn($id) => "FIND_IN_SET('$id', tc.s_t_activityIds)", $actarr);
//     if (!empty($activityFilters)) {
//         $where .= " AND (" . implode(" OR ", $activityFilters) . ") ";
//     }
// }
 
$iterationwhere = "";
if (!empty($testsuiteId)) {
    $where .= " AND tc.s_t_id IN (SELECT testcaseId FROM s_testexecution WHERE testsuiteId IN ($testsuiteId) AND accountId = ?) ";
    $whereParams[] = $accountId;
    $whereTypes .= "s";
 
    $iterationwhere = $iterationwhere." and testsuiteId in ($testsuiteId) ";
}
 
if ($usertype != "Admin") {
    $where .= " AND tc.projectId IN (SELECT s_p_id FROM s_project WHERE (s_p_id IN (SELECT projectId FROM s_project_members WHERE employeeId = ?) OR s_p_enteredby = ?) AND accountId = ?) ";
    array_push($whereParams, $userempid, $enteredby, $accountId);
    $whereTypes .= "sss";
}
 
 
 
$sql = "
SELECT
  tc.s_t_module AS module,
  COUNT(DISTINCT tc.s_t_id) AS totaltestcase,
  COUNT(DISTINCT tf.testcaseId) AS totalexecution,
  SUM(tf.s_f_testresult = 'Pass') AS passCount,
  SUM(tf.s_f_testresult = 'Fail') AS failCount,
  SUM(tf.s_f_testresult IN ('NA','CE_NA')) AS NACount,
  SUM(tf.s_f_testresult IN ('Block','Blocked','CE_Bug')) AS BlockedCount,
  SUM(tf.s_f_testresult IN ('Pending','No Run','Yet to Begin','Not Executed')) AS NoRunCount,
  SUM(tf.s_f_testresult = 'On Hold') AS OnHoldCount,
  SUM(tf.s_f_testresult = 'In Progress') AS InProgressCount,
  SUM(tf.s_f_testresult IN ('Deferred','CE_FR')) AS DeferredCount,
 
  MAX(iter.max_iteration) AS max_iteration
FROM s_testcase tc
LEFT JOIN (
    SELECT * FROM s_testcasefinal
    WHERE s_f_id IN (
        SELECT MAX(s_f_id) FROM s_testcasefinal
        WHERE accountId = ?
        GROUP BY testcaseId
    )
) tf ON tf.testcaseId = tc.s_t_id
 
LEFT JOIN (
    SELECT testcaseId, MAX(s_st_iteration) AS max_iteration
    FROM s_testcaserun
    WHERE accountId = ?
    GROUP BY testcaseId
) iter ON iter.testcaseId = tc.s_t_id
 
WHERE tc.accountId = ? AND tc.s_t_createdtime <= ? AND tc.projectId IN ($projectId)
$where
GROUP BY tc.s_t_module
";
// echo $sql;
 
 
// echo "<pre/>"; print_r($whereTypes);
// echo "<pre/>"; print_r($whereParams);
$stmt = mysqli_prepare($conn, $sql);
$params = array_merge([$whereTypes], [$accountId, $accountId,$accountId, $testcasedate], $whereParams);
 
// echo "<pre/>"; print_r($params);
mysqli_stmt_bind_param($stmt, ...$params);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
 
while ($row = mysqli_fetch_assoc($result)) {
 
 
    $Scoped_Test_cases = $row['totaltestcase'] - $row['NACount'];
    $totalexecuted = $row['passCount'] + $row['failCount'];
 
    $projarr['data'][] = [
        $row['module'],
        $row['totaltestcase'],
        $Scoped_Test_cases,
        $totalexecuted,
        $row['max_iteration'],
        // '-', // iteration count placeholder
        $row['passCount'],
        $row['failCount'],
        $row['InProgressCount'],
        $row['NoRunCount'],
        $row['BlockedCount'],
        $row['DeferredCount'],
        $row['NACount'],
        $row['OnHoldCount'],
        $Scoped_Test_cases > 0 ? round(($totalexecuted / $Scoped_Test_cases) * 100, 2) : 0,
        $totalexecuted > 0 ? round(($row['passCount'] / $totalexecuted) * 100, 2) : 0,
        $totalexecuted > 0 ? round(($row['failCount'] / $totalexecuted) * 100, 2) : 0,
        $Scoped_Test_cases > 0 ? round(($row['InProgressCount'] / $Scoped_Test_cases) * 100, 2) : 0,
        $Scoped_Test_cases > 0 ? round(($row['NoRunCount'] / $Scoped_Test_cases) * 100, 2) : 0,
        $Scoped_Test_cases > 0 ? round(($row['BlockedCount'] / $Scoped_Test_cases) * 100, 2) : 0,
        $Scoped_Test_cases > 0 ? round(($row['OnHoldCount'] / $Scoped_Test_cases) * 100, 2) : 0,
        $Scoped_Test_cases > 0 ? round(($row['DeferredCount'] / $Scoped_Test_cases) * 100, 2) : 0,
        $Scoped_Test_cases > 0 ? round(($row['NACount'] / $row['totaltestcase']) * 100, 2) : 0
    ];
}
 
mysqli_stmt_close($stmt);
echo json_encode($projarr);
?>
