<?php
include('../config.php');
session_start();
 
$enteredby = 0;$accountId = 0;$userempid = 0;
 

/** this script work when user click on chart data
 * this script show the drilldown view for chart */ 
if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
    $userempid = $_SESSION["userempid"];
}


$projectExtra = "";
if(isset($_SESSION["usertype"]) && $_SESSION["usertype"] != "Admin"){
	$projectExtra = " and p.s_p_id in (select projectId from s_project_members where employeeId = '".$userempid."' )";
}


$chart_id = isset($_POST['chart_id']) ? $_POST['chart_id']: 0;
$xVal = isset($_POST['xVal'])  && $_POST['xVal'] !="Not Specified" ? $_POST['xVal']: "";

$xAxis = "";$yAxis ="";$chart_type = "";$title = "";
$sql = "select * from s_chartsetting where s_c_id = ?"; // get chart setting

$stmt = mysqli_prepare($conn,$sql);
mysqli_stmt_bind_param($stmt, 's', $chart_id);
mysqli_stmt_execute($stmt);
$sqlCustomData = mysqli_stmt_get_result($stmt);

while($cdsdata = mysqli_fetch_assoc($sqlCustomData)){

	$xAxis = $cdsdata['s_c_xaxis'];
	$yAxis = $cdsdata['s_c_yaxis'];

	$chart_type = $cdsdata['s_c_charttype'];
	$title = $cdsdata['s_c_title'];

}
mysqli_stmt_close($stmt);

echo '  
<table class="table compact " style="width:100%;" id="projectinfotbl">
	<thead  class="bg-step text-white" id="filters">
		<tr  class="danger" align="center">				 
			<th>Project Name</th>
			<th>Project Code</th>
			<th>RAG Status</th> 
			<th>Members</th> 
			<th>Status</th> 
			<th>Plan Start Date</th> 
			<th>Plan End Date</th>
			<th>Revised Start Date</th> 
			<th>Revised End Date</th>
			<th>Actual Start Date</th> 
			<th>Actual End Date</th> 
			<th>Owner</th>  
			<th>Client</th>  
			<th>Description</th>
		</tr> 
	</thead> 
	<tbody> 
';

$sqldata = mysqli_query($conn,"SELECT p.*,concat(IFNULL(s_e_fname,''),' ',IFNULL(s_e_mname,''),' ',IFNULL(s_e_lname,'')) as owner,
IFNULL(s_c_name,'') as client  from s_project p
left JOIN s_employees o1 on o1.s_e_id = p.s_p_owner
left JOIN s_client c1 on c1.s_c_id = p.clientId 
WHERE p.accountId = '".$accountId."'  and p.s_p_activestatus = 'Active'  order by s_p_id desc");

while($data = mysqli_fetch_assoc($sqldata)){
		$planstartdate = (isset($data['s_p_planstartdate']) && ($data['s_p_planstartdate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_p_planstartdate'])) : "");

		$planenddate = (isset($data['s_p_planenddate']) && ($data['s_p_planenddate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_p_planenddate'])) : "");

		$revisedstartdate = (isset($data['s_p_revisedstartdate']) && ($data['s_p_revisedstartdate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_p_revisedstartdate'])) : "");

		$revisedenddate = (isset($data['s_p_revisedenddate']) && ($data['s_p_revisedenddate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_p_revisedenddate'])) : "");
		
		$actualstartdate = (isset($data['s_p_actualstartdate']) && ($data['s_p_actualstartdate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_p_actualstartdate'])) : "");

		$actualenddate = (isset($data['s_p_actualenddate']) && ($data['s_p_actualenddate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_p_actualenddate'])) : "");
		
		$membersarr = array();
		$membersnamearr = array();

		$chksql = "select mem.*, concat(IFNULL(s_e_fname,''),' ',IFNULL(s_e_mname,''),' ',IFNULL(s_e_lname,'')) as membersname from s_project_members mem join s_employees emp on emp.s_e_id = mem.employeeId where projectId = '".$data['s_p_id']."' and mem.accountId = '".$accountId."' ";

		$chkstmt = mysqli_query( $conn, $chksql);

		while($mdata = mysqli_fetch_assoc($chkstmt)){
			if(!in_array($mdata['employeeId'], $membersarr)){
				array_push($membersnamearr, $mdata['membersname']);
				array_push($membersarr, $mdata['employeeId']);
			}

		}
	$projectclient = $mdata['clientId'];

	$planthreshold = 0;$actualthreshold = 0;$schedule = "G";$tempPlanDenomentor = 0;$tempActualNumerator = 0;
	$Tempstartdate = ($revisedenddate == "" ? $planenddate : $revisedenddate);
	
	$planFormatenddate =  ($revisedenddate == "" ? $planenddate : $revisedenddate);
	$Tempenddate = date('d/m/Y');
	$tempPlanNumerator = ($Tempstartdate !="" && $Tempenddate != "") ? GetDateDuration($projectclient,$Tempstartdate,$Tempenddate) : 0;
	
	if($actualenddate !="" && $actualstartdate != ""){
		$Tempstartdate = $actualstartdate;//date('Y-m-d',strtotime($actualstartdate));
		$Tempenddate = $actualenddate;//date('Y-m-d',strtotime($actualenddate));
		$tempPlanDenomentor = ($Tempstartdate !="" && $Tempenddate != "") ? GetDateDuration($projectclient,$Tempstartdate,$Tempenddate): 0;			
	}

	if($actualenddate !=""){
		$Tempstartdate = $actualenddate; //date('Y-m-d',strtotime($actualenddate));
		$Tempenddate = date('d/m/Y');
		$tempActualNumerator = ($Tempstartdate !="" && $Tempenddate != "") ? GetDateDuration($projectclient,$Tempstartdate,$Tempenddate): 0;
	}
	$planthreshold = ($tempPlanDenomentor >0 ) ? $tempPlanNumerator/$tempPlanDenomentor *100 : 0;

	$actualthreshold = ($tempPlanDenomentor >0 ) ? $tempActualNumerator/$tempPlanDenomentor *100 : 0;

	$threshold = ($planthreshold > $actualthreshold ? ($planthreshold - $actualthreshold) : 0);

		// calculate threshold
		$ragthresholdsql = "SELECT *
				FROM s_ragthreshold where accountId='".$accountId."' order by s_rt_id desc limit 1";
		$ragthresholdquery = mysqli_query($conn,$ragthresholdsql);
		while($ragTdata =mysqli_fetch_assoc($ragthresholdquery)){
			$amber = $ragTdata['s_rt_amber'];
			$red = $ragTdata['s_rt_red'];
			if($threshold > $red){
				$schedule = "R";// Red
			}else if($threshold > $amber){
				$schedule = "A";// Red
			}else{
				$schedule = "G";// Red
			}
		}
		$ragcolor = "badge-warning";
		switch($schedule){
			case "R":
			$ragcolor = "badge-danger";
			break;
			case "A":
			$ragcolor = "badge-warning ";
			break;
			case "G":
			$ragcolor = "badge-success";
			break;

		}					
									
			
		$statuscolor = "badge-warning";
		switch($data['s_p_status']){
			case "Pending":
			$statuscolor = "badge-warning";
			break;
			case "In Progress":
			$statuscolor = "badge-primary ";
			break;
			case "Complete":
			$statuscolor = "badge-success";
			break;

		}

		$echoTR = '<tr  align="center">				 
		<td>'.$data['s_p_name'].'</td>
		<td>'.$data['s_p_code'].'</td>
		<td>'.'<span class="badge '.$ragcolor.'">'.$schedule.'</span></td> 
		<td>'.(implode(",", $membersnamearr)).'</td> 
		<td>'.'<span class="badge '.$statuscolor.'">'.$data['s_p_status'].'</span></td> 
		<td>'.$planstartdate.'</td> 
		<td>'.$planenddate.'</td>
		<td>'.$revisedstartdate.'</td> 
		<td>'.$revisedenddate.'</td>
		<td>'.$actualstartdate.'</td> 
		<td>'.$actualenddate.'</td> 
		<td>'.$data['owner'].'</td>  
		<td>'.$data['client'].'</td>  
		<td>'.$data['s_p_desc'].'</td>
	</tr> ';
				
	if($chart_type =="Pie"){
		if($yAxis == "s_p_name" && ($xVal == $data['s_p_name'])){
				echo $echoTR;
		}else if($yAxis == "s_p_code" && ($xVal == $data['s_p_code'])){
				echo $echoTR;
		}else if($yAxis == "s_p_ragstatus" && ($xVal == $schedule)){
				echo $echoTR;
		}else if($yAxis == "s_p_status" && ($xVal == $data['s_p_status'])){
				echo $echoTR;
		}else if($yAxis == "s_p_owner" && ($xVal == $data['owner'])){
				echo $echoTR;
		}else if($yAxis == "clientId" && ($xVal == $data['client'])){
				echo $echoTR;
		}
	}else if($chart_type == "Column" || $chart_type == "Line"){
		if($xAxis == "s_p_name" && ($xVal == $data['s_p_name'])){
				echo $echoTR;
		}else if($xAxis == "s_p_code" && ($xVal == $data['s_p_code'])){
				echo $echoTR;
		}else if($xAxis == "s_p_ragstatus" && ($xVal == $schedule)){
				echo $echoTR;
		}else if($xAxis == "s_p_status" && ($xVal == $data['s_p_status'])){
				echo $echoTR;
		}else if($xAxis == "s_p_owner" && ($xVal == $data['owner'])){
				echo $echoTR;
		}else if($xAxis == "clientId" && ($xVal == $data['client'])){
				echo $echoTR;
		}
	}
	
}
echo '</tbody></table></div>';				

