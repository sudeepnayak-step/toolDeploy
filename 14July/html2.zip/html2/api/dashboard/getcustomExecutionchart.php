<?php
include('../config.php');
session_start();
 
$enteredby = 0;$accountId=0;$userempid = 0;
 
/** get dynamic testexecution chart setting to show on dashboard */
if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
    $userempid = $_SESSION["userempid"];
}


$projectId = (isset($_GET['projectId']) && !empty($_GET['projectId'])? $_GET['projectId'] : "0");
$releaseId = (isset($_GET['releaseId'])  && !empty($_GET['releaseId'])? $_GET['releaseId'] : "0");
$activityId = (isset($_GET['activityId'])  && !empty($_GET['activityId'])? $_GET['activityId'] : "0");
$testcasedate = (isset($_GET['testcasedate']) && !empty($_GET['testcasedate']) ?  date('Y-m-d 23:59:59', strtotime(str_replace('/', '-', $_GET['testcasedate']))) : date('Y-m-d 23:59:59'));


$where = "";
if($projectId !="0"){
	$where = $where." and tc.projectId = '$projectId' ";
}

if($releaseId !="0"){
	$where = $where." and tc.releaseId = '$releaseId' ";
}

if($activityId !="0"){
	$where = $where." and tc.activityId = '$activityId' ";
}
if(isset($_SESSION["usertype"]) && $_SESSION["usertype"] != "Admin"){
	$where = " and tc.projectId in (select projectId from s_project_members where employeeId = '".$userempid."' )";
}

$tcstmt = mysqli_query($conn,"SELECT tc.s_t_module as module, count(1) as total_testcase from s_testcase tc where tc.s_t_createdtime <= ? and tc.accountId = ? ".$where ." group by tc.s_t_module");
mysqli_stmt_bind_param($tcstmt, 'ss', $testcasedate,$accountId);
mysqli_stmt_execute($tcstmt);
$sqldata = mysqli_stmt_get_result($tcstmt);

$uniqueArr = array();								
$allProjArr = array();	
$totprojCount = 0;							

while($data = mysqli_fetch_assoc($sqldata)){
	$totprojCount++;
					
	$allProjArr['module'][] = $data['module'];
	$allProjArr['total_testcase'][] = $data['total_testcase'];
	
 	if(!(isset($uniqueArr['module']) && in_array($data['module'], $uniqueArr['module']))){
 		$uniqueArr['module'][] = $data['module'];
 	}
	

 	if(!(isset($uniqueArr['total_testcase']) && in_array($data['total_testcase'], $uniqueArr['total_testcase']))){
 		$uniqueArr['total_testcase'][] = $data['total_testcase'];
 	}
}

// Close the statement
mysqli_stmt_close($tcstmt);

$colarr = array();

$stmt = mysqli_prepare($conn,"select * from s_chartsetting where s_c_tablename= ?  ");
mysqli_stmt_bind_param($stmt, 's', "s_testexecution");
mysqli_stmt_execute($stmt);
$sqlCustomData = mysqli_stmt_get_result($stmt);

while($cdsdata = mysqli_fetch_assoc($sqlCustomData)){
	$xAxis = $cdsdata['s_c_xaxis'];


	$category = array();
	$chart_type = $cdsdata['s_c_charttype'];
	$subtitle = $cdsdata['s_c_subtitle'];
	$yAxis = $cdsdata['s_c_yaxis'];
	$title = $cdsdata['s_c_title'];
	$cal_type = $cdsdata['s_c_type'];
	$rowarr = array();
	$colvaluearr = array();
	$seriesdata = array();
	$rowarr['id'] = $cdsdata['s_c_id'];
	$rowarr['title'] = $title;
	$rowarr['subtitle'] = $subtitle;
	$rowarr['charttype'] = $chart_type;
	$rowarr['type'] = $cal_type;
	$rowarr['data'] = $cdsdata['s_c_yaxis'];
	if($chart_type == "Pie"){

		$nArr = array();
		if(isset($uniqueArr[$yAxis])){
			foreach ($uniqueArr[$yAxis] as $ykey => $Modulename) {
				foreach ($allProjArr[$yAxis] as $akey => $avalue) {
					if(strval($avalue) == strval($Modulename)){
						$nArr[strval($avalue)] = (isset($nArr[strval($avalue)]) ? $nArr[strval($avalue)]  : 0) + 1;
					}else{
						$nArr[strval($avalue)] = (isset($nArr[strval($avalue)]) ? $nArr[strval($avalue)]  : 0) +0;
					}
				}			 				
			}
		}

		foreach ($nArr as $akey => $seriesname) {
			if($yAxis == "s_p_status"){				 				
				$bgcolor = "#ffc107";
				switch ($akey) {
					case "In Progress":
						$bgcolor = "#007bff";
						break;
					case "Completed":
						$bgcolor = "#28a745";
						break;
					case "Pending":
						$bgcolor = "#dc3545";
						break;
					default:
						$bgcolor = "#ffc107";
				}
				if($cal_type == "Percentage"){
					$seriesdata[] = array("name"=>$akey,"y"=>($totprojCount >0 ? round($seriesname/$totprojCount *100,2) : 0),"color"=>$bgcolor);
				}else{
					$seriesdata[] = array("name"=>$akey,"y"=>$seriesname,"color"=>$bgcolor);
				}
				
			}else if(in_array($yAxis, array("s_p_ragstatus","budget","scope_of_work"))){				 				
				$bgcolor = "#dc3545";
				switch ($akey) {
					case "G":
						$bgcolor = "#28a745";
						break;
					case "A":
						$bgcolor = "#ffc107";
						break;
					case "R":
						$bgcolor = "#dc3545";
						break;
					}
				if($cal_type == "Percentage"){
					$seriesdata[] = array("name"=>$akey,"y"=>($totprojCount >0 ? round($seriesname/$totprojCount *100,2) : 0),"color"=>$bgcolor);
				}else{
					$seriesdata[] = array("name"=>$akey,"y"=>$seriesname,"color"=>$bgcolor);
				}
				
			}else{
				if($cal_type == "Percentage"){
					$seriesdata[] = array("name"=>$akey,"y"=>($totprojCount >0 ? round($seriesname/$totprojCount *100,2) : 0));
				}else{
					$seriesdata[] = array("name"=>$akey,"y"=>$seriesname);
				}
			}
		}
	}
	else if($chart_type == "Column"){
		if(isset($uniqueArr[$xAxis])){
			foreach ($uniqueArr[$xAxis] as $xkey => $xname) {
				$category[] = $xname;
			}
		}

			if(in_array($xAxis, array('s_p_ragstatus','s_p_status','reusability','automatable_tests','failed_raised_total','planned_complete','actual_complete','scope_of_work','budget','clientId','s_p_owner'))){
			if(isset($uniqueArr[$yAxis])){
				foreach ($uniqueArr[$yAxis] as $ykey => $Modulename) {
					$nArr = array();
					foreach ($allProjArr[$xAxis] as $akey => $avalue) {
						if($Modulename == $allProjArr[$yAxis][$akey]){
							$nArr[strval($avalue)] = (isset($nArr[$avalue]) ? $nArr[$avalue]  : 0) + 1;
						}else{
							$nArr[strval($avalue)] = (isset($nArr[$avalue]) ? $nArr[$avalue]  : 0) +0;
						}
					}
					$seriesname = array();
					foreach ($uniqueArr[$xAxis] as $akey => $avalue) {
						$seriesname[]=($nArr[strval($avalue)]);
					}
					if($yAxis == "s_p_status"){	
						$bgcolor = "#ffc107";
						switch ($Modulename) {
							case "In Progress":
								$bgcolor = "#007bff";
								break;
							case "Completed":
								$bgcolor = "#28a745";
								break;
							case "Pending":
								$bgcolor = "#dc3545";
								break;
							default:
								$bgcolor = "#ffc107";
						}
						$seriesdata[] = array("name"=>$Modulename,"data"=>$seriesname,"color"=>$bgcolor);
						
					}else if(in_array($yAxis, array("s_p_ragstatus","budget","scope_of_work"))){				 				
						$bgcolor = "#dc3545";
							switch ($Modulename) {
								case "G":
									$bgcolor = "#28a745";
									break;
								case "A":
									$bgcolor = "#ffc107";
									break;
								case "R":
									$bgcolor = "#dc3545";
									break;
								}
						$seriesdata[] = array("name"=>$Modulename,"data"=>$seriesname,"color"=>$bgcolor);
						
					}else{
						
						$seriesdata[] = array("name"=>$Modulename,"data"=>$seriesname);
					}
				}
			}
		}
		else if(in_array($xAxis, array('module','s_p_code'))){
			if(isset($uniqueArr[$yAxis])){
				foreach ($uniqueArr[$yAxis] as $ykey => $Modulename) {
					$seriesname = array();
						foreach ($uniqueArr[$xAxis] as $akey => $avalue) {
							if($Modulename == $allProjArr[$yAxis][$akey]){
								$seriesname[] = 1;
							}else{
								$seriesname[] = 0;
							}
						}
					if($yAxis == "s_p_status"){				 				
						$bgcolor = "#ffc107";
						switch ($Modulename) {
							case "In Progress":
								$bgcolor = "#007bff";
								break;
							case "Completed":
								$bgcolor = "#28a745";
								break;
							case "Pending":
								$bgcolor = "#dc3545";
								break;
							default:
								$bgcolor = "#ffc107";
						}
						$seriesdata[] = array("name"=>$Modulename,"data"=>$seriesname,"color"=>$bgcolor);
						
					}else if(in_array($yAxis, array("s_p_ragstatus","budget","scope_of_work"))){				 				
						$bgcolor = "#dc3545";
							switch ($Modulename) {
								case "G":
									$bgcolor = "#28a745";
									break;
								case "A":
									$bgcolor = "#ffc107";
									break;
								case "R":
									$bgcolor = "#dc3545";
									break;
								}
						$seriesdata[] = array("name"=>$Modulename,"data"=>$seriesname,"color"=>$bgcolor);
						
					}else{
						
						$seriesdata[] = array("name"=>$Modulename,"data"=>$seriesname);
					}
				}
			}
		}
	}

	$rowarr['seriesdata'] = $seriesdata;
	$rowarr['xaxis'] = $category;
	array_push($colarr, $rowarr);
}
// Close the statement
mysqli_stmt_close($stmt);
echo json_encode($colarr,JSON_NUMERIC_CHECK);


										?>
