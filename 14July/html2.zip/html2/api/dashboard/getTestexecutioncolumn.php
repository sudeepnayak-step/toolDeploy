<?php
include('../config.php');

/** this script get the execution data for chart */
$projectId = (isset($_GET['projectId']) && !empty($_GET['projectId'])? $_GET['projectId'] : "0");
$releaseId = (isset($_GET['releaseId'])  && !empty($_GET['releaseId'])? $_GET['releaseId'] : "0");
$activityId = (isset($_GET['activityId'])  && !empty($_GET['activityId'])? $_GET['activityId'] : "0");
$testcasedate = (isset($_GET['testcasedate']) && !empty($_GET['testcasedate']) ?  date('Y-m-d 23:59:59', strtotime(str_replace('/', '-', $_GET['testcasedate']))) : date('Y-m-d 23:59:59'));


$where = "";
if($projectId !="0"){
		$where = $where." and projectId = '$projectId' ";
}

if($releaseId !="0"){
		$where = $where." and releaseId = '$releaseId' ";
}

if($activityId !="0"){
		$where = $where." and activityId = '$activityId' ";
}
$stmt = mysqli_prepare($conn,"SELECT distinct(s_t_module) as module from s_testcase where s_t_createdtime <= ? ".$where);

mysqli_stmt_bind_param($stmt, 's', $testcasedate);
mysqli_stmt_execute($stmt);
$sqldata = mysqli_stmt_get_result($stmt);

$rowarr = array();
$category = array();
$seriesdata = array();
while($mdata = mysqli_fetch_assoc($sqldata)){
	
	$totalexecution = 0;
	$totaltestcase = 0;
	$passCount = 0;
	$failCount = 0;
	$NACount = 0;
	$BlockedCount = 0;
	$No_RunCount = 0;
	$onholdCount = 0;
	$inprogressCount = 0;
	$deferredCount = 0;
	// get testcase
	$sqlexecutiondataarray = array();
	$module = $mdata['module'];
	$category[] = $module;//$dsdata['Module'];
	$tcstmt = mysqli_prepare($conn,"SELECT IFNULL(count(*),0) as cnt from s_testcase where  s_t_createdtime <= ? and s_t_module = '".$module."' ".$where);
	mysqli_stmt_bind_param($tcstmt, 's', $testcasedate);
	mysqli_stmt_execute($tcstmt);
	$sqlalltc = mysqli_stmt_get_result($tcstmt);


	while($tcdata = mysqli_fetch_assoc($sqlalltc)){		
		$totaltestcase = $tcdata['cnt'];
	}
	mysqli_stmt_close($tcstmt);

	$tcstmt = mysqli_prepare($conn,"SELECT DISTINCT(s_t_testcasenum) as tId from s_testcase where s_t_createdtime <= ? and s_t_module = '".$module."' ".$where);
	mysqli_stmt_bind_param($tcstmt, 's', $testcasedate);
	mysqli_stmt_execute($tcstmt);
	$sql2 = mysqli_stmt_get_result($tcstmt);

	$idstring = "";
	while($tdata = mysqli_fetch_assoc($sql2)){		
 		array_push($sqlexecutiondataarray, $tdata['tId']);
 		if($idstring == ""){
 			$idstring = "'".$tdata['tId']."'";
 		}else{
 			$idstring = $idstring.",'".$tdata['tId']."'";
 		}
	}
	mysqli_stmt_close($tcstmt);

 	///get test execution
 	$sql3 = mysqli_query($conn,"SELECT  * from s_testexecution where s_st_id in (select max(s_st_id) from s_testexecution where testcaseId in(".$idstring.") group by testcaseId)");
 	while($tedata = mysqli_fetch_assoc($sql3)){		
 		$totalexecution++;
		if($tedata['s_st_testresult'] == "Pass"){
		 	$passCount++;
		}else if($tedata['s_st_testresult'] == "Fail"){
			$failCount++;
		}else if(in_array($tedata['s_st_testresult'], array("NA","CE_NA"))){
			$NACount++;
		}else if(in_array($tedata['s_st_testresult'], array("Block","Blocked","CE_Bug"))){
			$BlockedCount++;
		}else if(in_array($tedata['s_st_testresult'], array("Pending","No Run","Yet to Begin"))){
			$No_RunCount++;
		}else if($tedata['s_st_testresult'] == "On Hold"){
			$onholdCount++;
		}else if($tedata['s_st_testresult'] == "In Progress"){
			$inprogressCount++;
		}else if(in_array($tedata['s_st_testresult'], array("Deferred","CE_FR"))){
			$deferredCount++;
		}
	}
	$totalexecuted = $passCount + $failCount;
	$Scoped_Test_cases = $totaltestcase-$NACount;

	$executedpercent = ($Scoped_Test_cases > 0 ? (round(($totalexecuted/$Scoped_Test_cases ) *100,2) ) : 0);
	$seriesdata[] = array("name"=>$module,"data"=>[$executedpercent]);
}
mysqli_stmt_close($stmt);

$rowarr['seriesdata'] = $seriesdata;

$mainarr = array("categories"=>$category,"seriesdata"=>$seriesdata);
echo json_encode($mainarr,JSON_NUMERIC_CHECK);
?>
