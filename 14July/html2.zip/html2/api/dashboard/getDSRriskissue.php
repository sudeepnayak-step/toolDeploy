<?php
include('../config.php');
session_start();
 
$enteredby = 0;$accountId = 0;$userempid = 0;
/** this script return the data for risk and issue  to show that in dsr */ 

if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $userempid = $_SESSION["userempid"];
    $accountId = $_SESSION["accountId"];
}


$projarr['data'] = array();

$projectId = (isset($_GET['projectId']) && !empty($_GET['projectId'])? $_GET['projectId'] : "");
$releaseId = (isset($_GET['releaseId'])  && !empty($_GET['releaseId'])? $_GET['releaseId'] : "");
$activityId = (isset($_GET['activityId'])  && !empty($_GET['activityId'])? $_GET['activityId'] : "");
$dsrdate = (isset($_GET['dsrdate']) && !empty($_GET['dsrdate']) ?  "'".date('Y-m-d 23:59:59', strtotime(str_replace('/', '-', $_GET['dsrdate'])))."'" : "'".date('Y-m-d 23:59:59')."'");

$where = "";
if($projectId !=""){
	$where = $where." and projectId in ($projectId) ";
}

if($releaseId !=""){
	$where = $where." and releaseId in ($releaseId) ";
}

if($activityId !=""){
	$where = $where." and activityId = '$activityId' ";
}
if($projectId != "" && $releaseId !=""){


	$stmt = mysqli_prepare($conn,"SELECT r.*,IFNULL(a.s_a_name,'') as activityname,

		concat(IFNULL(a1.s_e_fname,''),' ',IFNULL(a1.s_e_mname,''),' ',IFNULL(a1.s_e_lname,'')) as actionableby,
		concat(IFNULL(a2.s_e_fname,''),' ',IFNULL(a2.s_e_mname,''),' ',IFNULL(a2.s_e_lname,'')) as raisedby from s_riskissue r
		left join s_project_activity pa on pa.s_pa_id = r.s_r_activityId
		left join s_activitymaster a on a.s_a_id = pa.activityId

 		left JOIN s_employees a1 on a1.userId = r.s_r_actionableby and r.s_r_actionableby !='0'
 		left JOIN s_employees a2 on a2.userId = r.s_r_enteredby and r.s_r_enteredby !='0'
		WHERE r.accountId = ? and s_r_activityId in (select p1.s_pa_id from s_project_activity p1 where p1.accountId = ? $where)
		 order by s_r_id desc");
		 
	mysqli_stmt_bind_param($stmt, 'ss', $accountId,$accountId);
	mysqli_stmt_execute($stmt);
	$sqldata = mysqli_stmt_get_result($stmt);

	$srno = 0;
	while($data = mysqli_fetch_assoc($sqldata)){

		$raiseddate = (isset($data['s_r_raiseddate']) && ($data['s_r_raiseddate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_r_raiseddate'])) : "");

		$closuredate = (isset($data['s_r_closuredate']) && ($data['s_r_closuredate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_r_closuredate'])) : "");
		$projarr['data'][] = array(
			++$srno,
			$data['s_r_desc'],
			$data['s_r_status'],
			$data['activityname'],
			$data['s_r_type'],
			$data['s_r_plan'],	
			$data['s_r_impact'],
			$data['actionableby'],
			empty(trim($data['raisedby'])) ? "Admin":$data['raisedby'],
			$raiseddate
		);
	}
	// Close the statement
	mysqli_stmt_close($stmt);
}

echo json_encode($projarr);
?>