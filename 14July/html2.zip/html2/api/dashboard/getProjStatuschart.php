<?php
include('../config.php');
session_start();
 
$enteredby = 0;$accountId = 0;$userempid = 0;
 

if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
    $userempid = $_SESSION["userempid"];
}


$projectExtra = "";
if(isset($_SESSION["usertype"]) && $_SESSION["usertype"] != "Admin"){
	$projectExtra = " and s_p_id in (select projectId from s_project_members where employeeId = '".$userempid."' )";
}

$stmt = mysqli_prepare($conn,"SELECT * from s_project where s_p_activestatus = 'Active' and accountId = ? $projectExtra");
		
mysqli_stmt_bind_param($stmt, 's', $accountId);
mysqli_stmt_execute($stmt);
$sqldata = mysqli_stmt_get_result($stmt);


$rowarr = array();
$seriesdata = array();
$xarr = array();
$Pendingarr = array();
$inprogarr = array();
$cmpltarr = array();
while($mdata = mysqli_fetch_assoc($sqldata)){
	array_push($xarr, $mdata['s_p_name']);

	switch ($mdata['s_p_status']) {
			case "In Progress":
				array_push($inprogarr, 1);
				array_push($Pendingarr, 0);
				array_push($cmpltarr, 0);
				break;
			case "Completed":
				array_push($inprogarr, 0);
				array_push($Pendingarr, 0);
				array_push($cmpltarr, 1);
				break;
			case "Pending":
				array_push($inprogarr, 0);
				array_push($Pendingarr, 1);
				array_push($cmpltarr, 0);
				break;
	}
}
mysqli_stmt_close($stmt);
$seriesdata[] = array("name"=>"Pending","data"=>$Pendingarr,"color"=>"#dc3545");
$seriesdata[] = array("name"=>"In Progress","data"=>$inprogarr,"color"=>"#007bff");
$seriesdata[] = array("name"=>"Completed","data"=>$cmpltarr,"color"=>"#28a745");
$rowarr['xaxis'] = $xarr;
$rowarr['seriesdata'] = $seriesdata;
echo json_encode($rowarr,JSON_NUMERIC_CHECK);
?>