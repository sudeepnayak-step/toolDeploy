
<?php
include('config.php');
session_start();
 
$enteredby = 0;
$accountId = 0;
 
$testexecutionId = -1;
if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
}
if($_SERVER['REQUEST_METHOD'] === 'POST'){

$suiteId = (isset($_POST['testsuiteDBId']) && !empty($_POST['testsuiteDBId']) ? intval($_POST['testsuiteDBId']) : 0);
$testcaseIds = (isset($_POST['testcaseIds']) && !empty($_POST['testcaseIds']) ? $_POST['testcaseIds'] : "0");

$testcasesql = "INSERT INTO s_testexecution (testsuiteId, testcaseId, s_st_testresult, s_st_actualresult, s_st_executiontime, s_st_exectionstart, s_st_executionend, s_st_filename, s_st_filepath, s_st_enteredby, accountId, s_st_executionstatus, defectId) 
                SELECT ?, s_t_id, '', NULL, NULL, NULL, NULL, '', NULL, ?, ?, 0, 0 
                FROM s_testcase 
                WHERE s_t_id IN (".$testcaseIds.") AND accountId = ?";

$stmt = mysqli_prepare($conn, $testcasesql);
mysqli_stmt_bind_param($stmt, "iiii", $suiteId, $enteredby, $accountId, $accountId);
$result = mysqli_stmt_execute($stmt);

if($result){
	$sqldata = mysqli_query($conn,"SELECT * from s_testexecution   where 
	accountId = '".$accountId."' and testsuiteId = '".$suiteId."' and  testcaseId in(".$testcaseIds.") order by s_st_id asc");
	while($data = mysqli_fetch_assoc($sqldata)){
		$testexecutionId = $data['s_st_id'];
		$testcaseId = $data['testcaseId'];

		if($testexecutionId >0){
			$teststepsql = "INSERT INTO s_tcstep_execution (s_se_executionId, stepId, s_se_testresult, s_se_actualresult, s_se_enteredby, accountId) 
			SELECT ?, s_tss_id, 'In Progress', '', ?, ? 
			FROM s_testcase_steps 
			WHERE s_testcase_steps.testcaseId = ? AND s_testcase_steps.accountId = ?";

			$stepstmt = mysqli_prepare($conn, $teststepsql);
			mysqli_stmt_bind_param($stepstmt, "iiiii", $testexecutionId, $enteredby, $accountId, $testcaseId, $accountId);
			mysqli_stmt_execute($stepstmt);
			if ($stepstmt) mysqli_stmt_close($stepstmt);
		}
	}
}
if ($stmt) mysqli_stmt_close($stmt);

}
