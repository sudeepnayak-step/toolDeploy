<?php
include('config.php');
session_start();
 
$enteredby = 0;$accountId = 0;
 /** this script saves the data into release table */
$msgarr = array();

if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
}
$updateRecords = "";$auditlogDesc = "";
if($_SERVER['REQUEST_METHOD'] === 'POST'){

	$id = (isset($_POST['projreleaseId']) ? $_POST['projreleaseId'] : "0");
	$releasename = (isset($_POST['releasename']) && !empty($_POST['releasename']) ? mysqli_real_escape_string($conn,sanitize($_POST['releasename'])) : "");
	$releasename_change = (isset($_POST['releasename_change']) && !empty($_POST['releasename_change']) ? $_POST['releasename_change'] : "0");
	if($releasename_change == "1"){
		if($auditlogDesc == ""){
			$auditlogDesc = "Release Name";
		}else{
			$auditlogDesc .= ", Release Name";
		}
		if($updateRecords == ""){
			$updateRecords = "s_r_name = '".$releasename."'";
		}else{
			$updateRecords .= ", s_r_name = '".$releasename."'";
		}
	}

	$projectId = (isset($_POST['projectId']) && !empty($_POST['projectId']) ? $_POST['projectId'] : "0");
	$projectId_change = (isset($_POST['projectId_change']) && !empty($_POST['projectId_change']) ? $_POST['projectId_change'] : "0");
	if($projectId_change == "1"){
		if($auditlogDesc == ""){
			$auditlogDesc = "Project";
		}else{
			$auditlogDesc .= ", Project";
		}
		if($updateRecords == ""){
			$updateRecords = "projectId = '".$projectId."'";
		}else{
			$updateRecords .= ", projectId = '".$projectId."'";
		}
	}

	$releasestatus = (isset($_POST['releasestatus']) && !empty($_POST['releasestatus']) ? $_POST['releasestatus'] : "");
	$releasestatus_change = (isset($_POST['releasestatus_change']) && !empty($_POST['releasestatus_change']) ? $_POST['releasestatus_change'] : "0");
	if($releasestatus_change == "1"){
		if($auditlogDesc == ""){
			$auditlogDesc = "Status";
		}else{
			$auditlogDesc .= ", Status";
		}
		if($updateRecords == ""){
			$updateRecords = "s_r_status = '".$releasestatus."'";
		}else{
			$updateRecords .= ", s_r_status = '".$releasestatus."'";
		}
	}

	$planstartdate = (isset($_POST['planstartdate']) && !empty($_POST['planstartdate']) ? date('Y-m-d', strtotime(str_replace('/', '-', $_POST['planstartdate']))): null);
	$planstartdate_change = (isset($_POST['planstartdate_change']) && !empty($_POST['planstartdate_change']) ? $_POST['planstartdate_change'] : "0");
	if($planstartdate_change == "1"){
		if($auditlogDesc == ""){
			$auditlogDesc = "Plan start date";
		}else{
			$auditlogDesc .= ", Plan start date";
		}
		if($updateRecords == ""){
			$updateRecords = "s_r_planstartdate = '".$planstartdate."'";
		}else{
			$updateRecords .= ", s_r_planstartdate = '".$planstartdate."'";
		}
	}

	$planenddate = (isset($_POST['planenddate']) && !empty($_POST['planenddate']) ? date('Y-m-d', strtotime(str_replace('/', '-', $_POST['planenddate']))) : null);
	$planenddate_change = (isset($_POST['planenddate_change']) && !empty($_POST['planenddate_change']) ? $_POST['planenddate_change'] : "0");
	if($planenddate_change == "1"){
		if($auditlogDesc == ""){
			$auditlogDesc = "Plan end date";
		}else{
			$auditlogDesc .= ", Plan end date";
		}
		if($updateRecords == ""){
			$updateRecords = "s_r_planenddate = '".$planenddate."'";
		}else{
			$updateRecords .= ", s_r_planenddate = '".$planenddate."'";
		}
	}

	$revisedenddate = (isset($_POST['revisedenddate']) && !empty($_POST['revisedenddate']) ?  date('Y-m-d', strtotime(str_replace('/', '-', $_POST['revisedenddate']))) : null);
	$revisedenddate_change = (isset($_POST['revisedenddate_change']) && !empty($_POST['revisedenddate_change']) ? $_POST['revisedenddate_change'] : "0");
	if($revisedenddate_change == "1"){
		if($auditlogDesc == ""){
			$auditlogDesc = "Revised end date";
		}else{
			$auditlogDesc .= ", Revised end date";
		}
		if($updateRecords == ""){
			$updateRecords = "s_r_revisedenddate = '".$revisedenddate."'";
		}else{
			$updateRecords .= ", s_r_revisedenddate = '".$revisedenddate."'";
		}
	}

	$revisedstartdate = (isset($_POST['revisedstartdate']) && !empty($_POST['revisedstartdate']) ? date('Y-m-d', strtotime(str_replace('/', '-', $_POST['revisedstartdate']))) : null);
	$revisedstartdate_change = (isset($_POST['revisedstartdate_change']) && !empty($_POST['revisedstartdate_change']) ? $_POST['revisedstartdate_change'] : "0");
	if($revisedstartdate_change == "1"){
		if($auditlogDesc == ""){
			$auditlogDesc = "Revised start date";
		}else{
			$auditlogDesc .= ", Revised start date";
		}
		if($updateRecords == ""){
			$updateRecords = "s_r_revisedstartdate = '".$revisedstartdate."'";
		}else{
			$updateRecords .= ", s_r_revisedstartdate = '".$revisedstartdate."'";
		}
	}

	$actualstartdate = (isset($_POST['actualstartdate']) && !empty($_POST['actualstartdate']) ? date('Y-m-d', strtotime(str_replace('/', '-', $_POST['actualstartdate']))): null);
	$actualstartdate_change = (isset($_POST['actualstartdate_change']) && !empty($_POST['actualstartdate_change']) ? $_POST['actualstartdate_change'] : "0");
	if($actualstartdate_change == "1"){
		if($auditlogDesc == ""){
			$auditlogDesc = "Actual start date";
		}else{
			$auditlogDesc .= ", Actual start date";
		}
		if($updateRecords == ""){
			$updateRecords = "s_r_actualstartdate = '".$actualstartdate."'";
		}else{
			$updateRecords .= ", s_r_actualstartdate = '".$actualstartdate."'";
		}
	}

	$actualenddate = (isset($_POST['actualenddate']) && !empty($_POST['actualenddate']) ? date('Y-m-d', strtotime(str_replace('/', '-', $_POST['actualenddate'] ))): null);
	$actualenddate_change = (isset($_POST['actualenddate_change']) && !empty($_POST['actualenddate_change']) ? $_POST['actualenddate_change'] : "0");
	if($actualenddate_change == "1"){
		if($auditlogDesc == ""){
			$auditlogDesc = "Actual end date";
		}else{
			$auditlogDesc .= ", Actual end date";
		}
		if($updateRecords == ""){
			$updateRecords = "s_r_actualenddate = '".$actualenddate."'";
		}else{
			$updateRecords .= ", s_r_actualenddate = '".$actualenddate."'";
		}
	}

	$releasedesc = (isset($_POST['releasedesc']) && !empty($_POST['releasedesc']) ? mysqli_real_escape_string($conn,sanitize($_POST['releasedesc'])) : "");
	$releasedesc_change = (isset($_POST['releasedesc_change']) && !empty($_POST['releasedesc_change']) ? $_POST['releasedesc_change'] : "0");
	if($releasedesc_change == "1"){
		if($auditlogDesc == ""){
			$auditlogDesc = "Description";
		}else{
			$auditlogDesc .= ", Description";
		}
		if($updateRecords == ""){
			$updateRecords = "s_r_desc = '".$releasedesc."'";
		}else{
			$updateRecords .= ", s_r_desc = '".$releasedesc."'";
		}
	}

	$activestatus = (isset($_POST['activestatus']) && !empty($_POST['activestatus'])? $_POST['activestatus'] : "Active");
	$activestatus_change = (isset($_POST['activestatus_change']) && !empty($_POST['activestatus_change']) ? $_POST['activestatus_change'] : "0");
	if($activestatus_change == "1"){
		if($auditlogDesc == ""){
			$auditlogDesc = "Active status";
		}else{
			$auditlogDesc .= ", Active status";
		}
		if($updateRecords == ""){
			$updateRecords = "s_r_activestatus = '".$activestatus."'";
		}else{
			$updateRecords .= ", s_r_activestatus = '".$activestatus."'";
		}
	}
	// $enteredby = 0;



	// generate release ID

	$releaseId = 0;
	$releaseIdstr = "";
	$projcode = "";

	if($projectId_change == "1"){
		$projsqldata = mysqli_query($conn,"SELECT * from s_project where s_p_id = '".$projectId."'  and accountId = '".$accountId."'  order by s_p_id desc limit 1");
		if(mysqli_num_rows($projsqldata)>0){

			while($pdata = mysqli_fetch_assoc($projsqldata)){
				$projcode = $pdata['s_p_code'];
			}


			$releaseqldata = mysqli_query($conn,"SELECT * from s_release where projectId = '".$projectId."'  and accountId = '".$accountId."'  order by s_r_tempid desc limit 1");
			if(mysqli_num_rows($releaseqldata)>0){

				while($rdata = mysqli_fetch_assoc($releaseqldata)){
					$releaseId = (int)$rdata['s_r_tempid'] +1;
				}
			}else{
				$releaseId = 1;
			}
			$releaseIdstr = "$projcode-release$releaseId";
		}
	}

	if(!empty($id) && $id !="0") {

		if($updateRecords !=""  ){
				$sql = "UPDATE s_release SET $updateRecords WHERE s_r_id = ?";
				$stmt = mysqli_prepare($conn, $sql);
				mysqli_stmt_bind_param($stmt, "s", $id);
				if (mysqli_stmt_execute($stmt)) {
					$msgarr["status"] = "Success";
					$msgarr["message"] = "Release updated successfully.";
				} else {
					$msgarr["status"] = "Error";
					$msgarr["message"] = "Something went wrong. Please try again.";
				}
				mysqli_stmt_close($stmt);
		}else{

				$msgarr["status"] = "Success";
				$msgarr["message"] = "Release updated successfully.";
		}
	}else{

		$sql = "INSERT INTO s_release (s_r_releaseId, s_r_tempid, s_r_name, projectId, s_r_status, s_r_planstartdate, s_r_planenddate, s_r_revisedstartdate, s_r_revisedenddate, s_r_actualstartdate, s_r_actualenddate, s_r_desc, s_r_enteredby, s_r_activestatus, accountId) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "sissssssssssiss", $releaseIdstr, $releaseId, $releasename, $projectId, $releasestatus, $planstartdate, $planenddate, $revisedstartdate, $revisedenddate, $actualstartdate, $actualenddate, $releasedesc, $enteredby, $activestatus, $accountId);
        
        if (mysqli_stmt_execute($stmt)) {
            $msgarr["status"] = "Success";
            $msgarr["message"] = "Release added successfully.";
        } else {
            $msgarr["status"] = "Error";
            $msgarr["message"] = "Something went wrong. Please try again.";
        }
        mysqli_stmt_close($stmt);
	}
}
echo json_encode($msgarr);
