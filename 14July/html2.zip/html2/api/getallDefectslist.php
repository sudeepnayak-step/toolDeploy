<?php
include('config.php');
session_start();
  /**This PHP script retrieves defect data from a database based on user-provided filters (e.g., project, release, defect ID, status, etc.). 
  * It dynamically constructs a SQL query, executes it, and returns the results in JSON format. */

$userempid = 0;$accountId = 0;$enteredby =0;
 
if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
}

if(isset($_SESSION["usertype"]) && $_SESSION["usertype"] == "Employee"){
	if(isset($_SESSION["userempid"])){
		$userempid = $_SESSION["userempid"];
	}
}

$defectwhere = "";

// $projectId = (isset($_POST['projectId'])? implode(",", $_POST['projectId']) : "");
$projectIdStr = isset($_POST['projectId']) && !empty($_POST['projectId']) ? array_map('sanitize', $_POST['projectId']) : [];
$projectId = implode(",", $projectIdStr);

$releaseIdStr = isset($_POST['releaseId']) && !empty($_POST['releaseId']) ? array_map('sanitize', $_POST['releaseId']) : [];
$releaseId = implode(",", $releaseIdStr);

$defectIdStr = isset($_POST['defectId']) && !empty($_POST['defectId']) ? array_map('sanitize', $_POST['defectId']) : [];
$defectId = implode(",", $defectIdStr);

$statusIdStr = isset($_POST['statusId']) && !empty($_POST['statusId']) ? array_map('sanitize', $_POST['statusId']) : [];
$statusId = implode(",", $statusIdStr);

$assigntoIdStr = isset($_POST['assignto']) && !empty($_POST['assignto']) ? array_map('sanitize', $_POST['assignto']) : [];
$assignto = implode(",", $assigntoIdStr);

$defectTypedStr = isset($_POST['defectType']) && !empty($_POST['defectType']) ? array_map('sanitize', $_POST['defectType']) : [];
$defectType = implode(",", $defectTypedStr);

$severityStr = isset($_POST['severity']) && !empty($_POST['severity']) ? array_map('sanitize', $_POST['severity']) : [];
$severity = implode(",", $severityStr);

$priorityStr = isset($_POST['priority']) && !empty($_POST['priority']) ? array_map('sanitize', $_POST['priority']) : [];
$priority = implode(",", $priorityStr);

$environmentStr = isset($_POST['environment']) && !empty($_POST['environment']) ? array_map('sanitize', $_POST['environment']) : [];
$environment = implode(",", $environmentStr);

$platformStr = isset($_POST['platform']) && !empty($_POST['platform']) ? array_map('sanitize', $_POST['platform']) : [];
$platform = implode(",", $platformStr);

$versionStr = isset($_POST['version']) && !empty($_POST['version']) ? array_map('sanitize', $_POST['version']) : [];
$version = implode(",", $versionStr);


$reporterStr = isset($_POST['reporter']) && !empty($_POST['reporter']) ? array_map('sanitize', $_POST['reporter']) : [];
$reporter = implode(",", $reporterStr);

// $releaseId = (isset($_POST['releaseId'])  && !empty($_POST['releaseId'])? implode(",", $_POST['releaseId']) : "");
// $defectId = (isset($_POST['defectId'])  && !empty($_POST['defectId'])? implode(",", $_POST['defectId']) : "");
// $statusId = (isset($_POST['statusId'])  && !empty($_POST['statusId'])? implode(",", $_POST['statusId']) : "");

// $assignto = (isset($_POST['assignto'])  && !empty($_POST['assignto'])? implode(",", $_POST['assignto']) : "");
// $defectType = (isset($_POST['defectType'])  && !empty($_POST['defectType'])? implode(",", $_POST['defectType']) : "");
// $severity = (isset($_POST['severity'])  && !empty($_POST['severity'])? implode(",", $_POST['severity']) : "");
// $priority = (isset($_POST['priority'])  && !empty($_POST['priority'])? implode(",", $_POST['priority']) : "");

$rtmId = (isset($_POST['rtmId']) ? $_POST['rtmId'] : "0");
$module = (isset($_POST['module']) ? $_POST['module'] : "");

$startDate = (isset($_POST['startDate']) && !empty($_POST['startDate']) ? $_POST['startDate'] : "");
$endDate = (isset($_POST['endDate']) && !empty($_POST['endDate']) ? $_POST['endDate'] : "");


// Build the WHERE clause dynamically
$params = [];
$types = "";
$projarr['data'] = array();
if ($projectId != "") {
    $defectwhere .= " AND find_in_set(d.projectId,?) ";
    $params[] = $projectId;
    $types .= "s";
}else{
    echo json_encode([
        "draw" => intval($_POST['draw']),
        "recordsTotal" => 0,
        "recordsFiltered" => 0, // modify if search applied
        "data" => $projarr['data']
    ]);
        // echo json_encode($projarr);
        die;
}

if ($releaseId != "") {
    $defectwhere .= " AND find_in_set(d.releaseId,?) ";
    $params[] = $releaseId;
    $types .= "s";
}

if ($defectId != "") {
    $defectwhere .= " AND find_in_set(d.s_d_id,?) ";
    $params[] = $defectId;
    $types .= "s";
}

if ($statusId != "") {
    $defectwhere .= " AND find_in_set(d.defectstatusId,?) ";
    $params[] = $statusId;
    $types .= "s";
}

if ($assignto != "") {
    $defectwhere .= " AND FIND_IN_SET (d.s_d_assignto, ?) ";
    $params[] = $assignto;
    $types .= "s";
}


if ($reporter != "") {
    $defectwhere .= " AND FIND_IN_SET (d.s_d_enteredby, ?) ";
    $params[] = $reporter;
    $types .= "s";
}

if ($defectType != "") {
    $defectwhere .= " AND FIND_IN_SET (d.defecttypeId, ?)  ";
    $params[] = $defectType;
    $types .= "s";
}

if ($severity != "") {
    $defectwhere .= " AND FIND_IN_SET (d.s_d_severity, ?) ";
    $params[] = $severity;
    $types .= "s";
}

if ($priority != "") {
    $defectwhere .= " AND FIND_IN_SET (d.s_d_priority, ?)  ";
    $params[] = $priority;
    $types .= "s";
}

if ($environment != "") {
    $defectwhere .= " AND FIND_IN_SET (d.s_d_environment, ?) ";
    $params[] = $environment;
    $types .= "s";
}

if ($platform != "") {
    $defectwhere .= " AND FIND_IN_SET (d.s_d_platform, ?) ";
    $params[] = $platform;
    $types .= "s";
}

if ($version != "") {
    $defectwhere .= " AND FIND_IN_SET (d.s_d_version, ?) ";
    $params[] = $version;
    $types .= "s";
}

if ($module != "") {
    $defectwhere .= " AND FIND_IN_SET (d.s_d_module, ?) ";
    $params[] = $module;
    $types .= "s";
}

if ($rtmId != "0" && $rtmId != "") {
    $defectwhere .= " AND d.s_d_id NOT IN (SELECT defectId FROM s_rtm_testcase WHERE rtmId = ? AND accountId = ?)";
    $params[] = $rtmId;
    $params[] = $accountId;
    $types .= "ss";
}

if (isset($_SESSION["usertype"]) && $_SESSION["usertype"] != "Admin") {
    $defectwhere .= " AND d.projectId IN (SELECT s_p_id FROM s_project WHERE s_p_id IN (SELECT projectId FROM s_project_members WHERE employeeId = ? AND accountId = ?) OR s_p_enteredby = ? AND accountId = ?)";
    $params[] = $userempid;
    $params[] = $accountId;
    $params[] = $enteredby;
    $params[] = $accountId;
    $types .= "ssss";
}

if ($startDate != "" && $endDate != "") {
    $defectwhere .= " and DATE(d.s_d_createdtime) BETWEEN '" . $startDate . "' AND '" . $endDate . "'";
}


// Collect DataTables parameters
$start  = $_POST['start'];
$length = $_POST['length'];
$searchValue = $_POST['search']['value'] ?? '';
$orderColumn = $_POST['order'][0]['column'] ?? 0;
$orderDir    = $_POST['order'][0]['dir'] ?? 'asc';



// COUNT total records
$countSql = "SELECT COUNT(1) as total FROM s_defect d 
LEFT JOIN s_defectstatusmaster ds ON ds.s_ds_id = d.defectstatusId 
LEFT JOIN s_defecttypemaster dt ON dt.s_dt_id = d.defecttypeId 
 WHERE d.accountId = ? $defectwhere ";
// Prepare statement
$countstmt = mysqli_prepare($conn, $countSql);
	
mysqli_stmt_bind_param($countstmt, "i" . $types, $accountId, ...$params);
mysqli_stmt_execute($countstmt);
$countResult = mysqli_stmt_get_result($countstmt);

$totalRecords = 0;
while($cdata = mysqli_fetch_assoc($countResult)){
$totalRecords = $cdata['total'];
}
if (!empty($searchValue)) {
    $searchValue = $conn->real_escape_string($searchValue);
    $defectwhere .= " AND (s_d_defectnum LIKE '%$searchValue%' 
                     OR s_d_shortdesc LIKE '%$searchValue%' 
                     OR dt.s_dt_name LIKE '%$searchValue%'
                     OR ds.s_ds_name LIKE '%$searchValue%'
                     OR s_d_severity LIKE '%$searchValue%'
                     OR s_d_priority LIKE '%$searchValue%'
                     OR s_d_environment  LIKE '%$searchValue%'
                     OR s_d_platform LIKE '%$searchValue%'
                     OR s_d_version LIKE '%$searchValue%'
                     OR DATE_FORMAT(CONVERT_TZ(s_d_createdtime, 'UTC', 'Asia/Kolkata'), '%Y-%m-%d %l:%i %p') LIKE '%$searchValue%'
                     )";
}


// Prepare the SQL query for filter
$sql = "SELECT count(1) as filterrows
        FROM s_defect d 
        LEFT JOIN s_project p ON p.s_p_id = d.projectId 
        LEFT JOIN s_release r ON r.s_r_id = d.releaseId 
        LEFT JOIN s_testcase t ON t.s_t_id = d.testcaseId 
        LEFT JOIN s_defectstatusmaster ds ON ds.s_ds_id = d.defectstatusId 
        LEFT JOIN s_defecttypemaster dt ON dt.s_dt_id = d.defecttypeId 
        WHERE d.accountId = ? $defectwhere 
        
        ";
        // DATE_FORMAT(CONVERT_TZ(s_d_createdtime, 'UTC', 'Asia/Kolkata'), '%Y-%m-%d %l:%i %p') as createdtime,
        // DATE_FORMAT(CONVERT_TZ(s_d_updatetime, 'UTC', 'Asia/Kolkata'), '%Y-%m-%d %l:%i %p') as updatetime 

// Prepare statement
$filterstmt = mysqli_prepare($conn, $sql);
	
mysqli_stmt_bind_param($filterstmt, "i" . $types, $accountId, ...$params);
mysqli_stmt_execute($filterstmt);
$filterresult = mysqli_stmt_get_result($filterstmt);

$filterrows = 0;
while($fdata = mysqli_fetch_assoc($filterresult)){
$filterrows = $fdata['filterrows'];
}


// Prepare the SQL query
$sql = "SELECT d.* ,
        IFNULL(p.s_p_name,'') as projectname,
        IFNULL(r.s_r_releaseId,'') as releaseNum,
        IFNULL(t.s_t_testcasenum,'') as testcasenum,
        IFNULL(ds.s_ds_name,'') as defectstatus,
        IFNULL(dt.s_dt_name,'') as defecttype
        FROM s_defect d 
        LEFT JOIN s_project p ON p.s_p_id = d.projectId 
        LEFT JOIN s_release r ON r.s_r_id = d.releaseId 
        LEFT JOIN s_testcase t ON t.s_t_id = d.testcaseId 
        LEFT JOIN s_defectstatusmaster ds ON ds.s_ds_id = d.defectstatusId 
        LEFT JOIN s_defecttypemaster dt ON dt.s_dt_id = d.defecttypeId 
        WHERE d.accountId = ? $defectwhere 
        ORDER BY d.s_d_id $orderDir LIMIT $start, $length
        ";

//echo $sql;
// Prepare statement
$stmt = mysqli_prepare($conn, $sql);
	
mysqli_stmt_bind_param($stmt, "i" . $types, $accountId, ...$params);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

//$projarr['data'] = array();
while($data = mysqli_fetch_assoc($result)){
	$attachemnts = 0;

	$dir = $CFG['dirroot']."defectdata/".$accountId."/".$data['s_d_id']."/";

	if(is_dir($dir)) {
		$files = array_diff(scandir($dir), array('..', '.'));
		if(count($files) >0){
			$attachemnts = 1;
		}
	}
    // $updatedtime  =$data['updatetime'];
    $updatedtime  ="";
	if(isset($data['s_d_updatetime'])){
		// Create a DateTime object for the UTC time
		$dateTime = new DateTime($data['s_d_updatetime'], new DateTimeZone('UTC'));

		// Convert to Indian Standard Time (IST)
		$dateTime->setTimezone(new DateTimeZone('Asia/Kolkata'));
		$updatedtime = $dateTime->format('Y-m-d h:i a');
	}
	// $createdtime  =$data['createdtime'];
	$createdtime  ="";
	if(isset($data['s_d_createdtime'])){
		// Create a DateTime object for the UTC time
		$dateTime = new DateTime($data['s_d_createdtime'], new DateTimeZone('UTC'));

		// Convert to Indian Standard Time (IST)
		$dateTime->setTimezone(new DateTimeZone('Asia/Kolkata'));
		$createdtime = $dateTime->format('Y-m-d h:i a');
	}
    
	$projarr['data'][] = array($data['s_d_id'], //0
		$data['projectname'], //1
		$data['releaseNum'], //2
		$data['s_d_module'], //3
		$data['s_d_submodule'], //4 
		$data['s_d_defectnum'], //5
		$data['testcasenum'], //6
		$data['s_d_shortdesc'], //7
		$data['s_d_longdesc'], //8
		$data['s_d_testdata'], //9
		$data['s_d_steps'], //10
		$data['s_d_expectedresult'], //11
		$data['s_d_actualresult'], //12
		(!empty($data['defecttype']) ? $data['defecttype'] : "-"), //8 13
		$data['defectstatus'], //9 14
		(!empty($data['s_d_severity']) ? $data['s_d_severity'] : "-"), //10 15
		(!empty($data['s_d_priority']) ? $data['s_d_priority'] : "-"), //11 16
		(!empty($data['s_d_environment']) ? $data['s_d_environment'] : "-"), //11 17		
 		(!empty($data['s_d_platform']) ? $data['s_d_platform'] : "-"), //11 18
 		(!empty($data['s_d_version']) ? $data['s_d_version'] : "-"), //11 19
		$createdtime,$updatedtime,		 //20,21
		$attachemnts, //14 122
		$data['s_d_id'] //15 23
		);
}
// Return JSON response
echo json_encode([
    "draw" => intval($_POST['draw']),
    "recordsTotal" => $totalRecords,
    "recordsFiltered" => $filterrows, // modify if search applied
    "data" => $projarr['data']
]);
// echo json_encode($projarr);
?>
