<?php
include('config.php');
session_start();

header('Content-Type: application/json');

$response = [];
$enteredby = $_SESSION["id"] ?? 0;
$accountId = $_SESSION["accountId"] ?? 0;
$userempid = $_SESSION["userempid"] ?? 0;

try {
    // Handle file upload
    if (isset($_FILES['profilePicture']) && !empty($_FILES['profilePicture']['name'])) {
        $uploadDir = '../images/profile_pictures/';

        // Create directory if it doesn't exist
        if (!file_exists($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }

        // Validate file
        $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
        $fileType = mime_content_type($_FILES['profilePicture']['tmp_name']);

        if (!in_array($fileType, $allowedTypes)) {
            throw new Exception('Only JPG, PNG, and GIF images are allowed.');
        }

        if ($_FILES['profilePicture']['size'] > 2 * 1024 * 1024) {
            throw new Exception('File size must be less than 2MB.');
        }

        // Generate unique filename
        $fileExt = pathinfo($_FILES['profilePicture']['name'], PATHINFO_EXTENSION);
        $fileName = 'profile_' . $userempid . '_' . time() . '.' . $fileExt;
        $targetFilePath = $uploadDir . $fileName;

        if (move_uploaded_file($_FILES['profilePicture']['tmp_name'], $targetFilePath)) {
            $profilePath = 'profile_pictures/' . $fileName;

            // Update database
            $updateQuery = "UPDATE s_employees SET profile_path = ? WHERE accountId = ? AND s_e_id = ?";
            $stmt = mysqli_prepare($conn, $updateQuery);
            mysqli_stmt_bind_param($stmt, 'sii', $profilePath, $accountId, $userempid);

            if (mysqli_stmt_execute($stmt)) {
                // Update session variable
                $_SESSION['profile_path'] = $profilePath;
                $response = ['success' => true, 'profile_path' => $profilePath];
            } else {
                throw new Exception('Database update failed: ' . mysqli_error($conn));
            }
        } else {
            throw new Exception('File upload failed.');
        }

        echo json_encode($response);
        exit;
    }

    // Handle profile picture removal
    if (isset($_POST['removeProfilePicture'])) {
        $updateQuery = "UPDATE s_employees SET profile_path = 'admin.jpg' WHERE accountId = ? AND s_e_id = ?";
        $stmt = mysqli_prepare($conn, $updateQuery);
        mysqli_stmt_bind_param($stmt, 'ii', $accountId, $userempid);

        if (mysqli_stmt_execute($stmt)) {
            // Update session variable
            $_SESSION['profile_path'] = 'admin.jpg';
            echo json_encode(['success' => true]);
        } else {
            throw new Exception('Failed to remove profile picture: ' . mysqli_error($conn));
        }
        exit;
    }

    // Handle profile info update
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['firstName'])) {
        $firstName = trim($_POST['firstName']);
        $lastName = trim($_POST['lastName']);
        $phoneNumber = trim($_POST['phoneNumber'] ?? '');

        // Basic check to ensure first name and last name are not empty
        if (empty($firstName) || empty($lastName)) {
            throw new Exception('First name and last name are required.');
        }

        $updateQuery = "UPDATE s_employees SET s_e_fname = ?, s_e_lname = ?, s_e_phoneno = ? WHERE accountId = ? AND s_e_id = ?";
        $stmt = mysqli_prepare($conn, $updateQuery);
        mysqli_stmt_bind_param($stmt, 'sssii', $firstName, $lastName, $phoneNumber, $accountId, $userempid);

        if (mysqli_stmt_execute($stmt)) {
            echo json_encode(['success' => true]);
        } else {
            throw new Exception('Profile update failed: ' . mysqli_error($conn));
        }
        exit;
    }

    // Default: Get profile data
    $query = "SELECT e.*, IFNULL(r.s_role_name,'') as role, e.profile_path
              FROM s_employees e
              LEFT JOIN s_role r ON r.s_role_id = e.roleId
              WHERE e.accountId = ? AND e.s_e_id = ?";
    $stmt = mysqli_prepare($conn, $query);
    mysqli_stmt_bind_param($stmt, 'ii', $accountId, $userempid);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if ($data = mysqli_fetch_assoc($result)) {
        $response = [
            "id" => $data['s_e_id'],
            "firstname" => $data['s_e_fname'],
            "lastname" => $data['s_e_lname'],
            "emailid" => $data['s_e_emailid'],
            "phoneno" => $data['s_e_phoneno'],
            "activestatus" => $data['s_e_activestatus'],
            "role" => $data['role'],
            "profile_path" => $data['profile_path'] ?? 'admin.jpg',
            "type" => "Employee"
        ];
        // Update session variable
        $_SESSION['profile_path'] = $data['profile_path'] ?? 'admin.jpg';
    } else {
        $response = [
            "firstname" => "Admin",
            "role" => "Admin",
            "profile_path" => "admin.jpg"
        ];
        // Update session variable
        $_SESSION['profile_path'] = 'admin.jpg';
    }

    echo json_encode($response);

} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}

?>
