
<?php
header('Access-Control-Allow-Origin: *');
include('config.php');
/**
 * 
 *  script handles the creation and management of defects in a project. It allows users to:
 * Add new defects with details like project, release, test case, severity, priority, and more
 * Assign defects to team members.
 * Log audit trails and send notifications to relevant stakeholders.
 */
$body = file_get_contents('php://input');
$postobject = json_decode($body,true);

$enteredby = 0;$accountId=0;$projcode = "";
 
$temp_projectId = isset($postobject['projectId']) ? $postobject['projectId'] : 0;
$temp_releaseId = isset($postobject['releaseId']) ? $postobject['releaseId'] : 0;
$enteredby = isset($postobject['enteredby']) ? $postobject['enteredby'] : 0;


$releasedata = mysqli_query($conn,"SELECT r.s_r_id,r.projectId,r.accountId,p.s_p_code from s_release as r inner join s_project p on p.s_p_id = r.projectId  where r.s_r_id = '".$temp_releaseId ."' and r.projectId = '".$temp_projectId ."' order by s_r_id desc limit 1 ");

while($rpdata = mysqli_fetch_assoc($releasedata)){

	$accountId = $rpdata['accountId'];
	$projcode = $rpdata['s_p_code'];
}

$msgarr = array();

$msgarr["status"] = "Error";
$msgarr["message"] = "Something went wrong. Please try again.";
$updateRecords = "";$auditlogDesc = "";$emailids = "";$empids = "";$attachmentsLogs =array();$attachfilename = array();$newFlag = 0;

if($_SERVER['REQUEST_METHOD'] === 'POST'){

	$id = (isset($postobject['dId']) ? $postobject['dId'] : "0");
	$projectId = (isset($postobject['projectId']) && !empty($postobject['projectId']) ? $postobject['projectId'] : "0");
	$projectId_change = 1;
	if($projectId_change == "1"){
		if($auditlogDesc == ""){
			$auditlogDesc = "Project";
		}else{
			$auditlogDesc .= ", Project";
		}
		if($updateRecords == ""){
			$updateRecords = "projectId = '".$projectId."'";
		}else{
			$updateRecords .= ", projectId = '".$projectId."'";
		}
	}
	$empdata = mysqli_query($conn,"SELECT IFNULL(group_concat(s_e_emailid),'') as emailids, IFNULL(group_concat(s_e_id),'') as empids from  s_employees where s_e_activestatus = 'Active' and s_e_id in(select employeeId from s_project_members where projectId = '".$projectId."' and accountId ='".$accountId."' ) and accountId ='".$accountId."'   Order by s_e_id desc");

	while($edata = mysqli_fetch_assoc($empdata)){
		$emailids = $edata['emailids'];
		$empids = $edata['empids'];
	}


	$releaseId = (isset($postobject['releaseId']) && !empty($postobject['releaseId']) ? $postobject['releaseId'] : "0");
	$releaseId_change = 1;
	if($releaseId_change == "1"){
		if($auditlogDesc == ""){
			$auditlogDesc = "Release";
		}else{
			$auditlogDesc .= ", Release";
		}
		if($updateRecords == ""){
			$updateRecords = "releaseId = '".$releaseId."'";
		}else{
			$updateRecords .= ", releaseId = '".$releaseId."'";
		}
	}

	$testcaseId = (isset($postobject['testcaseId']) && !empty($postobject['testcaseId'])? $postobject['testcaseId'] : "0");
	$testcaseId_change = 1;
	if($testcaseId_change == "1"){
		if($auditlogDesc == ""){
			$auditlogDesc = "Testcase";
		}else{
			$auditlogDesc .= ", Testcase";
		}
		if($updateRecords == ""){
			$updateRecords = "testcaseId = '".$testcaseId."'";
		}else{
			$updateRecords .= ", testcaseId = '".$testcaseId."'";
		}
	}

	$assignto = (isset($postobject['assignto']) && !empty($postobject['assignto']) ? $postobject['assignto'] : "0");
	$assignto_change = 1;
	if($assignto_change == "1"){
		if($auditlogDesc == ""){
			$auditlogDesc = "Assignment";
		}else{
			$auditlogDesc .= ", Assignment";
		}
		if($updateRecords == ""){
			$updateRecords = "s_d_assignto = '".$assignto."'";
		}else{
			$updateRecords .= ", s_d_assignto = '".$assignto."'";
		}
	}

	$module = (isset($postobject['module']) ? mysqli_real_escape_string($conn,$postobject['module']) : "");
	$module_change = 1;
	if($module_change == "1"){
		if($auditlogDesc == ""){
			$auditlogDesc = "Module";
		}else{
			$auditlogDesc .= ", Module";
		}
		if($updateRecords == ""){
			$updateRecords = "s_d_module = '".$module."'";
		}else{
			$updateRecords .= ", s_d_module = '".$module."'";
		}
	}

	$submodule = (isset($postobject['submodule']) ? mysqli_real_escape_string($conn,$postobject['submodule']) : "");
	$submodule_change = 1;
	if($submodule_change == "1"){
		if($auditlogDesc == ""){
			$auditlogDesc = "Submodule";
		}else{
			$auditlogDesc .= ", Submodule";
		}
		if($updateRecords == ""){
			$updateRecords = "s_d_submodule = '".$submodule."'";
		}else{
			$updateRecords .= ", s_d_submodule = '".$submodule."'";
		}
	}

	$severity = (isset($postobject['severity']) ? $postobject['severity'] : "");
	$severity_change = 1;
	if($severity_change == "1"){
		if($auditlogDesc == ""){
			$auditlogDesc = "Severity";
		}else{
			$auditlogDesc .= ", Severity";
		}
		if($updateRecords == ""){
			$updateRecords = "s_d_severity = '".$severity."'";
		}else{
			$updateRecords .= ", s_d_severity = '".$severity."'";
		}
	}

	$priority = (isset($postobject['priority']) ? $postobject['priority'] : "");
	$priority_change = 1;
	if($priority_change == "1"){
		if($auditlogDesc == ""){
			$auditlogDesc = "Priority";
		}else{
			$auditlogDesc .= ", Priority";
		}
		if($updateRecords == ""){
			$updateRecords = "s_d_priority = '".$priority."'";
		}else{
			$updateRecords .= ", s_d_priority = '".$priority."'";
		}
	}

	$defecttypeId = (isset($postobject['defecttypeId'])  && !empty($postobject['defecttypeId']) ? $postobject['defecttypeId'] : "0");
	$defecttypeId_change = 1;
	if($defecttypeId_change == "1"){
		if($auditlogDesc == ""){
			$auditlogDesc = "Defect type";
		}else{
			$auditlogDesc .= ", Defect type";
		}
		if($updateRecords == ""){
			$updateRecords = "defecttypeId = '".$defecttypeId."'";
		}else{
			$updateRecords .= ", defecttypeId = '".$defecttypeId."'";
		}
	}

	$defectstatusId = (isset($postobject['defectstatusId'])   && !empty($postobject['defectstatusId']) ? $postobject['defectstatusId'] : "0");
	$defectstatusId_change = 1;
	if($defectstatusId_change == "1"){
		if($auditlogDesc == ""){
			$auditlogDesc = "Defect status";
		}else{
			$auditlogDesc .= ", Defect status";
		}
		if($updateRecords == ""){
			$updateRecords = "defectstatusId = '".$defectstatusId."'";
		}else{
			$updateRecords .= ", defectstatusId = '".$defectstatusId."'";
		}
	}

	$shortdesc = (isset($postobject['shortdesc']) ? mysqli_real_escape_string($conn,$postobject['shortdesc']) : "");
	$shortdesc_change = 1;
	if($shortdesc_change == "1"){
		if($auditlogDesc == ""){
			$auditlogDesc = "Short description";
		}else{
			$auditlogDesc .= ", Short description";
		}
		if($updateRecords == ""){
			$updateRecords = "s_d_shortdesc = '".$shortdesc."'";
		}else{
			$updateRecords .= ", s_d_shortdesc = '".$shortdesc."'";
		}
	}

	$longdesc = (isset($postobject['longdesc']) ? mysqli_real_escape_string($conn,$postobject['longdesc']) : "");
	$longdesc_change = 1;
	if($longdesc_change == "1"){
		if($auditlogDesc == ""){
			$auditlogDesc = "Detailed Description";
		}else{
			$auditlogDesc .= ", Detailed Description";
		}
		if($updateRecords == ""){
			$updateRecords = "s_d_longdesc = '".$longdesc."'";
		}else{
			$updateRecords .= ", s_d_longdesc = '".$longdesc."'";
		}
	}

	$testdata = (isset($postobject['testdata']) ? mysqli_real_escape_string($conn,$postobject['testdata']) : "");
	$testdata_change = 1;
	if($testdata_change == "1"){
		if($auditlogDesc == ""){
			$auditlogDesc = "Testdata";
		}else{
			$auditlogDesc .= ", Testdata";
		}
		if($updateRecords == ""){
			$updateRecords = "s_d_testdata = '".$testdata."'";
		}else{
			$updateRecords .= ", s_d_testdata = '".$testdata."'";
		}
	}

	$steps = (isset($postobject['steps']) ? mysqli_real_escape_string($conn,$postobject['steps']) : "");
	$steps_change = 1;
	if($steps_change == "1"){
		if($auditlogDesc == ""){
			$auditlogDesc = "Steps";
		}else{
			$auditlogDesc .= ", Steps";
		}
		if($updateRecords == ""){
			$updateRecords = "s_d_steps = '".$steps."'";
		}else{
			$updateRecords .= ", s_d_steps = '".$steps."'";
		}
	}

	$expectedresult = (isset($postobject['expectedresult']) ? mysqli_real_escape_string($conn,$postobject['expectedresult']) : "");
	$expectedresult_change = 1;
	if($expectedresult_change == "1"){
		if($auditlogDesc == ""){
			$auditlogDesc = "Expected Result";
		}else{
			$auditlogDesc .= ", Expected Result";
		}
		if($updateRecords == ""){
			$updateRecords = "s_d_expectedresult = '".$expectedresult."'";
		}else{
			$updateRecords .= ", s_d_expectedresult = '".$expectedresult."'";
		}
	}

	$actualresult = (isset($postobject['actualresult']) ? mysqli_real_escape_string($conn,$postobject['actualresult']) : "");
	$actualresult_change = 1;
	if($actualresult_change == "1"){
		if($auditlogDesc == ""){
			$auditlogDesc = "Actual Result";
		}else{
			$auditlogDesc .= ", Actual Result";
		}
		if($updateRecords == ""){
			$updateRecords = "s_d_actualresult = '".$actualresult."'";
		}else{
			$updateRecords .= ", s_d_actualresult = '".$actualresult."'";
		}
	}

	$comment = (isset($postobject['comment']) ? mysqli_real_escape_string($conn,$postobject['comment']) : "");

	$filename = "";
	$filepath = "";
	// generate release ID

	$defectId = 0;
	$defectIdstr = "";
	if($projectId_change == "1"){

		$defectsqldata = mysqli_query($conn,"SELECT * from s_defect where projectId = '".$projectId."' and accountId = '".$accountId."'  order by s_d_tempid desc limit 1");
		if(mysqli_num_rows($defectsqldata)>0){

			while($rdata = mysqli_fetch_assoc($defectsqldata)){
				$defectId = (int)$rdata['s_d_tempid'] +1;
			}
		}else{
			$defectId = 1;
		}
		$defectIdstr = "$projcode-D$defectId";

		if($auditlogDesc == ""){
			$auditlogDesc = "Defect ID";
		}else{
			$auditlogDesc .= ", Defect ID";
		}

		if($updateRecords == ""){
			$updateRecords = "s_d_tempid = '".$defectId."', s_d_defectnum = '".$defectIdstr."'";
		}else{
			$updateRecords .= ", s_d_tempid = '".$defectId."', s_d_defectnum = '".$defectIdstr."'";
		}

	}

	$sql = "INSERT INTO s_defect (projectId, releaseId, testcaseId, s_d_tempid, s_d_defectnum, s_d_module, s_d_submodule, defecttypeId, s_d_severity, s_d_priority, defectstatusId, s_d_assignto, s_d_shortdesc, s_d_longdesc, s_d_testdata, s_d_steps, s_d_expectedresult, s_d_actualresult, s_d_comment, s_d_enteredby, accountId) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "sssssssssssssssssssss", $projectId, $releaseId, $testcaseId, $defectId, $defectIdstr, $module, $submodule, $defecttypeId, $severity, $priority, $defectstatusId, $assignto, $shortdesc, $longdesc, $testdata, $steps, $expectedresult, $actualresult, $comment, $enteredby, $accountId);
	mysqli_stmt_execute($stmt);
	if($stmt){
		$newFlag = 1;
		$msgarr["status"] = "Success";
		$msgarr["message"] = "Defect added successfully.";
		$insertid = mysqli_insert_id($conn);

		if($assignto_change == "1" && $assignto !="0"){
			$history = "INSERT INTO s_defectassignmenthistory (defectId, s_dh_assignto, s_dh_enteredby, accountId) VALUES (?, ?, ?, ?)";
			$stmt_history = mysqli_prepare($conn, $history);
			mysqli_stmt_bind_param($stmt_history, "ssss", $insertid, $assignto, $enteredby, $accountId);
			mysqli_stmt_execute($stmt_history);

		}
		$auditlogDesc = "New defect created.";
		$auditlogSql = "insert into s_auditlogs (`s_a_desc`, `s_a_module`, `s_a_enteredby`,`accountId`,`s_a_recordId`,`s_a_recordnum`  ) values ('".$auditlogDesc."','Defect','".$enteredby."','".$accountId."','".$insertid."','".$defectIdstr."') ";
		
		mysqli_query( $conn, $auditlogSql);

		if(isset($postobject['attachment'])){
			if (!file_exists($CFG['dirroot'].'defectdata/'.$accountId.'/'.$insertid)) {
				mkdir($CFG['dirroot'].'defectdata/'.$accountId.'/'.$insertid, 0777, true);
			}
				
			$img = $postobject['attachment']; // Your data 'data:image/png;base64,AAAFBfj42Pj4';

			$img = str_replace('data:image/png;base64,', '', $img);
			$img = str_replace('data:image/jpeg;base64,', '', $img);
			$img = str_replace('data:image/jpg;base64,', '', $img);
			// $img = str_replace(' ', '+', $img);
			$idata = base64_decode($img);

			// Load GD resource from binary data
			$im = imageCreateFromString($idata);

			// Make sure that the GD library was able to load the image
			// This is important, because you should not miss corrupted or unsupported images
			if (!$im) {
				// die('Base64 value is not a valid image');
			}else{

				// Specify the location where you want to save the image
				$img_file = $CFG['dirroot'].'defectdata/'.$accountId.'/'.$insertid."/" .($insertid."-".uniqid()).'.png';

				// Save the GD resource as PNG in the best possible quality (no compression)
				// This will strip any metadata or invalid contents (including, the PHP backdoor)
				// To block any possible exploits, consider increasing the compression level
				imagepng($im, $img_file, 0);
			}
			
		}
		if($emailids !=""){
			$notificationSql = "insert into s_notifications (`s_n_viewer`, `s_n_employees`,`s_n_assignto`, `s_n_recordid`,`s_n_recordnum`,`s_n_desc`,`s_n_attachments`,`s_n_filename`,`accountId`,`s_n_enteredby` ,`s_n_newflag`,`s_n_emailflag` ) values (NULL,'".$empids."','0','".$insertid."','".$defectIdstr."','".$auditlogDesc."','".(implode(",", $attachmentsLogs))."','".(implode(",", $attachfilename))."','".$accountId."','".$enteredby."','".$newFlag."','0') ";
			
			mysqli_query( $conn, $notificationSql);
		}
		
	}else{
		$msgarr["status"] = "Error";
		$msgarr["message"] = "Something went wrong. Please try again.";
	}
}

echo json_encode($msgarr);