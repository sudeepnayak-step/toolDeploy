<?php
header('Access-Control-Allow-Origin: *');
include('config.php');

$msg = "Oops! Something went wrong. Please try again later.";

$msgarr = array();

$msgarr["status"] = "Error";
$msgarr["message"] = "Something went wrong. Please try again.";
if($_SERVER['REQUEST_METHOD'] === 'POST'){

  $activationnum = (isset($_POST['activationnum']) ? $_POST['activationnum'] : "0");
  $password = (isset($_POST['password']) ? $_POST['password'] : '');
 // echo $activationnum;die;
// echo $password;die; 
  if(!empty($activationnum) && $activationnum !="0") {
//	echo "1";die;

    $sql = "UPDATE s_users SET s_u_password = ? WHERE s_u_activationnum = ?";
//	echo $sql;die;
    $stmt = mysqli_prepare($conn, $sql);
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, "ss", password_hash($password, PASSWORD_DEFAULT), $activationnum);
        if (mysqli_stmt_execute($stmt)) {
            $msgarr["status"] = "Success";
            $msgarr["message"] = "Password reset successfully.";
        } else {

            $msgarr["status"] = "Failed";
            $msgarr["message"] = "Password reset failed.";
        }

        mysqli_stmt_close($stmt);
    }
  }
}
echo json_encode($msgarr);


