<?php
include('config.php');
session_start();
 
$enteredby = 0;$accountId = 0;
 

if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
}
if($_SERVER['REQUEST_METHOD'] === 'POST'){

$activityId = (isset($_POST['activityId']) ? $_POST['activityId'] : "0");
$riskissueIdarr = (isset($_POST['riskissueId']) ? $_POST['riskissueId'] : array());

$raiseddatearr = (isset($_POST['raiseddate']) ? $_POST['raiseddate'] : array());
$raiseddate_changearr = (isset($_POST['raiseddate_change']) ? $_POST['raiseddate_change'] : array());

$riskissuetypearr = (isset($_POST['riskissuetype']) ? $_POST['riskissuetype'] : array());
$riskissuetype_changearr = (isset($_POST['riskissuetype_change']) ? $_POST['riskissuetype_change'] : array());

$riskissuedescarr = (isset($_POST['riskissuedesc']) ? $_POST['riskissuedesc'] : array());
$changeriskissuedescarr = (isset($_POST['changeriskissuedesc']) ? $_POST['changeriskissuedesc'] : array());

$actionablebyarr = (isset($_POST['actionableby']) ? $_POST['actionableby'] : array());
$actionableby_changearr = (isset($_POST['actionableby_change']) ? $_POST['actionableby_change'] : array());

$riskissueplanarr = (isset($_POST['riskissueplan']) ? $_POST['riskissueplan'] : array());
$changeriskissueplanarr = (isset($_POST['changeriskissueplan']) ? $_POST['changeriskissueplan'] : array());

$closuredatearr = (isset($_POST['closuredate']) ? $_POST['closuredate'] : array());
$closuredate_changearr = (isset($_POST['closuredate_change']) ? $_POST['closuredate_change'] : array());

$riskissuestatusarr = (isset($_POST['riskissuestatus']) ? $_POST['riskissuestatus'] : array());
$riskissuestatus_changearr = (isset($_POST['riskissuestatus_change']) ? $_POST['riskissuestatus_change'] : array());

$probabilityarr = (isset($_POST['probability']) ? $_POST['probability'] : array());
$changeprobabilityarr = (isset($_POST['changeprobability']) ? $_POST['changeprobability'] : array());


$impactarr = (isset($_POST['impact']) ? $_POST['impact'] : array());
$changeimpactarr = (isset($_POST['changeimpact']) ? $_POST['changeimpact'] : array());

$len = count($riskissueIdarr);
if($len >0){
	for($k=0; $k <$len; $k++ ){
		$updateRecords = "";$auditlogDesc = "";$emailids = "";$empids = "";
		# code...
		$riskissueId = (isset($riskissueIdarr[$k]) ? $riskissueIdarr[$k] : 0);

		$riskissuetype = (isset($riskissuetypearr[$k]) ? $riskissuetypearr[$k] : "");
		$riskissuetype_change = (isset($riskissuetype_changearr[$k]) ? $riskissuetype_changearr[$k] : "0");
		if($riskissuetype_change == "1"){
			if($auditlogDesc == ""){
				$auditlogDesc = "Type";
			}else{
				$auditlogDesc .= ", Type";
			}
			if($updateRecords == ""){
				$updateRecords = "s_r_type = '".$riskissuetype."'";
			}else{
				$updateRecords .= ", s_r_type = '".$riskissuetype."'";
			}
		}

		$raiseddate = (isset($raiseddatearr[$k]) && !empty($raiseddatearr[$k]) ? date('Y-m-d', strtotime(str_replace('/', '-', $raiseddatearr[$k]))) : null);
		$raiseddate_change = (isset($raiseddate_changearr[$k]) ? $raiseddate_changearr[$k] : "0");
		if($raiseddate_change == "1"){
			if($auditlogDesc == ""){
				$auditlogDesc = "Raised Date";
			}else{
				$auditlogDesc .= ", Raised Date";
			}
			if($updateRecords == ""){
				$updateRecords = "s_r_raiseddate = '".$raiseddate."'";
			}else{
				$updateRecords .= ", s_r_raiseddate = '".$raiseddate."'";
			}
		}

		$riskissueplan = (isset($riskissueplanarr[$k]) ? $riskissueplanarr[$k] : "");
		$riskissueplan_change = (isset($changeriskissueplanarr[$k]) ? $changeriskissueplanarr[$k] : "0");
		if($riskissueplan_change == "1"){
			if($auditlogDesc == ""){
				$auditlogDesc = "Action/Mitigation Plans";
			}else{
				$auditlogDesc .= ", Action/Mitigation Plans";
			}
			if($updateRecords == ""){
				$updateRecords = "s_r_plan = '".$riskissueplan."'";
			}else{
				$updateRecords .= ", s_r_plan = '".$riskissueplan."'";
			}
		}

		$riskissuedesc = (isset($riskissuedescarr[$k]) ? mysqli_real_escape_string($conn,$riskissuedescarr[$k]) : "");
		$riskissuedesc_change = (isset($changeriskissuedescarr[$k]) ? $changeriskissuedescarr[$k] : "0");
		if($riskissuedesc_change == "1"){
			if($auditlogDesc == ""){
				$auditlogDesc = "Description";
			}else{
				$auditlogDesc .= ", Description";
			}
			if($updateRecords == ""){
				$updateRecords = "s_r_desc = '".$riskissuedesc."'";
			}else{
				$updateRecords .= ", s_r_desc = '".$riskissuedesc."'";
			}
		}

		$closuredate = (isset($closuredatearr[$k]) && !empty($closuredatearr[$k]) ? date('Y-m-d', strtotime(str_replace('/', '-', $closuredatearr[$k]))) : null);
		$closuredate_change = (isset($closuredate_changearr[$k]) ? $closuredate_changearr[$k] : "0");
		if($closuredate_change == "1"){
			if($auditlogDesc == ""){
				$auditlogDesc = "Target Closure Date";
			}else{
				$auditlogDesc .= ", Target Closure Date";
			}
			if($updateRecords == ""){
				$updateRecords = "s_r_closuredate = '".$closuredate."'";
			}else{
				$updateRecords .= ", s_r_closuredate = '".$closuredate."'";
			}
		}

		$riskissuestatus = (isset($riskissuestatusarr[$k]) ? $riskissuestatusarr[$k] : "");
		$riskissuestatus_change = (isset($riskissuestatus_changearr[$k]) ? $riskissuestatus_changearr[$k] : "0");
		if($riskissuestatus_change == "1"){
			if($auditlogDesc == ""){
				$auditlogDesc = "Status";
			}else{
				$auditlogDesc .= ", Status";
			}
			if($updateRecords == ""){
				$updateRecords = "s_r_status = '".$riskissuestatus."'";
			}else{
				$updateRecords .= ", s_r_status = '".$riskissuestatus."'";
			}
		}

		$probability = (isset($probabilityarr[$k]) ? $probabilityarr[$k] : "");
		$probability_change = (isset($probability_changearr[$k]) ? $probability_changearr[$k] : "0");
		if($probability_change == "1"){
			if($auditlogDesc == ""){
				$auditlogDesc = "Probability";
			}else{
				$auditlogDesc .= ", Probability";
			}
			if($updateRecords == ""){
				$updateRecords = "s_r_probability = '".$probability."'";
			}else{
				$updateRecords .= ", s_r_probability = '".$probability."'";
			}
		}

		$impact = (isset($impactarr[$k]) ? $impactarr[$k] : "");
		$impact_change = (isset($impact_changearr[$k]) ? $impact_changearr[$k] : "0");
		if($impact_change == "1"){
			if($auditlogDesc == ""){
				$auditlogDesc = "impact";
			}else{
				$auditlogDesc .= ", impact";
			}
			if($updateRecords == ""){
				$updateRecords = "s_r_impact = '".$impact."'";
			}else{
				$updateRecords .= ", s_r_impact = '".$impact."'";
			}
		}

		$actionableby = (isset($actionablebyarr[$k]) ? $actionablebyarr[$k] : 0);
		$actionableby_change = (isset($actionableby_changearr[$k]) ? $actionableby_changearr[$k] : "0");
		if($actionableby_change == "1"){
			if($auditlogDesc == ""){
				$auditlogDesc = "Actionable";
			}else{
				$auditlogDesc .= ", Actionable";
			}
			if($updateRecords == ""){
				$updateRecords = "s_r_impact = '".$actionableby."'";
			}else{
				$updateRecords .= ", s_r_impact = '".$actionableby."'";
			}
		}
		// if(!empty($assignto)){
			$empdata = mysqli_query($conn,"SELECT IFNULL(group_concat(s_e_emailid),'') as emailids, IFNULL(group_concat(s_e_id),'') as empids from  s_employees where s_e_activestatus = 'Active' and (s_e_id = '".$actionableby."'  or userId = '".$enteredby."') and accountId ='".$accountId."'   Order by s_e_id desc");

			while($edata = mysqli_fetch_assoc($empdata)){
				$emailids = $edata['emailids'];
				$empids = $edata['empids'];
			}
		// }


		if(!empty($riskissueId) && $riskissueId !="0") {
			$sql = "UPDATE s_riskissue SET 
                        s_r_activityId = ?, 
                        s_r_type = ?, 
                        s_r_raiseddate = ?, 
                        s_r_plan = ?, 
                        s_r_desc = ?, 
                        s_r_closuredate = ?, 
                        s_r_status = ?, 
                        s_r_probability = ?, 
                        s_r_impact = ?, 
                        s_r_actionableby = ? 
                        WHERE s_r_id = ? AND accountId = ?";

			$stmt = mysqli_prepare($conn, $sql);
			if ($stmt) {
				mysqli_stmt_bind_param($stmt, "isssssssssii", 
					$activityId, 
					$riskissuetype, 
					$raiseddate, 
					$riskissueplan, 
					$riskissuedesc, 
					$closuredate, 
					$riskissuestatus, 
					$probability, 
					$impact, 
					$actionableby, 
					$riskissueId, 
					$accountId
				);

				mysqli_stmt_execute($stmt);
				mysqli_stmt_close($stmt);
			}
			if($auditlogDesc != ""){
				$auditlogSql = "insert into s_auditlogs (`s_a_desc`, `s_a_module`, `s_a_enteredby`,`accountId`,`s_a_recordId`,`s_a_recordnum` ) values ('".$auditlogDesc."','Risk/Issue','".$enteredby."','".$accountId."','".$riskissueId."','') ";
				
				mysqli_query( $conn, $auditlogSql);


			}
			$newFlag = 0;
			if($emailids !=""){
				$notificationSql = "insert into s_notifications (`s_n_viewer`, `s_n_employees`,`s_n_assignto`, `s_n_recordid`,s_n_subid,`s_n_recordnum`,`s_n_desc`,`s_n_attachments`,`s_n_filename`,`accountId`,`s_n_enteredby`,s_n_newflag ,s_n_emailflag,s_n_module ) values (NULL,'".$empids."','0','".$activityId."','".$riskissueId."','','".$auditlogDesc."','','','".$accountId."','".$enteredby."','".$newFlag."','0','Risk/Issue') ";
				
				mysqli_query( $conn, $notificationSql);

				// sendEmail($emailids,$defectIdstr,$auditlogDesc,$id,$attachmentsLogs,$attachfilename,$newFlag);
			}
		}else{


			// Example: Refactor the INSERT query
			$sql = "INSERT INTO s_riskissue (
				s_r_activityId, 
				s_r_type, 
				s_r_raiseddate, 
				s_r_plan, 
				s_r_desc, 
				s_r_closuredate, 
				s_r_status, 
				s_r_probability, 
				s_r_impact, 
				s_r_actionableby, 
				s_r_enteredby, 
				accountId
			) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

			$stmt = mysqli_prepare($conn, $sql);
			if ($stmt) {
				mysqli_stmt_bind_param($stmt, "isssssssssii", 
					$activityId, 
					$riskissuetype, 
					$raiseddate, 
					$riskissueplan, 
					$riskissuedesc, 
					$closuredate, 
					$riskissuestatus, 
					$probability, 
					$impact, 
					$actionableby, 
					$enteredby, 
					$accountId
				);

				mysqli_stmt_execute($stmt);
				$riskissueId = mysqli_insert_id($conn);
				mysqli_stmt_close($stmt);
			}
			$newFlag = 1;
			if($emailids !=""){
				$notificationSql = "insert into s_notifications (`s_n_viewer`, `s_n_employees`,`s_n_assignto`, `s_n_recordid`,s_n_subid,`s_n_recordnum`,`s_n_desc`,`s_n_attachments`,`s_n_filename`,`accountId`,`s_n_enteredby`,s_n_newflag ,s_n_emailflag,s_n_module ) values (NULL,'".$empids."','0','".$activityId."','".$riskissueId."','','".$auditlogDesc."','','','".$accountId."','".$enteredby."','".$newFlag."','0','Risk/Issue') ";
				
				mysqli_query( $conn, $notificationSql);

			}

		}
	}
	
}
}
