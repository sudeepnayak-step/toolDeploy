<?php
// TO-DO: Implement password reset functionality
/**
 * TODO: Implement the password reset functionality here.
 * This section is currently incomplete and needs to be finished.
 */
header('Access-Control-Allow-Origin: *');
include('config.php');
$msgarr = array();

$msgarr["status"] = "Error";
$msgarr["message"] = "Something went wrong. Please try again.";
if($_SERVER['REQUEST_METHOD'] === 'POST'){

  $activationnum = (isset($_POST['activationnum']) ? $_POST['activationnum'] : "0");
  $emailid = (isset($_POST['username']) ? $_POST['username'] : "");
  $password = (isset($_POST['password']) ? $_POST['password'] : '');
  
  if(!empty($activationnum) && $activationnum !="0") {
    // TO-DO: Implement security measures to protect the user's password
    /**
     * TODO: Implement security measures, such as password hashing and salting, to protect the user's password.
     */
    // Use prepared statements to prevent SQL injection
    $sql = "UPDATE s_users SET s_u_password = ? WHERE s_u_activationnum = ?";
    $stmt = mysqli_prepare($conn, $sql);

    if ($stmt) {
        // Hash the password for security
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Bind parameters to the prepared statement
        mysqli_stmt_bind_param($stmt, "ss", $hashed_password, $activationnum);

        // Execute the statement
        if (mysqli_stmt_execute($stmt)) {
            $msgarr["status"] = "Success";
            $msgarr["message"] = "Account activated successfully.";
        }

        // Close the statement
        mysqli_stmt_close($stmt);
    }
  }
}
// TO-DO: Complete the script to return a response message and status to the client
/**
 * TODO: Complete the script to return the response message and status to the client.
 * This can be done using the json_encode() function to encode the $msgarr array as JSON.
 */
echo json_encode($msgarr);



