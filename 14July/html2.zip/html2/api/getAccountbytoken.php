<?php
header('Access-Control-Allow-Origin: *');
include('config.php');
/**This page is designed to handle user account activation via a token. 
 * It processes a POST request, validates the token, 
 * and updates the user's account status in the database. */
if($_SERVER['REQUEST_METHOD'] === 'POST'){

	$token = (isset($_POST['token']) ? $_POST['token'] : "0");
	$token = filter_input(INPUT_POST, 'token', FILTER_SANITIZE_STRING);
	if (empty($token)) {
		$msgarr["status"] = "Error";
		$msgarr["message"] = "Invalid token.";
		echo json_encode($msgarr);
		exit;
	}
	// Select user data
	$stmt = mysqli_prepare($conn, "SELECT * FROM s_users WHERE s_u_activationnum = ? ORDER BY s_u_id DESC LIMIT 1");
	mysqli_stmt_bind_param($stmt, "s", $token);
	mysqli_stmt_execute($stmt);
	$sqldata = mysqli_stmt_get_result($stmt);
	$msgarr = array();
	$msgarr["status"] = "Error";
	$msgarr["message"] = "Something went wrong. Please try again.";
	if(mysqli_num_rows($sqldata) >0){
	//	echo "1";die;
		while($data = mysqli_fetch_assoc($sqldata)){
		//	echo $data['s_u_password'];die;
			if(is_null($data['s_u_password']) || $data['s_u_password'] == 'NULL'){
			//	echo '3';die;
				$projarr= array("id"=>$data['s_u_id'],
					"username"=>$data['s_u_username']
				);
				$USERstmt = mysqli_prepare($conn, "UPDATE s_users SET s_u_accountstatus = 'Active', s_u_activationtime = ? WHERE s_u_id = ?");
			//	echo $USERstmt;die;
				$current_time = date("Y-m-d H:i:s");
				mysqli_stmt_bind_param($USERstmt, "si", $current_time, $data['s_u_id']);
				mysqli_stmt_execute($USERstmt);

				$msgarr["status"] = "Success";
				$msgarr["message"] = $projarr;
			
			}else if($data['s_u_accountstatus'] == "Active"){	
				$msgarr["status"] = "Information";
				$msgarr["message"] = "Your account is already active.";
			}else if($data['s_u_accountstatus'] == "Inactive"){
				$msgarr["status"] = "Information";
				$msgarr["message"] = "Your account is deactivated.";	
			}
		}
	}else{	
		$msgarr["status"] = "Information";
		$msgarr["message"] = "Invalid link.";
	}

	echo json_encode($msgarr);
}
?>
