<?php
include('config.php');
session_start();
 
$enteredby = 0;$accountId=0;$userempid = 0;
 
  /** This PHP script retrieves the count of new notification
 * It formats the data and returns it in JSON format. */

if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
}
if(isset($_SESSION["usertype"]) && $_SESSION["usertype"] == "Employee"){
	if(isset($_SESSION["userempid"])){
    $userempid = $_SESSION["userempid"];
}
}else if(isset($_SESSION["usertype"]) && $_SESSION["usertype"] == "Systemuser"){
	if(isset($_SESSION["userempid"])){
    $userempid = $_SESSION["userempid"];
    }
    $accountId = 0;
}
$projarr['data'] = array();


$sql  = "SELECT count(1) as count
	 from s_notifications  n
	WHERE n.accountId = ? and find_in_set(?,s_n_employees) and IFNULL(FIND_IN_SET(?,s_n_viewer), 0) = 0 
	order by n.s_n_id desc";

$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "iii",$accountId,$userempid,$userempid);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
while($data = mysqli_fetch_assoc($result)){

	$projarr= array("count"=>$data['count']);
}

echo json_encode($projarr);
?>