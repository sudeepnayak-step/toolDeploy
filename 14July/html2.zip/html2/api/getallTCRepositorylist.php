<?php
include('config.php');
session_start();
 
$enteredby = 0;$accountId=0;$userempid = 0;
   /** This PHP script retrieves the repository data from a database. 
 * It formats the data and returns it in JSON format. */

if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
    $userempid = $_SESSION["userempid"];
}


$where = "";
$application = (isset($_POST['application'])  && !empty($_POST['application'])? $_POST['application'] : "");
$module = (isset($_POST['module'])  && !empty($_POST['module'])? $_POST['module'] : "");


if($application !=""){
	$apparr = explode(",", $application);
	$application = "'" . implode ( "', '", $apparr ) . "'";
	$where .= " and tc.s_t_application in ($application) ";
}

if($module !=""){
	$modulearr = explode(",", $module);
	$module = "'" . implode ( "', '", $modulearr ) . "'";
	$where .= " and tc.s_t_module in ($module) ";
}


$table = "s_tcrepository";
$tctype = (isset($_POST['type']) ? mysqli_real_escape_string($conn,$_POST['type']) : "Banking");
switch ($tctype) {
    case 'Banking':
        $table = "s_tcrepository";
        break;
    case 'Automative':
        $table = "s_tcrepository1";
        break;
    case 'HR':
        $table = "s_tcrepository2";
        break;
    case 'Insurance':
        $table = "s_tcrepository3";
        break;
    
    default:
        $table = "s_tcrepository";
        break;
}



// Prepare the main query
$sql = "SELECT tc.*,
        CONCAT(IFNULL(a1.s_e_fname,''),' ',IFNULL(a1.s_e_mname,''),' ',IFNULL(a1.s_e_lname,'')) AS assignto,
        CONCAT(IFNULL(a2.s_e_fname,''),' ',IFNULL(a2.s_e_mname,''),' ',IFNULL(a2.s_e_lname,'')) AS author,
        CONCAT(IFNULL(a3.s_e_fname,''),' ',IFNULL(a3.s_e_mname,''),' ',IFNULL(a3.s_e_lname,'')) AS reviewer
        FROM $table tc
        LEFT JOIN s_employees a1 ON a1.s_e_id = tc.s_t_assignto AND tc.s_t_assignto != '0'
        LEFT JOIN s_employees a2 ON a2.userId = tc.s_t_author AND tc.s_t_author != '0'
        LEFT JOIN s_employees a3 ON a3.s_e_id = tc.s_t_reviewer AND tc.s_t_author != '0'
        WHERE tc.s_t_id != '0' $where
        ORDER BY tc.s_t_id ASC";

$stmt = mysqli_prepare($conn, $sql);
if ($stmt) {
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    $projarr['data'] = array();
    while ($data = mysqli_fetch_assoc($result)) {
        $activityname = "";
        if ($data['s_t_activityIds'] != "") {
            $activityIds = mysqli_real_escape_string($conn, $data['s_t_activityIds']);
            $chksql = "SELECT IFNULL(GROUP_CONCAT(s_a_name),'') AS activityname FROM s_activitymaster WHERE s_a_id IN ($activityIds) AND accountId = ?";
            $chkstmt = mysqli_prepare($conn, $chksql);
            mysqli_stmt_bind_param($chkstmt, "i", $accountId);
            mysqli_stmt_execute($chkstmt);
            $chkresult = mysqli_stmt_get_result($chkstmt);

            while ($actdata = mysqli_fetch_assoc($chkresult)) {
                $activityname = $actdata['activityname'];
            }
            mysqli_stmt_close($chkstmt);
        }

        $author = "Admin";
        if (trim($data['author']) != "") {
            $author = $data['author'];
        }
        $projarr['data'][] = array(
            $data['s_t_id'],
            $data['s_t_application'],
            $data['s_t_module'],
            $data['s_t_testscenariodesc'],
            $data['s_t_testcasenum'],
            $data['s_t_testcasedesc'],
            $data['s_t_id']
        );
    }
    mysqli_stmt_close($stmt);
}

echo json_encode($projarr);
?>
