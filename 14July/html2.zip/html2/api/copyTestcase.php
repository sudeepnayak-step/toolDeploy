<?php
include('config.php');
session_start();
 
$enteredby = 0;$accountId = 0;
 
$errormsg ="";
$msgarr = array();
$msgarr["status"] = "Error";
$msgarr["message"] = "Something went wrong. Please try again.";
if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
}
if($_SERVER['REQUEST_METHOD'] === 'POST'){

	$ids = (isset($_POST['ids']) ? $_POST['ids'] : "");
	$projectId = (isset($_POST['projectId']) ? intval($_POST['projectId']) : 0);
	$releaseId = (isset($_POST['releaseId']) ? intval($_POST['releaseId']) : 0);
	$activityId = (isset($_POST['activityId']) ? array_map('intval', $_POST['activityId']) : array());

	$arr = explode(",", $ids);
    $flag = 0;
	foreach ($arr as $tcid) {
        $tcid = intval($tcid); // Sanitize input

        // Fetch project code
        $projcode = "";
        $projquery = "SELECT * FROM s_project WHERE s_p_id = ? AND accountId = ? ORDER BY s_p_id DESC LIMIT 1";
        $stmt = mysqli_prepare($conn, $projquery);
        mysqli_stmt_bind_param($stmt, "ii", $projectId, $accountId);
        mysqli_stmt_execute($stmt);
        $projsqldata = mysqli_stmt_get_result($stmt);

        if (mysqli_num_rows($projsqldata) > 0) {
            $pdata = mysqli_fetch_assoc($projsqldata);
            $projcode = $pdata['s_p_code'];

            // Fetch scenario ID
            $scenarioId = 1;
            $scenarioquery = "SELECT * FROM s_testcase WHERE projectId = ? AND accountId = ? ORDER BY s_d_tempscenarioId DESC LIMIT 1";
            $stmt = mysqli_prepare($conn, $scenarioquery);
            mysqli_stmt_bind_param($stmt, "ii", $projectId, $accountId);
            mysqli_stmt_execute($stmt);
            $scenariosqldata = mysqli_stmt_get_result($stmt);

            if (mysqli_num_rows($scenariosqldata) > 0) {
                $rdata = mysqli_fetch_assoc($scenariosqldata);
                $scenarioId = (int)$rdata['s_d_tempscenarioId'] + 1;
            }
            $scenarioIdstr = "TS-$scenarioId";

            // Fetch test case number
            $testcaseNum = 1;
            $testnumquery = "SELECT * FROM s_testcase WHERE projectId = ? AND accountId = ? ORDER BY s_t_tempid DESC LIMIT 1";
            $stmt = mysqli_prepare($conn, $testnumquery);
            mysqli_stmt_bind_param($stmt, "ii", $projectId, $accountId);
            mysqli_stmt_execute($stmt);
            $testnumsqldata = mysqli_stmt_get_result($stmt);

            if (mysqli_num_rows($testnumsqldata) > 0) {
                $rdata = mysqli_fetch_assoc($testnumsqldata);
                $testcaseNum = (int)$rdata['s_t_tempid'] + 1;
            }
            $testcaseIdstr = "TC-$testcaseNum";
        }

		// Insert test case
		$insertquery = "INSERT INTO s_testcase (projectId, releaseId, s_t_activityIds, s_d_tempscenarioId, s_t_testscenarionum, s_t_tempid, s_t_testcasenum, s_t_module, s_t_submodule, s_t_testscenariodesc, s_t_testcasedesc, s_t_steps, s_t_expectedresult, s_t_precondition, s_t_testdata, s_t_enteredby, accountId, s_t_testmode, s_t_assignto, s_t_author, s_t_reviewer) 
		SELECT ?, ?, ?, ?, ?, ?, s_t_testscenarionum, s_t_module, s_t_submodule, s_t_testscenariodesc, s_t_testcasedesc, s_t_steps, s_t_expectedresult, s_t_precondition, s_t_testdata, ?, ?, s_t_testmode, s_t_assignto, s_t_author, s_t_reviewer 
		FROM s_testcase WHERE s_t_id = ?";
		$stmt = mysqli_prepare($conn, $insertquery);
		mysqli_stmt_bind_param($stmt, "iiissii", $projectId, $releaseId, implode(",", $activityId), $scenarioId, $scenarioIdstr, $testcaseNum, $testcaseIdstr, $tcid);
		$stmt_result = mysqli_stmt_execute($stmt);

		if ($stmt_result) {
		$flag = 1;
		$testcaseId = mysqli_insert_id($conn);
		if (isset($activityId) && !empty($activityId) && count($activityId) > 0) {
		$dsql = "UPDATE s_testcasefinal SET s_f_activestatus = 'Inactive' WHERE testcaseId = ? AND accountId = ?";
		$dstmt = mysqli_prepare($conn, $dsql);
		mysqli_stmt_bind_param($dstmt, "ii", $testcaseId, $accountId);
		mysqli_stmt_execute($dstmt);

		foreach ($activityId as $value) {
			$chksql = "SELECT * FROM s_testcasefinal WHERE testcaseId = ? AND activityId = ? AND accountId = ?";
			$chkstmt = mysqli_prepare($conn, $chksql);
			mysqli_stmt_bind_param($chkstmt, "iii", $testcaseId, $value, $accountId);
			mysqli_stmt_execute($chkstmt);
			$chkresult = mysqli_stmt_get_result($chkstmt);

			if (mysqli_num_rows($chkresult) <= 0) {
				$msql = "INSERT INTO s_testcasefinal (testcaseId, projectId, releaseId, activityId, s_f_testresult, s_f_actualresult, s_f_executiontime, defectId, s_f_enteredby, accountId, s_f_activestatus) 
						VALUES (?, ?, ?, ?, 'Not Executed', '', NULL, '0', ?, ?, 'Active')";
				$mstmt = mysqli_prepare($conn, $msql);
				mysqli_stmt_bind_param($mstmt, "iiiii", $testcaseId, $projectId, $releaseId, $value, $enteredby, $accountId);
				mysqli_stmt_execute($mstmt);
			} else {
				$finalsql = "UPDATE s_testcasefinal SET s_f_activestatus = 'Active' WHERE testcaseId = ? AND activityId = ? AND accountId = ?";
				$finalstmt = mysqli_prepare($conn, $finalsql);
				mysqli_stmt_bind_param($finalstmt, "iii", $testcaseId, $value, $accountId);
				mysqli_stmt_execute($finalstmt);
			}
		}
		}
		} else {
		$errormsg .= "Error ";
		}
	}


}


	if($flag >0)
	{
		$msgarr["status"] = "Success";
		$msgarr["message"] = "Testcase copied successfully.";
		if($errormsg !=""){
			$msgarr["message"] = "Some testcases copied successfully.";
		}
	}
	else
	{
		$msgarr["status"] = "Error";
		$msgarr["message"] = "Something went wrong. Please try again.";
		if($errormsg !=""){
			$msgarr["message"] = "Testcases copied failed.";
		}
	}

echo json_encode($msgarr);