<?php
include('config.php');
session_start();
 /** this saves the quality status master data */
$enteredby = 0;
$accountId = 0;
 
$msgarr = array();

if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = (isset($_SESSION["accountId"]) ? $_SESSION["accountId"] : 0);
}
if($_SERVER['REQUEST_METHOD'] === 'POST'){

$id = (isset($_POST['qId']) ? $_POST['qId'] : "0");

$isreadonly = (isset($_POST['isreadonly']) ? $_POST['isreadonly'] : "0");
$username = (isset($_POST['username']) ? $_POST['username'] : "");
$password = (isset($_POST['password']) ? $_POST['password'] : "");

if(!empty($id) && $id !="0") {
	// Update query using prepared statements
	$sql = "UPDATE settings SET isreadonly = ? WHERE id = ? AND accountId = ?";
	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "iis", $isreadonly, $id, $accountId);
	
	if(mysqli_stmt_execute($stmt)) {
		$msgarr["status"] = "Success";
		$msgarr["message"] = "Setting saved successfully.";
	}
	else
	{
		$msgarr["status"] = "Error";
		$msgarr["message"] = "Something went wrong. Please try again.";
	}
	mysqli_stmt_close($stmt);

}else{


	// Insert query using prepared statements
	$sql = "INSERT INTO settings(isreadonly, accountId, enteredby) VALUES ( ?, ?, ?)";
	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "iis", $isreadonly, $accountId, $enteredby);
	
	if(mysqli_stmt_execute($stmt)) {
		$msgarr["status"] = "Success";
		$msgarr["message"] = "Setting saved successfully.";
	}
	else
	{
		$msgarr["status"] = "Error";
		$msgarr["message"] = "Something went wrong. Please try again.";
	}
	mysqli_stmt_close($stmt);

}
}
echo json_encode($msgarr);
