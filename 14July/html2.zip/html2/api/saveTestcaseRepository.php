
<?php
include('config.php');
session_start();
 /** this script saves the data into testcase repository */
$enteredby = 0;
$accountId = 0;
$msgarr = array();
$msgarr["status"] = "Error";
$msgarr["message"] = "Something went wrong. Please try again.";

if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
}
$updateRecords = "";$auditlogDesc = "";
if($_SERVER['REQUEST_METHOD'] === 'POST'){


$table = "s_tcrepository";
$steptable = "s_tcrepository_steps";

$tctype = (isset($_POST['repositorytype']) ? mysqli_real_escape_string($conn,$_POST['repositorytype']) : "Banking");
switch ($tctype) {
    case 'Banking':
        $table = "s_tcrepository";
		$steptable = "s_tcrepository_steps";
        break;
    case 'Automative':
        $table = "s_tcrepository1";
		$steptable = "s_tcrepository_steps1";
        break;
    case 'HR':
        $table = "s_tcrepository2";
		$steptable = "s_tcrepository_steps2";
        break;
    case 'Insurance':
        $table = "s_tcrepository3";
		$steptable = "s_tcrepository_steps3";
        break;
    
    default:
        $table = "s_tcrepository";
		$steptable = "s_tcrepository_steps";
        break;
}

$id = (isset($_POST['testcaseDBId'])&& !empty($_POST['testcaseDBId'])  ? $_POST['testcaseDBId'] : "0");
$application = (isset($_POST['application']) && !empty($_POST['application']) ? $_POST['application'] : "0");
$application_change = (isset($_POST['application_change']) && !empty($_POST['application_change']) ? $_POST['application_change'] : "0");
if($application_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "Application";
	}else{
		$auditlogDesc .= ", Application";
	}
	if($updateRecords == ""){
		$updateRecords = "s_t_application = '".$application."'";
	}else{
		$updateRecords .= ", s_t_application = '".$application."'";
	}
}

$activityId = (isset($_POST['activityId']) ? $_POST['activityId'] : array());
$activityId_change = (isset($_POST['activityId_change']) && !empty($_POST['activityId_change']) ? $_POST['activityId_change'] : "0");
if($activityId_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "Activity ID";
	}else{
		$auditlogDesc .= ", Activity ID";
	}
	if($updateRecords == ""){
		$updateRecords = "s_t_activityIds = '".(implode(",", $activityId))."'";
	}else{
		$updateRecords .= ", s_t_activityIds = '".(implode(",", $activityId))."'";
	}
}

$module = (isset($_POST['module']) ? mysqli_real_escape_string($conn,$_POST['module']) : "");
$module_change = (isset($_POST['module_change']) && !empty($_POST['module_change']) ? $_POST['module_change'] : "0");
if($module_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "Module";
	}else{
		$auditlogDesc .= ", Module";
	}
	if($updateRecords == ""){
		$updateRecords = "s_t_module = '".$module."'";
	}else{
		$updateRecords .= ", s_t_module = '".$module."'";
	}
}

$submodule = (isset($_POST['submodule']) ? mysqli_real_escape_string($conn,$_POST['submodule']) : "");
$submodule_change = (isset($_POST['submodule_change']) && !empty($_POST['submodule_change']) ? $_POST['submodule_change'] : "0");
if($submodule_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "Submodule";
	}else{
		$auditlogDesc .= ", Submodule";
	}
	if($updateRecords == ""){
		$updateRecords = "s_t_submodule = '".$submodule."'";
	}else{
		$updateRecords .= ", s_t_submodule = '".$submodule."'";
	}
}


$testscenariodesc = (isset($_POST['testscenariodesc']) ? mysqli_real_escape_string($conn,$_POST['testscenariodesc']) : "");
$testscenariodesc_change = (isset($_POST['testscenariodesc_change']) && !empty($_POST['testscenariodesc_change']) ? $_POST['testscenariodesc_change'] : "0");
if($testscenariodesc_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "Test Scenario Description";
	}else{
		$auditlogDesc .= ", Test Scenario Description";
	}
	if($updateRecords == ""){
		$updateRecords = "s_t_testscenariodesc = '".$testscenariodesc."'";
	}else{
		$updateRecords .= ", s_t_testscenariodesc = '".$testscenariodesc."'";
	}
}

$testcasedesc = (isset($_POST['testcasedesc']) ? mysqli_real_escape_string($conn,$_POST['testcasedesc']) : "");
$testcasedesc_change = (isset($_POST['testcasedesc_change']) && !empty($_POST['testcasedesc_change']) ? $_POST['testcasedesc_change'] : "0");
if($testcasedesc_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "Test Case Description";
	}else{
		$auditlogDesc .= ", Test Case Description";
	}
	if($updateRecords == ""){
		$updateRecords = "s_t_testcasedesc = '".$testcasedesc."'";
	}else{
		$updateRecords .= ", s_t_testcasedesc = '".$testcasedesc."'";
	}
}

$steps = (isset($_POST['steps']) ? mysqli_real_escape_string($conn,$_POST['steps']) : "");
$steps_change = (isset($_POST['steps_change']) && !empty($_POST['steps_change']) ? $_POST['steps_change'] : "0");
if($steps_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "Steps";
	}else{
		$auditlogDesc .= ", Steps";
	}
	if($updateRecords == ""){
		$updateRecords = "s_t_steps = '".$steps."'";
	}else{
		$updateRecords .= ", s_t_steps = '".$steps."'";
	}
}

$expectedresult = (isset($_POST['expectedresult']) ? mysqli_real_escape_string($conn,$_POST['expectedresult']) : "");
$expectedresult_change = (isset($_POST['expectedresult_change']) && !empty($_POST['expectedresult_change']) ? $_POST['expectedresult_change'] : "0");
if($expectedresult_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "Expected Result";
	}else{
		$auditlogDesc .= ", Expected Result";
	}
	if($updateRecords == ""){
		$updateRecords = "s_t_expectedresult = '".$expectedresult."'";
	}else{
		$updateRecords .= ", s_t_expectedresult = '".$expectedresult."'";
	}
}

$precondition = (isset($_POST['precondition']) ? mysqli_real_escape_string($conn,$_POST['precondition']) : "");
$precondition_change = (isset($_POST['precondition_change']) && !empty($_POST['precondition_change']) ? $_POST['precondition_change'] : "0");
if($precondition_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "Pre-Condition";
	}else{
		$auditlogDesc .= ", Pre-Condition";
	}
	if($updateRecords == ""){
		$updateRecords = "s_t_precondition = '".$precondition."'";
	}else{
		$updateRecords .= ", s_t_precondition = '".$precondition."'";
	}
}

$testdata = (isset($_POST['testdata'])? mysqli_real_escape_string($conn,$_POST['testdata']) : "");
$testdata_change = (isset($_POST['testdata_change']) && !empty($_POST['testdata_change']) ? $_POST['testdata_change'] : "0");
if($testdata_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "Test Data";
	}else{
		$auditlogDesc .= ", Test Data";
	}
	if($updateRecords == ""){
		$updateRecords = "s_t_testdata = '".$testdata."'";
	}else{
		$updateRecords .= ", s_t_testdata = '".$testdata."'";
	}
}

$testmode = (isset($_POST['testmode']) ? $_POST['testmode'] : "");
$testmode_change = (isset($_POST['testmode_change']) && !empty($_POST['testmode_change']) ? $_POST['testmode_change'] : "0");
if($testmode_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "Test mode";
	}else{
		$auditlogDesc .= ", Test mode";
	}
	if($updateRecords == ""){
		$updateRecords = "s_t_testmode = '".$testmode."'";
	}else{
		$updateRecords .= ", s_t_testmode = '".$testmode."'";
	}
}

$comment = (isset($_POST['comment']) ? mysqli_real_escape_string($conn,$_POST['comment']) : "");
$comment_change = (isset($_POST['comment_change']) && !empty($_POST['comment_change']) ? $_POST['comment_change'] : "0");
if($comment_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "Comment";
	}else{
		$auditlogDesc .= ", Comment";
	}
	if($updateRecords == ""){
		$updateRecords = "s_t_comment = '".$comment."'";
	}else{
		$updateRecords .= ", s_t_comment = '".$comment."'";
	}
}


$scenarioId = (isset($_POST['scenarioId'])&& !empty($_POST['scenarioId'])  ? $_POST['scenarioId'] : "0");
$scenarioId_change = (isset($_POST['scenarioId_change']) && !empty($_POST['scenarioId_change']) ? $_POST['scenarioId_change'] : "0");

$scenarioIdstr = (isset($_POST['scenarioIdstr']) ? $_POST['scenarioIdstr'] : "");
if($scenarioId_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "Testcase Scenario";
	}else{
		$auditlogDesc .= ", Testcase Scenario";
	}

	if($updateRecords == ""){
		$updateRecords = "s_d_tempscenarioId = '".$scenarioId."', s_t_testscenarionum = '".$scenarioIdstr."'";
	}else{
		$updateRecords .= ", s_d_tempscenarioId = '".$scenarioId."', s_t_testscenarionum = '".$scenarioIdstr."'";
	}
}

$testcaseNum = 0;
$testcaseIdstr = "";

if($scenarioId_change == "1"){

	$testnumsqldata = mysqli_query($conn,"SELECT * from ".$table." where s_d_tempscenarioId = '".$scenarioId."' and accountId='".$accountId."'   order by s_t_tempid desc limit 1");
	if(mysqli_num_rows($testnumsqldata)>0){

		while($rdata = mysqli_fetch_assoc($testnumsqldata)){
			$testcaseNum = (int)$rdata['s_t_tempid'] +1;
		}
	}else{
		$testcaseNum = 1;
	}
	$testcaseIdstr = "TC-$testcaseNum";
	if($auditlogDesc == ""){
		$auditlogDesc = "Testcase ID";
	}else{
		$auditlogDesc .= ", Testcase ID";
	}

	if($updateRecords == ""){
		$updateRecords = "s_t_tempid = '".$testcaseNum."', s_t_testcasenum = '".$testcaseIdstr."'";
	}else{
		$updateRecords .= ", s_t_tempid = '".$testcaseNum."', s_t_testcasenum = '".$testcaseIdstr."'";
	}
}


	if(!empty($id) && $id !="0") {

		if($updateRecords !=""){
			$sql = "UPDATE ".$table." SET  $updateRecords where s_t_id = ?  and accountId=? ";
			$stmt = mysqli_prepare($conn, $sql);
			mysqli_stmt_bind_param($stmt, "si", $id, $accountId);
			$result = mysqli_stmt_execute($stmt);

			if((isset($result) && $result)){
				$newFlag = 0;
				$msgarr["status"] = "Success";
				$msgarr["message"] = "Testcase updated successfully.";
				$testcaseId = $id;
				

				$step_descarr =isset($_POST['step_desc']) && !empty($_POST['step_desc']) ? $_POST['step_desc']: array();
				$step_resultarr =isset($_POST['step_expectedresult']) && !empty($_POST['step_expectedresult']) ? $_POST['step_expectedresult']: array();
				$step_idarr =isset($_POST['step_id']) && !empty($_POST['step_id']) ? $_POST['step_id']: array();

				if(!empty($step_descarr) || !empty($step_resultarr)){
					$len = count($step_descarr);
					for($i=0; $i<$len; $i++){
						$s_id = mysqli_real_escape_string($conn,$step_idarr[$i]);
						$s_desc = mysqli_real_escape_string($conn,$step_descarr[$i]);
						$s_result = mysqli_real_escape_string($conn,$step_resultarr[$i]);

						if(!empty($s_id) && $s_id !="0"){	
							$stepsql = "UPDATE $steptable SET `s_tss_steps` = ?, `s_tss_expectedresult` = ? WHERE s_tss_id = ?";
							$step_stmt = mysqli_prepare($conn, $stepsql);
							mysqli_stmt_bind_param($step_stmt, "ssi", $s_desc, $s_result, $s_id);
							mysqli_stmt_execute($step_stmt);
							mysqli_stmt_close($stmt);
						}else{
							if(!empty($s_desc) || !empty($s_result)){
								$stepsql = "INSERT INTO $steptable (tcrepositoryId, `s_tss_steps`, `s_tss_expectedresult`, `accountId`, `s_tss_enteredby`) VALUES (?, ?, ?, ?, ?)";
								$step_stmt = mysqli_prepare($conn, $stepsql);
								mysqli_stmt_bind_param($step_stmt, "issii", $testcaseId, $s_desc, $s_result, $accountId, $enteredby);
								mysqli_stmt_execute($step_stmt);
								mysqli_stmt_close($stmt);
							}
	
						}
					}

				}
				if($auditlogDesc != ""){
					
					$auditlogSql = "INSERT INTO s_auditlogs (`s_a_desc`, `s_a_module`, `s_a_enteredby`, `accountId`, `s_a_recordId`, `s_a_recordnum`) VALUES (?, 'Testcase', ?, ?, ?, '')";
					$audit_stmt = mysqli_prepare($conn, $auditlogSql);
					mysqli_stmt_bind_param($audit_stmt, "siis", $auditlogDesc, $enteredby, $accountId, $id);
					mysqli_stmt_execute($audit_stmt);

				}
			}else{
				$msgarr["status"] = "Error";
				$msgarr["message"] = "Something went wrong. Please try again.";
			}
			mysqli_stmt_close($stmt);
		}else{
			$testcaseId = $id;
			$step_descarr =isset($_POST['step_desc']) && !empty($_POST['step_desc']) ? $_POST['step_desc']: array();
			$step_resultarr =isset($_POST['step_expectedresult']) && !empty($_POST['step_expectedresult']) ? $_POST['step_expectedresult']: array();
			$step_idarr =isset($_POST['step_id']) && !empty($_POST['step_id']) ? $_POST['step_id']: array();

			if(!empty($step_descarr) || !empty($step_resultarr)){
				$len = count($step_descarr);
				for($i=0; $i<$len; $i++){
					$s_id = mysqli_real_escape_string($conn,$step_idarr[$i]);
					$s_desc = mysqli_real_escape_string($conn,$step_descarr[$i]);
					$s_result = mysqli_real_escape_string($conn,$step_resultarr[$i]);

					if(!empty($s_id) && $s_id !="0"){	
						$stepsql = "UPDATE $steptable SET `s_tss_steps` = ?, `s_tss_expectedresult` = ? WHERE s_tss_id = ?";
						$step_stmt = mysqli_prepare($conn, $stepsql);
						mysqli_stmt_bind_param($step_stmt, "ssi", $s_desc, $s_result, $s_id);
						mysqli_stmt_execute($step_stmt);
						mysqli_stmt_close($stmt);
					}else{
						if(!empty($s_desc) || !empty($s_result)){
							$stepsql = "INSERT INTO $steptable (tcrepositoryId, `s_tss_steps`, `s_tss_expectedresult`, `accountId`, `s_tss_enteredby`) VALUES (?, ?, ?, ?, ?)";
							$step_stmt = mysqli_prepare($conn, $stepsql);
							mysqli_stmt_bind_param($step_stmt, "issii", $testcaseId, $s_desc, $s_result, $accountId, $enteredby);
							mysqli_stmt_execute($step_stmt);
							mysqli_stmt_close($stmt);
						}

					}
				}

			}
				
			$msgarr["status"] = "Success";
			$msgarr["message"] = "Testcase updated successfully.";
		}
	}
}
echo json_encode($msgarr);