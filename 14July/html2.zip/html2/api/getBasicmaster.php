<?php
header('Access-Control-Allow-Origin: *');
include('config.php');

   /** This PHP script retrieves the master table data from a database. 
 * It formats the data and returns it in JSON format. */

$enteredby = (isset($_POST["enteredby"]) && !empty($_POST["enteredby"]) ? $_POST["enteredby"] : 0);
$accountId = (isset($_POST["accountId"]) && !empty($_POST["accountId"]) ? $_POST["accountId"] : 0);
$userempid = (isset($_POST["userempid"]) && !empty($_POST["userempid"])  ? $_POST["userempid"] : 0);


$id = (isset($_POST['id']) ? intval($_POST['id']) : "0");
$formtype = isset($_POST['formtype']) ? $_POST['formtype'] :"";
$projarr = array();

if($formtype == "Activity"){
	$sql="SELECT * from s_activitymaster where s_a_id = ? and accountId = ? ";
	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "ii",$id,$accountId);
	mysqli_stmt_execute($stmt);
	$result = mysqli_stmt_get_result($stmt);

	while($data = mysqli_fetch_assoc($result)){
		$projarr = array("id"=>$data['s_a_id'],
			"activityname"=>$data['s_a_name'],
			"activitycode"=>$data['s_a_code'],
			"activitytype"=>$data['s_a_type']
		);
	}
}else if($formtype == "Client"){
	$sql = "SELECT * from s_client where s_c_id = ? and accountId = ? ";
	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "ii",$id,$accountId);
	mysqli_stmt_execute($stmt);
	$result = mysqli_stmt_get_result($stmt);

	while($data = mysqli_fetch_assoc($result)){
		$projarr = array("id"=>$data['s_c_id'],
			"clientname"=>$data['s_c_name'],
			"activestatus"=>$data['s_c_activestatus']
		);
	}
}else if($formtype == "DefectStatus"){
	$sql = "SELECT * from s_defectstatusmaster where s_ds_id = ? and accountId = ? ";
	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "ii",$id,$accountId);
	mysqli_stmt_execute($stmt);
	$result = mysqli_stmt_get_result($stmt);

	while($data = mysqli_fetch_assoc($result)){
		$projarr = array("id"=>$data['s_ds_id'],
			"defectstatusname"=>$data['s_ds_name'],
			"activestatus"=>$data['s_ds_activestatus']
		);
	}
}else if($formtype == "DefectType"){
	$sql = "SELECT * from s_defecttypemaster where s_dt_id == ? and accountId = ? ";
	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "ii",$id,$accountId);
	mysqli_stmt_execute($stmt);
	$result = mysqli_stmt_get_result($stmt);

	while($data = mysqli_fetch_assoc($result)){
		$projarr = array("id"=>$data['s_dt_id'],
			"defecttypename"=>$data['s_dt_name'],
			"activestatus"=>$data['s_dt_activestatus']
		);
	}
}else if($formtype == "TCCategory"){
	$sql = "SELECT * from s_tccategorymaster where s_cat_id = ? and accountId = ? ";
	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "ii",$id,$accountId);
	mysqli_stmt_execute($stmt);
	$result = mysqli_stmt_get_result($stmt);

	while($data = mysqli_fetch_assoc($result)){
		$projarr = array("id"=>$data['s_cat_id'],
			"categoryname"=>$data['s_cat_name'],
			"activestatus"=>$data['s_cat_activestatus']
		);
	}
}else if($formtype == "RuleModule"){
	$sql = "SELECT * from s_rule_module where s_rm_id = ?  ";
	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "i",$id);
	mysqli_stmt_execute($stmt);
	$result = mysqli_stmt_get_result($stmt);

	while($data = mysqli_fetch_assoc($result)){
		// $projarr['data'][] = array("projectname"=>$data['projectname'],'client'=>$data['client'],'description'=>$data['description'],'id'=>$data['id']);
		$projarr = array("id"=>$data['s_rm_id'],
			"modulename"=>$data['s_rm_name'],
			"activestatus"=>$data['s_rm_activestatus']
		);
	}
}else if($formtype == "BasicRules"){
	$sql = "SELECT * from s_basic_rules where s_br_id = ?  ";
	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "i",$id);
	mysqli_stmt_execute($stmt);
	$result = mysqli_stmt_get_result($stmt);

	while($data = mysqli_fetch_assoc($result)){
		$projarr = array("id"=>$data['s_br_id'],
			"rulename"=>$data['s_br_name'],
			"moduleId"=>$data['moduleId'],
			"activestatus"=>$data['s_br_activestatus']
		);
	}
}else if($formtype == "Role"){
	$sql = "SELECT * from s_role where s_role_id = ? and accountId = ? ";
	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "ii",$id,$accountId);
	mysqli_stmt_execute($stmt);
	$result = mysqli_stmt_get_result($stmt);

	while($data = mysqli_fetch_assoc($result)){
		$projarr = array("id"=>$data['s_role_id'],
			"rolename"=>$data['s_role_name'],
			"activestatus"=>$data['s_role_activestatus']
		);
	}
}else if($formtype == "Holiday"){
	$sql = "SELECT * from s_holiday_master where s_h_id = ? and accountId = ? ";
	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "ii",$id,$accountId);
	mysqli_stmt_execute($stmt);
	$result = mysqli_stmt_get_result($stmt);

	while($data = mysqli_fetch_assoc($result)){
	$hdate = (isset($data['s_h_date']) && ($data['s_h_date'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_h_date'])) : "");
		$projarr = array("id"=>$data['s_h_id'],
			"holidayname"=>$data['s_h_name'],
			"holidaydate"=>$hdate,
			"activestatus"=>$data['s_h_activestatus']
		);
	}
}else if($formtype == "Chart"){
	$sql = "SELECT * from s_chartsetting where s_c_id = ? and accountId = ? ";
	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "ii",$id,$accountId);
	mysqli_stmt_execute($stmt);
	$result = mysqli_stmt_get_result($stmt);

	while($data = mysqli_fetch_assoc($result)){

		$projarr = array("id"=>$data['s_c_id'],
			"charttitle"=>$data['s_c_title'],
			"chartsubtitle"=>$data['s_c_subtitle'],
			"charttype"=>$data['s_c_charttype'],
			"activestatus"=>$data['s_c_activestatus'],
			"module"=>$data['s_c_tablename'],
			"caltype"=>$data['s_c_type'],
			"xAxis"=>$data['s_c_xaxis'],
			"yAxis"=>$data['s_c_yaxis']
		);
	}
}else if($formtype == "ProjetEmailSetting"){
	$sql = "SELECT * from s_projemailsetting where s_projes_id = ? and accountId = ? ";
	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "ii",$id,$accountId);
	mysqli_stmt_execute($stmt);
	$result = mysqli_stmt_get_result($stmt);

	while($data = mysqli_fetch_assoc($result)){
		$projarr = array("id"=>$data['s_projes_id'],
			"projectId"=>$data['projectId'],
			"subject"=>$data['s_projes_subject'],
			"hostname"=>$data['s_projes_host'],
			"portno"=>$data['s_projes_port'],
			"fromname"=>$data['s_projes_fromname'],
			"username"=>$data['s_projes_username'],
			"password"=>$data['s_projes_password'],
			"receiver"=>$data['s_projes_receiver'],
			"scheduletime"=>$data['s_projes_scheduletime'],
			"cc"=>$data['s_projes_cc'],
			"bcc"=>$data['s_projes_bcc'],
		);
	}
}

echo json_encode($projarr);
?>
