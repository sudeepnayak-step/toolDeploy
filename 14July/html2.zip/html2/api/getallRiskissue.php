<?php
include('config.php');
session_start();
 
$enteredby = 0;$accountId=0;$userempid = 0;
/**This script retrieves risk/issue data from a database based on a specific activityId and session information. 
 * It formats the data and returns it in JSON format. */ 

if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
}
if(isset($_SESSION["usertype"]) && $_SESSION["usertype"] == "Employee"){
	if(isset($_SESSION["userempid"])){
    $userempid = $_SESSION["userempid"];
}
}

$activityId = (isset($_GET['activityId'])  && !empty($_GET['activityId'])? $_GET['activityId'] : "0");

$sql = "SELECT * from s_riskissue
	WHERE accountId = ? and s_r_activityId = ?
	order by s_r_id desc";
	 
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "is", $accountId,$activityId);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$projarr['data'] = array();
while($data = mysqli_fetch_assoc($result)){

	$raiseddate = (isset($data['s_r_raiseddate']) && ($data['s_r_raiseddate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_r_raiseddate'])) : "");

	$closuredate = (isset($data['s_r_closuredate']) && ($data['s_r_closuredate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_r_closuredate'])) : "");
	$projarr['data'][] = array($data['s_r_id'],$raiseddate,$data['s_r_type'],$data['s_r_desc'],$data['s_r_actionableby'],$data['s_r_plan'],	
	$closuredate,"0",$data['s_r_status'],$data['s_r_probability'],$data['s_r_impact'],$data['s_r_id']);
}

echo json_encode($projarr);
?>