<?php
include('config.php');
session_start();
 
$enteredby = 0;$accountId = 0;$userempid = 0;
 
/**This PHP script retrieves and filters release data from a database based on user inputs and session information. 
 * It also calculates thresholds and schedules based on planned and actual dates. */
$msgarr = array();
if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
    $userempid = $_SESSION["userempid"];
}

$where = "";

$projectId = (isset($_POST['projectId']) && !empty($_POST['projectId']) && !is_null($_POST['projectId']) ? $_POST['projectId'] : "");
$status = (isset($_POST['status']) && !empty($_POST['status']) && !is_null($_POST['status'])? $_POST['status'] : "");
$releaseId = (isset($_POST['releaseId']) && !empty($_POST['releaseId']) && !is_null($_POST['releaseId'])? $_POST['releaseId'] : "");
$planstart = (isset($_POST['planstart']) && !empty($_POST['planstart']) && !is_null($_POST['planstart'])? date('Y-m-d', strtotime(str_replace('/', '-', $_POST['planstart']))) : '');
$planend = (isset($_POST['planend']) && !empty($_POST['planend']) && !is_null($_POST['planend'])? date('Y-m-d', strtotime(str_replace('/', '-', $_POST['planend']))) : '');

if($projectId !=""){
		$where .= " and r.projectId in ($projectId) ";
}


if($status !=""){
	$statusarr = explode(",", $status);
	$status = "'" . implode ( "', '", $statusarr ) . "'";
	$where .= " and r.s_r_status in ($status) ";
}
if($releaseId !=""){
		$where .= " and r.s_r_id in ($releaseId) ";
}

if($planstart !=""){
		$where .= " and r.s_r_planstartdate >= '$planstart' ";
}

if($planend !=""){
		$where .= " and r.s_r_planenddate <= '$planend' ";
}

if(isset($_SESSION["usertype"]) && $_SESSION["usertype"] != "Admin"){
	$where .= " and r.projectId in (select s_p_id from s_project where s_p_id in (select projectId from s_project_members where employeeId = '".$userempid."'  and accountId = '".$accountId."') or s_p_enteredby = '".$enteredby."' and accountId = '".$accountId."')";
}
$sql = "SELECT r.*,IFNULL(p.s_p_name,'') as projectname,
		IFNULL(p.clientId,'0') as projectclient from s_release r 
		join s_project p on p.s_p_id = r.projectId WHERE r.accountId = ? $where  order by r.s_r_id asc";


$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $accountId);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$projarr['data'] = array();
while($data = mysqli_fetch_assoc($result)){
	$projectclient = $mdata['projectclient'];
	$planstartdate = (isset($data['s_r_planstartdate']) && ($data['s_r_planstartdate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_r_planstartdate'])) : "");

	$planenddate = (isset($data['s_r_planenddate']) && ($data['s_r_planenddate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_r_planenddate'])) : "");

	$revisedstartdate = (isset($data['s_r_revisedstartdate']) && ($data['s_r_revisedstartdate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_r_revisedstartdate'])) : "");

	$revisedenddate = (isset($data['s_r_revisedenddate']) && ($data['s_r_revisedenddate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_r_revisedenddate'])) : "");

	$actualstartdate = (isset($data['s_r_actualstartdate']) && ($data['s_r_actualstartdate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_r_actualstartdate'])) : "");

	$actualenddate = (isset($data['s_r_actualenddate']) && ($data['s_r_actualenddate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_r_actualenddate'])) : "");

	$planthreshold = 0;$actualthreshold = 0;$schedule = "G";
	$Tempstartdate = ($revisedenddate == "" ? $planenddate : $revisedenddate);
		
	$planFormatenddate =  ($revisedenddate == "" ? $planenddate : $revisedenddate);
	
	$Tempenddate = date('d/m/Y');
	$tempPlanNumerator = ($Tempstartdate !="" && $Tempenddate != "") ? GetDateDuration($projectclient,$Tempstartdate,$Tempenddate) : 0;

	$Tempstartdate = $actualstartdate;//date('Y-m-d',strtotime($actualstartdate));
	$Tempenddate = $actualenddate;//date('Y-m-d',strtotime($actualenddate));
	$tempPlanDenomentor = ($Tempstartdate !="" && $Tempenddate != "") ? GetDateDuration($projectclient,$Tempstartdate,$Tempenddate): 0;


	$Tempstartdate = $actualenddate; //date('Y-m-d',strtotime($actualenddate));
	$Tempenddate = date('d/m/Y');
	$tempActualNumerator = ($Tempstartdate !="" && $Tempenddate != "") ? GetDateDuration($projectclient,$Tempstartdate,$Tempenddate): 0;

	$planthreshold = ($tempPlanDenomentor >0 ) ? $tempPlanNumerator/$tempPlanDenomentor *100 : 0;

	$actualthreshold = ($tempPlanDenomentor >0 ) ? $tempActualNumerator/$tempPlanDenomentor *100 : 0;

	$threshold = ($planthreshold > $actualthreshold ? ($planthreshold - $actualthreshold) : 0);

	if($planFormatenddate <= date("d/m/Y") && $threshold <100){
		$schedule = "R";// default red
	}else{
		// calculate threshold
		$ragthresholdsql = "SELECT *
				FROM s_ragthreshold where accountId='".$accountId."' order by s_rt_id desc limit 1";
		$ragthresholdquery = mysqli_query($conn,$ragthresholdsql);
		while($ragTdata =mysqli_fetch_assoc($ragthresholdquery)){
		// if($ragTdata){
			$amber = $ragTdata['s_rt_amber'];
			$red = $ragTdata['s_rt_red'];
			if($threshold <= $amber){
				if($threshold <=$red){
					$schedule = "R";// Red
				}else{
					$schedule = "A";// amber
				}
			}else if($threshold <=$red){
				if($threshold <=$amber){
					$schedule = "A";// amber
				}else{
					$schedule = "R";// Red
				}
			}
		}
	}

	$projarr['data'][] = array($data['s_r_id'],$data['s_r_name'],$data['s_r_releaseId'],$data['projectname'],$schedule,$data['s_r_desc'],$data['s_r_status'],
		
		(!empty($planstartdate) ? $planstartdate : "-"),
		(!empty($planenddate) ? $planenddate : "-"),
		(!empty($revisedstartdate) ? $revisedstartdate : "-"),
		(!empty($revisedenddate) ? $revisedenddate : "-"),
		(!empty($actualstartdate) ? $actualstartdate : "-"),
		(!empty($actualenddate) ? $actualenddate : "-"),
		$data['s_r_activestatus'],$data['s_r_id']);
}

echo json_encode($projarr);
?>