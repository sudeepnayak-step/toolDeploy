<?php
include('config.php');
session_start();
 /** this script saves the defect status */
$enteredby = 0;$accountId = 0;
 
$msgarr = array();

if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
}
if($_SERVER['REQUEST_METHOD'] === 'POST'){

	$id = (isset($_POST['defectstatusId']) ? intval($_POST['defectstatusId']) : 0);
	$defectstatusname = (isset($_POST['defectstatusname']) ? mysqli_real_escape_string($conn,$_POST['defectstatusname']) : "");

	if (!empty($id) && $id != "0") {
		// Update query using prepared statements
		$sql = "UPDATE s_defectstatusmaster SET s_ds_name = ? WHERE s_ds_id = ? AND accountId = ?";
		$stmt = mysqli_prepare($conn, $sql);
		mysqli_stmt_bind_param($stmt, "sii", $defectstatusname, $id, $accountId);

		if (mysqli_stmt_execute($stmt)) {
			$msgarr["status"] = "Success";
			$msgarr["message"] = "Defect status updated successfully.";
		} else {
			$msgarr["status"] = "Error";
			$msgarr["message"] = "Something went wrong. Please try again.";
		}

		mysqli_stmt_close($stmt);
	} else {
		// Insert query using prepared statements
		$sql = "INSERT INTO s_defectstatusmaster (s_ds_name, s_ds_enteredby, accountId) VALUES (?, ?, ?)";
		$stmt = mysqli_prepare($conn, $sql);
		mysqli_stmt_bind_param($stmt, "sii", $defectstatusname, $enteredby, $accountId);

		if (mysqli_stmt_execute($stmt)) {
			$msgarr["status"] = "Success";
			$msgarr["message"] = "Defect status added successfully.";
		} else {
			$msgarr["status"] = "Error";
			$msgarr["message"] = "Something went wrong. Please try again.";
		}

		mysqli_stmt_close($stmt);
	}
}

echo json_encode($msgarr);