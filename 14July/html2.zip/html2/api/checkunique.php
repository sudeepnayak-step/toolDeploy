<?php
include('config.php');
session_start();
 
$enteredby = 0;$accountId = 0;
 
/*** 
 * script checks for uniqueness of a value in a database table based on a given column and value.
 */
if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
}
$id = (isset($_POST['id']) ? $_POST['id'] : "0");
$col = (isset($_POST['col']) ? $_POST['col'] : "");
$val = (isset($_POST['val']) ? $_POST['val'] : "");
$colname = "";
switch ($col) {
	case 'projectname':
		$colname = "s_p_name";
		break;
	case 'projectcode':
		$colname = "s_p_code";
		break;
	case 'releasename':
		$colname = "s_r_name";
		break;	
	case 'activityname':
		$colname = "s_a_name";
		break;
	case 'activitycode':
		$colname = "s_a_code";
		break;
	case 'clientname':
		$colname = "s_c_name";
		break;
	case 'defecttypename':
		$colname = "s_dt_name";
		break;
	case 'categoryname':
		$colname = "s_cat_name";
		break;
	case 'defectstatusname':
		$colname = "s_ds_name";
		break;
	case 'rolename':
		$colname = "s_role_name";
		break;
	case 'emailid':
		$colname = "s_e_emailid";
		break;
	default:
		# code...
		break;
}
if(in_array($col, array("projectname","projectcode"))){
	$stmt = $conn->prepare("SELECT * from s_project where $colname = ? and s_p_id != ? AND accountId = ?");
    $stmt->bind_param("sii", $val, $id, $accountId);
    $stmt->execute();
    $result = $stmt->get_result();
    $numrows = $result->num_rows;

    if ($numrows > 0) {
        echo false;
    } else {
        echo true;
    }	
}else if(in_array($col, array("releasename"))){
	$stmt = $conn->prepare("SELECT * from s_release where $colname = ? and s_r_id != ? AND accountId = ?");
    $stmt->bind_param("sii", $val, $id, $accountId);
    $stmt->execute();
    $result = $stmt->get_result();
    $numrows = $result->num_rows;

    if ($numrows > 0) {
        echo false;
    } else {
        echo true;
    }	
}else if(in_array($col, array("activityname","activitycode"))){
	$stmt = $conn->prepare("SELECT * from s_activitymaster where $colname = ? and s_a_id != ? AND accountId = ?");
    $stmt->bind_param("sii", $val, $id, $accountId);
    $stmt->execute();
    $result = $stmt->get_result();
    $numrows = $result->num_rows;

    if ($numrows > 0) {
        echo false;
    } else {
        echo true;
    }	
}else if(in_array($col, array("clientname"))){
	$stmt = $conn->prepare("SELECT * from s_client where $colname = ? and s_c_id != ? AND accountId = ?");
    $stmt->bind_param("sii", $val, $id, $accountId);
    $stmt->execute();
    $result = $stmt->get_result();
    $numrows = $result->num_rows;

    if ($numrows > 0) {
        echo false;
    } else {
        echo true;
    }	
}else if(in_array($col, array("categoryname"))){
	$stmt = $conn->prepare("SELECT * from s_tccategorymaster where $colname = ? and s_cat_id != ? AND accountId = ?");
    $stmt->bind_param("sii", $val, $id, $accountId);
    $stmt->execute();
    $result = $stmt->get_result();
    $numrows = $result->num_rows;

    if ($numrows > 0) {
        echo false;
    } else {
        echo true;
    }	
}else if(in_array($col, array("defecttypename"))){
	$stmt = $conn->prepare("SELECT * from s_defecttypemaster where $colname = ? and s_dt_id != ? AND accountId = ?");
    $stmt->bind_param("sii", $val, $id, $accountId);
    $stmt->execute();
    $result = $stmt->get_result();
    $numrows = $result->num_rows;

    if ($numrows > 0) {
        echo false;
    } else {
        echo true;
    }		
}else if(in_array($col, array("defectstatusname"))){
	$stmt = $conn->prepare("SELECT * from s_defectstatusmaster where $colname = ? and s_ds_id != ? AND accountId = ?");
    $stmt->bind_param("sii", $val, $id, $accountId);
    $stmt->execute();
    $result = $stmt->get_result();
    $numrows = $result->num_rows;

    if ($numrows > 0) {
        echo false;
    } else {
        echo true;
    }	
}else if(in_array($col, array("rolename"))){
	$stmt = $conn->prepare("SELECT * from s_role where $colname = ? and s_role_id != ? AND accountId = ?");
    $stmt->bind_param("sii", $val, $id, $accountId);
    $stmt->execute();
    $result = $stmt->get_result();
    $numrows = $result->num_rows;

    if ($numrows > 0) {
        echo false;
    } else {
        echo true;
    }		
}else if(in_array($col, array("emailid"))){
	$stmt = $conn->prepare("SELECT * from s_employees where $colname = ? and s_e_id != ? AND accountId = ?");
    $stmt->bind_param("sii", $val, $id, $accountId);
    $stmt->execute();
    $result = $stmt->get_result();
    $numrows = $result->num_rows;

    if ($numrows > 0) {
        echo false;
    } else {
        echo true;
    }	
}
?>