<?php
header('Access-Control-Allow-Origin: *');
include('config.php');
/** this script saves the testcase execution result */
$body = file_get_contents('php://input');
$postobject = json_decode($body,true);
 
$accountId = 0;
 
$msgarr = array();

$msgarr["status"] = "Error";
$msgarr["message"] = "Something went wrong. Please try again.";
if($_SERVER['REQUEST_METHOD'] === 'POST'){

$id = (isset($postobject['id']) ? $postobject['id'] : "0");
$iteration = (isset($postobject['iteration']) ? $postobject['iteration'] : "0");
$steps = isset($postobject['steps']) && !empty($postobject['steps']) ? $postobject['steps']: array();

// Fetch execution data using prepared statements
$executionQuery = "SELECT e.*, ts.activityId 
FROM s_testexecution e 
INNER JOIN s_testsuite ts ON ts.s_ts_id = e.testsuiteId 
WHERE e.s_st_id = ? 
ORDER BY e.s_st_id DESC 
LIMIT 1";
$stmt = mysqli_prepare($conn, $executionQuery);
mysqli_stmt_bind_param($stmt, "s", $id);
mysqli_stmt_execute($stmt);
$executionResult = mysqli_stmt_get_result($stmt);

$pass = 0;
$fail = 0;
$inprogress = 0;
$block = 0;
$na = 0;
while($edata = mysqli_fetch_assoc($executionResult)){

	$accountId = $edata['accountId'];
	$testexecutionId = $edata['s_st_id'];
	$activityId = $edata['activityId'];

	// Fetch step execution data using prepared statements
	$stepsQuery = "SELECT e.*, 
	IFNULL(s_tss_num, '') as step_num, 
	IFNULL(s_tss_steps, '') as steps, 
	IFNULL(s_tss_expectedresult, '') as expectedresult 
	FROM s_tcstep_execution e 
	LEFT JOIN s_testcase_steps ON s_testcase_steps.s_tss_id = e.stepId 
	WHERE e.s_se_executionId = ? 
	AND e.accountId = ? 
	ORDER BY e.s_se_id ASC";
	$stepstmt = mysqli_prepare($conn, $stepsQuery);
	mysqli_stmt_bind_param($stepstmt, "si", $testexecutionId, $accountId);
	mysqli_stmt_execute($stepstmt);
	$stepsResult = mysqli_stmt_get_result($stepstmt);


	while($sdata = mysqli_fetch_assoc($stepsResult)){
		$step_num = $sdata['step_num'];
		$stepexecutionId = $sdata['s_se_id'];

		$actualresult = $sdata['s_se_actualresult'];
		$testresult = $sdata['s_se_testresult'];
		if(isset($steps) && isset($steps[$step_num]) && !empty($steps[$step_num])){
			$stepsobj = $steps[$step_num];

			$actualresult = (isset($stepsobj['actualresult']) ? $stepsobj['actualresult'] : $sdata['s_se_actualresult']);
			$testresult = (isset($stepsobj['testresult']) ? $stepsobj['testresult'] : $sdata['s_se_testresult']);


			// Update step execution using prepared statements
			$updateStepQuery = "UPDATE s_tcstep_execution 
			SET s_se_testresult = ?, s_se_actualresult = ? 
			WHERE s_se_id = ?";
			$updatestepstmt = mysqli_prepare($conn, $updateStepQuery);
			mysqli_stmt_bind_param($updatestepstmt, "ssi", $testresult, $actualresult, $stepexecutionId);
			mysqli_stmt_execute($updatestepstmt);
			mysqli_stmt_close($updatestepstmt);

			// Update step iteration using prepared statements
			$updateIterationQuery = "UPDATE s_tcstep_iteration 
							SET s_se_testresult = ?, s_se_actualresult = ? 
							WHERE stepexecutionId = ? 
							AND accountId = ? 
							AND s_se_iteration = ?";
			$updatestepiterstmt = mysqli_prepare($conn, $updateIterationQuery);
			mysqli_stmt_bind_param($updatestepiterstmt, "ssi", $testresult, $actualresult, $stepexecutionId, $accountId, $iteration);
			mysqli_stmt_execute($updatestepiterstmt);
			mysqli_stmt_close($updatestepiterstmt);
		}


		switch ($testresult) {
			case 'Pass':
				$pass++;
				break;
			case 'Fail':
				$fail++;
				break;
			case 'In Progress':
				$inprogress++;
				break;
			case 'Block':
				$block++;
				break;
			case 'NA':
				$na++;
				break;
		}

	}
	
	mysqli_stmt_close($stepstmt);
	$status = "";
	if($fail > 0){
		$status = "Fail";
	}else if($block >0){
		$status = "Block";
	}else if($inprogress){
		$status = "In Progress";
	}else if($na > 0){
		$status = "NA";
	}else if($pass > 0){
		$status = "Pass";
	}else if($pending > 0){
		$status = "Pending";
	}

	if(!empty($status)){
		// Update test execution status using prepared statements
		$updateExecutionQuery = "UPDATE s_testexecution 
									SET s_st_testresult = ? " . (in_array($status,array("Pass","Fail")) ?  ",s_st_executionstatus = 2 " :"")." 
									WHERE s_st_id = ?";
		$stmt1 = mysqli_prepare($conn, $updateExecutionQuery);
		mysqli_stmt_bind_param($stmt1, "si", $status, $testexecutionId);
		mysqli_stmt_execute($stmt1);
		mysqli_stmt_close($stmt1);

		// Update test case run status using prepared statements
		$updateRunQuery = "UPDATE s_testcaserun 
							SET s_st_testresult = ? " . (in_array($status,array("Pass","Fail")) ?  ",s_st_executionstatus = 2 " :"")." 
							WHERE testexecutionId = ? 
							AND s_st_iteration = ?";
		$stmt2 = mysqli_prepare($conn, $updateRunQuery);
		mysqli_stmt_bind_param($stmt2, "ssi", $status, $testexecutionId, $iteration);
		mysqli_stmt_execute($stmt2);
		mysqli_stmt_close($stmt2);

		// Update final test case result using prepared statements
		$updateFinalQuery = "UPDATE s_testcasefinal 
								SET s_f_testresult = ? 
								WHERE testcaseId = (SELECT testcaseId 
													FROM s_testexecution 
													WHERE s_st_id = ? 
													AND accountId = ?) 
								AND accountId = ? 
								AND activityId = ?";
		$stmt3 = mysqli_prepare($conn, $updateFinalQuery);
		mysqli_stmt_bind_param($stmt3, "siisi", $status, $testexecutionId, $accountId, $accountId, $activityId);
		mysqli_stmt_execute($stmt3);
		mysqli_stmt_close($stmt3);
	}
	$msgarr["status"] = "Success";
	$msgarr["message"] = "Test execution result updated successfully.";

}

mysqli_stmt_close($stmt);
}
echo json_encode($msgarr);
