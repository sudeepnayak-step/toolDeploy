<?php
include('config.php');
session_start();
 
$enteredby = 0;$accountId = 0;
 

$errormsg ="";
$msgarr = array();
$msgarr["status"] = "Error";
$msgarr["message"] = "Something went wrong. Please try again.";
if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
}
if($_SERVER['REQUEST_METHOD'] === 'POST'){

	$ids = (isset($_POST['ids']) ? $_POST['ids'] : "");
	$projectId = (isset($_POST['projectId']) ? $_POST['projectId'] : "0");
	$releaseId = (isset($_POST['releaseId']) ? $_POST['releaseId'] : "0");
	$activityId = (isset($_POST['activityId']) ? $_POST['activityId'] : array());

	$arr = explode(",", $ids);
	for($i=0; $i<count($arr); $i++){
		$tcid = $arr[$i];

		$testcaseNum = 0;
		$testcaseIdstr = "";
		$projcode = "";
		$projquery = "SELECT * FROM s_project WHERE s_p_id = ? AND accountId = ? ORDER BY s_p_id DESC LIMIT 1";
        $stmt = mysqli_prepare($conn, $projquery);
        mysqli_stmt_bind_param($stmt, "ii", $projectId, $accountId);
        mysqli_stmt_execute($stmt);
        $projsqldata = mysqli_stmt_get_result($stmt);

        if (mysqli_num_rows($projsqldata) > 0) {
            $pdata = mysqli_fetch_assoc($projsqldata);
            $projcode = $pdata['s_p_code'];

            // Fetch scenario ID
            $scenarioId = 1;
            $scenarioquery = "SELECT * FROM s_testcase WHERE projectId = ? AND accountId = ? ORDER BY s_d_tempscenarioId DESC LIMIT 1";
            $stmt = mysqli_prepare($conn, $scenarioquery);
            mysqli_stmt_bind_param($stmt, "ii", $projectId, $accountId);
            mysqli_stmt_execute($stmt);
            $scenariosqldata = mysqli_stmt_get_result($stmt);

            if (mysqli_num_rows($scenariosqldata) > 0) {
                $rdata = mysqli_fetch_assoc($scenariosqldata);
                $scenarioId = (int)$rdata['s_d_tempscenarioId'] + 1;
            }
            $scenarioIdstr = "TS-$scenarioId";

            // Fetch test case number
            $testcaseNum = 1;
            $testnumquery = "SELECT * FROM s_testcase WHERE projectId = ? AND accountId = ? ORDER BY s_t_tempid DESC LIMIT 1";
            $stmt = mysqli_prepare($conn, $testnumquery);
            mysqli_stmt_bind_param($stmt, "ii", $projectId, $accountId);
            mysqli_stmt_execute($stmt);
            $testnumsqldata = mysqli_stmt_get_result($stmt);

            if (mysqli_num_rows($testnumsqldata) > 0) {
                $rdata = mysqli_fetch_assoc($testnumsqldata);
                $testcaseNum = (int)$rdata['s_t_tempid'] + 1;
            }
            $testcaseIdstr = "TC-$testcaseNum";
        }

		// Prepare the SQL statement with placeholders
		$sql = "UPDATE s_testcase 
		SET projectId = ?, 
			releaseId = ?, 
			s_t_activityIds = ?, 
			s_d_tempscenarioId = ?, 
			s_t_testscenarionum = ?, 
			s_t_tempid = ?, 
			s_t_testcasenum = ? 
		WHERE s_t_id = ?";

		// Prepare the statement
		$stmt = mysqli_prepare($conn, $sql);
		
		if($stmt){
			// Convert the array of activity IDs to a comma-separated string
			$activityIds = implode(",", $activityId);

			// Bind the parameters to the statement
			mysqli_stmt_bind_param($stmt, "ssssssss", 
				$projectId, 
				$releaseId, 
				$activityIds, 
				$scenarioId, 
				$scenarioIdstr, 
				$testcaseNum, 
				$testcaseIdstr, 
				$tcid
			);

			// Execute the statement
			$result = mysqli_stmt_execute($stmt);
			
			// Close the statement
			mysqli_stmt_close($stmt);

			$flag = 1;
			$testcaseId = $tcid;
			if(isset($activityId) && !empty($activityId) && count($activityId) >0){

					$dsql = "update s_testcasefinal set s_f_activestatus = 'Inactive' where testcaseId = '".$testcaseId."'  and accountId = '".$accountId."' ";
					
					$dstmt = mysqli_query( $conn, $dsql);
					foreach ($activityId as $key => $value) {
						
						$chksql = "select * from s_testcasefinal where testcaseId = '".$testcaseId."' and activityId = '".$value."' and accountId = '".$accountId."'  ";
						$chkstmt = mysqli_query( $conn, $chksql);
						if(mysqli_num_rows($chkstmt) <=0){
							$msql = "insert into s_testcasefinal(testcaseId, `projectId`, `releaseId`, `activityId`, `s_f_testresult`, `s_f_actualresult`, `s_f_executiontime`, `defectId`, `s_f_enteredby`, `accountId`, `s_f_activestatus`) values('".$testcaseId."','".$projectId."','".$releaseId."','".$value."','Not Executed','',NULL,'0','".$enteredby."','".$accountId."','Active')";
							$mstmt = mysqli_query( $conn, $msql);				
						}else{

							$finalsql = "update s_testcasefinal set s_f_activestatus = 'Active' where testcaseId = '".$testcaseId."' and activityId = '".$value."' and accountId = '".$accountId."' ";
							$dstmt = mysqli_query( $conn, $finalsql);
						}
					}
			}
		}else{
			$errormsg .= "Error ";
		}
	}
}



if($flag >0)
{
	$msgarr["status"] = "Success";
	$msgarr["message"] = "Testcase moved successfully.";
	if($errormsg !=""){
		$msgarr["message"] = "Some testcases moved successfully.";
	}
}
else
{
	$msgarr["status"] = "Error";
	$msgarr["message"] = "Something went wrong. Please try again.";
	if($errormsg !=""){
		$msgarr["message"] = "Moving of testcases failed.";
	}
}

echo json_encode($msgarr);