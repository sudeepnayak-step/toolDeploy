<?php
include('config.php');
session_start();
 
$enteredby = 0;$accountId = 0;
 

if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
}
/**remove the files from a folder */

$msgarr = array();

$msgarr["status"] = "Error";
$msgarr["message"] = "Something went wrong. Please try again.";
if($_SERVER['REQUEST_METHOD'] === 'POST'){

	$filepath = (isset($_POST['filepath']) ? $_POST['filepath'] : "");
	
	if(!empty($filepath) && $filepath !="") {

		$path = STEP_dir.$filepath;
		unlink($path);
		if (file_exists(STEP_dir.$filepath)) {
			$msgarr["status"] = "Error";
			$msgarr["message"] = "Attachment deletion failed. Please try again.";
		}
		else
		{

			$msgarr["status"] = "Success";
			$msgarr["message"] = "Attachment deleted successfully.";
		}



	}
}
echo json_encode($msgarr);