<?php
include('config.php');
session_start();

$enteredby = 0;$accountId = 0;$userempid = 0;
 
// create chart table header for view
if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
    $userempid = $_SESSION["userempid"];
}
$tablename = isset($_POST['tablename']) ? $_POST['tablename']:"";
$charttype = isset($_POST['charttype']) ? $_POST['charttype']:"";
$optionlist = "";
$optionArr['data'] = array();	 	

if($tablename == "Project"){

		$sqlCustom = "SELECT distinct(COLUMN_NAME) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = ? AND COLUMN_NAME NOT IN('s_p_id','accountId','s_p_enteredby','s_p_activestatus','s_p_createdtime','s_p_updatetime','s_p_planstartdate','s_p_planenddate','s_p_revisedstartdate','s_p_revisedenddate','s_p_actualstartdate','s_p_actualenddate','s_p_actualenddate','s_p_desc')";
		$tbl = "s_project";    
		$stmt = mysqli_prepare($conn, $sqlCustom);
		mysqli_stmt_bind_param($stmt, "s", $tbl);
		mysqli_stmt_execute($stmt);
		$result = mysqli_stmt_get_result($stmt);
		 
	 	while($pdata = mysqli_fetch_assoc($result)){
	 		// $col = $pdata['COLUMN_NAME'];
			$col = htmlspecialchars($pdata['COLUMN_NAME'], ENT_QUOTES, 'UTF-8');

	 		$optionlist .="<option value='".$col."'>".$col."</option>";
	 		$value = "";
	 		switch ($col) {
	 			case 's_p_name':
	 				$value = "Project Name";
	 				break;
	 			case 's_p_code':
	 				$value = "Project Code";
	 				break;
	 			case 's_p_status':
	 				$value = "Project Status";
	 				break;
	 			case 's_p_owner':
	 				$value = "Project Owner";
	 				break;
	 			case 'clientId':
	 				$value = "Project Client";
	 				break;
	 			case 's_p_ragstatus':
	 				$value = "RAG Status";
	 				break;	
	 		}
	 		$optionArr['data'][] = array("id"=>$col,"value"=>$value);
	 	}


}else 
if($tablename == "Defect"){

		$sqlCustom = "SELECT distinct(COLUMN_NAME) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = ? AND COLUMN_NAME NOT IN('s_d_id','s_d_tempid','s_d_shortdesc','s_d_longdesc','s_d_testdata','s_d_steps','s_d_expectedresult','s_d_actualresult','s_d_comment','s_d_filename','s_d_filepath','accountId','s_d_enteredby','s_d_createdtime','s_d_updatetime')";
		$tbl = "s_defect";
		$stmt = mysqli_prepare($conn, $sqlCustom);
		mysqli_stmt_bind_param($stmt, "s", $tbl);
		mysqli_stmt_execute($stmt);
		$result = mysqli_stmt_get_result($stmt);
		 
	 	while($pdata = mysqli_fetch_assoc($result)){
	 	
			$col = htmlspecialchars($pdata['COLUMN_NAME'], ENT_QUOTES, 'UTF-8');
			$optionlist .="<option value='".$col."'>".$col."</option>";
	 		$value = "";
	 		switch ($col) {
	 			case 'projectId':
	 				$value = "Project Name";
	 				break;
	 			case 'releaseId':
	 				$value = "Release ID";
	 				break;
	 			case 'testcaseId':
	 				$value = "Testcase ID";
	 				break;
	 			case 's_d_defectnum':
	 				$value = "Defect ID";
	 				break;
	 			case 'clientId':
	 				$value = "Project Client";
	 				break;
	 			case 's_d_module':
	 				$value = "Module";
	 				break;
	 			case 's_d_submodule':
	 				$value = "Submodule";
	 				break;	
	 			case 'defecttypeId':
	 				$value = "Defect Type";
	 				break;	
	 			case 's_d_severity':
	 				$value = "Severity";
	 				break;	
	 			case 's_d_priority':
	 				$value = "Priority";
	 				break;	
	 			case 'defectstatusId':
	 				$value = "Defect Status";
	 				break;	
	 			case 's_d_assignto':
	 				$value = "Assign To";
	 				break;	
				case 's_d_assigntorole':
                                        $value = "Assign To Role";
                                        break;
	 			case 's_d_reportedby':
	 				$value = "Reported By";
	 				break;		
	 		}
	 		$optionArr['data'][] = array("id"=>$col,"value"=>$value);
	 	}


}else 
if($tablename == "Test Execution"){
		$optionArr['data'][] = array("id"=>"Project Name","value"=>"Project Name");
		$optionArr['data'][] = array("id"=>"Release Name","value"=>"Release Name");
		$optionArr['data'][] = array("id"=>"Activity Name","value"=>"Activity Name");
		$optionArr['data'][] = array("id"=>"Test Scenario ID","value"=>"Test Scenario ID");
		$optionArr['data'][] = array("id"=>"Testcase ID","value"=>"Testcase ID");
		$optionArr['data'][] = array("id"=>"Module","value"=>"Module");
		$optionArr['data'][] = array("id"=>"Sub Module","value"=>"Sub Module");
		$optionArr['data'][] = array("id"=>"Test Mode","value"=>"Test Mode");
		$optionArr['data'][] = array("id"=>"Testcase Result","value"=>"Testcase Result");
		$optionArr['data'][] = array("id"=>"Iteration","value"=>"Iteration");
		
}

echo json_encode($optionArr);
