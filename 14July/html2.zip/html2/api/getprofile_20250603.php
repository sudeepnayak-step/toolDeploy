<?php
include('config.php');
session_start();
 
  /** This PHP script retrieves the user profile data based on login
 * It formats the data and returns it in JSON format. */
$enteredby = 0;$accountId=0;$userempid = 0;
 
	$projarr= array();

if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
}
if(isset($_SESSION["usertype"]) && $_SESSION["usertype"] == "Employee"){
	if(isset($_SESSION["userempid"])){
	    $userempid = intval($_SESSION["userempid"]);
	}

	$sql = "SELECT e.*,IFNULL(r.s_role_name,'') as role from s_employees e 
	left join s_role r on r.s_role_id = e.roleId 
	where   e.accountId = ?  and e.s_e_id = ?
	order by e.s_e_id desc";
	
	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "ii",$accountId,$userempid);
	mysqli_stmt_execute($stmt);
	$result = mysqli_stmt_get_result($stmt);
	while($data = mysqli_fetch_assoc($result)){
		$projarr = array("id"=>$data['s_e_id'],
			"name"=>$data['s_e_fname']." ".$data['s_e_mname']." ".$data['s_e_lname'] ,
			"emailid"=>$data['s_e_emailid'],
			"phoneno"=>$data['s_e_phoneno'],
			"activestatus"=>$data['s_e_activestatus'],
			"role"=>$data['role'],
			"type"=>"Employee"
		);
	}

}else{
	$projarr = array(
			"name"=>"Admin",
			"type"=>"Admin"
		);
}


echo json_encode($projarr);
?>