<?php
include('config.php');
session_start();
 
$enteredby = 0;$accountId = 0;
 
$errormsg ="";
$msgarr = array();
$msgarr["status"] = "Error";
$msgarr["message"] = "Something went wrong. Please try again.";
if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
}
if($_SERVER['REQUEST_METHOD'] === 'POST'){

	$ids = (isset($_POST['ids']) ? $_POST['ids'] : "");
	$projectId = (isset($_POST['projectId']) ? $_POST['projectId'] : "0");
	$releaseId = (isset($_POST['releaseId']) ? $_POST['releaseId'] : "0");
	$activityId = (isset($_POST['activityId']) ? $_POST['activityId'] : array());

	$arr = explode(",", $ids);
    $flag = 0;

    foreach ($arr as $tcid) {
        $testcaseNum = 0;
        $testcaseIdstr = "";
        $projcode = "";

        // Fetch project data using prepared statement
        $projsql = "SELECT * FROM s_project WHERE s_p_id = ? AND accountId = ? ORDER BY s_p_id DESC LIMIT 1";
        $projstmt = mysqli_prepare($conn, $projsql);
        mysqli_stmt_bind_param($projstmt, "ii", $projectId, $accountId);
        mysqli_stmt_execute($projstmt);
        $projresult = mysqli_stmt_get_result($projstmt);

        if (mysqli_num_rows($projresult) > 0) {
            while ($pdata = mysqli_fetch_assoc($projresult)) {
                $projcode = $pdata['s_p_code'];
            }

            // Fetch scenario data using prepared statement
            $scenariosql = "SELECT * FROM s_testcase WHERE projectId = ? AND accountId = ? ORDER BY s_d_tempscenarioId DESC LIMIT 1";
            $scenariostmt = mysqli_prepare($conn, $scenariosql);
            mysqli_stmt_bind_param($scenariostmt, "ii", $projectId, $accountId);
            mysqli_stmt_execute($scenariostmt);
            $scenarioresult = mysqli_stmt_get_result($scenariostmt);

            if (mysqli_num_rows($scenarioresult) > 0) {
                while ($rdata = mysqli_fetch_assoc($scenarioresult)) {
                    $scenarioId = (int)$rdata['s_d_tempscenarioId'] + 1;
                }
            } else {
                $scenarioId = 1;
            }
            $scenarioIdstr = "TS-$scenarioId";

            // Fetch test case number using prepared statement
            $testnumsql = "SELECT * FROM s_testcase WHERE projectId = ? AND accountId = ? ORDER BY s_t_tempid DESC LIMIT 1";
            $testnumstmt = mysqli_prepare($conn, $testnumsql);
            mysqli_stmt_bind_param($testnumstmt, "ii", $projectId, $accountId);
            mysqli_stmt_execute($testnumstmt);
            $testnumresult = mysqli_stmt_get_result($testnumstmt);

            if (mysqli_num_rows($testnumresult) > 0) {
                while ($rdata = mysqli_fetch_assoc($testnumresult)) {
                    $testcaseNum = (int)$rdata['s_t_tempid'] + 1;
                }
            } else {
                $testcaseNum = 1;
            }
            $testcaseIdstr = "TC-$testcaseNum";
        }

        // Insert new test case using prepared statement
        $sql = "INSERT INTO s_testcase (projectId, releaseId, s_t_activityIds, s_d_tempscenarioId, s_t_testscenarionum, s_t_tempid, s_t_testcasenum, s_t_module, s_t_submodule, s_t_testscenariodesc, s_t_testcasedesc, s_t_steps, s_t_expectedresult, s_t_precondition, s_t_testdata, s_t_enteredby, accountId, s_t_testmode, s_t_assignto, s_t_author, s_t_reviewer, s_t_category) 
                SELECT ?, ?, ?, ?, ?, ?,?, s_t_module, s_t_submodule, s_t_testscenariodesc, s_t_testcasedesc, s_t_steps, s_t_expectedresult, s_t_precondition, s_t_testdata, ?, ?, s_t_testmode, s_t_assignto, s_t_author, s_t_reviewer, s_t_category 
                FROM s_testcase WHERE s_t_id = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "iisssssiii", $projectId, $releaseId, implode(",", $activityId), $scenarioId, $scenarioIdstr, $testcaseNum, $testcaseIdstr, $enteredby, $accountId, $tcid);
        mysqli_stmt_execute($stmt);

        if ($stmt) {
            $flag = 1;
            $testcaseId = mysqli_insert_id($conn);

            // Fetch test case steps using prepared statement
            $tcstepsql = "SELECT * FROM s_testcase_steps WHERE testcaseId = ? AND accountId = ? ORDER BY s_tss_num ASC";
            $tcstepstmt = mysqli_prepare($conn, $tcstepsql);
            mysqli_stmt_bind_param($tcstepstmt, "ii", $tcid, $accountId);
            mysqli_stmt_execute($tcstepstmt);
            $tcstepsresult = mysqli_stmt_get_result($tcstepstmt);

            while ($stepdata = mysqli_fetch_assoc($tcstepsresult)) {
                $s_num = $stepdata['s_tss_num'];
                $s_desc = $stepdata['s_tss_steps'];
                $s_result = $stepdata['s_tss_expectedresult'];

                // Insert test case steps using prepared statement
                $stepsql = "INSERT INTO s_testcase_steps (s_tss_num, testcaseId, s_tss_steps, s_tss_expectedresult, accountId, s_tss_enteredby) VALUES (?, ?, ?, ?, ?, ?)";
                $stepsstmt = mysqli_prepare($conn, $stepsql);
                mysqli_stmt_bind_param($stepsstmt, "iissii", $s_num, $testcaseId, $s_desc, $s_result, $accountId, $enteredby);
                mysqli_stmt_execute($stepsstmt);
            }

            if (isset($activityId) && !empty($activityId) && count($activityId) > 0) {
                $dsql = "UPDATE s_testcasefinal SET s_f_activestatus = 'Inactive' WHERE testcaseId = ? AND accountId = ?";
                $dstmt = mysqli_prepare($conn, $dsql);
                mysqli_stmt_bind_param($dstmt, "ii", $testcaseId, $accountId);
                mysqli_stmt_execute($dstmt);

                foreach ($activityId as $value) {
                    $chksql = "SELECT * FROM s_testcasefinal WHERE testcaseId = ? AND activityId = ? AND accountId = ?";
                    $chkstmt = mysqli_prepare($conn, $chksql);
                    mysqli_stmt_bind_param($chkstmt, "iii", $testcaseId, $value, $accountId);
                    mysqli_stmt_execute($chkstmt);
                    $chkresult = mysqli_stmt_get_result($chkstmt);

                    if (mysqli_num_rows($chkresult) <= 0) {
                        $msql = "INSERT INTO s_testcasefinal (testcaseId, projectId, releaseId, activityId, s_f_testresult, s_f_actualresult, s_f_executiontime, defectId, s_f_enteredby, accountId, s_f_activestatus) VALUES (?, ?, ?, ?, 'Not Executed', '', NULL, '0', ?, ?, 'Active')";
                        $mstmt = mysqli_prepare($conn, $msql);
                        mysqli_stmt_bind_param($mstmt, "iiisii", $testcaseId, $projectId, $releaseId, $value, $enteredby, $accountId);
                        mysqli_stmt_execute($mstmt);
                    } else {
                        $finalsql = "UPDATE s_testcasefinal SET s_f_activestatus = 'Active' WHERE testcase Id = ? AND activityId = ? AND accountId = ?";
                        $finalstmt = mysqli_prepare($conn, $finalsql);
                        mysqli_stmt_bind_param($finalstmt, "iii", $testcaseId, $value, $accountId);
                        mysqli_stmt_execute($finalstmt);
                    }
                }
            }
        } else {
            $errormsg .= "Error ";
        }
    }
}


if($flag >0)
{
	$msgarr["status"] = "Success";
	$msgarr["message"] = "Testcase copied successfully.";
	if($errormsg !=""){
		$msgarr["message"] = "Some testcases copied successfully.";
	}
}
else
{
	$msgarr["status"] = "Error";
	$msgarr["message"] = "Something went wrong. Please try again.";
	if($errormsg !=""){
		$msgarr["message"] = "Testcases copied failed.";
	}
}

echo json_encode($msgarr);
