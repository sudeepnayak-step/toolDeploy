
<?php
include('config.php');
session_start();
 
$enteredby = 0;
$accountId = 0;
$msgarr = array();
 /** this script saves the testcases data into database */

if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
}
$updateRecords = "";$auditlogDesc = "";$emailids = "";$empids = "";
if($_SERVER['REQUEST_METHOD'] === 'POST'){

	$id = (isset($_POST['testcaseDBId'])&& !empty($_POST['testcaseDBId'])  ? $_POST['testcaseDBId'] : "0");
	$projectId = (isset($_POST['projectId']) && !empty($_POST['projectId']) ? $_POST['projectId'] : "0");
	$projectId_change = (isset($_POST['projectId_change']) && !empty($_POST['projectId_change']) ? $_POST['projectId_change'] : "0");
	if($projectId_change == "1"){
		if($auditlogDesc == ""){
			$auditlogDesc = "Project ID";
		}else{
			$auditlogDesc .= ", Project ID";
		}
		if($updateRecords == ""){
			$updateRecords = "projectId = '".$projectId."'";
		}else{
			$updateRecords .= ", projectId = '".$projectId."'";
		}
	}
        $empdata = mysqli_query($conn,"SELECT IFNULL(group_concat(s_e_emailid),'') as emailids, IFNULL(group_concat(s_e_id),'') as empids from  s_employees where s_e_activestatus = 'Active' and s_e_id in(select employeeId from s_project_members where projectId = '".$projectId."' and accountId ='".$accountId."' ) and accountId ='".$accountId."'   Order by s_e_id desc");
 
	while($edata = mysqli_fetch_assoc($empdata)){
        $emailids = $edata['emailids'];
        $empids = $edata['empids'];
}
	$releaseId = (isset($_POST['releaseId'])&& !empty($_POST['releaseId'])  ? $_POST['releaseId'] : "0");
	$releaseId_change = (isset($_POST['releaseId_change']) && !empty($_POST['releaseId_change']) ? $_POST['releaseId_change'] : "0");
	if($releaseId_change == "1"){
		if($auditlogDesc == ""){
			$auditlogDesc = "Release ID";
		}else{
			$auditlogDesc .= ", Release ID";
		}
		if($updateRecords == ""){
			$updateRecords = "releaseId = '".$releaseId."'";
		}else{
			$updateRecords .= ", releaseId = '".$releaseId."'";
		}
	}

	$activityId = array();
	if(isset($_POST['activityId']) && !empty($_POST['activityId'])){
	if(is_array($_POST['activityId'])){
			$activityId = $_POST['activityId'];
	}else{
		$activityId = explode(",",$_POST['activityId']);
	}
	}
	$activityId_change = (isset($_POST['activityId_change']) && !empty($_POST['activityId_change']) ? $_POST['activityId_change'] : "0");
	if($activityId_change == "1"){
		if($auditlogDesc == ""){
			$auditlogDesc = "Activity ID";
		}else{
			$auditlogDesc .= ", Activity ID";
		}
		if($updateRecords == ""){
			$updateRecords = "s_t_activityIds = '".(implode(",", $activityId))."'";
		}else{
			$updateRecords .= ", s_t_activityIds = '".(implode(",", $activityId))."'";
		}
	}

	$module = (isset($_POST['module']) ? mysqli_real_escape_string($conn,sanitize($_POST['module'])) : "");
	$module_change = (isset($_POST['module_change']) && !empty($_POST['module_change']) ? $_POST['module_change'] : "0");
	if($module_change == "1"){
		if($auditlogDesc == ""){
			$auditlogDesc = "Module";
		}else{
			$auditlogDesc .= ", Module";
		}
		if($updateRecords == ""){
			$updateRecords = "s_t_module = '".$module."'";
		}else{
			$updateRecords .= ", s_t_module = '".$module."'";
		}
	}

	$submodule = (isset($_POST['submodule']) ? mysqli_real_escape_string($conn,sanitize($_POST['submodule'])) : "");
	$submodule_change = (isset($_POST['submodule_change']) && !empty($_POST['submodule_change']) ? $_POST['submodule_change'] : "0");
	if($submodule_change == "1"){
		if($auditlogDesc == ""){
			$auditlogDesc = "Submodule";
		}else{
			$auditlogDesc .= ", Submodule";
		}
		if($updateRecords == ""){
			$updateRecords = "s_t_submodule = '".$submodule."'";
		}else{
			$updateRecords .= ", s_t_submodule = '".$submodule."'";
		}
	}


	$testscenariodesc = (isset($_POST['testscenariodesc']) ? mysqli_real_escape_string($conn,sanitize($_POST['testscenariodesc'])) : "");
	$testscenariodesc_change = (isset($_POST['testscenariodesc_change']) && !empty($_POST['testscenariodesc_change']) ? $_POST['testscenariodesc_change'] : "0");
	if($testscenariodesc_change == "1"){
		if($auditlogDesc == ""){
			$auditlogDesc = "Test Scenario Description";
		}else{
			$auditlogDesc .= ", Test Scenario Description";
		}
		if($updateRecords == ""){
			$updateRecords = "s_t_testscenariodesc = '".$testscenariodesc."'";
		}else{
			$updateRecords .= ", s_t_testscenariodesc = '".$testscenariodesc."'";
		}
	}

	$testcasedesc = (isset($_POST['testcasedesc']) ? mysqli_real_escape_string($conn,sanitize($_POST['testcasedesc'])) : "");
	$testcasedesc_change = (isset($_POST['testcasedesc_change']) && !empty($_POST['testcasedesc_change']) ? $_POST['testcasedesc_change'] : "0");
	if($testcasedesc_change == "1"){
		if($auditlogDesc == ""){
			$auditlogDesc = "Test Case Description";
		}else{
			$auditlogDesc .= ", Test Case Description";
		}
		if($updateRecords == ""){
			$updateRecords = "s_t_testcasedesc = '".$testcasedesc."'";
		}else{
			$updateRecords .= ", s_t_testcasedesc = '".$testcasedesc."'";
		}
	}

	$steps = (isset($_POST['steps']) ? mysqli_real_escape_string($conn,sanitize($_POST['steps'])) : "");
	$steps_change = (isset($_POST['steps_change']) && !empty($_POST['steps_change']) ? $_POST['steps_change'] : "0");
	if($steps_change == "1"){
		if($auditlogDesc == ""){
			$auditlogDesc = "Steps";
		}else{
			$auditlogDesc .= ", Steps";
		}
		if($updateRecords == ""){
			$updateRecords = "s_t_steps = '".$steps."'";
		}else{
			$updateRecords .= ", s_t_steps = '".$steps."'";
		}
	}

	$expectedresult = (isset($_POST['expectedresult']) ? mysqli_real_escape_string($conn,sanitize($_POST['expectedresult'])) : "");
	$expectedresult_change = (isset($_POST['expectedresult_change']) && !empty($_POST['expectedresult_change']) ? $_POST['expectedresult_change'] : "0");
	if($expectedresult_change == "1"){
		if($auditlogDesc == ""){
			$auditlogDesc = "Expected Result";
		}else{
			$auditlogDesc .= ", Expected Result";
		}
		if($updateRecords == ""){
			$updateRecords = "s_t_expectedresult = '".$expectedresult."'";
		}else{
			$updateRecords .= ", s_t_expectedresult = '".$expectedresult."'";
		}
	}

	$precondition = (isset($_POST['precondition']) ? mysqli_real_escape_string($conn,sanitize($_POST['precondition'])) : "");
	$precondition_change = (isset($_POST['precondition_change']) && !empty($_POST['precondition_change']) ? $_POST['precondition_change'] : "0");
	if($precondition_change == "1"){
		if($auditlogDesc == ""){
			$auditlogDesc = "Pre-Condition";
		}else{
			$auditlogDesc .= ", Pre-Condition";
		}
		if($updateRecords == ""){
			$updateRecords = "s_t_precondition = '".$precondition."'";
		}else{
			$updateRecords .= ", s_t_precondition = '".$precondition."'";
		}
	}

	$testdata = (isset($_POST['testdata'])? mysqli_real_escape_string($conn,sanitize($_POST['testdata'])) : "");
	$testdata_change = (isset($_POST['testdata_change']) && !empty($_POST['testdata_change']) ? $_POST['testdata_change'] : "0");
	if($testdata_change == "1"){
		if($auditlogDesc == ""){
			$auditlogDesc = "Test Data";
		}else{
			$auditlogDesc .= ", Test Data";
		}
		if($updateRecords == ""){
			$updateRecords = "s_t_testdata = '".$testdata."'";
		}else{
			$updateRecords .= ", s_t_testdata = '".$testdata."'";
		}
	}

	$assignto = (isset($_POST['assignto']) && !empty($_POST['assignto']) ? $_POST['assignto'] : "0");
	$assignto_change = (isset($_POST['assignto_change']) && !empty($_POST['assignto_change']) ? $_POST['assignto_change'] : "0");
	if($assignto_change == "1"){
		if($auditlogDesc == ""){
			$auditlogDesc = "Assignment";
		}else{
			$auditlogDesc .= ", Assignment";
		}
		if($updateRecords == ""){
			$updateRecords = "s_t_assignto = '".$assignto."'";
		}else{
			$updateRecords .= ", s_t_assignto = '".$assignto."'";
		}
	}

	$testmode = (isset($_POST['testmode']) ? $_POST['testmode'] : "");
	$testmode_change = (isset($_POST['testmode_change']) && !empty($_POST['testmode_change']) ? $_POST['testmode_change'] : "0");
	if($testmode_change == "1"){
		if($auditlogDesc == ""){
			$auditlogDesc = "Test mode";
		}else{
			$auditlogDesc .= ", Test mode";
		}
		if($updateRecords == ""){
			$updateRecords = "s_t_testmode = '".$testmode."'";
		}else{
			$updateRecords .= ", s_t_testmode = '".$testmode."'";
		}
	}

	$author = (isset($_POST['author']) && !empty($_POST['author']) ? $_POST['author'] : "0");
	$author_change = (isset($_POST['author_change']) && !empty($_POST['author_change']) ? $_POST['author_change'] : "0");
	if($author_change == "1"){
		if($auditlogDesc == ""){
			$auditlogDesc = "Author";
		}else{
			$auditlogDesc .= ", Author";
		}
		if($updateRecords == ""){
			$updateRecords = "s_t_author = '".$author."'";
		}else{
			$updateRecords .= ", s_t_author = '".$author."'";
		}
	}

	$reviewer = (isset($_POST['reviewer']) && !empty($_POST['reviewer']) ? $_POST['reviewer'] : "0");
	$reviewer_change = (isset($_POST['reviewer_change']) && !empty($_POST['reviewer_change']) ? $_POST['reviewer_change'] : "0");
	if($reviewer_change == "1"){
		if($auditlogDesc == ""){
			$auditlogDesc = "Reviewer";
		}else{
			$auditlogDesc .= ", Reviewer";
		}
		if($updateRecords == ""){
			$updateRecords = "s_t_reviewer = '".$reviewer."'";
		}else{
			$updateRecords .= ", s_t_reviewer = '".$reviewer."'";
		}
	}


	$category = (isset($_POST['category']) && !empty($_POST['category']) ? $_POST['category'] : "0");
	$category_change = (isset($_POST['category_change']) && !empty($_POST['category_change']) ? $_POST['category_change'] : "0");
	if($category_change == "1"){
		if($auditlogDesc == ""){
			$auditlogDesc = "Category";
		}else{
			$auditlogDesc .= ", Category";
		}
		if($updateRecords == ""){
			$updateRecords = "s_t_category = '".$category."'";
		}else{
			$updateRecords .= ", s_t_category = '".$category."'";
		}
	}

	$comment = (isset($_POST['comment']) ? mysqli_real_escape_string($conn,sanitize($_POST['comment'])) : "");
	$comment_change = (isset($_POST['comment_change']) && !empty($_POST['comment_change']) ? $_POST['comment_change'] : "0");
	if($comment_change == "1"){
		if($auditlogDesc == ""){
			$auditlogDesc = "Comment";
		}else{
			$auditlogDesc .= ", Comment";
		}
		if($updateRecords == ""){
			$updateRecords = "s_t_comment = '".$comment."'";
		}else{
			$updateRecords .= ", s_t_comment = '".$comment."'";
		}
	}


	$scenarioId = (isset($_POST['scenarioId'])&& !empty($_POST['scenarioId'])  ? $_POST['scenarioId'] : "0");
	$scenarioId_change = (isset($_POST['scenarioId_change']) && !empty($_POST['scenarioId_change']) ? $_POST['scenarioId_change'] : "0");

	$scenarioIdstr = (isset($_POST['scenarioIdstr']) ? $_POST['scenarioIdstr'] : "");
	if($scenarioId_change == "1"){
		if($auditlogDesc == ""){
			$auditlogDesc = "Testcase Scenario";
		}else{
			$auditlogDesc .= ", Testcase Scenario";
		}
		if($scenarioId == "0" || $scenarioId ==""){
			$scenariosqldata = mysqli_query($conn,"SELECT * from s_testcase where projectId = '".$projectId."' and accountId='".$accountId."'  order by s_d_tempscenarioId desc limit 1");
			if(mysqli_num_rows($scenariosqldata)>0){

				while($rdata = mysqli_fetch_assoc($scenariosqldata)){
					$scenarioId = (int)$rdata['s_d_tempscenarioId'] +1;
				}
			}else{
				$scenarioId = 1;
			}
			$scenarioIdstr = "TS-$scenarioId";
		}


		if($updateRecords == ""){
			$updateRecords = "s_d_tempscenarioId = '".$scenarioId."', s_t_testscenarionum = '".$scenarioIdstr."'";
		}else{
			$updateRecords .= ", s_d_tempscenarioId = '".$scenarioId."', s_t_testscenarionum = '".$scenarioIdstr."'";
		}
	}

	$testcaseNum = 0;
	$testcaseIdstr = "";
	$projcode = "";
	$tcqdata = mysqli_query($conn,"SELECT * from s_testcase where s_t_id = '".$id."' and accountId = '".$accountId."'  order by s_t_id desc limit 1");	
       if(mysqli_num_rows($tcqdata)>0){
 
        while($rdata = mysqli_fetch_assoc($tcqdata)){
        $testcaseIdstr = $rdata['s_t_testcasenum'] ;
       }
       }
 	
	if($projectId_change == "1"){
		$projsqldata = mysqli_query($conn,"SELECT * from s_project where s_p_id = '".$projectId."' and accountId='".$accountId."' order by s_p_id desc limit 1");
		if(mysqli_num_rows($projsqldata)>0){

			while($pdata = mysqli_fetch_assoc($projsqldata)){
				$projcode = $pdata['s_p_code'];
			}


			$testnumsqldata = mysqli_query($conn,"SELECT * from s_testcase where projectId = '".$projectId."' and accountId='".$accountId."'   order by s_t_tempid desc limit 1");

			if(mysqli_num_rows($testnumsqldata)>0){

				while($rdata = mysqli_fetch_assoc($testnumsqldata)){
					$testcaseNum = (int)$rdata['s_t_tempid'] +1;
				}
			}else{
				$testcaseNum = 1;
			}
			$testcaseIdstr = "$projcode-TC-$testcaseNum";
			if($auditlogDesc == ""){
				$auditlogDesc = "Testcase ID";
			}else{
				$auditlogDesc .= ", Testcase ID";
			}

			if($updateRecords == ""){
				$updateRecords = "s_t_tempid = '".$testcaseNum."', s_t_testcasenum = '".$testcaseIdstr."'";
			}else{
				$updateRecords .= ", s_t_tempid = '".$testcaseNum."', s_t_testcasenum = '".$testcaseIdstr."'";
			}
		}
	}

	if(!empty($id) && $id !="0") {

		if($updateRecords !=""){

			$sql = "UPDATE s_testcase SET  $updateRecords where s_t_id = ?  and accountId=? ";
			$stmt = mysqli_prepare($conn, $sql);
			mysqli_stmt_bind_param($stmt, "si", $id, $accountId);
			$result = mysqli_stmt_execute($stmt);

			if((isset($result) && $result)){
				mysqli_stmt_close($stmt);
				$newFlag = 0;
				$msgarr["status"] = "Success";
				$msgarr["message"] = "Testcase updated successfully.";
				$testcaseId = $id;
				if($activityId_change == "1"){
					if(isset($activityId) && !empty($activityId) && count($activityId) >0){

							$dsql = "update s_testcasefinal set s_f_activestatus = 'Inactive' where testcaseId = '".$testcaseId."'  and accountId = '".$accountId."' ";
							$dstmt = mysqli_query( $conn, $dsql);
							foreach ($activityId as $key => $value) {
								# code...

								$chksql = "select * from s_testcasefinal where testcaseId = '".$testcaseId."' and activityId = '".$value."' and accountId = '".$accountId."'  ";
								$chkstmt = mysqli_query( $conn, $chksql);
								if(mysqli_num_rows($chkstmt) <=0){
									$msql = "insert into s_testcasefinal(testcaseId, `projectId`, `releaseId`, `activityId`, `s_f_testresult`, `s_f_actualresult`, `s_f_executiontime`, `defectId`, `s_f_enteredby`, `accountId`, `s_f_activestatus`) values('".$testcaseId."','".$projectId."','".$releaseId."','".$value."','Not Executed','',NULL,'0','".$enteredby."','".$accountId."','Active')";
									$mstmt = mysqli_query( $conn, $msql);				
								}else{

									$finalsql = "update s_testcasefinal set s_f_activestatus = 'Active' where testcaseId = '".$testcaseId."' and activityId = '".$value."' and accountId = '".$accountId."' ";
									$dstmt = mysqli_query( $conn, $finalsql);
								}
							}
					}
				}
				            if($emailids !=""){
 			                    $notificationSql = "insert into s_notifications (`s_n_viewer`, `s_n_employees`,`s_n_assignto`, `s_n_recordid`,`s_n_recordnum`,`s_n_desc`,`s_n_attachments`,`s_n_filename`,`accountId`,`s_n_enteredby`,s_n_newflag ,s_n_emailflag,s_n_module ) values (NULL,'".$empids."','0','".$testcaseId."','".$testcaseIdstr."','".$auditlogDesc."','','','".$accountId."','".$enteredby."','".$newFlag."','0','Testcase') ";
               				    mysqli_query( $conn, $notificationSql);
           				 }
 
				if($auditlogDesc != ""){
					$auditlogSql = "insert into s_auditlogs (`s_a_desc`, `s_a_module`, `s_a_enteredby`,`accountId`,`s_a_recordId`,`s_a_recordnum` ) values ('".$auditlogDesc."','Testcase','".$enteredby."','".$accountId."','".$id."','') ";
					
					mysqli_query( $conn, $auditlogSql);


				}
			}else{
				$msgarr["status"] = "Error";
				$msgarr["message"] = "Something went wrong. Please try again.";
			}
		}else{

			$msgarr["status"] = "Success";
			$msgarr["message"] = "Testcase updated successfully.";
		}
	}else{

		$sql = "INSERT INTO s_testcase (projectId, releaseId, s_t_activityIds, s_d_tempscenarioId, s_t_testscenarionum, s_t_tempid, s_t_testcasenum, s_t_module, s_t_submodule, s_t_testscenariodesc, s_t_testcasedesc, s_t_steps, s_t_expectedresult, s_t_precondition, s_t_testdata, s_t_enteredby, accountId, s_t_assignto, s_t_testmode, s_t_author, s_t_reviewer, s_t_comment, s_t_category) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		$stmt = mysqli_prepare($conn, $sql);
		mysqli_stmt_bind_param($stmt, "iisssisssssssssiiissss", $projectId, $releaseId, implode(",", $activityId), $scenarioId, $scenarioIdstr, $testcaseNum, $testcaseIdstr, $module, $submodule, $testscenariodesc, $testcasedesc, $steps, $expectedresult, $precondition, $testdata, $enteredby, $accountId, $assignto, $testmode, $enteredby, $reviewer, $comment, $category);
		$result = mysqli_stmt_execute($stmt);

		if($result)
		{
			$msgarr["status"] = "Success";
			$msgarr["message"] = "Testcase added successfully.";

			$testcaseId = mysqli_insert_id($conn);
			if(isset($activityId) && !empty($activityId) && count($activityId) >0){

					$dsql = "update s_testcasefinal set s_f_activestatus = 'Inactive' where testcaseId = '".$testcaseId."'  and accountId = '".$accountId."' ";
					$dstmt = mysqli_query( $conn, $dsql);
					foreach ($activityId as $key => $value) {
						
						$chksql = "select * from s_testcasefinal where testcaseId = '".$testcaseId."' and activityId = '".$value."' and accountId = '".$accountId."'  ";
						$chkstmt = mysqli_query( $conn, $chksql);
						if(mysqli_num_rows($chkstmt) <=0){
							$msql = "insert into s_testcasefinal(testcaseId, `projectId`, `releaseId`, `activityId`, `s_f_testresult`, `s_f_actualresult`, `s_f_executiontime`, `defectId`, `s_f_enteredby`, `accountId`, `s_f_activestatus`) values('".$testcaseId."','".$projectId."','".$releaseId."','".$value."','Not Executed','',NULL,'0','".$enteredby."','".$accountId."','Active')";
							$mstmt = mysqli_query( $conn, $msql);				
						}else{

							$finalsql = "update s_testcasefinal set s_f_activestatus = 'Active' where testcaseId = '".$testcaseId."' and activityId = '".$value."' and accountId = '".$accountId."' ";
							$dstmt = mysqli_query( $conn, $finalsql);
						}
					}
			}
			 
 			   if($emailids !=""){
       			  $notificationSql = "insert into s_notifications (`s_n_viewer`, `s_n_employees`,`s_n_assignto`, `s_n_recordid`,`s_n_recordnum`,`s_n_desc`,`s_n_attachments`,`s_n_filename`,`accountId`,`s_n_enteredby`,s_n_newflag ,s_n_emailflag,s_n_module ) values (NULL,'".$empids."','0','".$testcaseId."','".$testcaseIdstr."','".$auditlogDesc."','','','".$accountId."','".$enteredby."','".$newFlag."','0','Testcase') ";
       
      			  mysqli_query( $conn, $notificationSql);
 
    }


 
		}
		
else
		{
			$msgarr["status"] = "Error";
			$msgarr["message"] = "Something went wrong. Please try again.";
		}
		mysqli_stmt_close($stmt);
	}
}
echo json_encode($msgarr);
