<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
include('config.php');
// include('../config.php');
session_start();
 
$enteredby = 0;$accountId=0;
 /** This PHP script retrieves the project data from a database. 
 * It formats the data and returns it in JSON format. */


if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
}

$editPermission = 0;
if((isset($_SESSION["usertype"]) && $_SESSION["usertype"] == "Admin") || (isset($_SESSION["ruleIds"]) && in_array("3", explode(",", $_SESSION["ruleIds"])))){ 
	$editPermission = 1;
	}
$id = (isset($_POST['id']) ? intval($_POST['id']) : 0);
$projarr = array();
$sql = "SELECT * from s_project where s_p_id = ? and accountId = ?  ";

$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "ii",$id,$accountId);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
while($data = mysqli_fetch_assoc($result)){

		$membersarr = array();
		$membersnamearr = array();

		$chksql = "select mem.*, concat(IFNULL(s_e_fname,''),' ',IFNULL(s_e_mname,''),' ',IFNULL(s_e_lname,'')) as membersname from s_project_members mem join s_employees emp on emp.s_e_id = mem.employeeId where mem.projectId = ? and mem.accountId =?  ";
		$chkstmt = mysqli_prepare($conn, $chksql);
		mysqli_stmt_bind_param($chkstmt, "ii", $data['s_p_id'],$accountId);
		mysqli_stmt_execute($chkstmt);
		$chkresult = mysqli_stmt_get_result($chkstmt);

		while($mdata = mysqli_fetch_assoc($chkresult)){
			if(!in_array($mdata['employeeId'], $membersarr)){
				array_push($membersnamearr, $mdata['membersname']);
				array_push($membersarr, $mdata['employeeId']);
			}

		}
		$attachmentsarr = array();

		$dir = STEP_dir."attachments/".$accountId."/project/".$data['s_p_id']."/";
		
		if(is_dir($dir)) {

			$files = array_diff(scandir($dir), array('..', '.'));
			if(count($files) >0){
				foreach($files as $file){
					// echo $file;
					$ext = pathinfo($file, PATHINFO_EXTENSION);
					$attachmentsarr[] = array("filenamestr"=>$file,"extension"=>$ext,"filename"=>STEP_root.'attachments/'.$accountId.'/project/'.$data['s_p_id']."/".$file,"filepath"=>'attachments/'.$accountId.'/project/'.$data['s_p_id']."/".$file);
				}
			}
		}

		$editable = 0; // editable allow
		$editsql = "SELECT 1 from s_release where accountId = ? and projectId = ? ";
		$editstmt = mysqli_prepare($conn, $editsql);
		mysqli_stmt_bind_param($editstmt, "ii",$accountId,$data['s_p_id']);
		mysqli_stmt_execute($editstmt);
		$editabledata = mysqli_stmt_get_result($editstmt);

		
		$editable = mysqli_num_rows($editabledata);
		$projarr = array("id"=>$data['s_p_id'],
			"projectname"=>$data['s_p_name'],
			"projectcode"=>$data['s_p_code'],
			"group"=>$data['s_p_group'],
			"teammember"=>implode(",", $membersarr),
			"projectstatus"=>$data['s_p_status'],
			"activestatus"=>$data['s_p_activestatus'],
			"ragstatus"=>$data['s_p_ragstatus'],
			"planstartdate"=>(isset($data['s_p_planstartdate']) && ($data['s_p_planstartdate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_p_planstartdate'])) : ""),
			"planenddate"=>(isset($data['s_p_planenddate']) && ($data['s_p_planenddate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_p_planenddate'])) : ""),
			"revisedstartdate"=>(isset($data['s_p_revisedstartdate']) && ($data['s_p_revisedstartdate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_p_revisedstartdate'])) : ""),
			"revisedenddate"=>(isset($data['s_p_revisedenddate']) && ($data['s_p_revisedenddate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_p_revisedenddate'])) : ""),
			"actualstartdate"=>(isset($data['s_p_actualstartdate']) && ($data['s_p_actualstartdate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_p_actualstartdate'])) : ""),
			"actualenddate"=>(isset($data['s_p_actualenddate']) && ($data['s_p_actualenddate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_p_actualenddate'])) : ""),
			"projectdesc"=>$data['s_p_desc'],
			"projectowner"=>$data['s_p_owner'],
			"projectclient"=>$data['clientId'],
			"attachments"=>$attachmentsarr,
			"editable"=>$editable,
			"editPermission"=>$editPermission,
		);
}

echo json_encode($projarr);
?>
