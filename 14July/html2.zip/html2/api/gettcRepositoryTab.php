<?php
include('config.php');
session_start();
 
$enteredby = 0;$accountId=0;$userempid = 0;
 

if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
    $userempid = $_SESSION["userempid"];
}

$table = "s_tcrepository";
$title = "Banking";
$tctype = (isset($_POST['type']) ? mysqli_real_escape_string($conn,$_POST['type']) : "Banking");
switch ($tctype) {
    case 'Banking':
        $table = "s_tcrepository";
        $title = "Banking";
        break;
    case 'Automative':
        $table = "s_tcrepository1";
        $title = "Automative";
        break;
    case 'HR':
        $table = "s_tcrepository2";
        $title = "Human Resource";
        break;
    case 'Insurance':
        $table = "s_tcrepository3";
        $title = "Insurance";
        break;
    
    default:
        $table = "s_tcrepository";
        $title = "Banking";
        break;
}

$nTab = '';
$sqlUsermodule = mysqli_query($conn,"SELECT IFNULL(count(distinct(s_t_application)),0) as appcount,IFNULL(count(distinct(s_t_module)),0) as modulecount,IFNULL(count(1),0) as tccount FROM ".$table."    order by s_t_id asc ");

while($data = mysqli_fetch_assoc($sqlUsermodule)){
	$nTab .= '<div class="col-sm-3">
                    <div class="card text-white bg-flat-color-1">
                        <div class="card-body pb-0">                                    
                            <h3 class="mb-0 font-weight-bold">
                                <span >'.$data['appcount'].'</span>
                            </h3>
                            <p class="text-light">Total Applications Covered</p>
                        </div>

                    </div>
                </div>';

 $nTab .= '<div class="col-sm-3">
                    <div class="card text-white bg-flat-color-3">
                        <div class="card-body pb-0">                                    
                            <h3 class="mb-0 font-weight-bold">
                                <span >'.$data['modulecount'].'</span>
                            </h3>
                            <p class="text-light">Total '.$title.' Modules</p>
                        </div>

                    </div>
                </div>';

 $nTab .= '<div class="col-sm-3">
                    <div class="card text-white bg-flat-color-4">
                        <div class="card-body pb-0">                                    
                            <h3 class="mb-0 font-weight-bold">
                                <span >'.$data['tccount'].'</span>
                            </h3>
                            <p class="text-light">Total Test Cases</p>
                        </div>

                    </div>
                </div>';

   }

echo $nTab;
?>