<?php
include('config.php');

session_start();
 
$enteredby = 0;$accountId=0;
 
/**This script is designed to handle file attachments for either a "project" or a "Defect" based on the form type provided. 
 * It retrieves and organizes file attachments from specific directories and returns the data in JSON format. */
if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
}

$id = (isset($_POST['id']) ? $_POST['id'] : "0");
$formtype = (isset($_POST['formtype']) ? $_POST['formtype'] : "");
$projarr = array();
$attachmentsarr = array();

if($formtype == "project"){
    $dir = STEP_dir."attachments/".$accountId."/project/".$id."/";

    if(is_dir($dir)) {

        $files = array_diff(scandir($dir), array('..', '.'));
        if(count($files) >0){
            foreach($files as $file){
                
                $ext = pathinfo($file, PATHINFO_EXTENSION);
                $attachmentsarr[] = array("filename"=>$file,"extension"=>$ext,"filename"=>STEP_root.'attachments/'.$accountId.'/project/'.$id."/".$file,"filepath"=>'attachments/'.$accountId.'/project/'.$id."/".$file);
            }
        }
    }
	$projarr = array(
		"attachments"=>$attachmentsarr
	);
}else if($formtype == "Defect"){
    $dir = STEP_dir."defectdata/".$accountId."/".$id."/";
    if(is_dir($dir)) {

        $files = array_diff(scandir($dir), array('..', '.'));
        if(count($files) >0){
            foreach($files as $file){
                $ext = pathinfo($file, PATHINFO_EXTENSION);
                $attachmentsarr[] = array("filename"=>$file,"extension"=>$ext,"filename"=>STEP_root.'defectdata/'.$accountId.'/'.$id."/".$file,"filepath"=>'defectdata/'.$accountId.'/'.$id."/".$file);
            }
        }
    }
	$projarr = array(
		"attachments"=>$attachmentsarr
	);
}


echo json_encode($projarr);
?>