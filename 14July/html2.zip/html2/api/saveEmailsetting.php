<?php
include('config.php');
session_start();
 
$enteredby = 0;
$accountId = 0;
 

$msgarr = array();
if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = (isset($_SESSION["accountId"]) ? $_SESSION["accountId"] : 0);
}
if($_SERVER['REQUEST_METHOD'] === 'POST'){

$id = (isset($_POST['emailsettingId']) ? intval($_POST['emailsettingId']) : 0);
$hostname = (isset($_POST['hostname']) ? mysqli_real_escape_string($conn,$_POST['hostname']) : "");
$portno = (isset($_POST['portno']) ? mysqli_real_escape_string($conn,$_POST['portno'] ): "");
$fromname = (isset($_POST['fromname']) ? mysqli_real_escape_string($conn,$_POST['fromname']) : "");
$username = (isset($_POST['username']) ? mysqli_real_escape_string($conn,$_POST['username']) : "");
$password = (isset($_POST['password']) ? mysqli_real_escape_string($conn,$_POST['password']) : "");

if(!empty($id) && $id !="0") {
	$sql = "UPDATE s_emailsetting SET s_es_host = ?,s_es_port = ?,s_es_fromname = ?,s_es_username = ?,s_es_password = ?   where s_es_id = ?  and accountId = ? ";
	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "sssssii", $hostname, $portno,$fromname,$username,$password, $id, $accountId);

	if (mysqli_stmt_execute($stmt)) {
		$msgarr["status"] = "Success";
		$msgarr["message"] = "Email setting updated successfully.";
	}
	else
	{
		$msgarr["status"] = "Error";
		$msgarr["message"] = "Something went wrong. Please try again.";
	}

}else{


	$sql = "insert into s_emailsetting(s_es_host,s_es_port,s_es_fromname,s_es_username,s_es_password,accountId,s_es_enteredby) values(?,?,?,?,?,?,?)";
	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "sssssii", $hostname, $portno,$fromname,$username,$password, $accountId, $enteredby);

	if (mysqli_stmt_execute($stmt)) {
		$msgarr["status"] = "Success";
		$msgarr["message"] = "Email setting updated successfully.";
	}
	else
	{
		$msgarr["status"] = "Error";
		$msgarr["message"] = "Something went wrong. Please try again.";
	}

}
}

echo json_encode($msgarr);