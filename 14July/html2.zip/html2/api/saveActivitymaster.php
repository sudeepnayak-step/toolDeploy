<?php
include('config.php');
session_start();
 
$enteredby = 0;$accountId = 0;
 
$msgarr = array();
if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
}
if($_SERVER['REQUEST_METHOD'] === 'POST'){

$id = (isset($_POST['activityId']) ? $_POST['activityId'] : "0");
$activityname = (isset($_POST['activityname']) ? mysqli_real_escape_string($conn,$_POST['activityname']) : "");
$activitycode = (isset($_POST['activitycode']) ? mysqli_real_escape_string($conn,$_POST['activitycode']) : "");
$activitytype = (isset($_POST['activitytype']) ? $_POST['activitytype'] : "");

if(!empty($id) && $id !="0") {
	// Update existing activity
	$sql = "UPDATE s_activitymaster SET s_a_name = ? ,s_a_code = ?,s_a_type = ? where s_a_id = ? and accountId = ? ";
	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "sssii", $activityname, $activitycode, $activitytype, $id, $accountId);

	if (mysqli_stmt_execute($stmt)) {
		$msgarr["status"] = "Success";
		$msgarr["message"] = "Activity updated successfully.";
	}
	else
	{
		$msgarr["status"] = "Error";
		$msgarr["message"] = "Something went wrong. Please try again.";
	}
	mysqli_stmt_close($stmt);
}else{

	// Insert new activity master
	$sql = "INSERT INTO s_activitymaster (s_a_name, s_a_code, s_a_type, s_a_enteredby, accountId) VALUES (?, ?, ?, ?, ?)";
	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "sssii", $activityname, $activitycode, $activitytype, $enteredby, $accountId);

	if (mysqli_stmt_execute($stmt)) {
		$msgarr["status"] = "Success";
		$msgarr["message"] = "Activity added successfully.";
	} else {
		$msgarr["status"] = "Error";
		$msgarr["message"] = "Something went wrong. Please try again.";
	}
	mysqli_stmt_close($stmt);
}
}
echo json_encode($msgarr);