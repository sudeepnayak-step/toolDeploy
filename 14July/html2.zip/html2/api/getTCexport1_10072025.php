<?php

include('config.php');
// include_once("excel/xlsxwriter.class.php");
include_once("xlsxwriter.class.php");

session_start();
 
$enteredby = 0;$accountId=0;$userempid = 0;
 

if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
    $userempid = $_SESSION["userempid"];
}


$styleitem = array('font-style'=>'bold','color'=>'#ffffff','fill'=>"#1b55e2",'border'=>'top,bottom', 'halign'=>'center');
$where = "";
$projectId = (isset($_POST['projectId']) && !empty($_POST['projectId']) ? $_POST['projectId'] : "");
$releaseId = (isset($_POST['releaseId'])  && !empty($_POST['releaseId'])? $_POST['releaseId'] : "");
$testcaseId = (isset($_POST['testcaseId'])  && !empty($_POST['testcaseId'])? $_POST['testcaseId'] : "");
$module = (isset($_POST['module'])  && !empty($_POST['module'])? $_POST['module'] : "");
$submodule = (isset($_POST['submodule'])  && !empty($_POST['submodule'])? $_POST['submodule'] : "");
$category = (isset($_POST['category'])  && !empty($_POST['category'])? $_POST['category'] : "");

if($projectId !=""){
        $where = $where." and tc.projectId in ($projectId) ";
}

if($releaseId !=""){
        $where = $where." and tc.releaseId in ($releaseId) ";
}


if($module !=""){
    $modulearr = explode(",", $module);
    $module = "'" . implode ( "', '", $modulearr ) . "'";
    $where .= " and tc.s_t_module in ($module) ";
}

if($submodule !=""){
    $submodulearr = explode(",", $submodule);
    $submodule = "'" . implode ( "', '", $submodulearr ) . "'";
    $where .= " and tc.s_t_submodule in ($submodule) ";
}

if($category !=""){
        $where = $where." and tc.s_t_category in ($category) ";
}

if($testcaseId !=""){
    $testcaseIdarr = explode(",", $testcaseId);
    $testcaseId = "'" . implode ( "', '", $testcaseIdarr ) . "'";
    $where .= " and tc.s_t_testcasenum in ($testcaseId) ";
}

if(isset($_SESSION["usertype"]) && $_SESSION["usertype"] != "Admin"){
    $where .= " and tc.projectId in (select s_p_id from s_project where s_p_id in (select projectId from s_project_members where employeeId = '".$userempid."'  and accountId = '".$accountId."') or s_p_enteredby = '".$enteredby."' and accountId = '".$accountId."')";
    
}


$stepdata = mysqli_query($conn,"SELECT s.*,IFNULL(s_t_testcasenum,'') as testcasenum
 from s_testcase_steps s
 left join s_testcase t on t.s_t_id = s.testcaseId
 where s.accountId = '".$accountId."'  and s.testcaseId in (select s_t_id from s_testcase tc where tc.accountId = '".$accountId."' 
".$where."  
    ) order by s_tss_id asc");
$stepsarr = array();
while($sdata = mysqli_fetch_assoc($stepdata)){
 $stepsarr[$sdata['testcaseId']][] = array($sdata['testcasenum'],$sdata['s_tss_num'],$sdata['s_tss_steps'],$sdata['s_tss_expectedresult']);
}

$sql1 = "SELECT tc.*,
    concat(IFNULL(a1.s_e_fname,''),' ',IFNULL(a1.s_e_mname,''),' ',IFNULL(a1.s_e_lname,'')) as assignto,
    concat(IFNULL(a2.s_e_fname,''),' ',IFNULL(a2.s_e_mname,''),' ',IFNULL(a2.s_e_lname,'')) as author,
    concat(IFNULL(a3.s_e_fname,''),' ',IFNULL(a3.s_e_mname,''),' ',IFNULL(a3.s_e_lname,'')) as reviewer,
    IFNULL(p.s_p_name,'') as projectname,
    IFNULL(r.s_r_releaseId,'') as releaseNum,
    IFNULL(c.s_cat_name,'') as categoryname 
    from s_testcase tc 
    join s_project p on p.s_p_id = tc.projectId 
    join s_release r on r.s_r_id = tc.releaseId      
    left join s_tccategorymaster c on c.s_cat_id = tc.s_t_category 
    left JOIN s_employees a1 on (a1.s_e_id = tc.s_t_assignto and tc.s_t_assignto !='0')
    left JOIN s_employees a2 on (a2.userId = tc.s_t_author and tc.s_t_author !='0')
    left JOIN s_employees a3 on (a3.s_e_id = tc.s_t_reviewer and tc.s_t_author !='0')
    where tc.accountId = '".$accountId."' 
".$where."  
    order by tc.s_t_id asc"; 
//echo $sql1;
$sqldata = mysqli_query($conn,$sql1);

$tcarr = array();
$tcidsarr = array();
while($data = mysqli_fetch_assoc($sqldata)){

    $activityname = "";
    if($data['s_t_activityIds'] !=""){
        $chksql = "select IFNULL(GROUP_CONCAT(s_a_name),'') as activityname from s_activitymaster where s_a_id in  (".$data['s_t_activityIds'].")  and accountId = '".$accountId."'  ";
        $chkstmt = mysqli_query( $conn, $chksql);

        while($actdata = mysqli_fetch_assoc($chkstmt)){
            $activityname = $actdata['activityname'];
        }
    }

        $author = "Admin";
        if(trim($data['author']) !=""){
            $author = $data['author'];
        }
    $tcidsarr[] = $data['s_t_id'];

    if(isset($stepsarr) && isset($stepsarr[$data['s_t_id']])){
        foreach($stepsarr[$data['s_t_id']] as $steprow){
            $tcarr[$data['s_t_id']][] = array($data['s_t_testcasenum'],$data['s_t_testscenarionum'],$data['projectname'],$data['releaseNum'],$activityname,$data['s_t_testmode'],$data['s_t_module'],$data['s_t_submodule'],       
            // $data['assignto'],
            $author,
            $data['reviewer'],
            $data['s_t_testcasedesc'],
            $data['s_t_testscenariodesc'],
            $data['s_t_precondition'],
            $data['s_t_testdata'],
            $data['s_t_comment'],
            $data['categoryname'],
            $steprow[1],
            $steprow[2],
            $steprow[3]);
        }
    }else{
        $tcarr[$data['s_t_id']][] = array($data['s_t_testcasenum'],$data['s_t_testscenarionum'],$data['projectname'],$data['releaseNum'],$activityname,$data['s_t_testmode'],$data['s_t_module'],$data['s_t_submodule'],       
            // $data['assignto'],
            $author,
            $data['reviewer'],
            $data['s_t_testcasedesc'],
            $data['s_t_testscenariodesc'],
            $data['s_t_precondition'],
            $data['s_t_testdata'],
            $data['s_t_comment'],
            $data['categoryname'],
            "",
            "",
            "");
    }
}

              

$tcheader = array(
    'Test Case ID'=>'string',
    'Test Scenario ID'=>'string',
    'Project'=>'string',
    'Release'=>'string',
    'Test Type'=>'string',
    'Test Mode'=>'string',
    'Module'=>'string',
    'Sub Module'=>'string',
    'Author'=>'string',
    'Reviewer'=>'string',
    'TC Description'=>'string',
    'TS Description'=>'string',
    'Pre-Condition'=>'string',
    'Test Data'=>'string',
    'Comment'=>'string',
    'Testcase Category'=>'string',
    'Steps No.'=>'string',
    'Steps'=>'string',
    'Expected Result'=>'string'
);

$writer = new XLSXWriter();


$writer->writeSheetHeader('Testcase', $tcheader,$styleitem );
$start_row = 1; $start_col = 0; $end_row = 0; $end_col = 0;
foreach($tcarr as $tcid){
    $lcount = count($tcid);
    $end_row += $lcount;
    foreach($tcid as $row){
    	$writer->writeSheetRow('Testcase', $row);
        $writer->markMergedCell('Testcase', $start_row , $start_col , $end_row , $end_col );
        $writer->markMergedCell('Testcase', $start_row , $start_col+1 , $end_row , $end_col +1 );
        $writer->markMergedCell('Testcase', $start_row , $start_col+2 , $end_row , $end_col +2 );
        $writer->markMergedCell('Testcase', $start_row , $start_col+3 , $end_row , $end_col +3 );
        $writer->markMergedCell('Testcase', $start_row , $start_col+4 , $end_row , $end_col +4 );
        $writer->markMergedCell('Testcase', $start_row , $start_col+5 , $end_row , $end_col +5 );
        $writer->markMergedCell('Testcase', $start_row , $start_col+6 , $end_row , $end_col +6 );
        $writer->markMergedCell('Testcase', $start_row , $start_col+7 , $end_row , $end_col +7 );
        $writer->markMergedCell('Testcase', $start_row , $start_col+8 , $end_row , $end_col +8 );
        $writer->markMergedCell('Testcase', $start_row , $start_col+9 , $end_row , $end_col +9 );
        $writer->markMergedCell('Testcase', $start_row , $start_col+10 , $end_row , $end_col +10 );
        $writer->markMergedCell('Testcase', $start_row , $start_col+11 , $end_row , $end_col +11 );
        $writer->markMergedCell('Testcase', $start_row , $start_col+12 , $end_row , $end_col +12 );
        $writer->markMergedCell('Testcase', $start_row , $start_col+13 , $end_row , $end_col +13 );
        $writer->markMergedCell('Testcase', $start_row , $start_col+14 , $end_row , $end_col +14 );
        $writer->markMergedCell('Testcase', $start_row , $start_col+15 , $end_row , $end_col +15 );
        // $start_col += 1;
        // $end_col += 1;
    }
    $start_row +=$lcount;
}

$filename = "D:/xampp/htdocs/SOSA/step-tool/export/Test Cases Export.xlsx";
$writer->writeToFile($filename);

//force download
header('Content-Description: File Transfer');
header("Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
header("Content-Disposition: attachment; filename=".basename($filename));
header("Content-Transfer-Encoding: binary");
header("Expires: 0");
header("Pragma: public");
header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
header('Content-Length: ' . filesize($filename)); //Remove

ob_clean();
flush();

readfile($filename);
unlink($filename);
exit(0);



?>
