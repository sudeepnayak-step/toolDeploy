


<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: *');
header('Access-Control-Allow-Header: Content-Type');
 
include('config.php');
 
$response = array();
$profilePath = "admin.jpg";
$msg = "Oops! Something went wrong. Please try again later.";
 
// Rate limiting parameters
$max_attempts = 5; // Maximum number of failed attempts
$lockout_time = 300; // Lockout time in seconds (5 minutes)
 
session_start();
 
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = (isset($_POST['username']) ? $_POST['username'] : "");
    $password = (isset($_POST['password']) ? $_POST['password'] : "");
 
    // Check if the user is already locked out
    if (isset($_SESSION['lockout_time']) && $_SESSION['lockout_time'] > time()) {
        $response['status'] = "Error";
        $response['msg'] = "Too many failed login attempts. Please try again later.";
        echo json_encode($response);
        exit;
    }else if(isset($_SESSION['lockout_time']) && $_SESSION['lockout_time'] <= time()){
	$_SESSION['lockout_time'] = null ;
	$_SESSION['login_attempts'] = 0;
    }
 
    // Check if the user has exceeded the maximum number of attempts
    if (isset($_SESSION['login_attempts']) && $_SESSION['login_attempts'] >= $max_attempts) {
        $_SESSION['lockout_time'] = time() + $lockout_time;
        $response['status'] = "Error";
        $response['msg'] = "Too many failed login attempts. Please try again later.";
        echo json_encode($response);
        exit;
    }
 
    // Increment the login attempts counter
    if (!isset($_SESSION['login_attempts'])) {
        $_SESSION['login_attempts'] = 0;
    }
 
    function encryptAES($plaintext, $iv) {
        $key = "12569103478";
        $cipher = "AES-128-CBC";
        $key = substr(hash('sha256', $key, true), 0, 16);
        $encrypted = openssl_encrypt($plaintext, $cipher, $key, OPENSSL_RAW_DATA, $iv);
        return base64_encode($iv . $encrypted);
    }
 
    // Validate credentials
    if (!empty($username) && !empty($password)) {
        $sql = "SELECT s_u_id, s_u_username, s_u_password, s_u_type, s_u_employeeId, s_users.accountId, s_u_licno, s_u_expirytime, IFNULL(s_role_management.ruleIds,'') as ruleIds, s_employees.profile_path, s_users.roleId as roleId FROM s_users LEFT JOIN s_role_management ON s_role_management.roleId = s_users.roleId AND s_role_management.accountId = s_users.accountId LEFT JOIN s_employees ON s_employees.s_e_id = s_users.s_u_employeeId WHERE BINARY `s_u_username` LIKE ?";
 
        if ($stmt = mysqli_prepare($conn, $sql)) {
            mysqli_stmt_bind_param($stmt, "s", $param_username);
            $param_username = strtolower($username);
 
            if (mysqli_stmt_execute($stmt)) {
                mysqli_stmt_store_result($stmt);
 
                if (mysqli_stmt_num_rows($stmt) == 1) {
                    mysqli_stmt_bind_result($stmt, $id, $username, $hashed_password, $type, $empid, $accountId, $liccount, $expiry, $ruleIds, $profilePath, $roleId);
 
                    if (mysqli_stmt_fetch($stmt)) {
                        if (password_verify($password, $hashed_password)) {
                            if (date("Y-m-d 23:59:59") <= $expiry) {
                                session_regenerate_id(true);
                                $_SESSION['user_agent'] = $_SERVER['HTTP_USER_AGENT'];
                                $_SESSION['ip'] = $_SERVER['REMOTE_ADDR'];
                                $userarr = array();
                                $userarr["loggedin"] = true;
                                $userarr["id"] = $id;
                                $userarr["username"] = $username;
                                $userarr["usertype"] = $type;
                                $userarr["userempid"] = $empid;
                                $userarr["liccount"] = $liccount;
                                $userarr["ruleIds"] = $ruleIds;
                                $userarr["accountId"] = $id;
                                if ($type == "Admin") {
                                    $userarr["accountId"] = $id;
                                } else if ($type == "Employee") {
                                    $userarr["accountId"] = $accountId;
                                }
                                $userarr["profile_path"] = $profilePath;
                                $userarr["roleId"] = $roleId;
                                $msg = "1";
                                $response['status'] = "Success";
                                $iv = openssl_random_pseudo_bytes(16);
                                $encrypted_userarr = encryptAES(json_encode($userarr), $iv);
                                $response['msg'] = $encrypted_userarr;
                                unset($_SESSION['login_attempts']); // Reset login attempts on successful login
                            } else {
                                $msg = "Oops... Your account got expired.";
                                $response['status'] = "Error";
                                $response['msg'] = $msg;
                                $_SESSION['login_attempts']++; // Increment failed attempts
                            }
                        } else {
                            $msg = "The password you entered was not valid.";
                            $response['status'] = "Error";
                            $response['msg'] = $msg;
                            $_SESSION['login_attempts']++; // Increment failed attempts
                        }
                    }
                } else {
                    $msg = "No account found with that username.";
                    $response['status'] = "Error";
                    $response['msg'] = $msg;
                    $_SESSION['login_attempts']++; // Increment failed attempts
                }
            } else {
                $msg = "Oops! Something went wrong. Please try again later.";
                $response['status'] = "Error";
                $response['msg'] = $msg;
            }
            mysqli_stmt_close($stmt);
        }
    } else {
        $msg = "Oops! Something went wrong. Please try again later.";
        $response['status'] = "Error";
        $response['msg'] = $msg;
    }
}
 
$_SESSION['profile_path'] = $profilePath;
echo json_encode($response);
?>
