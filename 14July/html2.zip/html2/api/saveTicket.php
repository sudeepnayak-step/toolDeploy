<?php
error_reporting(E_ALL);
ini_set('display_errors', '1');
include('config.php');
session_start();
 
$enteredby = 0;$accountId = 0;
 
$msgarr = array();
$msgarr["status"] = "Error";
$msgarr["message"] = "Something went wrong. Please try again.";

if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
}
$updateRecords = "";$auditlogDesc = "";$emailids = "";$empids = "";$attachmentsLogs =array();$attachfilename = array();$newFlag = 0;
if($_SERVER['REQUEST_METHOD'] === 'POST'){

	// $id = (isset($_POST['rtmId']) ? $_POST['rtmId'] : "0");
		

    $problem = (isset($_POST['problem']) ? mysqli_real_escape_string($conn,$_POST['problem']) : "");
    $description = (isset($_POST['description']) ? mysqli_real_escape_string($conn,$_POST['description']) : "");
    $module = (isset($_POST['module']) ? mysqli_real_escape_string($conn,$_POST['module']) : "");
	
	
    $number = "S$enteredby".time();
    $manualtime =date('Y-m-d H:i:s', time());
    $currentlevel = 1;
    $assignto = 446;
    $screenshot = "";
    $priority = "";$reply = "";
    // Insert new record
    $sql = "INSERT INTO s_tickets ( `s_t_number`, `s_t_problem`, s_t_screenshot,s_t_priority,s_t_reply,`s_t_description`,s_t_module,  `s_t_manualtime`, `accountId`, `s_t_enteredby`,`s_t_current_level`,`s_t_assigned_to`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)";
    $stmt = mysqli_prepare($conn, $sql);
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, 'ssssssssssss', $number, $problem,$screenshot,$priority,$reply, $description,$module, $manualtime, $accountId, $enteredby,$currentlevel,$assignto);
        if (mysqli_stmt_execute($stmt)) {
            
            $newFlag = 1;
            $msgarr["status"] = "Success";
            $msgarr["message"] = "Ticket raised successfully.";


            $insertid = mysqli_insert_id($conn);

            $auditlogDesc = "New Ticket created.";
            
            $escSql = "insert into ticket_escalations (`ticketId`, `level_id`,resolution_note ) values ('".$insertid."','".$currentlevel."','') ";
            
            mysqli_query( $conn, $escSql);

            
            if(isset($_FILES['fileToUpload']['name'])){
                //echo "aditya";exit;
                if (!file_exists($CFG['dirroot'].'ticket/'.$accountId.'/'.$insertid)) {
                    mkdir($CFG['dirroot'].'ticket/'.$accountId.'/'.$insertid, 0777, true);
                }
                    
                // Count # of uploaded files in array
                $total = count($_FILES['fileToUpload']['name']);

                // Loop through each file
                for( $i=0 ; $i < $total ; $i++ ) {

                    //Get the temp file path
                    $tmpFilePath = $_FILES['fileToUpload']['tmp_name'][$i];

                    //Make sure we have a file path
                    if ($tmpFilePath != ""){
                        //Setup our new file path
                        $newFilePath = $CFG['dirroot'].'ticket/'.$accountId.'/'.$insertid."/" . $_FILES['fileToUpload']['name'][$i];

                        //Upload the file into the temp dir
                        if(move_uploaded_file($tmpFilePath, $newFilePath)) {
                                $attachmentsLogs[] = STEP_dir.'ticket/'.$accountId.'/'.$insertid."/" . $_FILES['fileToUpload']['name'][$i];
                                $attachfilename[] = $_FILES['fileToUpload']['name'][$i];

                        //Handle other code here

                        }
                    }
                }
            }


            $notificationSql = "insert into s_notifications (`s_n_viewer`, `s_n_employees`,`s_n_assignto`, `s_n_recordid`,`s_n_recordnum`,`s_n_desc`,`s_n_attachments`,`s_n_filename`,`accountId`,`s_n_enteredby`,s_n_newflag ,s_n_emailflag ,s_n_module) values (NULL,'275','0','".$insertid."','".$number."','".$auditlogDesc."','','','".$accountId."','".$enteredby."','1','0','Support Ticket') ";
            
            mysqli_query( $conn, $notificationSql);

            $auditlogSql = "insert into s_auditlogs (`s_a_desc`, `s_a_module`, `s_a_enteredby`,`accountId`,`s_a_recordId`,`s_a_recordnum`  ) values ('".$auditlogDesc."','Ticket','".$enteredby."','".$accountId."','".$insertid."','".$number."') ";
            
            mysqli_query( $conn, $auditlogSql);

            
            //if(isset($stmt))mysqli_stmt_close($stmt);
        } else {
            $msgarr["status"] = "Error";
            $msgarr["message"] = "Something went wrong. Please try again.";
        }

    } else {
        $msgarr["status"] = "Error";
        $msgarr["message"] = "Database error. Please try again.";
    }
	
}

echo json_encode($msgarr);
