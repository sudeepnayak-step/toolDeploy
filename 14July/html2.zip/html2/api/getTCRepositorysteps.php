<?php
include('config.php');
session_start();
 
   /** This PHP script retrieves the data from testcase repository steps. 
 * It formats the data and returns it in JSON format. */
$userempid = 0;$accountId = 0;$enteredby =0;
 
if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
}

if(isset($_SESSION["usertype"]) && $_SESSION["usertype"] == "Employee"){
	if(isset($_SESSION["userempid"])){
    $userempid = $_SESSION["userempid"];
}
}

$projarr['data'] = array();
$tcrepositoryId = (isset($_POST['tcrepositoryId']) && !empty($_POST['tcrepositoryId'])?  $_POST['tcrepositoryId'] : "0");

$table = "s_tcrepository_steps";
$tctype = (isset($_POST['type']) ? mysqli_real_escape_string($conn,$_POST['type']) : "Banking");
switch ($tctype) {
    case 'Banking':
        $table = "s_tcrepository_steps";
        break;
    case 'Automative':
        $table = "s_tcrepository_steps1";
        break;
    case 'HR':
        $table = "s_tcrepository_steps2";
        break;
    case 'Insurance':
        $table = "s_tcrepository_steps3";
        break;
    
    default:
        $table = "s_tcrepository_steps";
        break;
}
if($tcrepositoryId !="0"){
$stmt = mysqli_prepare($conn,"SELECT *
	from ".$table." 
	where accountId = ?  and tcrepositoryId = ? 
	order by s_tss_id asc");

mysqli_stmt_bind_param($stmt, "is",$accountId,$tcrepositoryId);
mysqli_stmt_execute($stmt);
$sqldata = mysqli_stmt_get_result($stmt);

$srno=0;
while($data = mysqli_fetch_assoc($sqldata)){
	$projarr['data'][] = array($data['s_tss_id'],$data['s_tss_steps'],$data['s_tss_expectedresult'],
		$data['s_tss_id']);
}
}

echo json_encode($projarr);
?>