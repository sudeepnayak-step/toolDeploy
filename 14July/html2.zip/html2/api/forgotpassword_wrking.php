<?php
header('Access-Control-Allow-Origin: *');
include('config.php');
require_once('../PHPMailer/class.phpmailer.php');

/** send email to reset the passowrd incase user forgot the password */
$msg = "Oops! Something went wrong. Please try again later.";

$msgarr = array();

$msgarr["status"] = "Error";
$msgarr["message"] = "Something went wrong. Please try again.";
if($_SERVER['REQUEST_METHOD'] === 'POST'){

$username = (isset($_POST['emailid']) ? $_POST['emailid'] : "");
$local = (isset($_POST['local']) ? $_POST['local'] : "");
    if(!empty($username)){
    	
        // Prepare a select statement
         $sql = "SELECT s_u_id, s_u_username, s_u_activationnum,s_u_type,s_u_employeeId,accountId,s_u_licno,s_u_expirytime FROM s_users
         WHERE s_u_username = ?";
        
        if($stmt = mysqli_prepare($conn, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "s", $param_username);
            
            // Set parameters
            $param_username = $username;
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Store result
                mysqli_stmt_store_result($stmt);
                
                // Check if username exists, if yes then verify password
                if(mysqli_stmt_num_rows($stmt) == 1){                    
                    // Bind result variables
                    mysqli_stmt_bind_result($stmt, $id, $username, $activationnum,$type,$empid,$accountId,$liccount,$expiry,);
                    if(mysqli_stmt_fetch($stmt)){
                       $sendFlag =  sendEmail($activationnum,$username);
                       if($sendFlag == 0){
                        $msgarr["status"] = "Success";
                        $msgarr["message"] = "Email sent successfully.";
                       }else{

                        $msgarr["status"] = "Error";
                        $msgarr["message"] = "Email sending failed.";

                       }

                    }
                } else{
                    // Display an error message if username doesn't exist
                    $msg = "No account found with this email id.";

                    $msgarr["status"] = "Error";
                    $msgarr["message"] = "No account found with this email id.";
                }
            } else{
                $msg =  "Oops! Something went wrong. Please try again later.";

                $msgarr["status"] = "Error";
                $msgarr["message"] = "Something went wrong. Please try again.";
            }
        // Close statement
        mysqli_stmt_close($stmt);
        }
        
    }
}else{
    $msgarr["status"] = "Error";
    $msgarr["message"] = "Something went wrong. Please try again.";
}

function sendEmail($nActivationNum,$emailid){
    global $conn,$accountId,$local;
    // echo $nActivationNum;

    $emailsqldata = mysqli_query($conn,"SELECT *  from s_emailsetting where accountId = '1' order by s_es_id desc limit 1");
    $e_host = "";
    $e_port = "";
    $e_fromname = "";
    $e_username = "";
    $e_password = "";
    $e_id = 0;

    while($data = mysqli_fetch_assoc($emailsqldata)){
        $e_host = $data['s_es_host'];
        $e_port =  $data['s_es_port'];
        $e_fromname =  $data['s_es_fromname'];
        $e_username =  $data['s_es_username'];
        $e_password =  $data['s_es_password'];
        $e_id =  $data['s_es_id'];

    }
    $subject = "STEP - Reset Password";
    $mail             = new PHPMailer(); // defaults to using php "mail()"
    $mail->IsSMTP(); // enable SMTP
    $mail->IsHTML(true);
    $mail->SMTPDebug  = 1;                     // enables SMTP debug information (for testing)
    $mail->SMTPAuth   = true;                  // enable SMTP authentication
    $mail->SMTPSecure = "ssl";                   // sets the prefix to the servier
    $mail->Host       = "$e_host";      // sets GMAIL as the SMTP server
    $mail->Port       = $e_port;   // set the SMTP port for the GMAIL server
    // $mail->SMTPKeepAlive = true;
    $mail->Mailer = "smtp";
    $body             = "Dear User,<br/><br/>To reset the password please click on the following link .<br/><br/>
        <a href='".$local."resetpassword.php?token=".$nActivationNum."' >Reset Password</a>";
    $mail->Username   = "$e_username";  // GMAIL username
    $mail->Password   = "$e_password"     ;       // GMAIL password

    $mail->SetFrom("$e_username", "$e_fromname");

    // $mail->AddReplyTo('test@gmail.com', 'Dipika');


    $mail->AddAddress(trim($emailid));
    // $mail->Subject    = "Daily Status Report -".$dsrdate;
    $mail->Subject    = "$subject";

    $mail->AltBody    = "To view the message, please use an HTML compatible email viewer!"; // optional, comment out and test

    $mail->MsgHTML($body);

    if(!$mail->Send()) {
        return 1;
    // echo "Mailer Error: " . $mail->ErrorInfo;
    } else {
        return 0;
    // echo "Message sent!";
    }


}

echo json_encode($msgarr);
?>