<?php
include('config.php');
session_start();
 
$enteredby = 0;$accountId = 0;
 
$msgarr = array();

if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
}
if($_SERVER['REQUEST_METHOD'] === 'POST'){

	$id = (isset($_POST['clientId']) ? $_POST['clientId'] : "0");
	$clientname = (isset($_POST['clientname']) ? mysqli_real_escape_string($conn,$_POST['clientname']) : "");
	$activestatus = (isset($_POST['activestatus']) ? $_POST['activestatus'] : "Active");

	if(!empty($id) && $id !="0") {
		$sql = "UPDATE s_client SET s_c_name = ?, s_c_activestatus = ? WHERE s_c_id = ? AND accountId = ?";
		$stmt = mysqli_prepare($conn, $sql);
		
		if ($stmt) {
			mysqli_stmt_bind_param($stmt, "ssii", $clientname, $activestatus, $id, $accountId);
			$result = mysqli_stmt_execute($stmt);
			
			if ($result) {
				$msgarr["status"] = "Success";
				$msgarr["message"] = "Client updated successfully.";
			} else {
				$msgarr["status"] = "Error";
				$msgarr["message"] = "Something went wrong. Please try again.";
			}
			
			mysqli_stmt_close($stmt);
		} else {
			$msgarr["status"] = "Error";
			$msgarr["message"] = "Failed to prepare the SQL statement.";
		}

	}else{

		$sql = "INSERT INTO s_client (s_c_name, s_c_activestatus, s_c_enteredby, accountId) VALUES (?, ?, ?, ?)";
		$stmt = mysqli_prepare($conn, $sql);
		
		if ($stmt) {
			mysqli_stmt_bind_param($stmt, "ssii", $clientname, $activestatus, $enteredby, $accountId);
			$result = mysqli_stmt_execute($stmt);
			
			if ($result) {
				$msgarr["status"] = "Success";
				$msgarr["message"] = "Client added successfully.";
			} else {
				$msgarr["status"] = "Error";
				$msgarr["message"] = "Something went wrong. Please try again.";
			}
			
			mysqli_stmt_close($stmt);
		} else {
			$msgarr["status"] = "Error";
			$msgarr["message"] = "Failed to prepare the SQL statement.";
		}

	}
}

echo json_encode($msgarr);