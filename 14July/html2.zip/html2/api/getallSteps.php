<?php
include('config.php');
session_start();
 
$userempid = 0;$accountId = 0;$enteredby =0;
  /** This PHP script retrieves the testcase steps  data from a database based on testcase and session information. 
 * It formats the data and returns it in JSON format. */ 

if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
}

if(isset($_SESSION["usertype"]) && $_SESSION["usertype"] == "Employee"){
	if(isset($_SESSION["userempid"])){
    $userempid = $_SESSION["userempid"];
}
}

$projarr['data'] = array();
$testcaseId = (isset($_POST['testcaseId']) && !empty($_POST['testcaseId'])?  intval($_POST['testcaseId']) : 0);

if($testcaseId !="0"){
$sql = "SELECT *
	from s_testcase_steps 
	where accountId = ?  and testcaseId = ? 
	order by s_tss_id asc";
	
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "ii", $accountId,$testcaseId);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$srno=0;

while($data = mysqli_fetch_assoc($result)){
	
	$projarr['data'][] = array($data['s_tss_id'],$data['s_tss_num'],$data['s_tss_steps'],$data['s_tss_expectedresult'],
		$data['s_tss_id']);
}
}

mysqli_stmt_close($stmt);

echo json_encode($projarr);
?>
