<?php
include('config.php');
session_start();
 
$enteredby = 0;$accountId=0;
  /** This PHP script retrieves the testcase execution steps result data from a database. 
 * It formats the data and returns it in JSON format. */



if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
}


$testexecutionId = isset($_POST['testexecutionId']) ? intval($_POST['testexecutionId']) : 0;
$sql = "SELECT e.* , 
	IFNULL(s_tss_num,'') as step_num,
	IFNULL(s_tss_steps,'') as steps,
	IFNULL(s_tss_expectedresult,'') as expectedresult 
	from s_tcstep_execution e 
	left join s_testcase_steps on s_testcase_steps.s_tss_id = e.stepId 
	where  e.s_se_executionId = ? and e.accountId= ? order by e.s_se_id asc";

	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "ii",$testexecutionId,$accountId);
	mysqli_stmt_execute($stmt);
	$result = mysqli_stmt_get_result($stmt);

$projarr['data'] = array();
$srno = 0;
while($data = mysqli_fetch_assoc($result)){
	$projarr['data'][] = array($data['s_se_id'],++$srno ,$data['steps'],$data['expectedresult'],$data['s_se_testresult'],$data['s_se_actualresult'],$data['reasonId'],$data['s_se_comment'],$data['s_se_iteration']);
}

mysqli_stmt_close($stmt);
echo json_encode($projarr);
?>
