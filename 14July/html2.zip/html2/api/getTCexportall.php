<?php

include('config.php');
include_once("excel/xlsxwriter.class.php");
 /** This PHP script retrieves the data from testcase and export it in excel. 
 * It formats the data and returns it in JSON format. */

session_start();
 
$enteredby = 0;$accountId=0;$userempid = 0;
 

if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
    $userempid = $_SESSION["userempid"];
}


$styleitem = array('font-style'=>'bold','color'=>'#ffffff','fill'=>"#1b55e2",'border'=>'top,bottom', 'halign'=>'center');
$where = "";
$projectId = (isset($_POST['projectId']) && !empty($_POST['projectId']) ? $_POST['projectId'] : "");
$releaseId = (isset($_POST['releaseId'])  && !empty($_POST['releaseId'])? $_POST['releaseId'] : "");
$testcaseId = (isset($_POST['testcaseId'])  && !empty($_POST['testcaseId'])? $_POST['testcaseId'] : "");
$module = (isset($_POST['module'])  && !empty($_POST['module'])? $_POST['module'] : "");
$submodule = (isset($_POST['submodule'])  && !empty($_POST['submodule'])? $_POST['submodule'] : "");
$category = (isset($_POST['category'])  && !empty($_POST['category'])? $_POST['category'] : "");

if($projectId !=""){
        $where = $where." and tc.projectId in ($projectId) ";
}

if($releaseId !=""){
        $where = $where." and tc.releaseId in ($releaseId) ";
}

if($module !=""){
    $modulearr = explode(",", $module);
    $module = "'" . implode ( "', '", $modulearr ) . "'";
    $where .= " and tc.s_t_module in ($module) ";
}

if($submodule !=""){
    $submodulearr = explode(",", $submodule);
    $submodule = "'" . implode ( "', '", $submodulearr ) . "'";
    $where .= " and tc.s_t_submodule in ($submodule) ";
}

if($category !=""){
        $where = $where." and tc.s_t_category in ($category) ";
}

if($testcaseId !=""){
    $testcaseIdarr = explode(",", $testcaseId);
    $testcaseId = "'" . implode ( "', '", $testcaseIdarr ) . "'";
    $where .= " and tc.s_t_testcasenum in ($testcaseId) ";
}

if(isset($_SESSION["usertype"]) && $_SESSION["usertype"] != "Admin"){
   $where .= " and tc.projectId in (select s_p_id from s_project where s_p_id in (select projectId from s_project_members where employeeId = '".$userempid."'  and accountId = '".$accountId."') or s_p_enteredby = '".$enteredby."' and accountId = '".$accountId."')";
    
}

$sqldata = mysqli_query($conn,"SELECT tc.*,
    concat(IFNULL(a1.s_e_fname,''),' ',IFNULL(a1.s_e_mname,''),' ',IFNULL(a1.s_e_lname,'')) as assignto,
    concat(IFNULL(a2.s_e_fname,''),' ',IFNULL(a2.s_e_mname,''),' ',IFNULL(a2.s_e_lname,'')) as author,
    concat(IFNULL(a3.s_e_fname,''),' ',IFNULL(a3.s_e_mname,''),' ',IFNULL(a3.s_e_lname,'')) as reviewer,
    IFNULL(p.s_p_name,'') as projectname,
    IFNULL(r.s_r_releaseId,'') as releaseNum,
    IFNULL(c.s_cat_name,'') as categoryname 
    from s_testcase tc 
    join s_project p on p.s_p_id = tc.projectId 
    join s_release r on r.s_r_id = tc.releaseId  
    left join s_tccategorymaster c on c.s_cat_id = tc.s_t_category 
    left JOIN s_employees a1 on a1.s_e_id = tc.s_t_assignto and tc.s_t_assignto !='0'
    left JOIN s_employees a2 on a2.userId = tc.s_t_author and tc.s_t_author !='0'
    left JOIN s_employees a3 on a3.s_e_id = tc.s_t_reviewer and tc.s_t_author !='0'
     
    order by tc.s_t_id asc");

$tcarr = array();
$tcidsarr = array();
while($data = mysqli_fetch_assoc($sqldata)){


    $accountname = "";
        $chkaccsql = "SELECT `s_u_username` FROM `s_users` WHERE `s_u_type` = 'Admin' and s_u_id = '".$data['accountId']."'  ";
        $chkaccstmt = mysqli_query( $conn, $chkaccsql);

        while($accdata = mysqli_fetch_assoc($chkaccstmt)){
            $accountname = $accdata['s_u_username'];
        }
    

    $activityname = "";
    if($data['s_t_activityIds'] !=""){
        $chksql = "select IFNULL(GROUP_CONCAT(s_a_name),'') as activityname from s_activitymaster where s_a_id in  (".$data['s_t_activityIds'].")    ";
        $chkstmt = mysqli_query( $conn, $chksql);

        while($actdata = mysqli_fetch_assoc($chkstmt)){
            $activityname = $actdata['activityname'];
        }
    }

        $author = "Admin";
        if(trim($data['author']) !=""){
            $author = $data['author'];
        }
    $tcidsarr[] = $data[s_t_id];
    $tcarr[] = array($accountname,$data['s_t_testcasenum'],$data['s_t_testscenarionum'],$data['projectname'],$data['releaseNum'],$activityname,$data['s_t_testmode'],$data['s_t_module'],$data['s_t_submodule'],       
        // $data['assignto'],
        $author,
        $data['reviewer'],
        $data['s_t_testcasedesc'],
        $data['s_t_testscenariodesc'],
        $data['s_t_steps'],
        $data['s_t_expectedresult'],
        $data['s_t_precondition'],
        $data['s_t_testdata'],
        $data['s_t_comment'],
        $data['categoryname']);
}

              

$tcheader = array(
    'Account ID'=>'string',
    'Test Case ID'=>'string',
    'Test Scenario ID'=>'string',
    'Project'=>'string',
    'Release'=>'string',
    'Test Type'=>'string',
    'Test Mode'=>'string',
    'Module'=>'string',
    'Sub Module'=>'string',
    'Author'=>'string',
    'Reviewer'=>'string',
    'TC Description'=>'string',
    'TS Description'=>'string',
    'Steps'=>'string',
    'Expected Result'=>'string',
    'Pre-Condition'=>'string',
    'Test Data'=>'string',
    'Comment'=>'string',
    'Testcase Category'=>'string'
);

$writer = new XLSXWriter();
$writer->writeSheetHeader('Testcase', $tcheader,$styleitem );
foreach($tcarr as $row)
	$writer->writeSheetRow('Testcase', $row);



$stepsheader = array(
    'Account ID'=>'string',
    'Test Case ID'=>'string',
    'Step No.'=>'string',
    'Steps'=>'string',
    'Expected Result'=>'string'
);

$stepdata = mysqli_query($conn,"SELECT s.*,IFNULL(s_t_testcasenum,'') as testcasenum
	from s_testcase_steps s
	left join s_testcase t on t.s_t_id = s.testcaseId
	where  s.testcaseId in (".implode(",",$tcidsarr).") order by s_tss_id asc");
$stepsarr = array();
while($sdata = mysqli_fetch_assoc($stepdata)){

    $accountname = "";
        $chkaccsql = "SELECT `s_u_username` FROM `s_users` WHERE `s_u_type` = 'Admin' and s_u_id = '".$sdata['accountId']."'  ";
        $chkaccstmt = mysqli_query( $conn, $chkaccsql);

        while($accdata = mysqli_fetch_assoc($chkaccstmt)){
            $accountname = $accdata['s_u_username'];
        }
	$stepsarr[] = array($accountname,$sdata['testcasenum'],$sdata['s_tss_num'],$sdata['s_tss_steps'],$sdata['s_tss_expectedresult']);
}

$writer->writeSheetHeader('Steps', $stepsheader,$styleitem);
foreach($stepsarr as $row)
	$writer->writeSheetRow('Steps', $row);
$filename = "Test Cases Export.xlsx";
$writer->writeToFile($filename);
//$writer->writeToStdOut();
//echo $writer->writeToString();
//force download
header('Content-Description: File Transfer');
header("Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
header("Content-Disposition: attachment; filename=".basename($filename));
header("Content-Transfer-Encoding: binary");
header("Expires: 0");
header("Pragma: public");
header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
header('Content-Length: ' . filesize($filename)); //Remove

ob_clean();
flush();

readfile($filename);
unlink($filename);
exit(0);



?>