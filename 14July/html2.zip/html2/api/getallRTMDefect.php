<?php
include('config.php');
session_start();
 
$enteredby = 0;$accountId=0;
 /** This PHP script retrieves and filters RTM (Requirement Traceability Matrix) defect
 * data from a database based on user inputs and session information. 
 * It formats the data and returns it in JSON format. */ 


if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
}
$projectId = (isset($_POST['projectId']) ? $_POST['projectId'] : "0");
$releaseId = (isset($_POST['releaseId']) ? $_POST['releaseId'] : "0");
$where = "";
if($projectId !="0" && $projectId !=""){
	$where = " AND tc.projectId  = '".$projectId."' ";
}
if($releaseId !="0" && $releaseId !=""){
	if($where == ""){
		$where = " AND tc.releaseId  = '".$releaseId."' ";
	}else{
		$where .=" and tc.releaseId  = '".$releaseId."' ";
	}
}

$temp_rtmId = isset($_POST['rtmId']) ? intval($_POST['rtmId']) : 0;
$sql = "SELECT rtc.*,
	IFNULL(d.s_d_id,'0') as defectautoId,
	IFNULL(d.s_d_shortdesc,'') as shortdesc,
	IFNULL(d.s_d_severity,'') as severity,
	IFNULL(d.s_d_priority,'') as priority,
	IFNULL(d.s_d_defectnum,'') as defectId,
	IFNULL(d.s_d_module,'') as module,
	IFNULL(d.s_d_submodule,'') as submodule,
	IFNULL(t.s_t_testcasenum,'') as testcasenum,
	IFNULL(ds.s_ds_name,'') as defectstatus,
	IFNULL(dt.s_dt_name,'') as defecttype
	 from s_rtm_testcase rtc
	 join s_defect d on d.s_d_id = rtc.defectId
	left join s_testcase t on t.s_t_id = d.testcaseId 
	left join s_defectstatusmaster ds on ds.s_ds_id = d.defectstatusId 
	left join s_defecttypemaster dt on dt.s_dt_id = d.defecttypeId 

	where rtc.accountId = ? and rtc.rtmId = ? and rtc.defectId !='0'

	order by rtc.s_rt_id asc";

	
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "ii", $accountId,$temp_rtmId);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$projarr['data'] = array();
while($data = mysqli_fetch_assoc($result)){
	$projarr['data'][] = array($data['s_rt_id'],$data['module'],$data['submodule'],$data['defectId'],$data['defectautoId'],
	$data['testcasenum'],
	$data['shortdesc'],$data['defecttype'],$data['defectstatus'],$data['severity'],$data['priority'],$data['s_rt_id']);
}

echo json_encode($projarr);
?>