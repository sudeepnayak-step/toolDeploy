<?php
//echo "test";die;
include('config.php');
session_start();
$enteredby = 0;$accountId=0;$userempid = 0;
if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
}

$id = (isset($_POST['id']) ? intval($_POST['id']) : 0);
//echo $id;die;
$projarr = array();

	$sql = "SELECT e.s_e_id as id,r.s_role_name as role FROM s_employees as e JOIN s_role as r ON r.s_role_id = e.roleId WHERE e.s_e_id = ? and e.accountId = ?  ";
	$stmt = mysqli_prepare($conn, $sql);
//	echo $sql; die;
	mysqli_stmt_bind_param($stmt, "ii",$id,$accountId);
	mysqli_stmt_execute($stmt);
	$result = mysqli_stmt_get_result($stmt);
	while($data = mysqli_fetch_assoc($result)){
		$projarr[] = array("id"=>$data["id"],"role"=>$data["role"]);
	}

echo json_encode($projarr);
?>
