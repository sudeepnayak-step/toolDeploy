<?php
include('config.php');
session_start();
 
$enteredby = 0;$accountId = 0;
 
$msgarr = array();
if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
}
if($_SERVER['REQUEST_METHOD'] === 'POST'){

	$id = (isset($_POST['chartId']) && !empty($_POST['chartId']) ? $_POST['chartId'] : "0");
	$charttitle = (isset($_POST['charttitle']) ? mysqli_real_escape_string($conn,sanitize($_POST['charttitle'])) : "");
	$chartsubtitle = (isset($_POST['chartsubtitle']) ? mysqli_real_escape_string($conn,sanitize($_POST['chartsubtitle'])) : "");
	$charttype = (isset($_POST['charttype']) ? $_POST['charttype'] : "");
	$module = (isset($_POST['module']) ? $_POST['module'] : "");
	$xAxis = (isset($_POST['xAxis']) ? $_POST['xAxis'] : "");
	$yAxis = (isset($_POST['yAxis']) ? $_POST['yAxis'] : "");
	$caltype = (isset($_POST['caltype']) && !empty($_POST['caltype']) ? $_POST['caltype'] : "Count");
	$activestatus = (isset($_POST['activestatus']) ? $_POST['activestatus'] : "Active");

	if(!empty($id) && $id !="0") {
		$sql = "UPDATE s_chartsetting SET s_c_title = ?, s_c_subtitle = ?, s_c_charttype = ?, s_c_tablename = ?, s_c_xaxis = ?, s_c_yaxis = ?, s_c_type = ?, s_c_activestatus = ? WHERE s_c_id = ? AND accountId = ?";
		$stmt = mysqli_prepare($conn, $sql);
		mysqli_stmt_bind_param($stmt,"ssssssssii", $charttitle, $chartsubtitle, $charttype, $module, $xAxis, $yAxis, $caltype, $activestatus, $id, $accountId);
	
		if (mysqli_stmt_execute($stmt)) {
			$msgarr["status"] = "Success";
			$msgarr["message"] = "Chart setting updated successfully.";
		}
		else
		{
			$msgarr["status"] = "Error";
			$msgarr["message"] = "Something went wrong. Please try again.";
		}
	}else{
		$sql = "INSERT INTO s_chartsetting (s_c_title, s_c_subtitle, s_c_charttype, s_c_tablename, s_c_xaxis, s_c_yaxis, s_c_type, s_c_activestatus, s_c_enteredby, accountId) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
		//echo $sql;
		$stmt = mysqli_prepare($conn, $sql);
		mysqli_stmt_bind_param($stmt,"ssssssssii", $charttitle, $chartsubtitle, $charttype, $module, $xAxis, $yAxis, $caltype, $activestatus, $enteredby, $accountId);
		
		if (mysqli_stmt_execute($stmt)) {
			$msgarr["status"] = "Success";
			$msgarr["message"] = "Chart setting added successfully.";
		}
		else
		{
			$msgarr["status"] = "Error";
			$msgarr["message"] = "Something went wrong. Please try again.";
		}
		//echo $msgarr["status"];
	}
}
echo json_encode($msgarr);
