<?php
include('config.php');
session_start();
 
$enteredby = 0;$accountId = 0;
 

if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
}
if($_SERVER['REQUEST_METHOD'] === 'POST'){

	$id = (isset($_POST['holidayId']) ? intval($_POST['holidayId']) : 0);
	$holidayname = (isset($_POST['holidayname']) ? mysqli_real_escape_string($conn,($_POST['holidayname'])) : "");
	$clientId = (isset($_POST['clientId']) ? mysqli_real_escape_string($conn,($_POST['clientId'])) : "0");

	$holidaydate = (isset($_POST['holidaydate']) && !empty($_POST['holidaydate']) ?  date('Y-m-d', strtotime(str_replace('/', '-', $_POST['holidaydate']))) : null);
	$activestatus = (isset($_POST['activestatus']) ? $_POST['activestatus'] : "");

	if (!empty($id) && $id != "0") {
		// Update query using prepared statements
		$sql = "UPDATE s_holiday_master SET clientId = ?, s_h_name = ?, s_h_date = ?, s_h_activestatus = ? WHERE s_h_id = ? AND accountId = ?";
		$stmt = mysqli_prepare($conn, $sql);
		mysqli_stmt_bind_param($stmt, "ssssii", $clientId, $holidayname, $holidaydate, $activestatus, $id, $accountId);

		if (mysqli_stmt_execute($stmt)) {
			$msgarr["status"] = "Success";
			$msgarr["message"] = "Holiday updated successfully.";
		} else {
			$msgarr["status"] = "Error";
			$msgarr["message"] = "Something went wrong. Please try again.";
		}
		mysqli_stmt_close($stmt);
	} else {
		// Insert query using prepared statements
		$sql = "INSERT INTO s_holiday_master (clientId, s_h_name, s_h_date, s_h_activestatus, s_h_enteredby, accountId) VALUES (?, ?, ?, ?, ?, ?)";
		$stmt = mysqli_prepare($conn, $sql);
		mysqli_stmt_bind_param($stmt, "ssssii", $clientId, $holidayname, $holidaydate, $activestatus, $enteredby, $accountId);

		if (mysqli_stmt_execute($stmt)) {
			$msgarr["status"] = "Success";
			$msgarr["message"] = "Holiday added successfully.";
		} else {
			$msgarr["status"] = "Error";
			$msgarr["message"] = "Something went wrong. Please try again.";
		}
		mysqli_stmt_close($stmt);
	}
}
echo json_encode($msgarr);
