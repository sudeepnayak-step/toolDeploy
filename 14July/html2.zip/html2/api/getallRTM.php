	<?php
include('config.php');
session_start();
 
$userempid = 0;$accountId = 0;$roleId = 0;$enteredby =0;
/** This PHP script retrieves and filters RTM (Requirement Traceability Matrix) 
 * data from a database based on user inputs and session information. 
 * It formats the data and returns it in JSON format. */ 
if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
    $roleId = $_SESSION["roleId"];
}

if(isset($_SESSION["usertype"]) && $_SESSION["usertype"] == "Employee"){
	if(isset($_SESSION["userempid"])){
    $userempid = $_SESSION["userempid"];
}
}

$defectwhere = "";

// $projectId = (isset($_POST['projectId']) && !empty($_POST['projectId'])?  implode(",", $_POST['projectId']) : "");
// $releaseId = (isset($_POST['releaseId'])  && !empty($_POST['releaseId'])? implode(",", $_POST['releaseId']) : "");
// $rtmId = (isset($_POST['rtmId'])  && !empty($_POST['rtmId'])? implode(",", $_POST['rtmId']) : "");
// $status = (isset($_POST['status'])  && !empty($_POST['status'])? implode(",", $_POST['status']) : "");
// $module = (isset($_POST['module'])  && !empty($_POST['module'])? implode(",", $_POST['module']) : "");

$projectIdStr = isset($_POST['projectId']) && !empty($_POST['projectId']) ? array_map('sanitize', $_POST['projectId']) : [];
$projectId = implode(",", $projectIdStr);

$releaseIdStr = isset($_POST['releaseId']) && !empty($_POST['releaseId']) ? array_map('sanitize', $_POST['releaseId']) : [];
$releaseId = implode(",", $releaseIdStr);

$rtmIdStr = isset($_POST['rtmId']) && !empty($_POST['rtmId']) ? array_map('sanitize', $_POST['rtmId']) : [];
$rtmId = implode(",", $rtmIdStr);

$statusStr = isset($_POST['status']) && !empty($_POST['status']) ? array_map('sanitize', $_POST['status']) : [];
$status = implode(",", $statusStr);

$moduleStr = isset($_POST['module']) && !empty($_POST['module']) ? array_map('sanitize', $_POST['module']) : [];
$module = implode(",", $moduleStr);



$projarr['data'] = array();
// Build the WHERE clause dynamically
$params = [];
$types = "";
if($projectId !=""){
		$defectwhere .= " AND find_in_set(rtm.projectId,?) ";
		$params[] = $projectId;
		$types .= "s";
}else{
	echo json_encode([
        "draw" => intval($_POST['draw']),
        "recordsTotal" => 0,
        "recordsFiltered" => 0, // modify if search applied
        "data" => $projarr['data']
    ]);
        die;
}

if($module !=""){
		$module = "'" . implode("','",explode(",",$module)) . "'";
		$defectwhere.=" and rtm.s_rtm_module in ($module) ";
		
}

if($releaseId !=""){
		$defectwhere .= " AND find_in_set(rtm.releaseId,?) ";
		$params[] = $releaseId;
		$types .= "s";
}

if($rtmId !=""){
		$defectwhere .= " AND find_in_set(rtm.s_rtm_id,?) ";
		$params[] = $rtmId;
		$types .= "s";
}

if($status !=""){
	$statusarr = explode(",", $status);
	$status = "'" . implode ( "', '", $statusarr ) . "'";
	$defectwhere .= " and rtm.s_rtm_status in ($status) ";
}


if (isset($_SESSION["usertype"]) && $_SESSION["usertype"] != "Admin") {
    $defectwhere .= " AND rtm.projectId IN (SELECT s_p_id FROM s_project WHERE s_p_id IN (SELECT projectId FROM s_project_members WHERE employeeId = ? AND accountId = ?) OR s_p_enteredby = ? AND accountId = ?)";
    $params[] = $userempid;
    $params[] = $accountId;
    $params[] = $enteredby;
    $params[] = $accountId;
    $types .= "ssss";
}

// Collect DataTables parameters
$start  = $_POST['start'];
$length = $_POST['length'];
$searchValue = $_POST['search']['value'] ?? '';
$orderColumn = $_POST['order'][0]['column'] ?? 0;
$orderDir    = $_POST['order'][0]['dir'] ?? 'asc';

// COUNT total records
$countSql = "SELECT COUNT(1) as total FROM s_rtm rtm
 WHERE rtm.accountId = ? $defectwhere ";
// Prepare statement
$countstmt = mysqli_prepare($conn, $countSql);
	
mysqli_stmt_bind_param($countstmt, "i" . $types, $accountId, ...$params);
mysqli_stmt_execute($countstmt);
$countResult = mysqli_stmt_get_result($countstmt);

$totalRecords = 0;
while($cdata = mysqli_fetch_assoc($countResult)){
$totalRecords = $cdata['total'];
}

if (!empty($searchValue)) {
    $searchValue = $conn->real_escape_string($searchValue);
    $defectwhere .= " AND (s_rtm_reqnum LIKE '%$searchValue%' 
                     OR p.s_p_name LIKE '%$searchValue%' 
                     OR r.s_r_name LIKE '%$searchValue%'
                     OR s_rtm_module LIKE '%$searchValue%'
                     OR s_rtm_summary LIKE '%$searchValue%'
                     OR s_rtm_status LIKE '%$searchValue%'
                     OR s_rtm_approvalstatus  LIKE '%$searchValue%'
                     OR DATE_FORMAT(CONVERT_TZ(s_rtm_createddate, 'UTC', 'Asia/Kolkata'), '%Y-%m-%d %l:%i %p') LIKE '%$searchValue%'
					 OR CONCAT(IFNULL(a2.s_e_fname,''), ' ', IFNULL(a2.s_e_mname,''), ' ', IFNULL(a2.s_e_lname,'')) LIKE '%$searchValue%'
					 OR CONCAT(IFNULL(a3.s_e_fname,''), ' ', IFNULL(a3.s_e_mname,''), ' ', IFNULL(a3.s_e_lname,'')) LIKE '%$searchValue%'
                     )";
}


// Prepare the SQL query for filter
$sql = "SELECT count(1) as filterrows
        FROM s_rtm rtm 
		left join s_project p on p.s_p_id = rtm.projectId 
		left join s_release r on r.s_r_id = rtm.releaseId 
        left JOIN s_employees a2 on a2.userId = rtm.s_rtm_author and rtm.s_rtm_author != '0'
		left JOIN s_employees a3 on a3.s_e_id = rtm.s_rtm_reviewer and rtm.s_rtm_reviewer !='0'
		WHERE rtm.accountId = ? $defectwhere 
        
        ";
		// echo $sql;
// Prepare statement
$filterstmt = mysqli_prepare($conn, $sql);
	
mysqli_stmt_bind_param($filterstmt, "i" . $types, $accountId, ...$params);
mysqli_stmt_execute($filterstmt);
$filterresult = mysqli_stmt_get_result($filterstmt);

$filterrows = 0;
while($fdata = mysqli_fetch_assoc($filterresult)){
$filterrows = $fdata['filterrows'];
}

$sql = "SELECT rtm.*,
	IFNULL(p.s_p_name,'') as projectname,
	IFNULL(r.s_r_name,'') as releaseNum,
	concat(IFNULL(a2.s_e_fname,''),' ',IFNULL(a2.s_e_mname,''),' ',IFNULL(a2.s_e_lname,'')) as author,
	concat(IFNULL(a3.s_e_fname,''),' ',IFNULL(a3.s_e_mname,''),' ',IFNULL(a3.s_e_lname,'')) as reviewer 
	from s_rtm rtm 
	left join s_project p on p.s_p_id = rtm.projectId 
	left join s_release r on r.s_r_id = rtm.releaseId 
 	left JOIN s_employees a2 on a2.userId = rtm.s_rtm_author and rtm.s_rtm_author != '0'
 	left JOIN s_employees a3 on a3.s_e_id = rtm.s_rtm_reviewer and rtm.s_rtm_reviewer !='0'
	where rtm.accountId = ?  $defectwhere
    ORDER BY rtm.s_rtm_id $orderDir LIMIT $start, $length";


$stmt = mysqli_prepare($conn, $sql);

mysqli_stmt_bind_param($stmt, "i" . $types, $accountId, ...$params);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

while($data = mysqli_fetch_assoc($result)){

	$author = "Admin";
	if(trim($data['author']) !=""){
		$author = $data['author'];
	}
	$approvalstatus = isset($data['s_rtm_approvalstatus']) ? $data['s_rtm_approvalstatus'] : "";
	$lastaction = isset($data['s_rtm_lastaction']) ? $data['s_rtm_lastaction'] : "";
        $lastactionedbyrole = $data['s_rtm_actionedbyrole'];
        $lastactionedby = $data['s_rtm_actionedby'];
        $actionvisible = 0;
        
		if(!isset($approvalstatus)  || $approvalstatus == "" || ($approvalstatus == "Disapproved" && $lastactionedbyrole == '66')){// first level
				if($roleId == '64')$actionvisible = 2;	    
		}else if($approvalstatus == "Pending" && $lastaction == ""){
				if($roleId == '66')$actionvisible = 1;
			}else if($lastaction == "Approved" && $lastactionedbyrole == '66'){	    
			if($roleId == '71')$actionvisible = 1; 	    
		}else if($lastaction == "Approved" && $lastactionedbyrole == '71'){
			if($roleId == '65')$actionvisible = 1;
		}else if($lastaction == "Disapproved" && $lastactionedbyrole == '71'){
			if($roleId == '66')$actionvisible = 1;
		}else if($lastaction == "Disapproved" && $lastactionedbyrole == '65'){
			if($roleId == '71')$actionvisible = 1;
		}

	$projarr['data'][] = array($data['s_rtm_id'],$data['s_rtm_reqnum'],$data['projectname'],$data['releaseNum'],$data['s_rtm_module'],html_entity_decode(strip_tags($data['s_rtm_summary'])),$data['s_rtm_description'],$data['s_rtm_status'],
		$author,
		(!empty(trim($data['reviewer'])) ? $data['reviewer'] : "-"),
		(isset($data['s_rtm_createddate']) && ($data['s_rtm_createddate'] != "0000-00-00") ? date("d/m/Y H:m a",strtotime($data['s_rtm_createddate'])) : "-"),
		$data['s_rtm_approvalstatus'],  $actionvisible, $data['s_rtm_id']);
}

// Return JSON response
echo json_encode([
    "draw" => intval($_POST['draw']),
    "recordsTotal" => $totalRecords,
    "recordsFiltered" => $filterrows, // modify if search applied
    "data" => $projarr['data']
]);
?>
