<?php
include('config.php');
session_start();
 
$enteredby = 0;$accountId=0;$userempid = 0;
 
   /** This PHP script retrieves the comments for defects from a database. 
 * It formats the data and returns it in JSON format. */


if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
    $userempid = $_SESSION["userempid"];
}


$rtmId = (isset($_POST['rtmId']) ? intval($_POST['rtmId']) : 0);

$projarr['data'] = array();
$sql = "SELECT a.*, CONCAT(IFNULL(enteredbyTBl.s_e_fname, ''), ' ', IFNULL(enteredbyTBl.s_e_mname, ''), ' ', IFNULL(enteredbyTBl.s_e_lname, '')) as entered_by FROM s_auditlogs a LEFT JOIN s_employees as enteredbyTBl ON enteredbyTBl.userId = a.s_a_enteredby WHERE a.accountId = ? and s_a_recordId = ? and s_a_module = 'Requirement' ORDER BY a.s_a_id asc";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "ii",$accountId,$rtmId);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
	$srno=0;

while($data = mysqli_fetch_assoc($result)){

$entered_by = (trim($data['entered_by'])  == "" ? "Admin" : $data['entered_by'] );

		$hdate = (isset($data['s_a_createdtime']) && ($data['s_a_createdtime'] != "0000-00-00 00:00:00") ? date("d/m/Y H:i a",strtotime($data['s_a_createdtime'])) : "");
$logtime  ="";
	if(isset($data['s_a_createdtime'])){
		// Create a DateTime object for the UTC time
		$dateTime = new DateTime($data['s_a_createdtime'], new DateTimeZone('UTC'));

		// Convert to Indian Standard Time (IST)
		$dateTime->setTimezone(new DateTimeZone('Asia/Kolkata'));
		$logtime = $dateTime->format('Y-m-d H:i:s');
	}		
	//	$projarr['data'][] = array(++$srno,$data['s_a_desc'],$data['s_a_module'],$entered_by,$hdate);
		$projarr['data'][] = array("id"=>$data['s_a_id'],
			"description"=>$data['s_a_desc'],
			"logtime"=>$logtime,
			"empname"=> $entered_by);
}

echo json_encode($projarr);
?>
