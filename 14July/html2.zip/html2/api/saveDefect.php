
<?php
include('config.php');
//require_once('../PHPMailer/class.phpmailer.php');
session_start();

 /** this script saves the defect data */
$enteredby = 0;$accountId=0;
 
$msgarr = array();

$msgarr["status"] = "Error";
$msgarr["message"] = "Something went wrong. Please try again.";
if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
}
$updateRecords = "";$auditlogDesc = "";$emailids = "";$empids = "";$attachmentsLogs =array();$attachfilename = array();$newFlag = 0;
if($_SERVER['REQUEST_METHOD'] === 'POST'){

$id = (isset($_POST['dId']) ? $_POST['dId'] : "0");
$projectId = (isset($_POST['projectId']) && !empty($_POST['projectId']) ? $_POST['projectId'] : "0");
$projectId_change = (isset($_POST['projectId_change']) && !empty($_POST['projectId_change']) ? $_POST['projectId_change'] : "0");
if($projectId_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "Project";
	}else{
		$auditlogDesc .= ", Project";
	}
	if($updateRecords == ""){
		$updateRecords = "projectId = '".$projectId."'";
	}else{
		$updateRecords .= ", projectId = '".$projectId."'";
	}
}
$empdata = mysqli_query($conn,"SELECT IFNULL(group_concat(s_e_emailid),'') as emailids, IFNULL(group_concat(s_e_id),'') as empids from  s_employees where s_e_activestatus = 'Active' and s_e_id in(select employeeId from s_project_members where projectId = '".$projectId."' and accountId ='".$accountId."' ) and accountId ='".$accountId."'   Order by s_e_id desc");

while($edata = mysqli_fetch_assoc($empdata)){
	$emailids = $edata['emailids'];
	$empids = $edata['empids'];
}


$releaseId = (isset($_POST['releaseId']) && !empty($_POST['releaseId']) ? $_POST['releaseId'] : "0");
$releaseId_change = (isset($_POST['releaseId_change']) && !empty($_POST['releaseId_change']) ? $_POST['releaseId_change'] : "0");
if($releaseId_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "Release";
	}else{
		$auditlogDesc .= ", Release";
	}
	if($updateRecords == ""){
		$updateRecords = "releaseId = '".$releaseId."'";
	}else{
		$updateRecords .= ", releaseId = '".$releaseId."'";
	}
}

$testcaseId = (isset($_POST['testcaseId']) && !empty($_POST['testcaseId'])? $_POST['testcaseId'] : "0");
$testcaseId_change = (isset($_POST['testcaseId_change']) && !empty($_POST['testcaseId_change']) ? $_POST['testcaseId_change'] : "0");
if($testcaseId_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "Testcase";
	}else{
		$auditlogDesc .= ", Testcase";
	}
	if($updateRecords == ""){
		$updateRecords = "testcaseId = '".$testcaseId."'";
	}else{
		$updateRecords .= ", testcaseId = '".$testcaseId."'";
	}
}

$assignto = (isset($_POST['assignto']) && !empty($_POST['assignto']) ? $_POST['assignto'] : "0");
$assignto_change = (isset($_POST['assignto_change']) && !empty($_POST['assignto_change']) ? $_POST['assignto_change'] : "0");
if($assignto_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "Assignment";
	}else{
		$auditlogDesc .= ", Assignment";
	}
	if($updateRecords == ""){
		$updateRecords = "s_d_assignto = '".$assignto."'";
	}else{
		$updateRecords .= ", s_d_assignto = '".$assignto."'";
	}
}
$assigntorole = (isset($_POST['assigntorole']) && !empty($_POST['assigntorole']) ? $_POST['assigntorole'] : "0");
	if($updateRecords == ""){
                $updateRecords = "s_d_assigntorole = '".$assigntorole."'";
        }else{
                $updateRecords .= ", s_d_assigntorole = '".$assigntorole."'";
        }

$module = (isset($_POST['module']) ? mysqli_real_escape_string($conn,$_POST['module']) : "");
$module_change = (isset($_POST['module_change']) && !empty($_POST['module_change']) ? $_POST['module_change'] : "0");
if($module_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "Module";
	}else{
		$auditlogDesc .= ", Module";
	}
	if($updateRecords == ""){
		$updateRecords = "s_d_module = '".$module."'";
	}else{
		$updateRecords .= ", s_d_module = '".$module."'";
	}
}

$submodule = (isset($_POST['submodule']) ? mysqli_real_escape_string($conn,$_POST['submodule']) : "");
$submodule_change = (isset($_POST['submodule_change']) && !empty($_POST['submodule_change']) ? $_POST['submodule_change'] : "0");
if($submodule_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "Submodule";
	}else{
		$auditlogDesc .= ", Submodule";
	}
	if($updateRecords == ""){
		$updateRecords = "s_d_submodule = '".$submodule."'";
	}else{
		$updateRecords .= ", s_d_submodule = '".$submodule."'";
	}
}

$severity = (isset($_POST['severity']) ? $_POST['severity'] : "");
$severity_change = (isset($_POST['severity_change']) && !empty($_POST['severity_change']) ? $_POST['severity_change'] : "0");
if($severity_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "Severity";
	}else{
		$auditlogDesc .= ", Severity";
	}
	if($updateRecords == ""){
		$updateRecords = "s_d_severity = '".$severity."'";
	}else{
		$updateRecords .= ", s_d_severity = '".$severity."'";
	}
}
//echo $_POST['environment_change'];die;
$environment = (isset($_POST['environment']) ? $_POST['environment'] : "");
$environment_change = (isset($_POST['environment_change']) && !empty($_POST['environment_change']) ? $_POST['environment_change'] : "0");
if($environment_change == "1"){
        if($auditlogDesc == ""){
                $auditlogDesc = "Environment";
        }else{
                $auditlogDesc .= ", Environment";
        }
        if($updateRecords == ""){
                $updateRecords = "s_d_environment = '".$environment."'";
        }else{
                $updateRecords .= ", s_d_environment = '".$environment."'";
        }
}

$platform = (isset($_POST['platform']) ? $_POST['platform'] : "");
 $platform_change = (isset($_POST['platform_change']) && !empty($_POST['platform_change']) ? $_POST['platform_change'] : "0");
 if($platform_change == "1"){
 if($auditlogDesc == ""){
 $auditlogDesc = "Platform";
 }else{
 $auditlogDesc .= ", Platform";
 }
 if($updateRecords == ""){
 $updateRecords = "s_d_platform = '".$platform."'";
 }else{
 $updateRecords .= ", s_d_platform = '".$platform."'";
 }
 }
 $version = (isset($_POST['version']) ? $_POST['version'] : "");
 $version_change = (isset($_POST['version_change']) && !empty($_POST['version_change']) ? $_POST['version_change'] : "0");
 if($version_change == "1"){
 if($auditlogDesc == ""){
 $auditlogDesc = "Version";
 }else{
 $auditlogDesc .= ", Version";
 }
 if($updateRecords == ""){
 $updateRecords = "s_d_version = '".$version."'";
 }else{
 $updateRecords .= ", s_d_version = '".$version."'";
 }
 }

$priority = (isset($_POST['priority']) ? $_POST['priority'] : "");
$priority_change = (isset($_POST['priority_change']) && !empty($_POST['priority_change']) ? $_POST['priority_change'] : "0");
if($priority_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "Priority";
	}else{
		$auditlogDesc .= ", Priority";
	}
	if($updateRecords == ""){
		$updateRecords = "s_d_priority = '".$priority."'";
	}else{
		$updateRecords .= ", s_d_priority = '".$priority."'";
	}
}

$defecttypeId = (isset($_POST['defecttypeId'])  && !empty($_POST['defecttypeId']) ? $_POST['defecttypeId'] : "0");
$defecttypeId_change = (isset($_POST['defecttypeId_change']) && !empty($_POST['defecttypeId_change']) ? $_POST['defecttypeId_change'] : "0");
if($defecttypeId_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "Defect type";
	}else{
		$auditlogDesc .= ", Defect type";
	}
	if($updateRecords == ""){
		$updateRecords = "defecttypeId = '".$defecttypeId."'";
	}else{
		$updateRecords .= ", defecttypeId = '".$defecttypeId."'";
	}
}

$defectstatusId = (isset($_POST['defectstatusId'])   && !empty($_POST['defectstatusId']) ? $_POST['defectstatusId'] : "0");
$defectstatusId_change = (isset($_POST['defectstatusId_change'])   && !empty($_POST['defectstatusId_change']) ? $_POST['defectstatusId_change'] : "0");
if($defectstatusId_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "Defect status";
	}else{
		$auditlogDesc .= ", Defect status";
	}
	if($updateRecords == ""){
		$updateRecords = "defectstatusId = '".$defectstatusId."'";
	}else{
		$updateRecords .= ", defectstatusId = '".$defectstatusId."'";
	}
}

$shortdesc = (isset($_POST['shortdesc']) ? mysqli_real_escape_string($conn,sanitize($_POST['shortdesc'])) : "");
$shortdesc_change = (isset($_POST['shortdesc_change'])   && !empty($_POST['shortdesc_change']) ? $_POST['shortdesc_change'] : "0");
if($shortdesc_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "Short description";
	}else{
		$auditlogDesc .= ", Short description";
	}
	if($updateRecords == ""){
		$updateRecords = "s_d_shortdesc = '".$shortdesc."'";
	}else{
		$updateRecords .= ", s_d_shortdesc = '".$shortdesc."'";
	}
}

$longdesc = (isset($_POST['longdesc']) ? mysqli_real_escape_string($conn,sanitize($_POST['longdesc'])) : "");
$longdesc_change = (isset($_POST['longdesc_change']) && !empty($_POST['longdesc_change'])  ? $_POST['longdesc_change'] : "0");
if($longdesc_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "Detailed Description";
	}else{
		$auditlogDesc .= ", Detailed Description";
	}
	if($updateRecords == ""){
		$updateRecords = "s_d_longdesc = '".$longdesc."'";
	}else{
		$updateRecords .= ", s_d_longdesc = '".$longdesc."'";
	}
}

$testdata = (isset($_POST['testdata']) ? mysqli_real_escape_string($conn,sanitize($_POST['testdata'])) : "");
$testdata_change = (isset($_POST['testdata_change']) && !empty($_POST['testdata_change'])  ? $_POST['testdata_change'] : "0");
if($testdata_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "Testdata";
	}else{
		$auditlogDesc .= ", Testdata";
	}
	if($updateRecords == ""){
		$updateRecords = "s_d_testdata = '".$testdata."'";
	}else{
		$updateRecords .= ", s_d_testdata = '".$testdata."'";
	}
}

$steps = (isset($_POST['steps']) ? mysqli_real_escape_string($conn,sanitize($_POST['steps'])) : "");
$steps_change = (isset($_POST['steps_change']) ? $_POST['steps_change'] : "0");
if($steps_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "Steps";
	}else{
		$auditlogDesc .= ", Steps";
	}
	if($updateRecords == ""){
		$updateRecords = "s_d_steps = '".$steps."'";
	}else{
		$updateRecords .= ", s_d_steps = '".$steps."'";
	}
}

$expectedresult = (isset($_POST['expectedresult']) ? mysqli_real_escape_string($conn,sanitize($_POST['expectedresult'])) : "");
$expectedresult_change = (isset($_POST['expectedresult_change']) ? $_POST['expectedresult_change'] : "0");
if($expectedresult_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "Expected Result";
	}else{
		$auditlogDesc .= ", Expected Result";
	}
	if($updateRecords == ""){
		$updateRecords = "s_d_expectedresult = '".$expectedresult."'";
	}else{
		$updateRecords .= ", s_d_expectedresult = '".$expectedresult."'";
	}
}

$actualresult = (isset($_POST['actualresult']) ? mysqli_real_escape_string($conn,sanitize($_POST['actualresult'])) : "");
$actualresult_change = (isset($_POST['actualresult_change']) ? $_POST['actualresult_change'] : "0");
if($actualresult_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "Actual Result";
	}else{
		$auditlogDesc .= ", Actual Result";
	}
	if($updateRecords == ""){
		$updateRecords = "s_d_actualresult = '".$actualresult."'";
	}else{
		$updateRecords .= ", s_d_actualresult = '".$actualresult."'";
	}
}

$comment = (isset($_POST['comment']) ? mysqli_real_escape_string($conn,$_POST['comment']) : "");

$filename = "";
$filepath = "";

$defectId = 0;
$defectIdstr = "";
$projcode = "";
$defectdata = mysqli_query($conn,"SELECT * from s_defect where s_d_id = '".$id."' and accountId = '".$accountId."'  order by s_d_id desc limit 1");
if(mysqli_num_rows($defectdata)>0){

	while($rdata = mysqli_fetch_assoc($defectdata)){
		$defectIdstr = $rdata['s_d_defectnum'] ;
	}
}

if($projectId_change == "1"){
	$projsqldata = mysqli_query($conn,"SELECT * from s_project where s_p_id = '".$projectId."' and accountId = '".$accountId."'  order by s_p_id desc limit 1");
	if(mysqli_num_rows($projsqldata)>0){

		while($pdata = mysqli_fetch_assoc($projsqldata)){
			$projcode = $pdata['s_p_code'];
		}


		$defectsqldata = mysqli_query($conn,"SELECT * from s_defect where projectId = '".$projectId."' and accountId = '".$accountId."'  order by s_d_tempid desc limit 1");
		if(mysqli_num_rows($defectsqldata)>0){

			while($rdata = mysqli_fetch_assoc($defectsqldata)){
				$defectId = (int)$rdata['s_d_tempid'] +1;
			}
		}else{
			$defectId = 1;
		}
		$defectIdstr = "$projcode-D$defectId";

		if($auditlogDesc == ""){
			$auditlogDesc = "Defect ID";
		}else{
			$auditlogDesc .= ", Defect ID";
		}

		if($updateRecords == ""){
			$updateRecords = "s_d_tempid = '".$defectId."', s_d_defectnum = '".$defectIdstr."'";
		}else{
			$updateRecords .= ", s_d_tempid = '".$defectId."', s_d_defectnum = '".$defectIdstr."'";
		}

	}
}


if(!empty($id) && $id !="0") {
 	if(isset($_FILES['fileToUpload']['name'])){
			
		if (!file_exists($CFG['dirroot'].'defectdata/'.$accountId.'/'.$id)) {

			mkdir($CFG['dirroot'].'defectdata/'.$accountId.'/'.$id, 0777, true);

		}
						
		// Count # of uploaded files in array
		$total = count($_FILES['fileToUpload']['name']);

		// Loop through each file
		for( $i=0 ; $i < $total ; $i++ ) {

			//Get the temp file path
			$tmpFilePath = $_FILES['fileToUpload']['tmp_name'][$i];

			//Make sure we have a file path
			if ($tmpFilePath != ""){
				//Setup our new file path
				$newFilePath = $CFG['dirroot'].'defectdata/'.$accountId.'/'.$id."/" . $_FILES['fileToUpload']['name'][$i];

				//Upload the file into the temp dir
				if(move_uploaded_file($tmpFilePath, $newFilePath)) {
			
					$attachmentsLogs[] = STEP_dir.'defectdata/'.$accountId.'/'.$id."/" . $_FILES['fileToUpload']['name'][$i];
					$attachfilename[] = $_FILES['fileToUpload']['name'][$i];
					//Handle other code here

				}
			}
		}

		if(isset($attachmentsLogs) && !empty($attachmentsLogs)){

			if($auditlogDesc == ""){
				$auditlogDesc = "Attachments";
			}else{
				$auditlogDesc .= ", Attachments";
			}
		}
	}
	// var_dump($updateRecords); die;
	if($updateRecords !="" || (isset($attachmentsLogs) && !empty($attachmentsLogs)) ){
		if($updateRecords !=""){
			//var_dump($updateRecords); die;
			$sql = "UPDATE s_defect SET  $updateRecords where s_d_id = ? ";
			//echo $sql;
			$stmt = mysqli_prepare($conn, $sql);
			mysqli_stmt_bind_param($stmt, "s", $id);
			mysqli_stmt_execute($stmt);
			mysqli_stmt_close($stmt);
		}

		if((isset($stmt) && $stmt) || (isset($attachmentsLogs) && !empty($attachmentsLogs))){
			$newFlag = 0;
			$msgarr["status"] = "Success";
			$msgarr["message"] = "Defect updated successfully.";
			if($emailids !=""){
				$notificationSql = "insert into s_notifications (`s_n_viewer`, `s_n_employees`,`s_n_assignto`, `s_n_recordid`,`s_n_recordnum`,`s_n_desc`,`s_n_attachments`,`s_n_filename`,`accountId`,`s_n_enteredby`,s_n_newflag ,s_n_emailflag ) values (NULL,'".$empids."','0','".$id."','".$defectIdstr."','".$auditlogDesc."','".(implode(",", $attachmentsLogs))."','".(implode(",", $attachfilename))."','".$accountId."','".$enteredby."','".$newFlag."','0') ";
				
				mysqli_query( $conn, $notificationSql);
			}

			if($assignto_change == "1"  && $assignto !="0"){
				$history = "insert into s_defectassignmenthistory (`defectId`, `s_dh_assignto`, `s_dh_enteredby` ,`accountId`) values ('".$id."','".$assignto."','".$enteredby."','".$accountId."') ";
				
				mysqli_query( $conn, $history);

			}
			if($auditlogDesc != ""){
				$auditlogSql = "insert into s_auditlogs (`s_a_desc`, `s_a_module`, `s_a_enteredby`,`accountId`,`s_a_recordId`,`s_a_recordnum` ) values ('".$auditlogDesc."','Defect','".$enteredby."','".$accountId."','".$id."','".$defectIdstr."') ";
				
				mysqli_query( $conn, $auditlogSql);


			}
		}else{
			$msgarr["status"] = "Error";
			$msgarr["message"] = "Something went wrong. Please try again.";
		}
	}else{

			$msgarr["status"] = "Success";
			$msgarr["message"] = "Defect updated successfully.";
	}
	
}else{

	// Prepare the SQL statement with placeholders
	$sql = "INSERT INTO s_defect (
		projectId, releaseId, testcaseId, s_d_tempid, s_d_defectnum, s_d_module, s_d_submodule, 
		defecttypeId, s_d_severity, s_d_priority, defectstatusId, s_d_assignto, s_d_assigntorole, s_d_shortdesc, 
		s_d_longdesc, s_d_testdata, s_d_steps, s_d_expectedresult, s_d_actualresult, s_d_comment, 
		s_d_enteredby, accountId,s_d_platform,s_d_environment,s_d_version
	) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,?,?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

	// Prepare the statement
	$stmt = mysqli_prepare($conn, $sql);

	// Bind parameters to the statement
	mysqli_stmt_bind_param(
		$stmt, 
		"sssssssssssssssssssssssss", 
		$projectId, $releaseId, $testcaseId, $defectId, $defectIdstr, $module, $submodule, 
		$defecttypeId, $severity, $priority, $defectstatusId, $assignto, $assigntorole, $shortdesc, 
		$longdesc, $testdata, $steps, $expectedresult, $actualresult, $comment, 
		$enteredby, $accountId,$platform,$environment,$version
	);

	// Execute the statement
	$dresult =mysqli_stmt_execute($stmt);
	if($dresult){
		$newFlag = 1;
		$msgarr["status"] = "Success";
			$msgarr["message"] = "Defect added successfully.";
		$insertid = mysqli_insert_id($conn);

		if($assignto_change == "1" && $assignto !="0"){
			$history = "insert into s_defectassignmenthistory (`defectId`, `s_dh_assignto`, `s_dh_enteredby`,`accountId` ) values ('".$insertid."','".$assignto."','".$enteredby."','".$accountId."') ";
			
			mysqli_query( $conn, $history);

		}
		$auditlogDesc = "New defect created.";
		// if($auditlogDesc != ""){
			$auditlogSql = "insert into s_auditlogs (`s_a_desc`, `s_a_module`, `s_a_enteredby`,`accountId`,`s_a_recordId`,`s_a_recordnum`  ) values ('".$auditlogDesc."','Defect','".$enteredby."','".$accountId."','".$insertid."','".$defectIdstr."') ";
			
			mysqli_query( $conn, $auditlogSql);

		// }
		if(isset($_FILES['fileToUpload']['name'])){
			//echo "aditya";exit;
			if (!file_exists($CFG['dirroot'].'defectdata/'.$accountId.'/'.$insertid)) {
				mkdir($CFG['dirroot'].'defectdata/'.$accountId.'/'.$insertid, 0777, true);
			}
						
			// Count # of uploaded files in array
			$total = count($_FILES['fileToUpload']['name']);

			// Loop through each file
			for( $i=0 ; $i < $total ; $i++ ) {

			//Get the temp file path
			$tmpFilePath = $_FILES['fileToUpload']['tmp_name'][$i];

			//Make sure we have a file path
			if ($tmpFilePath != ""){
				//Setup our new file path
				$newFilePath = $CFG['dirroot'].'defectdata/'.$accountId.'/'.$insertid."/" . $_FILES['fileToUpload']['name'][$i];

				//Upload the file into the temp dir
				if(move_uploaded_file($tmpFilePath, $newFilePath)) {
						$attachmentsLogs[] = STEP_dir.'defectdata/'.$accountId.'/'.$insertid."/" . $_FILES['fileToUpload']['name'][$i];
						$attachfilename[] = $_FILES['fileToUpload']['name'][$i];

				//Handle other code here

				}
			}
			}
		}
		if($emailids !=""){
			$notificationSql = "insert into s_notifications (`s_n_viewer`, `s_n_employees`,`s_n_assignto`, `s_n_recordid`,`s_n_recordnum`,`s_n_desc`,`s_n_attachments`,`s_n_filename`,`accountId`,`s_n_enteredby` ,`s_n_newflag`,`s_n_emailflag` ) values (NULL,'".$empids."','0','".$insertid."','".$defectIdstr."','".$auditlogDesc."','".(implode(",", $attachmentsLogs))."','".(implode(",", $attachfilename))."','".$accountId."','".$enteredby."','".$newFlag."','0') ";
			
			mysqli_query( $conn, $notificationSql);

		}
		
		mysqli_stmt_close($stmt);
	}else{
		$msgarr["status"] = "Error";
		$msgarr["message"] = "Something went wrong. Please try again.";
	}
}
}

function sendEmail($nEmailids,$ndefectnum,$nauditlogDesc,$ndefectId,$nattachmentsLogs,$nattachfilename,$nFlag){
	global $conn,$accountId;

	$emailarr = explode(",", $nEmailids);
	if(count($emailarr) >0){

		$emailsqldata = mysqli_query($conn,"SELECT *  from s_emailsetting where accountId = '".$accountId."' order by s_es_id desc limit 1");
		$e_host = "";
		$e_port = "";
		$e_fromname = "";
		$e_username = "";
		$e_password = "";
		$e_id = 0;

		while($data = mysqli_fetch_assoc($emailsqldata)){
		$e_host = $data['s_es_host'];
		$e_port =  $data['s_es_port'];
		$e_fromname =  $data['s_es_fromname'];
		$e_username =  $data['s_es_username'];
		$e_password =  $data['s_es_password'];
		$e_id =  $data['s_es_id'];

		}
		$subject = "STEP - Defect Details";
		$mail             = new PHPMailer(); // defaults to using php "mail()"
 
		$mail->IsSMTP(); // enable SMTP
		$mail->IsHTML(true);
		$mail->SMTPDebug  = 1;                     // enables SMTP debug information (for testing)
		$mail->SMTPAuth   = true;                  // enable SMTP authentication
		$mail->SMTPSecure = "ssl";                 // sets the prefix to the servier
		$mail->Host       = "$e_host";      // sets GMAIL as the SMTP server
		$mail->Port       = $e_port;   // set the SMTP port for the GMAIL server
		$mail->SMTPKeepAlive = true;
		$mail->Mailer = "smtp";
		$msgbody = "Hi,<br/><br/>User has change $nauditlogDesc in defect $ndefectnum. Please click on the following link by login to your account.<br/><br/>
		<a href='".STEP_root."master/defectdetails.php?id=$ndefectId' >$ndefectnum</a>";
		if($nFlag == 1){
			$msgbody =  "Hi,<br/><br/>New defect added $ndefectnum. Please click on the following link by login to your account.<br/><br/>
		<a href='".STEP_root."master/defectdetails.php?id=$ndefectId' >$ndefectnum</a>";
		}
		$body             = $msgbody;
		$mail->Username   = "$e_username";  // GMAIL username
		$mail->Password   = "$e_password"     ;       // GMAIL password

		$mail->SetFrom("$e_username", "$e_fromname");

		$len = count($emailarr);
		for($i=0; $i< $len; $i++){

		$mail->AddAddress(trim($emailarr[$i]));
		}
		
		$attachmentlen = count($nattachmentsLogs);
		for($i=0; $i< $attachmentlen; $i++){
			if (file_exists($nattachmentsLogs[$i])) {
			$mail->AddAttachment($nattachmentsLogs[$i],$nattachfilename[$i]);
			}
		}
		$mail->Subject    = "$subject";

		$mail->AltBody    = "To view the message, please use an HTML compatible email viewer!"; // optional, comment out and test

		$mail->MsgHTML($body);

		if(!$mail->Send()) {
			return 1;
		} else {
			return 0;
		}
	}

}

echo json_encode($msgarr);
