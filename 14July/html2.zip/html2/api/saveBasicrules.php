<?php
include('config.php');
session_start();
 
$enteredby = 0;
 

if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
}
if($_SERVER['REQUEST_METHOD'] === 'POST'){

    $id = (isset($_POST['ruleId']) ? $_POST['ruleId'] : "0");
    $moduleId = (isset($_POST['moduleId']) ? $_POST['moduleId'] : "0");
    $rulename = (isset($_POST['rulename']) ? $_POST['rulename'] : "");
    $activestatus = (isset($_POST['activestatus']) ? $_POST['activestatus'] : "");

    if (!empty($id) && $id != "0") {
        // Update existing record
        $sql = "UPDATE s_basic_rules SET s_br_name = ?, moduleId = ?, s_br_activestatus = ? WHERE s_br_id = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "sisi", $rulename, $moduleId, $activestatus, $id);
        mysqli_stmt_execute($stmt)
    } else {
        // Insert new record
        $sql = "INSERT INTO s_basic_rules (s_br_name, moduleId, s_br_activestatus, s_br_enteredby) VALUES (?, ?, ?, ?)";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "sisi", $rulename, $moduleId, $activestatus, $enteredby);
        mysqli_stmt_execute($stmt)
    }
    // Close the statement
    mysqli_stmt_close($stmt);
}