<?php

require 'vendor/autoload.php';
//require 'vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
 
//require 'PHPMailer/src/Exception.php';
//require 'PHPMailer/src/PHPMailer.php';
//require 'PHPMailer/src/SMTP.php';
 
$mail = new PHPMailer(true);
 
try {
    // Server settings
    $mail->isSMTP();
    $mail->Host       = '10.80.92.30'; // Outlook SMTP server
    //$mail->SMTPAuth   = true;
    $mail->SMTPAuth   = false;
    $mail->Username   = '';
    $mail->Password   = ''; // Your Outlook password or app password
    $mail->SMTPSecure = true; // 'tls';
    $mail->Port       = 587;
    $mail->SMTPDebug  = 3;
    $mail->SMTPAutoTLS=false;
    $mail->Debugoutput='html';
   // $mail->AuthType = 'PLAIN';
 
  //  $mail->SMTPOptions = [
    //    'ssl' => [
      //      'verify_peer'       => false,
        //    'verify_peer_name'  => false,
          //  'allow_self_signed' => true,
       // ],
   // ];
 
    // Recipients
    $mail->setFrom('JIRARBL@rblbank.com', 'test calibre');
    $mail->addAddress('dharmesh.wadavana@rblbank.com', 'Dharmesh');
 
    // Content
    $mail->isHTML(true);
    $mail->Subject = 'Test Email from PHPMailer';
    $mail->Body    = 'This is a test email sent using PHPMailer via Outlook SMTP. this mail from testcalibre UAT VM machine';
 
    $mail->send();
    echo 'Message has been sent successfully';
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}
?>
