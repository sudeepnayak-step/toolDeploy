<?php
include('config.php');
session_start();
 
$enteredby = 0;$accountId=0;$userempid = 0;
    /** This PHP script retrieves the test suite data from a database. 
 * It formats the data and returns it in JSON format. */


if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
}
if(isset($_SESSION["usertype"]) && $_SESSION["usertype"] == "Employee"){
	if(isset($_SESSION["userempid"])){
    $userempid = $_SESSION["userempid"];
}
}

$where = "";

// $projectId = (isset($_POST['projectId']) && !empty($_POST['projectId'])? implode(",", $_POST['projectId']) : "");
// $releaseId = (isset($_POST['releaseId'])  && !empty($_POST['releaseId'])? implode(",", $_POST['releaseId']) : "");
// $activityId = (isset($_POST['activityId'])  && !empty($_POST['activityId'])? implode(",", $_POST['activityId']) : "");
// $testsuiteId = (isset($_POST['testsuiteId'])  && !empty($_POST['testsuiteId'])? implode(",", $_POST['testsuiteId']) : "");

$projectIdStr = isset($_POST['projectId']) && !empty($_POST['projectId']) ? array_map('sanitize', $_POST['projectId']) : [];
$projectId = implode(",", $projectIdStr);

$releaseIdStr = isset($_POST['releaseId']) && !empty($_POST['releaseId']) ? array_map('sanitize', $_POST['releaseId']) : [];
$releaseId = implode(",", $releaseIdStr);

$activityIdStr = isset($_POST['activityId']) && !empty($_POST['activityId']) ? array_map('sanitize', $_POST['activityId']) : [];
$activityId = implode(",", $activityIdStr);

$testsuiteIdStr = isset($_POST['testsuiteId']) && !empty($_POST['testsuiteId']) ? array_map('sanitize', $_POST['testsuiteId']) : [];
$testsuiteId = implode(",", $testsuiteIdStr);

// Build the WHERE clause dynamically
$params = [];
$types = "";
$projarr['data'] = array();
if ($projectId != "") {
    $where .= " AND find_in_set(ts.projectId,?) ";
    $params[] = $projectId;
    $types .= "s";
}else{
    echo json_encode([
        "draw" => intval($_POST['draw']),
        "recordsTotal" => 0,
        "recordsFiltered" => 0, // modify if search applied
        "data" => $projarr['data']
    ]);
        // echo json_encode($projarr);
        die;
}


if ($releaseId != "") {
    $where .= " AND find_in_set(ts.releaseId,?) ";
    $params[] = $releaseId;
    $types .= "s";
}

if ($activityId != "") {
    $where .= " AND find_in_set(ts.activityId,?) ";
    $params[] = $activityId;
    $types .= "s";
}

if ($testsuiteId != "") {
    $where .= " AND find_in_set(ts.s_ts_id,?) ";
    $params[] = $testsuiteId;
    $types .= "s";
}
if (isset($_SESSION["usertype"]) && $_SESSION["usertype"] != "Admin") {
    $where .= " AND ts.projectId IN (SELECT s_p_id FROM s_project WHERE s_p_id IN (SELECT projectId FROM s_project_members WHERE employeeId = ? AND accountId = ?) OR s_p_enteredby = ? AND accountId = ?)";
    $params[] = $userempid;
    $params[] = $accountId;
    $params[] = $enteredby;
    $params[] = $accountId;
    $types .= "ssss";
}


// Collect DataTables parameters
$start  = $_POST['start'];
$length = $_POST['length'];
$searchValue = $_POST['search']['value'] ?? '';
$orderColumn = $_POST['order'][0]['column'] ?? 0;
$orderDir    = $_POST['order'][0]['dir'] ?? 'asc';



// COUNT total records
$countSql = "SELECT COUNT(1) as total FROM s_testsuite ts 
 WHERE ts.accountId = ? $where ";
// Prepare statement
$countstmt = mysqli_prepare($conn, $countSql);
	
mysqli_stmt_bind_param($countstmt, "i" . $types, $accountId, ...$params);
mysqli_stmt_execute($countstmt);
$countResult = mysqli_stmt_get_result($countstmt);

$totalRecords = 0;
while($cdata = mysqli_fetch_assoc($countResult)){
$totalRecords = $cdata['total'];
}

if (!empty($searchValue)) {
    $searchValue = $conn->real_escape_string($searchValue);
    $where .= " AND (s_ts_name LIKE '%$searchValue%' 
                     OR s_ts_testsuitenum LIKE '%$searchValue%'
                     OR p.s_p_name LIKE '%$searchValue%' 
                     OR r.s_r_name LIKE '%$searchValue%' 
                     OR a.s_a_name LIKE '%$searchValue%'
                     OR s_ts_type LIKE '%$searchValue%'
                     OR s_ts_description LIKE '%$searchValue%'
                     OR CONCAT(IFNULL(a1.s_e_fname,''), ' ', IFNULL(a1.s_e_mname,''), ' ', IFNULL(a1.s_e_lname,'')) LIKE '%$searchValue%'
					 )";
}


// Prepare the SQL query for filter
$sql = "SELECT count(1) as filterrows
        from s_testsuite ts 
		join s_project p on p.s_p_id = ts.projectId 
		join s_activitymaster a on a.s_a_id = ts.activityId 
		join s_release r on r.s_r_id = ts.releaseId 
		left JOIN s_employees a1 on a1.s_e_id = ts.s_ts_assignto and ts.s_ts_assignto !='0' 
        WHERE ts.accountId = ? $where 
        
        ";
        // DATE_FORMAT(CONVERT_TZ(s_d_createdtime, 'UTC', 'Asia/Kolkata'), '%Y-%m-%d %l:%i %p') as createdtime,
        // DATE_FORMAT(CONVERT_TZ(s_d_updatetime, 'UTC', 'Asia/Kolkata'), '%Y-%m-%d %l:%i %p') as updatetime 

// Prepare statement
$filterstmt = mysqli_prepare($conn, $sql);
	
mysqli_stmt_bind_param($filterstmt, "i" . $types, $accountId, ...$params);
mysqli_stmt_execute($filterstmt);
$filterresult = mysqli_stmt_get_result($filterstmt);

$filterrows = 0;
while($fdata = mysqli_fetch_assoc($filterresult)){
$filterrows = $fdata['filterrows'];
}

$sql = "SELECT ts.*,
	concat(IFNULL(a1.s_e_fname,''),' ',IFNULL(a1.s_e_mname,''),' ',IFNULL(a1.s_e_lname,'')) as assignto,
	IFNULL(p.s_p_name,'') as projectname,
	IFNULL(r.s_r_name,'') as releaseNum,
	IFNULL(a.s_a_name,'') as activityname,
	IFNULL(a.s_a_code,'') as activitycode from s_testsuite ts 
	join s_project p on p.s_p_id = ts.projectId 
	join s_activitymaster a on a.s_a_id = ts.activityId 
	join s_release r on r.s_r_id = ts.releaseId 
 	left JOIN s_employees a1 on a1.s_e_id = ts.s_ts_assignto and ts.s_ts_assignto !='0' 
	WHERE ts.accountId = ? $where 
	
	ORDER BY ts.s_ts_id $orderDir LIMIT $start, $length";


$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i" . $types, $accountId, ...$params);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$projarr['data'] = array();
while($data = mysqli_fetch_assoc($result)){
	$projarr['data'][] = array($data['s_ts_id'],$data['s_ts_name'],
		$data['s_ts_testsuitenum'],$data['projectname'],$data['releaseNum'],$data['activityname'],	
		(!empty(trim($data['assignto'])) ? $data['assignto'] : "-"),
		(!empty($data['s_ts_type']) ? $data['s_ts_type'] : "-"),
		(!empty($data['s_ts_description']) ? $data['s_ts_description'] : "-"),
		$data['s_ts_id']);
}
// Return JSON response
echo json_encode([
    "draw" => intval($_POST['draw']),
    "recordsTotal" => $totalRecords,
    "recordsFiltered" => $filterrows, // modify if search applied
    "data" => $projarr['data']
]);
// echo json_encode($projarr);
?>
