<?php
header('Access-Control-Allow-Origin: *');
include('config.php');
 /** This PHP script retrieves the role data from a database. 
 * It formats the data and returns it in JSON format. */

 
$enteredby = (isset($_POST["enteredby"]) && !empty($_POST["enteredby"]) ? $_POST["enteredby"] : 0);
$accountId = (isset($_POST["accountId"]) && !empty($_POST["accountId"]) ? $_POST["accountId"] : 0);
$userempid = (isset($_POST["userempid"]) && !empty($_POST["userempid"])  ? $_POST["userempid"] : 0);

$roleId = (isset($_POST['id']) ? intval($_POST['id']) : 0);
$permissions = array();

$stmt = mysqli_prepare($conn,"SELECT * from s_role_management where roleId = ? and accountId = ? order by s_rm_id asc");
mysqli_stmt_bind_param($stmt, "ii", $roleId, $accountId);
mysqli_stmt_execute($stmt);
$chkpermissison = mysqli_stmt_get_result($stmt);
while($pdata = mysqli_fetch_assoc($chkpermissison)){
	$permissions = explode(",", $pdata['ruleIds']);
}

$card = "";
$projarr['data'] = array();
$rstmt = mysqli_prepare($conn, "SELECT * FROM s_rule_module WHERE s_rm_activestatus = ? ORDER BY s_rm_id ASC");
$status = "Active";
mysqli_stmt_bind_param($rstmt, "s", $status);
mysqli_stmt_execute($rstmt);
$sqldata = mysqli_stmt_get_result($rstmt);

while($data = mysqli_fetch_assoc($sqldata)){
	$moduleId = $data['s_rm_id'];
	$modulename = $data['s_rm_name'];

    // Fetch basic rules using prepared statement
    $stmt = mysqli_prepare($conn, "SELECT * FROM s_basic_rules WHERE s_br_activestatus = 'Active' AND moduleId = ? ORDER BY s_br_id ASC");
    mysqli_stmt_bind_param($stmt, "i", $moduleId);
    mysqli_stmt_execute($stmt);
    $basicsql = mysqli_stmt_get_result($stmt);


	$litag = "";
	$selectallflag = "checked";
	while($basicdata = mysqli_fetch_assoc($basicsql)){
		$ruleId = $basicdata['s_br_id'];
		$basicrule = $basicdata['s_br_name'];
		$checkval = "";
		if(in_array($ruleId, $permissions)){
			$checkval = "checked";
		}else{
			$selectallflag = "";
		}
		$litag .= '<li class="list-group-item">
                         '.$basicrule.'
                        <div class="custom-control custom-checkbox pull-right">
                            <input type="checkbox" class="custom-control-input" id="rule'.$ruleId.'" data-id="'.$ruleId.'" data-moduleid ="'.$moduleId.'" '.$checkval.'>
                            <label class="custom-control-label" for="rule'.$ruleId.'">&nbsp;</label>
                        </div>
                    </li>';
	}
	$card .= '<div class="col-md-3">
                <div class="card">
                    <div class="card-header bg-step">
                        <strong class="card-title">'.$modulename.'</strong>
                        <div class="custom-control custom-checkbox pull-right">
                            <input type="checkbox" class="custom-control-input" id="module'.$moduleId.'" data-id="'.$moduleId.'" name="module'.$moduleId.'" '.$selectallflag.'>
                            <label class="custom-control-label" for="module'.$moduleId.'">&nbsp;</label>
                        </div>
                    </div>
                        <ul class="list-group list-group-flush">
                            '.$litag.'                                   
                        </ul>
                </div>
            </div>';

}

echo $card;
?>