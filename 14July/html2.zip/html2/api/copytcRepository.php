<?php
include('config.php');
session_start();
/***
script copies test cases from a repository table (s_tcrepository) to a test case table (s_testcase), inserts corresponding steps into s_testcase_steps, and updates/inserts records into s_testcasefinal based on activity IDs. It dynamically selects source tables based on the repositorytype input. 
*/
$enteredby = 0;$accountId = 0;
 
$errormsg ="";
$msgarr = array();
$msgarr["status"] = "Error";
$msgarr["message"] = "Something went wrong. Please try again.";
if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
}
if($_SERVER['REQUEST_METHOD'] === 'POST'){

	$ids = (isset($_POST['ids']) ? $_POST['ids'] : "");
	$projectId = (isset($_POST['projectId']) ? $_POST['projectId'] : "0");
	$releaseId = (isset($_POST['releaseId']) ? $_POST['releaseId'] : "0");
	$assignto = (isset($_POST['assignto']) ? $_POST['assignto'] : "0");
	$activityId = (isset($_POST['activityId']) ? $_POST['activityId'] : array());

	$table = "s_tcrepository";
	$steptable = "s_tcrepository_steps";

	$allowedTables = [
		'Banking' => ['s_tcrepository', 's_tcrepository_steps'],
		'Automative' => ['s_tcrepository1', 's_tcrepository_steps1'],
		'HR' => ['s_tcrepository2', 's_tcrepository_steps2'],
		'Insurance' => ['s_tcrepository3', 's_tcrepository_steps3'],
	];
	
	$tctype = isset($_POST['repositorytype']) ? $_POST['repositorytype'] : 'Banking';
	if (array_key_exists($tctype, $allowedTables)) {
		$table = $allowedTables[$tctype][0];
		$steptable = $allowedTables[$tctype][1];
	}

	$arr = explode(",", $ids);
	for($i=0; $i<count($arr); $i++){
		$tcid = $arr[$i];

		$testcaseNum = 0;
		$testcaseIdstr = "";
		$projcode = "";
		$projsqldata = mysqli_query($conn,"SELECT * from s_project where s_p_id = '".$projectId."' and accountId = '".$accountId."' order by s_p_id desc limit 1");
		if(mysqli_num_rows($projsqldata)>0){

			while($pdata = mysqli_fetch_assoc($projsqldata)){
				$projcode = $pdata['s_p_code'];
			}


			$scenariosqldata = mysqli_query($conn,"SELECT * from s_testcase where projectId = '".$projectId."' and accountId = '".$accountId."'  order by s_d_tempscenarioId desc limit 1");
			if(mysqli_num_rows($scenariosqldata)>0){

				while($rdata = mysqli_fetch_assoc($scenariosqldata)){
					$scenarioId = (int)$rdata['s_d_tempscenarioId'] +1;
				}
			}else{
				$scenarioId = 1;
			}
			$scenarioIdstr = "TS-$scenarioId";


			$testnumsqldata = mysqli_query($conn,"SELECT * from s_testcase where projectId = '".$projectId."' and accountId = '".$accountId."'   order by s_t_tempid desc limit 1");

			if(mysqli_num_rows($testnumsqldata)>0){

				while($rdata = mysqli_fetch_assoc($testnumsqldata)){
					$testcaseNum = (int)$rdata['s_t_tempid'] +1;
				}
			}else{
				$testcaseNum = 1;
			}
			$testcaseIdstr = "TC-$testcaseNum";
		}

		// inserting into s_testcase
		$sql = "INSERT INTO s_testcase (projectId, releaseId, s_t_activityIds, s_d_tempscenarioId, s_t_testscenarionum, s_t_tempid, s_t_testcasenum, s_t_module, s_t_submodule, s_t_testscenariodesc, s_t_testcasedesc, s_t_steps, s_t_expectedresult, s_t_precondition, s_t_testdata, s_t_enteredby, accountId, s_t_testmode, s_t_assignto, s_t_author, s_t_reviewer) 
		SELECT ?, ?, ?, ?, ?, ?, ?, s_t_module, s_t_submodule, s_t_testscenariodesc, s_t_testcasedesc, s_t_steps, s_t_expectedresult, s_t_precondition, s_t_testdata, ?, ?, s_t_testmode, ?, s_t_author, s_t_reviewer 
		FROM $table WHERE s_t_id = ?";

		$stmt = mysqli_prepare($conn, $sql);
		mysqli_stmt_bind_param($stmt, "ssssssssssss", $projectId, $releaseId, implode(",", $activityId), $scenarioId, $scenarioIdstr, $testcaseNum, $testcaseIdstr, $enteredby, $accountId, $assignto, $tcid);
		mysqli_stmt_execute($stmt);

		if($stmt){
			$flag = 1;
			$testcaseId = mysqli_insert_id($conn);

			$sqldata = mysqli_query($conn,"SELECT *
				from ".$steptable." 
				where accountId = '".$accountId."'  and tcrepositoryId = '".$tcid."' 
				order by s_tss_id asc");

			$srno=0;
			while($data = mysqli_fetch_assoc($sqldata)){
				$s_desc = $data['s_tss_steps'];
				$s_result = $data['s_tss_expectedresult'];
				
				//inserting into s_testcase_steps
				$stepsql = "INSERT INTO s_testcase_steps (testcaseId, s_tss_steps, s_tss_expectedresult, accountId, s_tss_enteredby) VALUES (?, ?, ?, ?, ?)";
				$stmt = mysqli_prepare($conn, $stepsql);
				mysqli_stmt_bind_param($stmt, "sssss", $testcaseId, $s_desc, $s_result, $accountId, $enteredby);
				mysqli_stmt_execute($stmt);
			}
			if(isset($activityId) && !empty($activityId) && count($activityId) >0){

					$dsql = "update s_testcasefinal set s_f_activestatus = 'Inactive' where testcaseId = '".$testcaseId."'  and accountId = '".$accountId."' ";
					// //echo $sql;
					$dstmt = mysqli_query( $conn, $dsql);
					foreach ($activityId as $key => $value) {
						# code...

						$chksql = "select * from s_testcasefinal where testcaseId = '".$testcaseId."' and activityId = '".$value."' and accountId = '".$accountId."'  ";
						// echo $sql;
						$chkstmt = mysqli_query( $conn, $chksql);
						if(mysqli_num_rows($chkstmt) <=0){
							$msql = "insert into s_testcasefinal(testcaseId, `projectId`, `releaseId`, `activityId`, `s_f_testresult`, `s_f_actualresult`, `s_f_executiontime`, `defectId`, `s_f_enteredby`, `accountId`, `s_f_activestatus`) values('".$testcaseId."','".$projectId."','".$releaseId."','".$value."','Not Executed','',NULL,'0','".$enteredby."','".$accountId."','Active')";
							// echo $sql;
							$mstmt = mysqli_query( $conn, $msql);				
						}else{

							$finalsql = "update s_testcasefinal set s_f_activestatus = 'Active' where testcaseId = '".$testcaseId."' and activityId = '".$value."' and accountId = '".$accountId."' ";
							// //echo $sql;
							$dstmt = mysqli_query( $conn, $finalsql);
						}
					}
			}
		}else{
			$errormsg .= "Error ";
		}
	}


}


if($flag >0)
{
	$msgarr["status"] = "Success";
	$msgarr["message"] = "Testcase copied successfully.";
	if($errormsg !=""){
		$msgarr["message"] = "Some testcases copied successfully.";
	}
}
else
{
	$msgarr["status"] = "Error";
	$msgarr["message"] = "Something went wrong. Please try again.";
	if($errormsg !=""){
		$msgarr["message"] = "Testcases copied failed.";
	}
}

echo json_encode($msgarr);