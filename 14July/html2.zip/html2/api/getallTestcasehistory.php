<?php
include('config.php');
session_start();
 
$enteredby = 0;$accountId=0;
/**This PHP script retrieves test case execution data from a database based on a provided testexecutionId and accountId. 
 * The data is then formatted into a JSON response. */ 

if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
}


$testexecutionId = isset($_POST['testexecutionId']) ? intval($_POST['testexecutionId']) : 0;
$sql = "SELECT * from s_testcaserun 
	where  testexecutionId = ? and accountId= ? order by s_st_id desc";

$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "ii", $testexecutionId,$accountId);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
	

$projarr['data'] = array();
while($data = mysqli_fetch_assoc($result)){
	$projarr['data'][] = array($data['s_st_iteration'],$data['s_st_testresult'],$data['s_st_actualresult'],$data['s_st_exectionstart'],$data['s_st_executionend'],
		$data['s_st_executiontime'],$data['s_st_filepath']);
}

mysqli_stmt_close($stmt);
echo json_encode($projarr);
?>
