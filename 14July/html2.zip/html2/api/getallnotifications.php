<?php
include('config.php');
session_start();
 
$enteredby = 0;$accountId=0;$userempid = 0;
 
/** This script retrieves notifications for a specific employee within the last 7 days from the database and returns the data in JSON format. */
if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
}
if(isset($_SESSION["usertype"]) && $_SESSION["usertype"] == "Employee"){
	if(isset($_SESSION["userempid"])){
    $userempid = $_SESSION["userempid"];
}
}else if(isset($_SESSION["usertype"]) && $_SESSION["usertype"] == "Systemuser"){
	if(isset($_SESSION["userempid"])){
    $userempid = $_SESSION["userempid"];
    }
    $accountId = 0;
}

$projarr['data'] = array();
//Use prepared statements to prevent SQL injection
$query = "SELECT n.*, 
CONCAT(IFNULL(a1.s_e_fname,''),' ',IFNULL(a1.s_e_mname,''),' ',IFNULL(a1.s_e_lname,'')) as enteredby 
FROM s_notifications n 
LEFT JOIN s_employees a1 ON a1.userId = n.s_n_enteredby 
WHERE n.accountId = ? AND FIND_IN_SET(?, s_n_employees) 
AND `s_n_createdtime` >= DATE(NOW()) - INTERVAL 7 DAY 
ORDER BY n.s_n_id DESC";

// Prepare the statement
if ($stmt = mysqli_prepare($conn, $query)) {
    // Bind parameters to the query
    mysqli_stmt_bind_param($stmt, "ii", $accountId, $userempid);

    // Execute the query
    mysqli_stmt_execute($stmt);

    // Get the result
    $result = mysqli_stmt_get_result($stmt);

    $projarr['data'] = array();
    while ($data = mysqli_fetch_assoc($result)) {
        $newcount = 1;
        if (in_array($userempid, explode(",", $data['s_n_viewer']))) {
            $newcount = 0;
        }
        $projarr['data'][] = array(
            "id" => $data['s_n_id'],
            "desc" => $data['s_n_desc'],
            "createdtime" => $data['s_n_createdtime'],
            "enteredby" => (!empty(str_replace(' ', '', $data['enteredby'])) ? $data['enteredby'] : "Admin"),
            "recordid" => $data['s_n_recordid'],
            "recordnum" => $data['s_n_recordnum'],
            "recordflag" => $data['s_n_newflag'],
            "module" => $data['s_n_module'],
            "new" => $newcount
        );
    }

    // Close the statement
    mysqli_stmt_close($stmt);
} else {
    // Handle query preparation error
    die("Query preparation failed: " . mysqli_error($conn));
}

echo json_encode($projarr);
?>