<?php
header('Access-Control-Allow-Origin: *');
include('config.php');
/** delete user based on id */
$msgarr = array();
$msgarr["status"] = "Error";
$msgarr["message"] = "Something went wrong. Please try again.";
if($_SERVER['REQUEST_METHOD'] === 'POST'){

	$id = (isset($_POST['userId']) && !empty($_POST['userId']) ? $_POST['userId'] : "0");

	if(!empty($id) && $id !="0") {
		$sql = "DELETE FROM s_users WHERE s_u_id = ? ";
		$stmt = mysqli_prepare($conn, $sql);
		mysqli_stmt_bind_param($stmt, "ss", $id, $accountId);
		mysqli_stmt_execute($stmt);
		if($stmt)
		{
			$msgarr["status"] = "Success";
			$msgarr["message"] = "Project deleted successfully.";
		}
		else
		{
			$msgarr["status"] = "Error";
			$msgarr["message"] = "Something went wrong. Please try again.";
		}
	}
}
echo json_encode($msgarr);