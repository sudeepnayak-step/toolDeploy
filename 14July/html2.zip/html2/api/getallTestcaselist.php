<?php
include('config.php');
session_start();
 
$enteredby = 0;$accountId=0;$userempid = 0;
 /** This PHP script retrieves the testcase data from a database. 
 * It formats the data and returns it in JSON format. */


if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
    $userempid = $_SESSION["userempid"];
}


$where = "";
// $projectId = (isset($_POST['projectId']) && !empty($_POST['projectId']) ? implode(",", $_POST['projectId']) : "");
// $releaseId = (isset($_POST['releaseId'])  && !empty($_POST['releaseId'])? implode(",", $_POST['releaseId']) : "");
// $testcaseId = (isset($_POST['testcaseId'])  && !empty($_POST['testcaseId'])? implode(",", $_POST['testcaseId']) : "");
// $module = (isset($_POST['module'])  && !empty($_POST['module'])?implode(",", $_POST['module']) : "");
// $submodule = (isset($_POST['submodule'])  && !empty($_POST['submodule'])? implode(",", $_POST['submodule']) : "");
// $category = (isset($_POST['category'])  && !empty($_POST['category'])? implode(",", $_POST['category']) : "");

$projectIdStr = isset($_POST['projectId']) && !empty($_POST['projectId']) ? array_map('sanitize', $_POST['projectId']) : [];
$projectId = implode(",", $projectIdStr);

$releaseIdStr = isset($_POST['releaseId']) && !empty($_POST['releaseId']) ? array_map('sanitize', $_POST['releaseId']) : [];
$releaseId = implode(",", $releaseIdStr);

$testcaseIdStr = isset($_POST['testcaseId']) && !empty($_POST['testcaseId']) ? array_map('sanitize', $_POST['testcaseId']) : [];
$testcaseId = implode(",", $testcaseIdStr);

$moduleStr = isset($_POST['module']) && !empty($_POST['module']) ? array_map('sanitize', $_POST['module']) : [];
$module = implode(",", $moduleStr);

$submoduleStr = isset($_POST['submodule']) && !empty($_POST['submodule']) ? array_map('sanitize', $_POST['submodule']) : [];
$submodule = implode(",", $submoduleStr);

$categoryStr = isset($_POST['category']) && !empty($_POST['category']) ? array_map('sanitize', $_POST['category']) : [];
$category = implode(",", $categoryStr);

$projarr['data'] = array();
// Build the WHERE clause dynamically
$params = [];
$types = "";
$projarr['data'] = array();
if ($projectId != "") {
    $where .= " AND find_in_set(tc.projectId,?) ";
    $params[] = $projectId;
    $types .= "s";
}else{
    echo json_encode([
        "draw" => intval($_POST['draw']),
        "recordsTotal" => 0,
        "recordsFiltered" => 0, // modify if search applied
        "data" => $projarr['data']
    ]);
        // echo json_encode($projarr);
        die;
}

if ($releaseId != "") {
    $where .= " AND find_in_set(tc.releaseId,?) ";
    $params[] = $releaseId;
    $types .= "s";
}
if($testcaseId !=""){
	$testcaseIdarr = explode(",", $testcaseId);
	$testcaseId = "'" . implode ( "', '", $testcaseIdarr ) . "'";
	$where .= " and tc.s_t_testcasenum in ($testcaseId) ";
}
if($module !=""){
	$module = "'" . implode("','",explode(",",$module)) . "'";
	$where.=" and tc.s_t_module in ($module) ";
	
}
if($submodule !=""){
	$submodulearr = explode(",", $submodule);
	$submodule = "'" . implode ( "', '", $submodulearr ) . "'";
	$where .= " and tc.s_t_submodule in ($submodule) ";
}

if ($category != "") {
    $where .= " AND find_in_set(tc.s_t_category,?) ";
    $params[] = $category;
    $types .= "s";
}

if (isset($_SESSION["usertype"]) && $_SESSION["usertype"] != "Admin") {
    $where .= " AND tc.projectId IN (SELECT s_p_id FROM s_project WHERE s_p_id IN (SELECT projectId FROM s_project_members WHERE employeeId = ? AND accountId = ?) OR s_p_enteredby = ? AND accountId = ?)";
    $params[] = $userempid;
    $params[] = $accountId;
    $params[] = $enteredby;
    $params[] = $accountId;
    $types .= "ssss";
}

// Collect DataTables parameters
$start  = $_POST['start'];
$length = $_POST['length'];
$searchValue = $_POST['search']['value'] ?? '';
$orderColumn = $_POST['order'][0]['column'] ?? 0;
$orderDir    = $_POST['order'][0]['dir'] ?? 'asc';

// COUNT total records
$countSql = "SELECT COUNT(1) as total FROM s_testcase tc
 WHERE tc.accountId = ? $where ";
// Prepare statement
$countstmt = mysqli_prepare($conn, $countSql);
	
mysqli_stmt_bind_param($countstmt, "i" . $types, $accountId, ...$params);
mysqli_stmt_execute($countstmt);
$countResult = mysqli_stmt_get_result($countstmt);

$totalRecords = 0;
while($cdata = mysqli_fetch_assoc($countResult)){
$totalRecords = $cdata['total'];
}

if (!empty($searchValue)) {
    $searchValue = $conn->real_escape_string($searchValue);
    $where .= " AND (s_t_testcasenum LIKE '%$searchValue%' 
                     OR r.s_r_name LIKE '%$searchValue%'
                     OR s_t_module LIKE '%$searchValue%'
                     OR s_t_testcasedesc LIKE '%$searchValue%'
					 OR (
						SELECT GROUP_CONCAT(s_a_name)
						FROM s_activitymaster
						WHERE FIND_IN_SET(s_a_id, tc.s_t_activityIds) AND accountId = '$accountId'
					) LIKE '%$searchValue%'
                     )";
}


// Prepare the SQL query for filter
$sql = "SELECT count(1) as filterrows
        FROM s_testcase tc 
		join s_project p on p.s_p_id = tc.projectId 
		join s_release r on r.s_r_id = tc.releaseId  
		left join s_tccategorymaster c on c.s_cat_id = tc.s_t_category 
		left JOIN s_employees a1 on a1.s_e_id = tc.s_t_assignto and tc.s_t_assignto !='0'
		left JOIN s_employees a2 on a2.userId = tc.s_t_author and tc.s_t_author !='0'
		left JOIN s_employees a3 on a3.s_e_id = tc.s_t_reviewer and tc.s_t_reviewer !='0'
		WHERE tc.accountId = ? $where 
        
        ";
		// echo $sql;
// Prepare statement
$filterstmt = mysqli_prepare($conn, $sql);
	
mysqli_stmt_bind_param($filterstmt, "i" . $types, $accountId, ...$params);
mysqli_stmt_execute($filterstmt);
$filterresult = mysqli_stmt_get_result($filterstmt);

$filterrows = 0;
while($fdata = mysqli_fetch_assoc($filterresult)){
$filterrows = $fdata['filterrows'];
}


$sql = "SELECT tc.*,
	concat(IFNULL(a1.s_e_fname,''),' ',IFNULL(a1.s_e_mname,''),' ',IFNULL(a1.s_e_lname,'')) as assignto,
	concat(IFNULL(a2.s_e_fname,''),' ',IFNULL(a2.s_e_mname,''),' ',IFNULL(a2.s_e_lname,'')) as author,
	concat(IFNULL(a3.s_e_fname,''),' ',IFNULL(a3.s_e_mname,''),' ',IFNULL(a3.s_e_lname,'')) as reviewer,
	IFNULL(p.s_p_name,'') as projectname,
	IFNULL(r.s_r_releaseId,'') as releaseNum,
	IFNULL(c.s_cat_name,'') as categoryname ,
	(
            SELECT GROUP_CONCAT(s_a_name)
            FROM s_activitymaster
            WHERE FIND_IN_SET(s_a_id, tc.s_t_activityIds) AND accountId = '$accountId'
        ) AS activityname
	from s_testcase tc 
	join s_project p on p.s_p_id = tc.projectId 
	join s_release r on r.s_r_id = tc.releaseId  
	left join s_tccategorymaster c on c.s_cat_id = tc.s_t_category 
 	left JOIN s_employees a1 on a1.s_e_id = tc.s_t_assignto and tc.s_t_assignto !='0'
 	left JOIN s_employees a2 on a2.userId = tc.s_t_author and tc.s_t_author !='0'
 	left JOIN s_employees a3 on a3.s_e_id = tc.s_t_reviewer and tc.s_t_reviewer !='0'
	where tc.accountId = ? $where
    ORDER BY tc.s_t_id $orderDir LIMIT $start, $length";
//echo $sql; die;

$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i" . $types, $accountId, ...$params);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

//$projarr['data'] = array();
while($data = mysqli_fetch_assoc($result)){

	$activityname = "";
	//if($data['s_t_activityIds'] !=""){
	//	$activityIds = mysqli_real_escape_string($conn, $data['s_t_activityIds']);
	//	$chksql = "SELECT IFNULL(GROUP_CONCAT(s_a_name),'') AS activityname FROM s_activitymaster WHERE s_a_id IN ($activityIds) AND accountId = ?";
	//	$chkstmt = mysqli_prepare($conn, $chksql);
	//	mysqli_stmt_bind_param($chkstmt, "i", $accountId);
	//	mysqli_stmt_execute($chkstmt);
	//	$chkresult = mysqli_stmt_get_result($chkstmt);
//
//		while($actdata = mysqli_fetch_assoc($chkresult)){
//			$activityname = $actdata['activityname'];
//		}
//	}

	$activityname = $data['activityname'];

	$author = "Admin";
	if(trim($data['author']) !=""){
		$author = $data['author'];
	}
	$projarr['data'][] = array($data['s_t_id'],$data['s_t_testcasenum'],$data['s_t_testscenarionum'],$data['projectname'],$data['releaseNum'],$activityname,$data['s_t_testmode'],$data['s_t_module'],$data['s_t_submodule'],		
		$data['assignto'],
		$author,
		$data['reviewer'],
		$data['s_t_testcasedesc'],
		$data['s_t_testscenariodesc'],
		$data['s_t_steps'],
		$data['s_t_expectedresult'],
		$data['s_t_precondition'],
		$data['s_t_testdata'],
		$data['s_t_comment'],
		$data['categoryname'],
		$data['s_t_id']);
}
// Return JSON response
echo json_encode([
    "draw" => intval($_POST['draw']),
    "recordsTotal" => $totalRecords,
    "recordsFiltered" => $filterrows, // modify if search applied
    "data" => $projarr['data']
]);
?>
