<?php
include('config.php');
//require_once('../PHPMailer/class.phpmailer.php');
session_start();
/** this script is saves the data to activity */ 
$enteredby = 0;$accountId = 0;

$msgarr = array();
 

if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
}
$updateRecords = "";$auditlogDesc = "";$emailids = "";$empids = "";
if($_SERVER['REQUEST_METHOD'] === 'POST'){

$id = (isset($_POST['projactivityId']) && !empty($_POST['projactivityId']) ? $_POST['projactivityId'] : "0");

$activityId = (isset($_POST['activityId']) && !empty($_POST['activityId']) ? $_POST['activityId'] : "0");
$activityId_change = (isset($_POST['activityId_change']) && !empty($_POST['activityId_change']) ? $_POST['activityId_change'] : "0");
if($activityId_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "Activity";
	}else{
		$auditlogDesc .= ", Activity";
	}
	if($updateRecords == ""){
		$updateRecords = "activityId = '".$activityId."'";
	}else{
		$updateRecords .= ", activityId = '".$activityId."'";
	}
}

$projectId = (isset($_POST['projectId']) && !empty($_POST['projectId']) ? $_POST['projectId'] : "0");
$projectId_change = (isset($_POST['projectId_change']) && !empty($_POST['projectId_change']) ? $_POST['projectId_change'] : "0");
if($projectId_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "Project";
	}else{
		$auditlogDesc .= ", Project";
	}
	if($updateRecords == ""){
		$updateRecords = "projectId = '".$projectId."'";
	}else{
		$updateRecords .= ", projectId = '".$projectId."'";
	}
}


$releaseId = (isset($_POST['releaseId']) && !empty($_POST['releaseId'])? $_POST['releaseId'] : "0");
$releaseId_change = (isset($_POST['releaseId_change']) && !empty($_POST['releaseId_change']) ? $_POST['releaseId_change'] : "0");
if($releaseId_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "Release";
	}else{
		$auditlogDesc .= ", Release";
	}
	if($updateRecords == ""){
		$updateRecords = "releaseId = '".$releaseId."'";
	}else{
		$updateRecords .= ", releaseId = '".$releaseId."'";
	}
}

$percompletion = (isset($_POST['percompletion'])  && !empty($_POST['percompletion'])? $_POST['percompletion'] : "0");
$percompletion_change = (isset($_POST['percompletion_change']) && !empty($_POST['percompletion_change']) ? $_POST['percompletion_change'] : "0");
if($percompletion_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "Completion %";
	}else{
		$auditlogDesc .= ", Completion %";
	}
	if($updateRecords == ""){
		$updateRecords = "s_pa_completion = '".$percompletion."'";
	}else{
		$updateRecords .= ", s_pa_completion = '".$percompletion."'";
	}
}

$projectactivitystatus = (isset($_POST['projectactivitystatus']) ? $_POST['projectactivitystatus'] : "");
$projectactivitystatus_change = (isset($_POST['projectactivitystatus_change']) && !empty($_POST['projectactivitystatus_change']) ? $_POST['projectactivitystatus_change'] : "0");
if($projectactivitystatus_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "Status";
	}else{
		$auditlogDesc .= ", Status";
	}
	if($updateRecords == ""){
		$updateRecords = "s_pa_status = '".$projectactivitystatus."'";
	}else{
		$updateRecords .= ", s_pa_status = '".$projectactivitystatus."'";
	}
}

$activestatus = (isset($_POST['activestatus']) ? $_POST['activestatus'] : "Active");
$activestatus_change = (isset($_POST['activestatus_change']) && !empty($_POST['activestatus_change']) ? $_POST['activestatus_change'] : "0");
if($activestatus_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "Active Status";
	}else{
		$auditlogDesc .= ", Active Status";
	}
	if($updateRecords == ""){
		$updateRecords = "s_pa_status = '".$activestatus."'";
	}else{
		$updateRecords .= ", s_pa_status = '".$activestatus."'";
	}
}


$planstartdate = (isset($_POST['planstartdate']) && !empty($_POST['planstartdate']) ? date('Y-m-d', strtotime(str_replace('/', '-', $_POST['planstartdate']))) : null);
$planstartdate_change = (isset($_POST['planstartdate_change']) && !empty($_POST['planstartdate_change']) ? $_POST['planstartdate_change'] : "0");
if($planstartdate_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "Plan Start Date";
	}else{
		$auditlogDesc .= ", Plan Start Date";
	}
	if($updateRecords == ""){
		$updateRecords = "s_pa_planstartdate = '".$planstartdate."'";
	}else{
		$updateRecords .= ", s_pa_planstartdate = '".$planstartdate."'";
	}
}


$planenddate = (isset($_POST['planenddate']) && !empty($_POST['planenddate']) ? date('Y-m-d', strtotime(str_replace('/', '-', $_POST['planenddate']))) : null);
$planenddate_change = (isset($_POST['planenddate_change']) && !empty($_POST['planenddate_change']) ? $_POST['planenddate_change'] : "0");
if($planenddate_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "Plan End Date";
	}else{
		$auditlogDesc .= ", Plan End Date";
	}
	if($updateRecords == ""){
		$updateRecords = "s_pa_planenddate = '".$planenddate."'";
	}else{
		$updateRecords .= ", s_pa_planenddate = '".$planenddate."'";
	}
}

$revisedenddate = (isset($_POST['revisedenddate']) && !empty($_POST['revisedenddate']) ?  date('Y-m-d', strtotime(str_replace('/', '-', $_POST['revisedenddate']))) : null);
$revisedenddate_change = (isset($_POST['revisedenddate_change']) && !empty($_POST['revisedenddate_change']) ? $_POST['revisedenddate_change'] : "0");
if($revisedenddate_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "Revised End Date";
	}else{
		$auditlogDesc .= ", Revised End Date";
	}
	if($updateRecords == ""){
		$updateRecords = "s_pa_revisedenddate = '".$revisedenddate."'";
	}else{
		$updateRecords .= ", s_pa_revisedenddate = '".$revisedenddate."'";
	}
}


$revisedstartdate = (isset($_POST['revisedstartdate']) && !empty($_POST['revisedstartdate']) ? date('Y-m-d', strtotime(str_replace('/', '-', $_POST['revisedstartdate']))) : null);
$revisedstartdate_change = (isset($_POST['revisedstartdate_change']) && !empty($_POST['revisedstartdate_change']) ? $_POST['revisedstartdate_change'] : "0");
if($revisedstartdate_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "Revised Start Date";
	}else{
		$auditlogDesc .= ", Revised Start Date";
	}
	if($updateRecords == ""){
		$updateRecords = "s_pa_revisedstartdate = '".$revisedstartdate."'";
	}else{
		$updateRecords .= ", s_pa_revisedstartdate = '".$revisedstartdate."'";
	}
}

$actualstartdate = (isset($_POST['actualstartdate']) && !empty($_POST['actualstartdate']) ? date('Y-m-d', strtotime(str_replace('/', '-', $_POST['actualstartdate']))) : null);
$actualstartdate_change = (isset($_POST['actualstartdate_change']) && !empty($_POST['actualstartdate_change']) ? $_POST['actualstartdate_change'] : "0");
if($actualstartdate_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "Actual Start Date";
	}else{
		$auditlogDesc .= ", Actual Start Date";
	}
	if($updateRecords == ""){
		$updateRecords = "s_pa_actualstartdate = '".$actualstartdate."'";
	}else{
		$updateRecords .= ", s_pa_actualstartdate = '".$actualstartdate."'";
	}
}

$actualenddate = (isset($_POST['actualenddate']) && !empty($_POST['actualenddate']) ? date('Y-m-d', strtotime(str_replace('/', '-', $_POST['actualenddate'] ))): null);
$actualenddate_change = (isset($_POST['actualenddate_change']) && !empty($_POST['actualenddate_change']) ? $_POST['actualenddate_change'] : "0");
if($actualenddate_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "Actual End Date";
	}else{
		$auditlogDesc .= ", Actual End Date";
	}
	if($updateRecords == ""){
		$updateRecords = "s_pa_actualenddate = '".$actualenddate."'";
	}else{
		$updateRecords .= ", s_pa_actualenddate = '".$actualenddate."'";
	}
}

// $owner = (isset($_POST['owner']) ? $_POST['owner'] : "0");
$projactivitydesc = (isset($_POST['projactivitydesc']) && !empty($_POST['projactivitydesc']) ? mysqli_real_escape_string($conn,sanitize($_POST['projactivitydesc'])) : "");
$projactivitydesc_change = (isset($_POST['projactivitydesc_change']) && !empty($_POST['projactivitydesc_change']) ? $_POST['projactivitydesc_change'] : "0");
if($projactivitydesc_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "Description";
	}else{
		$auditlogDesc .= ", Description";
	}
	if($updateRecords == ""){
		$updateRecords = "s_pa_desc = '".$projactivitydesc."'";
	}else{
		$updateRecords .= ", s_pa_desc = '".$projactivitydesc."'";
	}
}

$activestatus = (isset($_POST['activestatus']) && !empty($_POST['activestatus'])? $_POST['activestatus'] : "Active");
$activestatus_change = (isset($_POST['activestatus_change']) && !empty($_POST['activestatus_change']) ? $_POST['activestatus_change'] : "0");
if($activestatus_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "Active status";
	}else{
		$auditlogDesc .= ", Active status";
	}
	if($updateRecords == ""){
		$updateRecords = "s_pa_activestatus = '".$activestatus."'";
	}else{
		$updateRecords .= ", s_pa_activestatus = '".$activestatus."'";
	}
}

$assignto = (isset($_POST['assignto']) && !empty($_POST['assignto']) ?  $_POST['assignto'] : array());
$assignto_change = (isset($_POST['assignto_change']) && !empty($_POST['assignto_change']) ? $_POST['assignto_change'] : "0");
if($assignto_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "Assignment";
	}else{
		$auditlogDesc .= ", Assignment";
	}
	if($updateRecords == ""){
		$updateRecords = "s_pa_activestatus = '".$activestatus."'";
	}else{
		$updateRecords .= ", s_pa_activestatus = '".$activestatus."'";
	}
}
if(!empty($assignto)){
	$empdata = mysqli_query($conn,"SELECT IFNULL(group_concat(s_e_emailid),'') as emailids, IFNULL(group_concat(s_e_id),'') as empids from  s_employees where s_e_activestatus = 'Active' and s_e_id in (".(implode(",", $assignto)).") and accountId ='".$accountId."'   Order by s_e_id desc");

	while($edata = mysqli_fetch_assoc($empdata)){
		$emailids = $edata['emailids'];
		$empids = $edata['empids'];
	}
}

if(!empty($id) && $id !="0") {

if($updateRecords !=""  ){
		$sql = "UPDATE s_project_activity SET  $updateRecords where s_pa_id = ?";

		$stmt = mysqli_prepare($conn, $sql);
		mysqli_stmt_bind_param($stmt, "s", $id);
		$result = mysqli_stmt_execute($stmt);
		

		if((isset($result) && $result) ){
			$newFlag = 0;
			$msgarr["status"] = "Success";
			$msgarr["message"] = "Project activity updated successfully.";
			
			
			$projactivityId = $id;

			if($emailids !=""){
				$notificationSql = "insert into s_notifications (`s_n_viewer`, `s_n_employees`,`s_n_assignto`, `s_n_recordid`,`s_n_recordnum`,`s_n_desc`,`s_n_attachments`,`s_n_filename`,`accountId`,`s_n_enteredby`,s_n_newflag ,s_n_emailflag,s_n_module ) values (NULL,'".$empids."','0','".$projactivityId."','','".$auditlogDesc."','','','".$accountId."','".$enteredby."','".$newFlag."','0','Project Activity') ";
				
				mysqli_query( $conn, $notificationSql);

			}

			if($assignto_change == "1"){
				if(isset($assignto) && !empty($assignto) && count($assignto) >0){

						$dsql = "delete from s_activity_members where projactivityId = '".$projactivityId."' and employeeId not in (".(implode(",", $assignto)).") and accountId = '".$accountId."' ";
						//echo $sql;
						$dstmt = mysqli_query( $conn, $dsql);
						foreach ($assignto as $key => $value) {
							# code...

							$chksql = "select * from s_activity_members where projactivityId = '".$projactivityId."' and employeeId = '".$value."' and accountId = '".$accountId."'  ";
							//echo $sql;
							$chkstmt = mysqli_query( $conn, $chksql);
							if(mysqli_num_rows($chkstmt) <=0){
								$msql = "insert into s_activity_members(projactivityId,employeeId,accountId) values('".$projactivityId."','".$value."','".$accountId."')";
								//echo $sql;
								$mstmt = mysqli_query( $conn, $msql);				
							}
						}
				}else{

						$dsql = "delete from s_activity_members where projactivityId = '".$projactivityId."' and accountId = '".$accountId."' ";
						//echo $sql;
						$dstmt = mysqli_query( $conn, $dsql);
				}
			}
			if($auditlogDesc != ""){
				$auditlogSql = "insert into s_auditlogs (`s_a_desc`, `s_a_module`, `s_a_enteredby`,`accountId`,`s_a_recordId`,`s_a_recordnum` ) values ('".$auditlogDesc."','Project Activity','".$enteredby."','".$accountId."','".$id."','') ";
				
				mysqli_query( $conn, $auditlogSql);


			}
		}else{
			$msgarr["status"] = "Error";
			$msgarr["message"] = "Something went wrong. Please try again.";
		}
		mysqli_stmt_close($stmt);
	}else{

			$msgarr["status"] = "Success";
			$msgarr["message"] = "Project activity updated successfully.";
	}


}else{


	// SQL query using prepared statements
	$sql = "INSERT INTO s_project_activity (
		projectId, releaseId, activityId, s_pa_status, s_pa_planstartdate, s_pa_planenddate, 
		s_pa_revisedstartdate, s_pa_revisedenddate, s_pa_actualstartdate, s_pa_actualenddate, 
		s_pa_desc, s_pa_enteredby, s_pa_activestatus, accountId, s_pa_completion
	) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

	// Prepare the statement
	$stmt = mysqli_prepare($conn, $sql);

	// Bind parameters to the statement
	mysqli_stmt_bind_param(
		$stmt, 
		"sssssssssssssss", 
		$projectId, $releaseId, $activityId, $projectactivitystatus, 
		$planstartdate, $planenddate, $revisedstartdate, $revisedenddate, 
		$actualstartdate, $actualenddate, $projactivitydesc, $enteredby, 
		$activestatus, $accountId, $percompletion
	);

	// Execute the statement
	$result = mysqli_stmt_execute($stmt);

	// Check if the query was successful
	if ($result) {
		$msgarr["status"] = "Success";
		$msgarr["message"] = "Project activity added successfully.";

		$projactivityId = mysqli_insert_id($conn);
		$newFlag = 1;
		if($emailids !=""){
			$notificationSql = "insert into s_notifications (`s_n_viewer`, `s_n_employees`,`s_n_assignto`, `s_n_recordid`,`s_n_recordnum`,`s_n_desc`,`s_n_attachments`,`s_n_filename`,`accountId`,`s_n_enteredby`,s_n_newflag ,s_n_emailflag,s_n_module ) values (NULL,'".$empids."','0','".$projactivityId."','','".$auditlogDesc."','','','".$accountId."','".$enteredby."','".$newFlag."','0','Project Activity') ";
			
			mysqli_query( $conn, $notificationSql);

		}
		if(isset($assignto) && !empty($assignto) && count($assignto) >0){

				$dsql = "delete from s_activity_members where projactivityId = '".$projactivityId."' and employeeId not in (".(implode(",", $assignto)).") and accountId = '".$accountId."' ";
		
				$dstmt = mysqli_query( $conn, $dsql);
				foreach ($assignto as $key => $value) {
					# code...

					$chksql = "select * from s_activity_members where projactivityId = '".$projactivityId."' and employeeId = '".$value."' and accountId = '".$accountId."'  ";

					$chkstmt = mysqli_query( $conn, $chksql);
					if(mysqli_num_rows($chkstmt) <=0){
		
////							$mstmt = mysqli_query( $conn, $msql);				
						$msql = "insert into s_activity_members(projactivityId,employeeId,accountId) values('".$projactivityId."','".$value."','".$accountId."')";
						$mstmt = mysqli_query( $conn, $msql);
					}
				}
		}
	}
	else
	{
		$msgarr["status"] = "Error";
		$msgarr["message"] = "Something went wrong. Please try again.";
	}
}
}

echo json_encode($msgarr);
