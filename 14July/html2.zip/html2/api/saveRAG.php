<?php
include('config.php');
session_start();
 
$enteredby = 0;
$accountId = 0;
 /** this saves the data into rag threshold table */
$msgarr = array();

if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = (isset($_SESSION["accountId"]) ? $_SESSION["accountId"] : 0);
}
if($_SERVER['REQUEST_METHOD'] === 'POST'){

$id = (isset($_POST['rId']) ? intval($_POST['rId']) : "0");
$amber = (isset($_POST['amber']) ? $_POST['amber'] : "0");
$red = (isset($_POST['red']) ? $_POST['red'] : "0");

if(!empty($id) && $id !="0") {
	// Update query using prepared statements
	$sql = "UPDATE s_ragthreshold SET s_rt_amber = ?, s_rt_red = ? WHERE s_rt_id = ? AND accountId = ?";
	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "ssii", $amber, $red, $id, $accountId);
	
	if(mysqli_stmt_execute($stmt)) {
		$msgarr["status"] = "Success";
		$msgarr["message"] = "RAG status updated successfully.";
	}
	else
	{
		$msgarr["status"] = "Error";
		$msgarr["message"] = "Something went wrong. Please try again.";
	}


}else{
	// Insert query using prepared statements
	$sql = "INSERT INTO s_ragthreshold(s_rt_amber, s_rt_red, accountId, s_rt_enteredby) VALUES (?, ?, ?, ?)";
	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "ssii", $amber, $red, $accountId, $enteredby);

	if(mysqli_stmt_execute($stmt)) {
		$msgarr["status"] = "Success";
		$msgarr["message"] = "RAG added successfully.";
	}
	else
	{
		$msgarr["status"] = "Error";
		$msgarr["message"] = "Something went wrong. Please try again.";
	}

}
}
echo json_encode($msgarr);