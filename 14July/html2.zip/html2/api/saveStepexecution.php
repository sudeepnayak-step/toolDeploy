
<?php
include('config.php');
session_start();
/** this script saves the execution result step wise */ 
$enteredby = 0;
$accountId = 0;
$msgarr = array();
 
$msgarr["status"] = "Error";
$msgarr["message"] = "Something went wrong. Please try again.";

if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
}
$updateRecords = "";$auditlogDesc = "";
if($_SERVER['REQUEST_METHOD'] === 'POST'){

	$executionId =isset($_POST['executionId']) && !empty($_POST['executionId']) ? $_POST['executionId']: 0;
	$stepexecutionId =isset($_POST['stepexecutionId']) && !empty($_POST['stepexecutionId']) ? $_POST['stepexecutionId']: array();
	$stepiteration =isset($_POST['stepiteration']) && !empty($_POST['stepiteration']) ? $_POST['stepiteration']: array();
	$step_testresult =isset($_POST['step_testresult']) && !empty($_POST['step_testresult']) ? $_POST['step_testresult']: array();
	$step_actualresult =isset($_POST['step_actualresult']) && !empty($_POST['step_actualresult']) ? $_POST['step_actualresult']: array();
	$step_reason =isset($_POST['step_reason']) && !empty($_POST['step_reason']) ? $_POST['step_reason']: array();
	$step_comment =isset($_POST['step_comment']) && !empty($_POST['step_comment']) ? $_POST['step_comment']: array();
	$activityId =isset($_POST['activityId']) && !empty($_POST['activityId']) ? $_POST['activityId']: 0;
	$artifactschk = isset($_POST['artifactschk']) && !empty($_POST['artifactschk']) ? $_POST['artifactschk'] : 0;
	if(!empty($stepexecutionId) || !empty($stepexecutionId)){
		$len = count($stepexecutionId);
		$pass = 0;
		$fail = 0;
		$inprogress = 0;
		$block = 0;
		$na = 0;
		$iteration =0;
		for($i=0; $i<$len; $i++){
			$eId = $stepexecutionId[$i];
			$iteration = $stepiteration[$i];
			$testresult = mysqli_real_escape_string($conn,$step_testresult[$i]);
			$actualresult = mysqli_real_escape_string($conn,$step_actualresult[$i]);
			$reasonId = isset($step_reason[$i]) && $step_reason[$i] != "" ? $step_reason[$i] : 0;
			//$reasonId = mysqli_real_escape_string($conn,$step_reason[$i]);
			
            		$comment = mysqli_real_escape_string($conn,$step_comment[$i]);	
			$stepsql = "UPDATE s_tcstep_execution SET s_se_testresult = ?, s_se_actualresult = ? ,reasonId = '".$reasonId."',
                    s_se_comment = '".$comment."'   WHERE s_se_id = ?";
			//echo $stepsql;			echo $testresult; 			echo $actualresult;			echo $eId;
			$stmt = mysqli_prepare($conn, $stepsql);
			mysqli_stmt_bind_param($stmt, "sss", $testresult, $actualresult, $eId);
			mysqli_stmt_execute($stmt);
			if ($stmt) mysqli_stmt_close($stmt);


			$runsql = "UPDATE s_tcstep_iteration SET s_se_testresult = ?, s_se_actualresult = ? ,reasonId = '".$reasonId."',
                    s_se_comment = '".$comment."'   WHERE stepexecutionId = ? AND accountId = ? AND s_se_iteration = ?";
			$stmt = mysqli_prepare($conn, $runsql);
			mysqli_stmt_bind_param($stmt, "sssii", $testresult, $actualresult, $eId, $accountId, $iteration);
			mysqli_stmt_execute($stmt);
			if ($stmt) mysqli_stmt_close($stmt);

			switch ($testresult) {
				case 'Pass':
					$pass++;
					break;
				case 'Fail':
					$fail++;
					break;
				case 'In Progress':
					$inprogress++;
					break;
				case 'Block':
					$block++;
					break;
				case 'NA':
					$na++;
					break;
			}
				
		}

		$msgarr["status"] = "Success";
		$msgarr["message"] = "Result updated successfully.";
		$status = "";
		if($fail > 0){
			$status = "Fail";
		}else if($block >0){
			$status = "Block";
		}else if($inprogress){
			$status = "In Progress";
		}else if($na > 0){
			$status = "NA";
		}else if($pass > 0){
			$status = "Pass";
		}else if($pending > 0){
			$status = "Pending";
		}

		$msgarr["result"] = $status;
		$msgarr["executionId"] = $executionId;
		if(!empty($status) && $artifactschk==1){
			$rtmupdatesql = "UPDATE s_testexecution SET s_st_testresult = ? " . (in_array($status,array("Pass","Fail")) ?  ",s_st_executionstatus = 2 " :"")." WHERE s_st_id = ?";
			$stmt = mysqli_prepare($conn, $rtmupdatesql);
			mysqli_stmt_bind_param($stmt, "si", $status, $executionId);
			mysqli_stmt_execute($stmt);
			if ($stmt) mysqli_stmt_close($stmt);

			$runupdatesql = "UPDATE s_testcaserun SET s_st_testresult = ? " . (in_array($status,array("Pass","Fail")) ?  ",s_st_executionstatus = 2 " :"")." WHERE testexecutionId = ? AND s_st_iteration = ?";
			$stmt = mysqli_prepare($conn, $runupdatesql);
			mysqli_stmt_bind_param($stmt, "sii", $status, $executionId, $iteration);
			mysqli_stmt_execute($stmt);
			if ($stmt) mysqli_stmt_close($stmt);


			$tcfinalsql = "UPDATE s_testcasefinal SET s_f_testresult = ? WHERE testcaseId = (SELECT testcaseId FROM s_testexecution WHERE s_st_id = ? AND accountId = ?) AND accountId = ? AND activityId = ?";
			$stmt = mysqli_prepare($conn, $tcfinalsql);
			mysqli_stmt_bind_param($stmt, "siiii", $status, $executionId, $accountId, $accountId, $activityId);
			mysqli_stmt_execute($stmt);
			if ($stmt) mysqli_stmt_close($stmt);
		}else if(!empty($status) && $artifactschk==0){
            if (isset($_FILES['docfile']) && $_FILES['docfile']['error'] === UPLOAD_ERR_OK) {
            $uploadDir = $CFG['dirroot'] . 'testexecution/' . $accountId . '/' . $executionId . '/';
            if (!file_exists($uploadDir)) {
                mkdir($uploadDir, 0777, true);
            }
 
            $fileTmpPath = $_FILES['docfile']['tmp_name'];
            $fileName = basename($_FILES['docfile']['name']);
            $fileExt = pathinfo($fileName, PATHINFO_EXTENSION);
            $newFileName = "testcase_" . time() . "." . $fileExt;
            $destination = $uploadDir . $newFileName;
    
            if (move_uploaded_file($fileTmpPath, $destination)) {
                $filePath = $uploadDir . $newFileName;
                $updatefile = ",s_st_filename='$newFileName',s_st_filepath='$filePath'";
                $stmt = $conn->prepare("UPDATE s_testcaserun SET s_st_testresult = '$status' " . (in_array($status,array("Pass","Fail")) ?  ",s_st_executionstatus = 2 " :"").", s_st_filename = ?, s_st_filepath = ? WHERE testexecutionId = ? AND s_st_iteration = '$iteration'");
                $stmt->bind_param("ssi", $newFileName, $filePath, $executionId);
                $stmt->execute();
                $stmt->close();
    
                $execStmt = $conn->prepare("UPDATE s_testexecution SET s_st_testresult = '$status' " . (in_array($status,array("Pass","Fail")) ?  ",s_st_executionstatus = 2 " :"").", s_st_filename = ?, s_st_filepath = ? WHERE s_st_id = ?");
                $execStmt->bind_param("ssi", $newFileName, $filePath, $executionId);
                $execStmt->execute();
                $execStmt->close();

                $tcfinalsql = "UPDATE s_testcasefinal SET s_f_testresult = '$status' WHERE testcaseId = (SELECT testcaseId FROM s_testexecution WHERE s_st_id = '$executionId' AND accountId = '$accountId') AND accountId = '$accountId' AND activityId = '$activityId'";
                mysqli_query($conn, $tcfinalsql);
    
                $msgarr["filepath"] = $filePath;
            } else {
                $msgarr["status"] = "Error";
                $msgarr["message"] = "Failed to move uploaded file.";
            }
        }else {
                $msgarr["status"] = "Error";
                $msgarr["message"] = "Please Upload File.";
            }
            }

	}
}
echo json_encode($msgarr);
