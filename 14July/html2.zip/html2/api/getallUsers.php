<?php
header('Access-Control-Allow-Origin: *');
include('config.php');

   /** This PHP script retrieves the all user data from a database. 
 * It formats the data and returns it in JSON format. */

$enteredby = (isset($_POST["enteredby"]) && !empty($_POST["enteredby"]) ? $_POST["enteredby"] : 0);
$accountId = (isset($_POST["accountId"]) && !empty($_POST["accountId"]) ? $_POST["accountId"] : 0);
$userempid = (isset($_POST["userempid"]) && !empty($_POST["userempid"])  ? $_POST["userempid"] : 0);

$sql = "SELECT e.*,IFNULL(r.s_role_name,'') as role, IFNULL(g.s_group_name,'') as empgroup , IFNULL(e.s_e_accountstatus,'') as accountstatus from s_employees e 
left join s_role r on r.s_role_id = e.roleId  
left join s_group g on g.s_group_id = e.groupId
where   e.accountId =? 
order by e.s_e_id desc";


$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i",$accountId);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$projarr['data'] = array();
while($data = mysqli_fetch_assoc($result)){
	$projarr['data'][] = array($data['s_e_id'],$data['s_e_fname']." ".$data['s_e_mname']." ".$data['s_e_lname'],
	$data['s_e_emailid'],$data['s_e_phoneno'],$data['role'],$data['userId'],$data['empgroup'], $data['accountstatus'],
	$data['s_e_activestatus'],$data['s_e_id']);
}

echo json_encode($projarr);
?>
