<?php
include('config.php');
session_start();
 
$enteredby = 0;$accountId = 0;$userempid = 0;
/** This script fetches active projects from the database based on the user's session and account ID. 
 * It ensures that only authorized users can access the data. */ 

if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
    $userempid = $_SESSION["userempid"];
}


$projectExtra = "";
if(isset($_SESSION["usertype"]) && $_SESSION["usertype"] != "Admin"){
	$projectExtra .= " and (s_p_id in (select projectId from s_project_members where employeeId = '".$userempid."' ) or s_p_enteredby = '".$enteredby."' )";
}

// Use prepared statements to prevent SQL injection
$stmt = mysqli_prepare($conn, "SELECT * FROM s_project WHERE s_p_activestatus = 'Active' AND accountId = ? $projectExtra order by s_p_name asc");
mysqli_stmt_bind_param($stmt, "i", $accountId);
mysqli_stmt_execute($stmt);
$sqldata = mysqli_stmt_get_result($stmt);


$projarr['data'] = array();
while($data = mysqli_fetch_assoc($sqldata)){
	$projarr['data'][] = array("id"=>$data['s_p_id'],
		"projectname"=>$data['s_p_name'],
		"projectcode"=>$data['s_p_code'],
		"projectstatus"=>$data['s_p_status'],
		"activestatus"=>$data['s_p_activestatus'],
		"ragstatus"=>$data['s_p_ragstatus'],
		"planstartdate"=>(isset($data['s_p_planstartdate']) && ($data['s_p_planstartdate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_p_planstartdate'])) : ""),
		"planenddate"=>(isset($data['s_p_planenddate']) && ($data['s_p_planenddate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_p_planenddate'])) : ""),
		"actualstartdate"=>(isset($data['s_p_actualstartdate']) && ($data['s_p_actualstartdate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_p_actualstartdate'])) : ""),
		"actualenddate"=>(isset($data['s_p_actualenddate']) && ($data['s_p_actualenddate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_p_actualenddate'])) : ""),
		"projectdesc"=>$data['s_p_desc']
	);
}

echo json_encode($projarr);
?>
