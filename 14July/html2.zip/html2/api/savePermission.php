<?php
header('Access-Control-Allow-Origin: *');
include('config.php');

$enteredby = 0;$accountId = 0;
 
$enteredby = (isset($_POST["enteredby"]) && !empty($_POST["enteredby"]) ? $_POST["enteredby"] : 0);
$accountId = (isset($_POST["accountId"]) && !empty($_POST["accountId"]) ? $_POST["accountId"] : 0);
$userempid = (isset($_POST["userempid"]) && !empty($_POST["userempid"])  ? $_POST["userempid"] : 0);

if($_SERVER['REQUEST_METHOD'] === 'POST'){

	$roleId = (isset($_POST['roleId']) ? intval($_POST['roleId']) : 0);
	$ruleids = (isset($_POST['ids']) ? $_POST['ids'] : array());
	$checkval = (isset($_POST['checkval']) ? $_POST['checkval'] : "");

	if ($checkval != "") {
        // Check if the role already exists
        $chkpermissison = mysqli_prepare($conn, "SELECT * FROM s_role_management WHERE roleId = ? AND accountId = ? ORDER BY s_rm_id DESC LIMIT 1");
        mysqli_stmt_bind_param($chkpermissison, "ii", $roleId, $accountId);
        mysqli_stmt_execute($chkpermissison);
        $result = mysqli_stmt_get_result($chkpermissison);

        if (mysqli_num_rows($result) > 0) {
            $newarray = array();
            while ($data = mysqli_fetch_assoc($result)) {
                $existingrules = explode(",", $data['ruleIds']);
                if ($checkval == "1") {
                    $newarray = array_unique(array_merge($ruleids, $existingrules));
                } else if ($checkval == "0") {
                    $newarray = array_diff($existingrules, $ruleids);
                }
            }

            // Update the role with new rules
            $sql = "UPDATE s_role_management SET ruleIds = ? WHERE roleId = ?";
            $stmt = mysqli_prepare($conn, $sql);
            $ruleIdsString = implode(",", $newarray);
            mysqli_stmt_bind_param($stmt, "si", $ruleIdsString, $roleId);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);
        } else {
            // Insert a new role with rules
            $sql = "INSERT INTO s_role_management (roleId, ruleIds, s_rm_enteredby, accountId) VALUES (?, ?, ?, ?)";
            $stmt = mysqli_prepare($conn, $sql);
            $ruleIdsString = implode(",", $ruleids);
            mysqli_stmt_bind_param($stmt, "isii", $roleId, $ruleIdsString, $enteredby, $accountId);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);
        }
    }

}