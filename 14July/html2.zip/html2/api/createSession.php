<?php	 
header('Access-Control-Allow-Origin: *');
include('config.php');
 
function decryptAES($base64, $key) {
 $cipher = "AES-128-CBC";
 $key = substr(hash('sha256', $key, true), 0, 16); // 16 bytes = AES-128
 $data = base64_decode($base64);
 if ($data === false || strlen($data) < 16) {
 return false; // invalid input
 }
 $iv = substr($data, 0, 16); // first 16 bytes = IV
 $ciphertext = substr($data, 16); // rest = encrypted data
 
 $decrypted = openssl_decrypt($ciphertext, $cipher, $key, OPENSSL_RAW_DATA, $iv);
 return $decrypted;
 }
 
//echo $encryptedData;die; 
$response = array();
$msg = "Oops! Something went wrong. Please try again later.";
// print($_POST);
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $encryptedData = isset($_POST["data"]) ? $_POST["data"] : ""; 
    if (!empty($encryptedData)) {
        $encryption_key = "12569103478"; // Must match the key used in chklogin.php
        $decryptedJson = decryptAES($encryptedData, $encryption_key);
 
        if ($decryptedJson !== false) {
            $user = json_decode($decryptedJson, true);
 
            if (isset($user['id']) && $user['id'] != "0") {
                session_start();
                $_SESSION["loggedin"] = true;
                $_SESSION["id"] = $user['id'];
                $_SESSION["username"] = $user['username'];
                $_SESSION["usertype"] = $user['usertype'];
                $_SESSION["userempid"] = $user['userempid'];
                $_SESSION["liccount"] = $user['liccount'];
                $_SESSION["ruleIds"] = $user['ruleIds'];
                $_SESSION["accountId"] = $user['usertype'] == "Admin" ? $user['id'] : $user['accountId'];
                $_SESSION["roleId"] = $user['roleId'];
 
                $response['status'] = "Success";
                $response['data'] = $user;
            } else {
                $response['status'] = "Error";
                $response['msg'] = "Invalid user data.";
            }
        } else {
            $response['status'] = "Error";
            $response['msg'] = "Decryption failed.";
        }
    } else {
        $response['status'] = "Error";
        $response['msg'] = "No encrypted data received.";
    }
}
 
echo json_encode($response);
?>
