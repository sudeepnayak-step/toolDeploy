<?php
include('config.php');
session_start();
 
$enteredby = 0;$accountId = 0; $roleId = 0;
 
 
if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
    $roleId = $_SESSION["roleId"];
}
 
$msgarr = array();
if($_SERVER['REQUEST_METHOD'] === 'POST'){
 
    $rtmId = (isset($_POST['id']) && !empty($_POST['id']) ? $_POST['id'] : "0");
    $status = (isset($_POST['status']) && !empty($_POST['status']) ? $_POST['status'] : "");
    $comment = (isset($_POST['comment']) && !empty($_POST['comment']) ? $_POST['comment'] : "");
    // echo $id;
    if(!empty($rtmId) && $rtmId !="0") {
 
 
        $sql = "INSERT INTO s_req_approval (`rtmId`, `s_req_status`, `s_req_comment`, `s_req_actionedby`,accountId) VALUES (?, ?, ?, ?,?)";
	//echo $rtmId. $status. $comment. $enteredby. $accountId;
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "sssss", $rtmId, $status, $comment, $enteredby, $accountId);
 	//echo "before if";
	
	$comment = "Status changed to ".$status.($comment != "" ? "  <br/>Reason: ".$comment : "");
	$sql = "INSERT INTO s_rtm_comments (`rtmId`, `s_dc_comment`, accountId, s_dc_enteredby) VALUES (?, ?, ?, ?)";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "ssss", $rtmId, $comment, $accountId, $enteredby);

        if (mysqli_stmt_execute($stmt)) {
	//echo "1st if";
          if( $status == "Pending"){
		 //$sql = "update s_rtm set s_rtm_approvalstatus = ? where s_rtm_id = ? and accountId = ? ";
		$sql = "update s_rtm set s_rtm_approvalstatus = ?,s_rtm_actionedby =  '0',s_rtm_actionedbyrole = '0', s_rtm_lastaction = '' where s_rtm_id = ? and accountId = ? ";
                $stmt1 = mysqli_prepare($conn, $sql);
                mysqli_stmt_bind_param($stmt1, "sss",$status, $rtmId,$accountId);
                mysqli_stmt_execute($stmt1);

	   }else if($roleId == '65' || $status == "Disapproved"){ //final roleId
 
                $sql = "update s_rtm set s_rtm_approvalstatus = ?,s_rtm_actionedby =  ?,s_rtm_actionedbyrole = ?, s_rtm_lastaction = ? where s_rtm_id = ? and accountId = ? ";
                $stmt1 = mysqli_prepare($conn, $sql);
                mysqli_stmt_bind_param($stmt1, "ssssss",$status,$enteredby, $roleId,$status, $rtmId,$accountId);
                mysqli_stmt_execute($stmt1);
            }else{
 		//echo "Accept Clicked";
                $sql = "update s_rtm set s_rtm_actionedby =  ?,s_rtm_actionedbyrole = ?,s_rtm_lastaction = ?".($roleId == '66' || $roleId == '71' ? ",s_rtm_approvalstatus = 'Pending'":"")." where s_rtm_id = ? and accountId = ? ";
                //echo $sql;die;
		$stmt2 = mysqli_prepare($conn, $sql);
                mysqli_stmt_bind_param($stmt2, "sssss", $enteredby,$roleId,$status, $rtmId,$accountId);
                mysqli_stmt_execute($stmt2);
            }
 
            $msgarr["status"] = "Success";
            $msgarr["message"] = "Status updated successfully.";
           
        } else {
            $msgarr["status"] = "Error";
            $msgarr["message"] = "Something went wrong. Please try again.";
        }
        mysqli_stmt_close($stmt);
 
    }
    else
    {
        $msgarr["status"] = "Error";
        $msgarr["message"] = "Something went wrong. Please try again.";
    }
}
echo json_encode($msgarr);
