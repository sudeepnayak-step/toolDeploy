<?php
include('config.php');
session_start();
/**This PHP script retrieves and filters project activity data 
 * from a database based on user inputs and session information. 
 * It also calculates execution percentages, quality status, and risk/issue counts for each activity. */ 
$userempid = 0;$accountId = 0;$enteredby =0;
 
if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
}

if(isset($_SESSION["usertype"]) && $_SESSION["usertype"] == "Employee"){
	if(isset($_SESSION["userempid"])){
    $userempid = $_SESSION["userempid"];
}
}

$where = "";

$projarr['data'] = array();
$projectId = (isset($_POST['projectId']) && !empty($_POST['projectId']) && !is_null($_POST['projectId']) ? $_POST['projectId'] : "");
$releaseId = (isset($_POST['releaseId']) && !empty($_POST['releaseId']) && !is_null($_POST['releaseId'])? $_POST['releaseId'] : "");
$activityId = (isset($_POST['activityId']) && !empty($_POST['activityId']) && !is_null($_POST['activityId']) ? $_POST['activityId'] : "");
$status = (isset($_POST['status']) && !empty($_POST['status']) && !is_null($_POST['status'])? $_POST['status'] : "");
$planstart = (isset($_POST['planstart']) && !empty($_POST['planstart']) && !is_null($_POST['planstart'])? date('Y-m-d', strtotime(str_replace('/', '-', $_POST['planstart']))) : '');
$planend = (isset($_POST['planend']) && !empty($_POST['planend']) && !is_null($_POST['planend'])? date('Y-m-d', strtotime(str_replace('/', '-', $_POST['planend']))) : '');

if($projectId !=""){
		$where = $where." and pa.projectId in ($projectId) ";
}else{
        echo json_encode($projarr);
        die;
}

if($releaseId !=""){
		$where = $where." and pa.releaseId in ($releaseId) ";
}
if($activityId !=""){
		$where = $where." and pa.activityId in ($activityId) ";
}

if($status !=""){
	$statusarr = explode(",", $status);
	$status = "'" . implode ( "', '", $statusarr ) . "'";
	$where .= " and pa.s_pa_status in ($status) ";
}

if($planstart !=""){
		$where .= " and pa.s_pa_planstartdate >= '$planstart' ";
}

if($planend !=""){
		$where .= " and pa.s_pa_planenddate <= '$planend' ";
}

if(isset($_SESSION["usertype"]) && $_SESSION["usertype"] != "Admin"){
	
	$where .= " and pa.projectId in (select s_p_id from s_project where s_p_id in (select projectId from s_project_members where employeeId = '".$userempid."'  and accountId = '".$accountId."') or s_p_enteredby = '".$enteredby."' and accountId = '".$accountId."')";
}
$sql = "SELECT pa.*, IFNULL(p.s_p_name,'') as projectname, IFNULL(r.s_r_name,'') as releaseNum, IFNULL(a.s_a_name,'') as activityname, 
        IFNULL(a.s_a_code,'') as activitycode, IFNULL(a.s_a_type,'') as activitytype 
        FROM s_project_activity pa 
        JOIN s_project p ON p.s_p_id = pa.projectId 
        JOIN s_activitymaster a ON a.s_a_id = pa.activityId 
        JOIN s_release r ON r.s_r_id = pa.releaseId 
        WHERE pa.accountId = ? $where 
        ORDER BY pa.s_pa_id ASC";

$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $accountId);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);


//$projarr['data'] = array();
while($data = mysqli_fetch_assoc($result)){

	$planstartdate = (isset($data['s_pa_planstartdate']) && ($data['s_pa_planstartdate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_pa_planstartdate'])) : "");

	$planenddate = (isset($data['s_pa_planenddate']) && ($data['s_pa_planenddate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_pa_planenddate'])) : "");

	$revisedstartdate = (isset($data['s_pa_revisedstartdate']) && ($data['s_pa_revisedstartdate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_pa_revisedstartdate'])) : "");

	$revisedenddate = (isset($data['s_pa_revisedenddate']) && ($data['s_pa_revisedenddate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_pa_revisedenddate'])) : "");
	
	$actualstartdate = (isset($data['s_pa_actualstartdate']) && ($data['s_pa_actualstartdate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_pa_actualstartdate'])) : "");

	$actualenddate = (isset($data['s_pa_actualenddate']) && ($data['s_pa_actualenddate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_pa_actualenddate'])) : "");
			
	$relesenum = isset($data['releaseNum']) ? $data['releaseNum'] : "";

	$totexecution = 0;
	$perexecution = 0;
	$tottestcase = 0;
	$totPass = 0;
	$totPasspercent = 0;
	if($data['activitytype'] == "Execution"){
		//$testcasedata = mysqli_query($conn,"SELECT IFNULL(count(1),0) as totcount from s_testcase where projectId = '".$data['projectId']."'
		//							  and releaseId = '".$data['releaseId']."' and find_in_set('".$data['activityId']."',s_t_activityIds)   and accountId = '".$accountId."' ");

		//while($tdata = mysqli_fetch_assoc($testcasedata)){
		//	$tottestcase = $tdata['totcount'] ;
		//}
		//$exedata = mysqli_query($conn, "SELECT  IFNULL(SUM(CASE WHEN s_f_testresult = 'Fail' THEN 1 ELSE 0 END),0) as Failcount,
		//							IFNULL(SUM(CASE WHEN s_f_testresult = 'Pass' THEN 1 ELSE 0 END),0) as Passcount from s_testcasefinal where projectId = '".$data['projectId']."'
		//							  and releaseId = '".$data['releaseId']."' and activityId = '".$data['activityId']."' and accountId = '".$accountId."' ");
		
		$exesql = "
            SELECT
                COUNT(DISTINCT st.s_t_id) AS totcount,
                SUM(CASE WHEN sf.s_f_testresult = 'Fail' THEN 1 ELSE 0 END) AS Failcount,
                SUM(CASE WHEN sf.s_f_testresult = 'Pass' THEN 1 ELSE 0 END) AS Passcount
            FROM s_testcase st
            LEFT JOIN (
                SELECT sf1.*
                FROM s_testcasefinal sf1
                INNER JOIN (
                    SELECT testcaseId, MAX(s_f_id) AS max_id
                    FROM s_testcasefinal
                    WHERE projectId = '".$data['projectId']."'
                      AND releaseId = '".$data['releaseId']."'
                      AND activityId = '".$data['activityId']."'
                      AND accountId = '".$accountId."'
                    GROUP BY testcaseId
                ) latest ON sf1.s_f_id = latest.max_id
            ) sf ON sf.testcaseId = st.s_t_id
            WHERE st.projectId = '".$data['projectId']."'
              AND st.releaseId = '".$data['releaseId']."'
              AND FIND_IN_SET('".$data['activityId']."', st.s_t_activityIds)
              AND st.accountId = '".$accountId."'";
        $exedata = mysqli_query($conn,$exesql);

		while($edata = mysqli_fetch_assoc($exedata)){
			$totexecution = $edata['Failcount'] + $edata['Passcount'];
			$totPass = $edata['Passcount'];
			$tottestcase = $edata['totcount'];
		}
		$perexecution = ($tottestcase >0) ?  round(($totexecution/$tottestcase * 100),2) : 0;
		$totPasspercent = ($tottestcase >0) ?  round(($totPass/$tottestcase * 100),2) : 0;
	}else{
		$perexecution = round($data['s_pa_completion'],2);
		$totPasspercent = round($data['s_pa_completion'],2);
	}

	$qualityStatus = "";
	// calculate threshold
	$qualitythresholdsql = "SELECT *
			FROM s_qualitystatus where accountId='".$accountId."' order by s_q_id desc limit 1";
	$qthresholdquery = mysqli_query($conn,$qualitythresholdsql);
	while($qTdata =mysqli_fetch_assoc($qthresholdquery)){
		if($totPasspercent >= $qTdata['s_q_excellent']){
			$qualityStatus = "Excellent";
		}else if($totPasspercent >= $qTdata['s_q_good']){
			$qualityStatus = "Good";
		}else if($totPasspercent >= $qTdata['s_q_normal']){
			$qualityStatus = "Normal";
		}else if($totPasspercent >0){
			$qualityStatus = "Poor";
		}
	}

	$riskissuecount = 0;
	$riskissuedata = mysqli_query($conn,"SELECT 1 from s_riskissue where s_r_activityId = '".$data['s_pa_id']."' and accountId = '".$accountId."'  ");
	$riskissuecount = mysqli_num_rows($riskissuedata);


	$membersarr = array();
	$membersnamearr = array();

	$chksql = "select mem.*, concat(IFNULL(s_e_fname,''),' ',IFNULL(s_e_mname,''),' ',IFNULL(s_e_lname,'')) as membersname from s_activity_members mem join s_employees emp on emp.s_e_id = mem.employeeId where projactivityId = '".$data['s_pa_id']."' and mem.accountId = '".$accountId."' ";
	
	$chkstmt = mysqli_query( $conn, $chksql);

	while($mdata = mysqli_fetch_assoc($chkstmt)){
		if(!in_array($mdata['employeeId'], $membersarr)){
			array_push($membersnamearr, $mdata['membersname']);
			array_push($membersarr, $mdata['employeeId']);
		}

	}

	$projarr['data'][] = array($data['s_pa_id'],
		$data['activityname'],
		$data['s_pa_status'],
		$relesenum ,
	    $perexecution." %",
		(!empty($planstartdate) ? $planstartdate : "-"),
		(!empty($planenddate) ? $planenddate : "-"),
		(!empty($revisedstartdate) ? $revisedstartdate : "-"),
		(!empty($revisedenddate) ? $revisedenddate : "-"),
		(!empty($actualstartdate) ? $actualstartdate : "-"),
		(!empty($actualenddate) ? $actualenddate : "-"),
		$riskissuecount,
		$qualityStatus,
		$data['s_pa_activestatus'],
		$data['s_pa_id']

	);
}

echo json_encode($projarr);
?>
