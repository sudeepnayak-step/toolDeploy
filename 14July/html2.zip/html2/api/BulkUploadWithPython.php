<?php
session_start(); // Start the session at the beginning

header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json'); // Tells the browser it's JSON
include("config.php"); // Include your database configuration file

$response = array('status' => 'Error', 'message' => 'An error occurred.');
$enteredby = 0;$accountId=0;$userempid = 0;
 
//echo "Bulk";die;
if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
    $userempid = $_SESSION["userempid"];
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
//    $accountId = !empty($_POST['account_id']) ? $_POST['account_id']:0;
    $projectId = !empty($_POST['project_id']) ? $_POST['project_id']:0;
    $releasedId = !empty($_POST['released_id']) ? $_POST['released_id']:0;
    $status = !empty($_POST['status']) ? $_POST['status']:null;
    $type = !empty($_POST['type']) ? $_POST['type']:null;
    $suiteId = !empty($_POST['suiteId']) ? $_POST['suiteId'] : null;
    //$suiteId = !empty($_GET['suiteId']) ? $_GET['suiteId'] : null;
//echo $suitId;die;
    // Check if the session variable is set
    if (isset($_SESSION['userempid'])) {
        $userempid = $_SESSION['userempid'];
    } else {
        $response['message'] = 'User Emp ID is not set in the session.';
        echo json_encode($response);
        exit;
    }

    $targetDir = $CFG["dirroot"]."BulkUploadScript/input/";
    $originalFileName = basename($_FILES["file"]["name"]);

    // Check if the uploaded file is an Excel file
    $fileType = strtolower(pathinfo($originalFileName, PATHINFO_EXTENSION));
    if ($fileType != "xls" && $fileType != "xlsx") {
        $response['message'] = 'Only Excel files (.xls, .xlsx) are allowed.';
        echo json_encode($response);
        exit;
    }

    // Append date and time to the file name
    $dateTime = date('Ymd_His');
    $newFileName = pathinfo($originalFileName, PATHINFO_FILENAME) . '_' . $dateTime . '.' . $fileType;
    $targetFile = $targetDir . $newFileName;

    if (move_uploaded_file($_FILES["file"]["tmp_name"], $targetFile)) {
        $filePath = $targetFile;

        // Insert into scriptaction table
        $sql = "INSERT INTO scriptaction (account_id, enteredby_id, project_id, released_id, status, file_path, type,suiteId) VALUES (?, ?, ?, ?, ?, ?, ?,?)";
        $stmt = $conn->prepare($sql);

        if ($stmt === false) {
            $response['message'] = 'Failed to prepare SQL statement: ' . $conn->error;
        } else {
            $stmt->bind_param("iiissssi", $accountId, $userempid, $projectId, $releasedId, $status, $filePath, $type,$suiteId);

            if ($stmt->execute()) {
                $response['status'] = 'Success';
                $response['message'] = "The uploaded Excel file is being processed in the background. You'll be notified once it's done. please check back in 5 minutes." ;
            } else {
                $response['message'] = 'Failed to store data in the database: ' . $stmt->error;
            }
        }
    } else {
        $response['message'] = 'Failed to upload file.';
    }
}

echo json_encode($response);
?>
