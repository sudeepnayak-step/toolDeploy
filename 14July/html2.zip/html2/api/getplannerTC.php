<?php
header('Access-Control-Allow-Origin: *');
include('config.php');
  /** This PHP script retrieves the testexecution data from database fr testsuite
 * It formats the data and returns it in JSON format. */

$projarr['data'] = array();
$temp_testsuiteId = isset($_GET['id']) ? intval($_GET['id']) : 0;
$sql = "SELECT temp.*,
	IFNULL(tc.s_t_testscenarionum,'') as testscenarioId,
	IFNULL(tc.s_t_testcasenum,'') as testcaseId,
	IFNULL(tc.s_t_id,'') as testcaseautoId,
	IFNULL(tc.s_t_module,'-') as module,
	IFNULL(tc.s_t_submodule,'') as submodule,
	IFNULL(tc.s_t_testcasenum,'') as testcaseId,
	IFNULL(tc.s_t_testcasedesc,'') as testcasedesc,
	IFNULL(temp.s_st_filepath,'') as s_st_filepath,
	IFNULL(temp.s_st_testresult,'') as s_st_testresult,
	IFNULL(temp.s_st_actualresult,'') as s_st_actualresult,
	IFNULL(temp.s_st_executionstatus,'') as executionstatus,
	IFNULL(d.s_d_defectnum,'') as defectnum
	 from s_testexecution temp 
	join s_testcase tc on tc.s_t_id = temp.testcaseId 
	left join s_defect d on d.s_d_id = temp.defectId 
	where temp.testsuiteId = '".$temp_testsuiteId ."'

	order by temp.s_st_id desc";
	

	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "i",$temp_testsuiteId);
	mysqli_stmt_execute($stmt);
	$result = mysqli_stmt_get_result($stmt);
	while($data = mysqli_fetch_assoc($result)){

		$projarr['data'][] = array(
			"id"=>$data['testcaseautoId'],"name"=>$data['testcaseId']);
	}

echo json_encode($projarr);
?>