<?php
include('config.php');
session_start();
 
$enteredby = 0;$accountId=0;
 
 /** This PHP script retrieves the release data from a database. 
 * It formats the data and returns it in JSON format. */

if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
}

$editPermission = 0;
if((isset($_SESSION["usertype"]) && $_SESSION["usertype"] == "Admin") || (isset($_SESSION["ruleIds"]) && in_array("7", explode(",", $_SESSION["ruleIds"])))){ 
	$editPermission = 1;
}

$id = (isset($_POST['id']) ? intval($_POST['id']) : 0);
$projarr = array();
$sql = "SELECT r.*,
	IFNULL(p.clientId,'0') as projectclient

	from s_release r 
	join s_project p on p.s_p_id = r.projectId
	 where r.s_r_id = ? and r.accountId = ? ";

$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "ii",$id,$accountId);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
while($data = mysqli_fetch_assoc($result)){


		$editable = 0; // editable allow
		$editabledata = mysqli_query($conn,"SELECT 1 from s_project_activity where accountId = '".$accountId."' and releaseId = '".$data['s_r_id']."' ");
		$editable = mysqli_num_rows($editabledata);

		if($editable == 0){
			$editabledata = mysqli_query($conn,"SELECT 1 from s_testcase where accountId = '".$accountId."' and releaseId = '".$data['s_r_id']."' ");
			$editable = ($editable == 0 ? mysqli_num_rows($editabledata) : $editable);
		}
		if($editable == 0){
			$editabledata = mysqli_query($conn,"SELECT 1 from s_testsuite where accountId = '".$accountId."' and releaseId = '".$data['s_r_id']."' ");
			$editable = ($editable == 0 ? mysqli_num_rows($editabledata) : $editable);
		}

		if($editable == 0){
			$editabledata = mysqli_query($conn,"SELECT 1 from s_rtm where accountId = '".$accountId."' and releaseId = '".$data['s_r_id']."' ");
			$editable = ($editable == 0 ? mysqli_num_rows($editabledata) : $editable);
		}
		if($editable == 0){
			$editabledata = mysqli_query($conn,"SELECT 1 from s_defect where accountId = '".$accountId."' and releaseId = '".$data['s_r_id']."' ");
			$editable = ($editable == 0 ? mysqli_num_rows($editabledata) : $editable);
		}
		$projarr = array("id"=>$data['s_r_id'],
		"releasename"=>$data['s_r_name'],
		"projectId"=>$data['projectId'],
		"projectclient"=>$data['projectclient'],
		"releasestatus"=>$data['s_r_status'],
		"activestatus"=>$data['s_r_activestatus'],
		"planstartdate"=>(isset($data['s_r_planstartdate']) && ($data['s_r_planstartdate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_r_planstartdate'])) : ""),
		"planenddate"=>(isset($data['s_r_planenddate']) && ($data['s_r_planenddate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_r_planenddate'])) : ""),
		"revisedstartdate"=>(isset($data['s_r_revisedstartdate']) && ($data['s_r_revisedstartdate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_r_revisedstartdate'])) : ""),
		"revisedenddate"=>(isset($data['s_r_revisedenddate']) && ($data['s_r_revisedenddate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_r_revisedenddate'])) : ""),
		"actualstartdate"=>(isset($data['s_r_actualstartdate']) && ($data['s_r_actualstartdate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_r_actualstartdate'])) : ""),
		"actualenddate"=>(isset($data['s_r_actualenddate']) && ($data['s_r_actualenddate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_r_actualenddate'])) : ""),
		"releasedesc"=>$data['s_r_desc'],
			"editable"=>$editable,
			"editPermission"=>$editPermission,
		);
}

echo json_encode($projarr);
?>