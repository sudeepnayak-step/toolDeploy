<?php
include('config.php');
session_start();
 
$enteredby = 0;$accountId=0;
 /** This PHP script retrieves and filters RTM (Requirement Traceability Matrix) 
 * twith testcase data from a database based on user inputs and session information. 
 * It formats the data and returns it in JSON format. */ 


if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
}
$projectId = (isset($_POST['projectId']) ? $_POST['projectId'] : "0");
$releaseId = (isset($_POST['releaseId']) ? $_POST['releaseId'] : "0");
$where = "";
if($projectId !="0" && $projectId !=""){
	$where = " AND tc.projectId  = '".$projectId."' ";
}
if($releaseId !="0" && $releaseId !=""){
	if($where == ""){
		$where = " AND tc.releaseId  = '".$releaseId."' ";
	}else{
		$where .=" and tc.releaseId  = '".$releaseId."' ";
	}
}

$temp_rtmId = isset($_POST['rtmId']) ? intval($_POST['rtmId']) : 0;

$sql = "SELECT rtc.*,
	IFNULL(tc.s_t_id,'0') as s_t_id,
	IFNULL(tc.s_t_testscenarionum,'') as testscenarioId,
	IFNULL(tc.s_t_testcasenum,'') as testcaseId,
	IFNULL(tc.s_t_id,'') as testcaseautoId,
	IFNULL(tc.s_t_module,'') as module,
	IFNULL(tc.s_t_submodule,'') as submodule,
	IFNULL(tc.s_t_testcasenum,'') as testcaseId,
	IFNULL(tc.s_t_testcasedesc,'') as testcasedesc,
	IFNULL(result_max.s_f_testresult,'') as testresult,
	IFNULL(result_max.s_f_actualresult,'') as actualresult
	 from s_rtm_testcase rtc
	 join s_testcase tc on tc.s_t_id = rtc.testcaseId
	left join (SELECT t1.* FROM s_testcasefinal t1 WHERE t1. s_f_id  = (SELECT t2.s_f_id  FROM s_testcasefinal t2  WHERE t2.testcaseId = t1.testcaseId and t2. s_f_updatetime <= now() order by s_f_id desc limit 1  )
	) result_max on result_max.testcaseId = rtc.testcaseId
	where rtc.accountId = ? and rtc.rtmId = ? and rtc.testcaseId !='0'

	order by rtc.s_rt_id asc";
	
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "ii", $accountId,$temp_rtmId);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);


$projarr['data'] = array();
while($data = mysqli_fetch_assoc($result)){
	//$iterationsqldata = mysqli_query($conn,"SELECT 1 from s_testcaserun where testcaseId = '".$data['testcaseautoId']."' and accountId = '".$accountId."'  order by s_st_id desc ");
	//$iterationcount = mysqli_num_rows($iterationsqldata);
	$iterationsqldata = mysqli_query($conn,"SELECT IFNULL(max(s_st_iteration),0) as iteration from s_testcaserun where testcaseId = '".$data['testcaseautoId']."' and accountId = '".$accountId."' order by s_st_id desc ");
	while($itdata = mysqli_fetch_assoc($iterationsqldata)){
		$iterationcount = $itdata['iteration'];
	}

	$projarr['data'][] = array($data['s_rt_id'],$data['module'],$data['testscenarioId'],$data['testcaseId'],$data['testcaseautoId'],
		$data['testcasedesc'],
		$data['testresult'],$data['actualresult'],$iterationcount,$data['s_rt_id']);
}

echo json_encode($projarr);
?>
