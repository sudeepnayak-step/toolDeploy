<?php

header('Access-Control-Allow-Origin: *');
include('config.php');
/**This page handles user account activation via a token. 
 * It processes a POST request, validates the token, 
 * and fetches user data from the database */
if($_SERVER['REQUEST_METHOD'] === 'POST'){

// $token = (isset($_POST['token']) ? $_POST['token'] : "0");
$token = filter_input(INPUT_POST, 'token', FILTER_SANITIZE_STRING); // Sanitize input

$projarr = array();
if (empty($token)) {
	$projarr = array("msg" => "Invalid token");
	echo json_encode($projarr);
	exit;
}
// Use prepared statements to prevent SQL injection
$stmt = mysqli_prepare($conn, "SELECT * FROM s_users WHERE s_u_activationnum = ? ORDER BY s_u_id DESC LIMIT 1");
mysqli_stmt_bind_param($stmt, "s", $token);
mysqli_stmt_execute($stmt);
$sqldata = mysqli_stmt_get_result($stmt);


if(mysqli_num_rows($sqldata) >0){
	while($data = mysqli_fetch_assoc($sqldata)){
		$projarr= array("id"=>$data['s_u_id'],
			"username"=>$data['s_u_username']
		);

}
}else{
	$projarr= array("msg"=>"Invalid link");	
}

echo json_encode($projarr);
}
?>