<?php
include('config.php');
session_start();
 /**This PHP script retrieves defect data from a database based on user-provided filters (e.g., project, release, defect ID, status, etc.). 
  * It dynamically constructs a SQL query, executes it, and returns the results in JSON format. */
$userempid = 0;$accountId = 0;$enteredby =0;
 
if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
}

if(isset($_SESSION["usertype"]) && $_SESSION["usertype"] == "Employee"){
	if(isset($_SESSION["userempid"])){
    $userempid = $_SESSION["userempid"];
}
}

$defectwhere = "";

$projectId = (isset($_POST['projectId']) && !empty($_POST['projectId'])? $_POST['projectId'] : "0");
$releaseId = (isset($_POST['releaseId'])  && !empty($_POST['releaseId'])? $_POST['releaseId'] : "0");
$defectId = (isset($_POST['defectId'])  && !empty($_POST['defectId'])? $_POST['defectId'] : "0");
$statusId = (isset($_POST['statusId'])  && !empty($_POST['statusId'])? $_POST['statusId'] : "0");

$rtmId = (isset($_POST['rtmId']) ? $_POST['rtmId'] : "0");
$module = (isset($_POST['module']) ? $_POST['module'] : "");

// Build the WHERE clause dynamically
$conditions = [];
$params = [];
$types = "";

if ($projectId != "0") {
    $conditions[] = "d.projectId = ?";
    $params[] = $projectId;
    $types .= "i"; // Assuming projectId is an integer
}

if ($releaseId != "0") {
    $conditions[] = "d.releaseId = ?";
    $params[] = $releaseId;
    $types .= "i"; // Assuming releaseId is an integer
}

if ($defectId != "0") {
    $conditions[] = "d.s_d_id = ?";
    $params[] = $defectId;
    $types .= "i"; // Assuming defectId is an integer
}

if ($statusId != "0") {
    $conditions[] = "d.defectstatusId = ?";
    $params[] = $statusId;
    $types .= "i"; // Assuming statusId is an integer
}

if ($module != "") {
    $conditions[] = "d.s_d_module = ?";
    $params[] = $module;
    $types .= "s"; // Assuming module is a string
}

if ($rtmId != "0" && $rtmId != "") {
    $conditions[] = "d.s_d_id NOT IN (SELECT defectId FROM s_rtm_testcase WHERE rtmId = ? AND accountId = ?)";
    $params[] = $rtmId;
    $params[] = $accountId;
    $types .= "ii"; // Assuming rtmId and accountId are integers
}

if (isset($_SESSION["usertype"]) && $_SESSION["usertype"] != "Admin") {
    if (empty($conditions)) {
        $conditions[] = "d.projectId IN (SELECT s_p_id FROM s_project WHERE s_p_id IN (SELECT projectId FROM s_project_members WHERE employeeId = ?) OR s_p_enteredby = ?)";
        $params[] = $userempid;
        $params[] = $enteredby;
        $types .= "ii"; // Assuming userempid and enteredby are integers
    } else {
        $conditions[] = "d.projectId IN (SELECT s_p_id FROM s_project WHERE s_p_id IN (SELECT projectId FROM s_project_members WHERE employeeId = ?) OR s_p_enteredby = ?)";
        $params[] = $userempid;
        $params[] = $enteredby;
        $types .= "ii"; // Assuming userempid and enteredby are integers
    }
}

$defectwhere = implode(" AND ", $conditions);
$sql = "SELECT d.*, IFNULL(p.s_p_name, '') AS projectname,
    IFNULL(r.s_r_releaseId, '') AS releaseNum,
    IFNULL(t.s_t_testcasenum, '') AS testcasenum,
    IFNULL(ds.s_ds_name, '') AS defectstatus,
    IFNULL(dt.s_dt_name, '') AS defecttype
    FROM s_defect d 
    LEFT JOIN s_project p ON p.s_p_id = d.projectId 
    LEFT JOIN s_release r ON r.s_r_id = d.releaseId 
    LEFT JOIN s_testcase t ON t.s_t_id = d.testcaseId 
    LEFT JOIN s_defectstatusmaster ds ON ds.s_ds_id = d.defectstatusId 
    LEFT JOIN s_defecttypemaster dt ON dt.s_dt_id = d.defecttypeId 
    WHERE d.accountId = ? AND $defectwhere 
    ORDER BY d.s_d_id ASC";

$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i" . $types, $accountId, ...$params);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

$projarr['data'] = array();
while($data = mysqli_fetch_assoc($result)){
	$attachemnts = 0;

	$dir = $CFG['dirroot']."defectdata/".$accountId."/".$data['s_d_id']."/";

	if(is_dir($dir)) {
		$files = array_diff(scandir($dir), array('..', '.'));
		if(count($files) >0){
			$attachemnts = 1;
		}
	}
	$projarr['data'][] = array($data['s_d_id'],$data['projectname'],$data['releaseNum'],$data['s_d_module'],$data['s_d_submodule'],$data['s_d_defectnum'],$data['testcasenum'],$data['s_d_shortdesc'],$data['defecttype'],$data['defectstatus'],$data['s_d_severity'],$data['s_d_priority'],
	(isset($data['s_d_createdtime']) && ($data['s_d_createdtime'] != "0000-00-00 00:00:00") ? date("d/m/Y h:i a",strtotime($data['s_d_createdtime'])) : ""),
	(isset($data['s_d_updatetime']) && ($data['s_d_updatetime'] != "0000-00-00 00:00:00") ? date("d/m/Y h:i a",strtotime($data['s_d_updatetime'])) : ""),
		$attachemnts,$data['s_d_id']);
}

echo json_encode($projarr);
?>
