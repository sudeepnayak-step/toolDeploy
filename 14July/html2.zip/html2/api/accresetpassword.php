<?php
/**
 * Account Reset Password Script
 *
 * This script handles account reset password functionality.
 * It accepts POST requests and processes the data to reset a user's password.
 */
header('Access-Control-Allow-Origin: *');
include('config.php');

// Check for the presence of enteredby, accountId, and userempid in the POST request data
$enteredby = (isset($_POST["enteredby"]) && !empty($_POST["enteredby"]) ? $_POST["enteredby"] : 0);
$accountId = (isset($_POST["accountId"]) && !empty($_POST["accountId"]) ? $_POST["accountId"] : 0);
$userempid = (isset($_POST["userempid"]) && !empty($_POST["userempid"])  ? $_POST["userempid"] : 0);
// Initialize the response message and status array
$msgarr = array();
$msg = "Oops! Something went wrong. Please try again later.";

$msgarr["status"] = "Error";
$msgarr["message"] = "Oops! Something went wrong. Please try again later.";

// Check if the request method is POST
if($_SERVER['REQUEST_METHOD'] === 'POST'){

    // Retrieve old and new passwords from POST data
    $oldpassword = (isset($_POST['oldpassword']) ? $_POST['oldpassword'] : '');
    $password = (isset($_POST['newpassword']) ? $_POST['newpassword'] : '');

    // Prepare the SQL query to fetch user details
    $sql = "SELECT s_u_id, s_u_username, s_u_password, s_u_type FROM s_users WHERE s_u_id = ?";

    if($stmt = mysqli_prepare($conn, $sql)){
        // Bind the enteredby parameter to the query
        mysqli_stmt_bind_param($stmt, "s", $enteredby);

        // Execute the prepared statement
        if(mysqli_stmt_execute($stmt)){
            // Store the result
            mysqli_stmt_store_result($stmt);

            // Check if the user exists
            if(mysqli_stmt_num_rows($stmt) == 1){ 
                // Bind the result variables
                mysqli_stmt_bind_result($stmt, $id, $username, $hashed_password, $type);

                // Fetch the result
                if(mysqli_stmt_fetch($stmt)){
                    // Verify the old password
                    if(password_verify($oldpassword, $hashed_password)){
                        // Prepare the SQL query to update the password
                        $update_sql = "UPDATE s_users SET s_u_password = ? WHERE s_u_id = ?";

                        if($update_stmt = mysqli_prepare($conn, $update_sql)){
                            // Hash the new password
                            $hashed_new_password = password_hash($password, PASSWORD_DEFAULT);

                            // Bind the parameters to the update query
                            mysqli_stmt_bind_param($update_stmt, "si", $hashed_new_password, $id);

                            // Execute the update query
                            if(mysqli_stmt_execute($update_stmt)){
                                $msgarr["status"] = "Success";
                                $msgarr["message"] = "Password reset successfully.";
                            } else {
                                $msgarr["status"] = "Error";
                                $msgarr["message"] = "Password reset failed.";
                            }

                            // Close the update statement
                            mysqli_stmt_close($update_stmt);
                        } else {
                            $msgarr["status"] = "Error";
                            $msgarr["message"] = "Failed to prepare the update statement.";
                        }
                    } else {
                        // Display an error message if the old password is invalid
                        $msgarr["status"] = "Error";
                        $msgarr["message"] = "The password you entered was not valid.";
                    }
                }
            } else {
                // Display an error message if the user does not exist
                $msgarr["status"] = "Error";
                $msgarr["message"] = "No account found with that username.";
            }
        } else {
            $msgarr["status"] = "Error";
            $msgarr["message"] = "Oops! Something went wrong. Please try again later.";
        }

        // Close the statement
        mysqli_stmt_close($stmt);
    } else {
        $msgarr["status"] = "Error";
        $msgarr["message"] = "Failed to prepare the statement.";
    }
}

// Return the response message and status to the client
echo json_encode($msgarr);
