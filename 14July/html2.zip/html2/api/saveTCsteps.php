
<?php
include('config.php');
session_start();
 
$enteredby = 0;
$accountId = 0;
$msgarr = array();
 /** this script saves the data into testcases steps */

if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
}
$updateRecords = "";$auditlogDesc = "";
if($_SERVER['REQUEST_METHOD'] === 'POST'){

	$id = (isset($_POST['stepId'])&& !empty($_POST['stepId'])  ? $_POST['stepId'] : "0");
	$testcaseId = (isset($_POST['testcaseId']) && !empty($_POST['testcaseId']) ? $_POST['testcaseId'] : "0");


	$steps = (isset($_POST['steps']) ? mysqli_real_escape_string($conn,$_POST['steps']) : "");
	$steps_change = (isset($_POST['steps_change']) && !empty($_POST['steps_change']) ? $_POST['steps_change'] : "0");
	if($steps_change == "1"){
		if($auditlogDesc == ""){
			$auditlogDesc = "Steps";
		}else{
			$auditlogDesc .= ", Steps";
		}
		if($updateRecords == ""){
			$updateRecords = "s_tss_steps = '".$steps."'";
		}else{
			$updateRecords .= ", s_tss_steps = '".$steps."'";
		}
	}

	$expectedresult = (isset($_POST['expectedresult']) ? mysqli_real_escape_string($conn,$_POST['expectedresult']) : "");
	$expectedresult_change = (isset($_POST['expectedresult_change']) && !empty($_POST['expectedresult_change']) ? $_POST['expectedresult_change'] : "0");
	if($expectedresult_change == "1"){
		if($auditlogDesc == ""){
			$auditlogDesc = "Expected Result";
		}else{
			$auditlogDesc .= ", Expected Result";
		}
		if($updateRecords == ""){
			$updateRecords = "s_tss_expectedresult = '".$expectedresult."'";
		}else{
			$updateRecords .= ", s_tss_expectedresult = '".$expectedresult."'";
		}
	}
	if(!empty($id) && $id !="0") {

		if($updateRecords !=""){
			$sql = "UPDATE s_testcase_steps SET  $updateRecords where s_tss_id = ?  and accountId= ?  ";
			$stmt = mysqli_prepare($conn, $sql);
			mysqli_stmt_bind_param($stmt, "si",$id, $accountId);
			$result = mysqli_stmt_execute($stmt);

			if((isset($result) && $result)){
				$newFlag = 0;
				$msgarr["status"] = "Success";
				$msgarr["message"] = "Steps updated successfully.";
				$stepId = $id;
				

				if($auditlogDesc != ""){
					$auditlogSql = "insert into s_auditlogs (`s_a_desc`, `s_a_module`, `s_a_enteredby`,`accountId`,`s_a_recordId`,`s_a_recordnum` ) values ('".$auditlogDesc."','Testcase Steps','".$enteredby."','".$accountId."','".$stepId."','') ";
					
					mysqli_query( $conn, $auditlogSql);


				}
			}else{
				$msgarr["status"] = "Error";
				$msgarr["message"] = "Something went wrong. Please try again.";
			}
			if ($stmt) mysqli_stmt_close($stmt);
		}else{

			$msgarr["status"] = "Success";
			$msgarr["message"] = "Steps updated successfully.";
		}
	}else{
		$stepnum = 1;
		$stepnumdata = mysqli_query($conn,"SELECT * from s_testcase_steps where testcaseId = '".$testcaseId."' and accountId='".$accountId."'   order by s_tss_num desc limit 1");

		if(mysqli_num_rows($stepnumdata)>0){

			while($sdata = mysqli_fetch_assoc($stepnumdata)){
				$stepnum = (int)$sdata['s_tss_num'] +1;
			}
		}
		$sql = "INSERT INTO s_testcase_steps (s_tss_num, s_tss_steps, s_tss_expectedresult, testcaseId, accountId, s_tss_enteredby) VALUES (?, ?, ?, ?, ?, ?)";
		$stmt = mysqli_prepare($conn, $sql);
		mysqli_stmt_bind_param($stmt, "issiii", $stepnum, $steps, $expectedresult, $testcaseId, $accountId, $enteredby);
		$result = mysqli_stmt_execute($stmt);
		if($result)
		{
			$msgarr["status"] = "Success";
			$msgarr["message"] = "Steps added successfully.";

			$testcaseId = mysqli_insert_id($conn);
			}
		else
		{
			$msgarr["status"] = "Error";
			$msgarr["message"] = "Something went wrong. Please try again.";
		}
		if ($stmt) mysqli_stmt_close($stmt);
	}
}
echo json_encode($msgarr);