
<?php
include('config.php');
session_start();
 
$enteredby = 0;
$accountId = 0;
 
$msgarr = array();
$msgarr["status"] = "Error";
$msgarr["message"] = "Something went wrong. Please try again.";


if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
}
if($_SERVER['REQUEST_METHOD'] === 'POST'){

	$rtmId = (isset($_POST['rtmId']) ? intval($_POST['rtmId']) : 0);
	$defectIds = (isset($_POST['defectIds']) ? $_POST['defectIds'] : "0");

	
    // Prepare the SQL query using a prepared statement
    $sql = "INSERT INTO s_rtm_testcase (rtmId, defectId, testcaseId, s_rt_enteredby, accountId) 
            SELECT ?, s_d_id, '0', ?, ? 
            FROM s_defect 
            WHERE FIND_IN_SET(s_d_id,?) AND accountId = ?";

    $stmt = mysqli_prepare($conn, $sql);
    if ($stmt) {
        // Bind parameters to the prepared statement
        mysqli_stmt_bind_param($stmt, "iiisi", $rtmId, $enteredby, $accountId, $defectIds, $accountId);

        // Execute the prepared statement
        if (mysqli_stmt_execute($stmt)) {
            $msgarr["status"] = "Success";
            $msgarr["message"] = "Defects added successfully.";
        } else {
            $msgarr["status"] = "Error";
            $msgarr["message"] = "Something went wrong. Please try again.";
        }

        // Close the prepared statement
        mysqli_stmt_close($stmt);
    } else {
        $msgarr["status"] = "Error";
        $msgarr["message"] = "Database error. Please try again.";
    }

}

echo json_encode($msgarr);
