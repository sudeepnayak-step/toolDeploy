
<?php
include('config.php');
//require_once('../PHPMailer/class.phpmailer.php');

require 'vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$sqldata = mysqli_query($conn,"SELECT * from s_notifications where s_n_emailflag = '0' order by s_n_id asc limit 10");

while($data = mysqli_fetch_assoc($sqldata)){
	$attachmentsLogs =array();$attachfilename = array();
	$notificationId = $data['s_n_id'];
	$empids = $data['s_n_employees'];
	$recordid = $data['s_n_recordid'];
	$subid = $data['s_n_subid'];
	$recordnum = $data['s_n_recordnum'];
	$desc = $data['s_n_desc'];
	$module = $data['s_n_module'];
	$accountId = $data['accountId'];
	$enteredby = $data['s_n_enteredby'];
	$attachmentsLogs = explode(",", $data['s_n_attachments']);
	$attachfilename = explode(",", $data['s_n_filename']);
	$newflag = $data['s_n_newflag'];

	$empdata = mysqli_query($conn,"SELECT IFNULL(group_concat(s_e_emailid),'') as emailids from s_employees where accountId ='".$accountId."' and find_in_set(s_e_id,'$empids')   ");
	$emailids = "";
	while($edata = mysqli_fetch_assoc($empdata)){
		$emailids = $edata['emailids'];
	}
	
	if($emailids !=""){
		sendEmail($notificationId,$emailids,$recordnum,$desc,$recordid,$attachmentsLogs,$attachfilename,$newflag,$accountId,$module,$subid);
	}else{
		mysqli_query($conn,"update s_notifications set s_n_emailflag = '2' where s_n_id = '".$notificationId."' ");
	}

}
function sendEmail($nNotificationId,$nEmailids,$ndefectnum,$nauditlogDesc,$ndefectId,$nattachmentsLogs,$nattachfilename,$nFlag,$nAccountId,$nModule,$nSubid){
	global $conn;
	echo $nEmailids;
	 
	$emailarr = explode(",", $nEmailids);
	if(count($emailarr) >0){

	$emailsqldata = mysqli_query($conn,"SELECT *  from s_emailsetting where accountId = '".$nAccountId."' order by s_es_id desc limit 1");
	$e_host = "";
	$e_port = "";
	$e_fromname = "";
	$e_username = "";
	$e_password = "";
	$e_id = 0;

	while($data = mysqli_fetch_assoc($emailsqldata)){
	$e_host = $data['s_es_host'];
	$e_port =  $data['s_es_port'];
	$e_fromname =  $data['s_es_fromname'];
	$e_username =  $data['s_es_username'];
	 $e_password =  $data['s_es_password'];
	$e_id =  $data['s_es_id'];


	}
	$subject = "STEP - Defect Details";
$mail             = new PHPMailer(); // defaults to using php "mail()"
 
   	$mail->IsSMTP(); // enable SMTP
    $mail->IsHTML(true);
   	$mail->SMTPDebug  = 0;                     // enables SMTP debug information (for testing)
    $mail->SMTPAuth   = true;                  // enable SMTP authentication
    $mail->SMTPSecure = "tls";                 // sets the prefix to the servier
    $mail->Host       = "$e_host";      // sets GMAIL as the SMTP server
    $mail->Port       = $e_port;   // set the SMTP port for the GMAIL server
    $mail->SMTPKeepAlive = true;
    $mail->Mailer = "smtp";
	$body             = $emaildsrbody;
	$mail->Username   = $e_username;  // GMAIL username
	$mail->Password   = $e_password    ;   
	$mail->SetFrom($e_username, $e_fromname);
    $msgbody = "Hi,<br/><br/>User has change $nauditlogDesc in defect $ndefectnum. Please click on the following link by login to your account.<br/><br/>
	<a href='".STEP_root."master/defectdetails.php?id=$ndefectId' >$ndefectnum</a>";
      if($nFlag == 1){
      	$msgbody =  "Hi,<br/><br/>New defect added $ndefectnum. Please click on the following link by login to your account.<br/><br/>
	<a href='".STEP_root."master/defectdetails.php?id=$ndefectId' >$ndefectnum</a>";
      }
	$body             = $msgbody;
	if($nModule == "Risk/Issue"){

		$sqlquery = "SELECT rs.*,		
			concat(IFNULL(a1.s_e_fname,''),' ',IFNULL(a1.s_e_mname,''),' ',IFNULL(a1.s_e_lname,'')) as actionable,
			concat(IFNULL(a2.s_e_fname,''),' ',IFNULL(a2.s_e_mname,''),' ',IFNULL(a2.s_e_lname,'')) as raisedby
		from s_riskissue rs 
	 	left JOIN s_employees a1 on a1.s_e_id = rs.s_r_actionableby and rs.s_r_actionableby !='0'
	 	left JOIN s_employees a2 on a2.userId = rs.s_r_enteredby and rs.s_r_enteredby !='0'
		where rs.s_r_id = '".$nSubid."'
		     and rs.accountId = '".$nAccountId."' ";

		$sqldata = mysqli_query($conn,$sqlquery);

		while($data = mysqli_fetch_assoc($sqldata)){
				$risktype = $data['s_r_type'];
				$desc = $data['s_r_desc'];
				$actionableby = $data['actionable'];
				$plan = $data['s_r_plan'];
				$status = $data['s_r_status'];
				$probability = $data['s_r_probability'];
				$impact = $data['s_r_impact'];
				$raisedby = "Admin";
		        if(trim($data['raisedby']) !=""){
		            $raisedby = $data['raisedby'];
		        }
		    	$raiseddate = (isset($data['s_r_raiseddate']) && ($data['s_r_raiseddate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_r_raiseddate'])) : "");
		    	$closuredate = (isset($data['s_r_closuredate']) && ($data['s_r_closuredate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_r_closuredate'])) : "");

				$subject = "STEP - $risktype";

		    $details = "$risktype created by $raisedby on $raiseddate<br/><br/><br/>
		            <b>Description</b> :  $desc<br/><br/>
		            <b>Actionable</b> :  $actionableby<br/><br/>
		            <b>Action/Mitigation Plans</b> :  $plan<br/><br/>
		            <b>Target Closure Date</b> :  ".(!empty($closuredate) ? $closuredate : "-")."<br/><br/>
		            <b>Status</b> :  $status<br/><br/>
		            <b>Probability</b> :  $probability<br/><br/>
		            <b>Impact</b> :  $impact               

		            ";
		            $body= '<!DOCTYPE html>
			<html>

			<head>
			<title></title>
			<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
			<meta name="viewport" content="width=device-width, initial-scale=1">
			<meta http-equiv="X-UA-Compatible" content="IE=edge" />
			<style type="text/css">
				body,
				table,
				td,
				a {
					-webkit-text-size-adjust: 100%;
					-ms-text-size-adjust: 100%;
				}

				table,
				td {
					mso-table-lspace: 0pt;
					mso-table-rspace: 0pt;
				}

				img {
					-ms-interpolation-mode: bicubic;
				}
				img {
					border: 0;
					height: auto;
					line-height: 100%;
					outline: none;
					text-decoration: none;
				}

				table {
					border-collapse: collapse !important;
				}

				body {
					height: 100% !important;
					margin: 0 !important;
					padding: 0 !important;
					width: 100% !important;
				}

				a[x-apple-data-detectors] {
					color: inherit !important;
					text-decoration: none !important;
					font-size: inherit !important;
					font-family: inherit !important;
					font-weight: inherit !important;
					line-height: inherit !important;
				}

				/* MOBILE STYLES */
				@media screen and (max-width:600px) {
					h1 {
						font-size: 32px !important;
						line-height: 32px !important;
					}
				}

				div[style*="margin: 16px 0;"] {
					margin: 0 !important;
				}
			</style>
			</head>

			<body style=" margin: 0 !important; padding: 0 !important;">
			<table border="0" cellpadding="0" cellspacing="0" width="100%">
				<tr>
					<td  align="left"  style="padding: 0px 10px 0px 10px;">
						<table border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width: 600px;">
							<tr>
								<td bgcolor="#ffffff" align="left" style="padding: 20px 30px 40px 30px; color: #666666;  font-size: 14px; font-family: Helvetica, Arial, sans-serif; line-height: 25px;">

									'.$details.'
								</td>
							</tr>
							<tr>
								<td bgcolor="#ffffff" align="left">
									<table width="100%" border="0" cellspacing="0" cellpadding="0">
										<tr>
											<td bgcolor="#ffffff" align="left" style="padding: 20px 30px 60px 30px;">
												<table border="0" cellspacing="0" cellpadding="0">
													<tr>
														<td align="center" style="border-radius: 3px;" bgcolor="#1E73B6"><a href="'.STEP_root.'master/activity.php?id='.$ndefectId.'&&type='.$type.'" target="_blank" style="font-size: 16px; font-family: Helvetica, Arial, sans-serif; color: #ffffff; text-decoration: none; color: #ffffff; text-decoration: none; padding: 8px 15px; border-radius: 2px; border: 1px solid #1E73B6; display: inline-block;">View Activity</a></td>
													</tr>
												</table>
											</td>
										</tr>
									</table>
								</td>
							</tr>
						</table>
					</td>
				</tr>
			</table>
		</body></html>';
		}
	}else if($nModule == "Project Activity"){

		$sqlquery = "SELECT pa.*,IFNULL(p.s_p_name,'') as projectname,IFNULL(r.s_r_name,'') as releaseNum,IFNULL(a.s_a_name,'') as activityname,
		IFNULL(a.s_a_code,'') as activitycode ,
		IFNULL(a.s_a_type,'') as activitytype 
		from s_project_activity pa 
		join s_project p on p.s_p_id = pa.projectId 
		join s_activitymaster a on a.s_a_id = pa.activityId 
		join s_release r on r.s_r_id = pa.releaseId 
		where pa.s_pa_id = '".$ndefectId."'
		     and pa.accountId = '".$nAccountId."' ";

		$sqldata = mysqli_query($conn,$sqlquery);

		while($data = mysqli_fetch_assoc($sqldata)){
		    
		    $projectname = $data['projectname'];
		    $releaseNum = $data['releaseNum'];
		    $activityname = $data['activityname'];
		    $activitycode = $data['activitycode'];
		    $activitytype = $data['activitytype'];
		    $status = $data['s_pa_status'];
		    $desc = $data['s_pa_desc'];

		    $planstartdate = (isset($data['s_pa_planstartdate']) && ($data['s_pa_planstartdate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_pa_planstartdate'])) : "");

		    $planenddate = (isset($data['s_pa_planenddate']) && ($data['s_pa_planenddate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_pa_planenddate'])) : "");

		    $revisedstartdate = (isset($data['s_pa_revisedstartdate']) && ($data['s_pa_revisedstartdate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_pa_revisedstartdate'])) : "");

		    $revisedenddate = (isset($data['s_pa_revisedenddate']) && ($data['s_pa_revisedenddate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_pa_revisedenddate'])) : "");
		        
		    $actualstartdate = (isset($data['s_pa_actualstartdate']) && ($data['s_pa_actualstartdate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_pa_actualstartdate'])) : "");

		    $actualenddate = (isset($data['s_pa_actualenddate']) && ($data['s_pa_actualenddate'] != "0000-00-00") ? date("d/m/Y",strtotime($data['s_pa_actualenddate'])) : "");
		        


		    $totexecution = 0;
		    $perexecution = 0;
		    $tottestcase = 0;
		    $totPass = 0;
		    $totPasspercent = 0;
		    if($data['activitytype'] == "Execution"){
		        $testcasedata = mysqli_query($conn,"SELECT IFNULL(count(1),0) as totcount from s_testcase where projectId = '".$data['projectId']."'
		                                  and releaseId = '".$data['releaseId']."' and find_in_set('".$data['activityId']."',s_t_activityIds)   and accountId = '".$accountId."' ");

		        while($tdata = mysqli_fetch_assoc($testcasedata)){
		            $tottestcase = $tdata['totcount'] ;
		        }

		        $exedata = mysqli_query($conn, "SELECT  IFNULL(SUM(CASE WHEN s_f_testresult = 'Fail' THEN 1 ELSE 0 END),0) as Failcount,
		                                IFNULL(SUM(CASE WHEN s_f_testresult = 'Pass' THEN 1 ELSE 0 END),0) as Passcount from s_testcasefinal where projectId = '".$data['projectId']."'
		                                  and releaseId = '".$data['releaseId']."' and activityId = '".$data['activityId']."' and accountId = '".$accountId."' ");
		        while($edata = mysqli_fetch_assoc($exedata)){
		            $totexecution = $edata['Failcount'] + $edata['Passcount'];
		            $totPass = $edata['Passcount'];
		        }
		        $perexecution = ($tottestcase >0) ?  round(($totexecution/$tottestcase * 100),2) : 0;
		        $totPasspercent = ($tottestcase >0) ?  round(($totPass/$tottestcase * 100),2) : 0;
		    }else{
		        $perexecution = round($data['s_pa_completion'],2);
		        $totPasspercent = round($data['s_pa_completion'],2);
		    }

		    $qualityStatus = "";

		    $qualitythresholdsql = "SELECT *
		            FROM s_qualitystatus where accountId='".$nAccountId."' order by s_q_id desc limit 1";
		    $qthresholdquery = mysqli_query($conn,$qualitythresholdsql);
		    while($qTdata =mysqli_fetch_assoc($qthresholdquery)){
		        if($totPasspercent >= $qTdata['s_q_excellent']){
		            $qualityStatus = "<spam style='color: #fff;background-color: #28a745;display: inline-block;
		                                padding: .25em .4em;
		                                font-size: 75%;
		                                font-weight: 700;
		                                line-height: 1;
		                                text-align: center;
		                                white-space: nowrap;
		                                vertical-align: baseline;
		                                border-radius: .25rem;'>Excellent</spam>";
		        }else if($totPasspercent >= $qTdata['s_q_good']){
		            $qualityStatus = "<spam style='color: #fff;background-color: #007bff;display: inline-block;
		                                padding: .25em .4em;
		                                font-size: 75%;
		                                font-weight: 700;
		                                line-height: 1;
		                                text-align: center;
		                                white-space: nowrap;
		                                vertical-align: baseline;
		                                border-radius: .25rem;'>Good</spam>";
		        }else if($totPasspercent >= $qTdata['s_q_normal']){
		            $qualityStatus = "<spam style='color: #fff;background-color: #ffc107;display: inline-block;
		                                padding: .25em .4em;
		                                font-size: 75%;
		                                font-weight: 700;
		                                line-height: 1;
		                                text-align: center;
		                                white-space: nowrap;
		                                vertical-align: baseline;
		                                border-radius: .25rem;'>Normal</spam>";
		        }else {
		            $qualityStatus = "<spam style='color: #fff;background-color: #dc3545;display: inline-block;
		                                padding: .25em .4em;
		                                font-size: 75%;
		                                font-weight: 700;
		                                line-height: 1;
		                                text-align: center;
		                                white-space: nowrap;
		                                vertical-align: baseline;
		                                border-radius: .25rem;'>Poor</spam>";
		        }
		    }

		    $membersarr = array();
		    $membersnamearr = array();
		    $assignee = "";
		    $chksql = "select mem.*, concat(IFNULL(s_e_fname,''),' ',IFNULL(s_e_mname,''),' ',IFNULL(s_e_lname,'')) as membersname from s_activity_members mem join s_employees emp on emp.s_e_id = mem.employeeId where projactivityId = '".$data['s_pa_id']."' and mem.accountId = '".$nAccountId."' ";
		    //echo $sql;
		    $chkstmt = mysqli_query( $conn, $chksql);

		    while($mdata = mysqli_fetch_assoc($chkstmt)){
		        if(!in_array($mdata['employeeId'], $membersarr)){
		            array_push($membersnamearr, $mdata['membersname']);
		            array_push($membersarr, $mdata['employeeId']);

		            $assignee .= ($assignee != "" ? " | ".$mdata['membersname'] : $mdata['membersname']);
		        }

		    }

		    $subject = "STEP - Activity";

		    $details = "<b>$projectname</b> | <b>$releaseNum</b> | <b>$activityname</b><br/><br/>
		            <b>Activity</b> :  $activityname<br/><br/>
		            <b>Status</b> :  $status<br/><br/>
		            <b>Plan start date</b> :  ".(!empty($planstartdate) ? $planstartdate : "-")."<br/><br/>
		            <b>Plan end date</b> :  ".(!empty($planenddate) ? $planenddate : "-")."<br/><br/>
		            <b>Revised start date</b> :  ".(!empty($revisedstartdate) ? $revisedstartdate : "-")."<br/><br/>
		            <b>Revised end date</b> :  ".(!empty($revisedenddate) ? $revisedenddate : "-")."<br/><br/>
		            <b>Actual start date</b> :  ".(!empty($actualstartdate) ? $actualstartdate : "-")."<br/><br/>
		            <b>Actual end date</b> :  ".(!empty($actualenddate) ? $actualenddate : "-")."<br/><br/>
		            <b>Assignee</b> :  $assignee<br/><br/>
		            <b>Quality Status</b> :  $qualityStatus<br/><br/>
		            <b>Description</b> :  $desc               

		            ";
		            $body= '<!DOCTYPE html>
		<html>

		<head>
		<title></title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta http-equiv="X-UA-Compatible" content="IE=edge" />
		<style type="text/css">
		    body,
		    table,
		    td,
		    a {
		        -webkit-text-size-adjust: 100%;
		        -ms-text-size-adjust: 100%;
		    }

		    table,
		    td {
		        mso-table-lspace: 0pt;
		        mso-table-rspace: 0pt;
		    }

		    img {
		        -ms-interpolation-mode: bicubic;
		    }
		    img {
		        border: 0;
		        height: auto;
		        line-height: 100%;
		        outline: none;
		        text-decoration: none;
		    }

		    table {
		        border-collapse: collapse !important;
		    }

		    body {
		        height: 100% !important;
		        margin: 0 !important;
		        padding: 0 !important;
		        width: 100% !important;
		    }

		    a[x-apple-data-detectors] {
		        color: inherit !important;
		        text-decoration: none !important;
		        font-size: inherit !important;
		        font-family: inherit !important;
		        font-weight: inherit !important;
		        line-height: inherit !important;
		    }

		    /* MOBILE STYLES */
		    @media screen and (max-width:600px) {
		        h1 {
		            font-size: 32px !important;
		            line-height: 32px !important;
		        }
		    }

		    div[style*="margin: 16px 0;"] {
		        margin: 0 !important;
		    }
		</style>
		</head>

		<body style=" margin: 0 !important; padding: 0 !important;">
		<table border="0" cellpadding="0" cellspacing="0" width="100%">
		    <tr>
		        <td  align="left"  style="padding: 0px 10px 0px 10px;">
		             <table border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width: 600px;">
		                <tr>
		                    <td bgcolor="#ffffff" align="left" style="padding: 20px 30px 40px 30px; color: #666666;  font-size: 14px; font-family: Helvetica, Arial, sans-serif; line-height: 25px;">

		                        '.$details.'
		                    </td>
		                </tr>
		                <tr>
		                    <td bgcolor="#ffffff" align="left">
		                        <table width="100%" border="0" cellspacing="0" cellpadding="0">
		                            <tr>
		                                <td bgcolor="#ffffff" align="left" style="padding: 20px 30px 60px 30px;">
		                                    <table border="0" cellspacing="0" cellpadding="0">
		                                        <tr>
		                                            <td align="center" style="border-radius: 3px;" bgcolor="#1E73B6"><a href="'.STEP_root.'master/activity.php?id='.$ndefectId.'" target="_blank" style="font-size: 16px; font-family: Helvetica, Arial, sans-serif; color: #ffffff; text-decoration: none; color: #ffffff; text-decoration: none; padding: 8px 15px; border-radius: 2px; border: 1px solid #1E73B6; display: inline-block;">View Activity</a></td>
		                                        </tr>
		                                    </table>
		                                </td>
		                            </tr>
		                        </table>
		                    </td>
		                </tr>
		            </table>
		        </td>
		    </tr>
		</table>
	</body></html>';
	}
}else{

$sqlquery = "SELECT d.*,IFNULL(p.s_p_name,'') as projectname,
    IFNULL(r.s_r_name,'') as releaseNum,
    IFNULL(t.s_t_testcasenum,'') as testcasenum,
    IFNULL(ds.s_ds_name,'') as defectstatus,
    IFNULL(dt.s_dt_name,'') as defecttype,
    concat(IFNULL(a2.s_e_fname,''),' ',IFNULL(a2.s_e_mname,''),' ',IFNULL(a2.s_e_lname,'')) as reporteby

    from s_defect d 
    left join s_project p on p.s_p_id = d.projectId 
    left join s_release r on r.s_r_id = d.releaseId 
    left join s_testcase t on t.s_t_id = d.testcaseId 
    left JOIN s_employees a2 on a2.userId = d.s_d_enteredby and d.s_d_enteredby !='0'
    left join s_defectstatusmaster ds on ds.s_ds_id = d.defectstatusId 
    left join s_defecttypemaster dt on dt.s_dt_id = d.defecttypeId  
        
        where d.s_d_id = '".$ndefectId."' and d.accountId = '".$nAccountId."' ";

$sqldata = mysqli_query($conn,$sqlquery);

    while($data = mysqli_fetch_assoc($sqldata)){
        $createdat = (isset($data['s_d_createdtime']) && ($data['s_d_createdtime'] != "0000-00-00 00:00:00") ? date("d/m/Y H:m a",strtotime($data['s_d_createdtime'])) : "-");
        $defectnum = $data['s_d_defectnum'];
        $projectname = $data['projectname'];
        $releaseNum = $data['releaseNum'];
        $testcasenum = $data['testcasenum'];
        $defecttype = $data['defecttype'];
        $defectstatus = $data['defectstatus'];
        $module = $data['s_d_module'];
        $submodule = $data['s_d_submodule'];
        $severity = $data['s_d_severity'];
        $priority = $data['s_d_priority'];
        $shortdesc = $data['s_d_shortdesc'];
        $longdesc = $data['s_d_longdesc'];
        $testdata = $data['s_d_testdata'];
        $steps = $data['s_d_steps'];
        $expectedresult = $data['s_d_expectedresult'];
        $actualresult = $data['s_d_actualresult'];
        $assignee = $data['s_d_actualresult'];
        // $reporteby = $data['reporteby'];
        $reporteby = "Admin";
        if(trim($data['reporteby']) !=""){
            $reporteby = $data['reporteby'];
        }
        
        $dir = STEP_dir."defectdata/".$nAccountId."/".$data['s_d_id']."/";
                    // echo $dir;
                    if(is_dir($dir)) {

                        $files = array_diff(scandir($dir), array('..', '.'));
                        if(count($files) >0){
                            foreach($files as $file){
                                // echo $file;
                                $ext = pathinfo($file, PATHINFO_EXTENSION);
                                // $attachmentsarr[] = array("filenamestr"=>$file,"extension"=>$ext,"filename"=>STEP_root.'defectdata/'.$accountId.'/'.$data['s_d_id']."/".$file,"filepath"=>'defectdata/'.$accountId.'/'.$data['s_d_id']."/".$file);;
                                // if (file_exists($nattachmentsLogs[$i])) {
                                // echo STEP_dir.'defectdata/'.$nAccountId.'/'.$data['s_d_id']."/".$file."<br/>";
								$mail->AddAttachment(STEP_dir.'defectdata/'.$nAccountId.'/'.$data['s_d_id']."/".$file,$file);
								// }
                            }
                        }
                    }

        $nCount = 0;
        $assignee = "";
        $assigndata = mysqli_query($conn,"SELECT d.*,concat(IFNULL(s_e_fname,''),' ',IFNULL(s_e_mname,''),' ',IFNULL(s_e_lname,'')) as assignee 
            from s_defectassignmenthistory d 
         left JOIN s_employees o1 on o1.s_e_id = d.s_dh_assignto and d.s_dh_assignto !='0' 

                where d.defectId = '".$data['s_d_id']."' and d.accountId = '".$nAccountId."' ");
        $len = mysqli_num_rows($assigndata);
        while($adata = mysqli_fetch_assoc($assigndata)){
            if($nCount == ($len -1)){

                    $assignee .= ($assignee != "" ? " | ".$adata['assignee'] : $adata['assignee']);
            }else{
                    $assignee .= ($assignee != "" ? " | "."<strike>".$adata['assignee']."</strike>" : "<strike>".$adata['assignee']."</strike>");

            }
            $nCount++;
        }
        $subject = "STEP-".$defectnum." | ".$shortdesc;

        $details = "$reporteby <b>created an issue.</b><br/><hr>$projectname | $defectnum<br/>
        $shortdesc<br/>
                Defect created by $reporteby on $createdat<br/><br/><br/>
                <b>Description</b> :  $longdesc<br/><br/>
                <b>Test Data</b> :  $testdata<br/><br/>
                <b>Steps To Reproduce</b> :  $steps<br/><br/>
                <b>Actual Result</b> :  $actualresult<br/><br/>
                <b>Expected Result</b> :  $expectedresult<br/><br/>
                <b>Defect Type</b> :  $defecttype<br/><br/>
                <b>Assignee</b> :  $assignee<br/><br/>
                <b>Priority</b> :  $priority<br/><br/>
                <b>Created</b> :  $createdat<br/><br/>
                <b>Severity</b> :  $severity<br/><br/>
                <b>Reporter</b> :  $reporteby

                ";
                $body= '<!DOCTYPE html>
<html>

<head>
    <title></title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <style type="text/css">
        body,
        table,
        td,
        a {
            -webkit-text-size-adjust: 100%;
            -ms-text-size-adjust: 100%;
        }

        table,
        td {
            mso-table-lspace: 0pt;
            mso-table-rspace: 0pt;
        }

        img {
            -ms-interpolation-mode: bicubic;
        }
        img {
            border: 0;
            height: auto;
            line-height: 100%;
            outline: none;
            text-decoration: none;
        }

        table {
            border-collapse: collapse !important;
        }

        body {
            height: 100% !important;
            margin: 0 !important;
            padding: 0 !important;
            width: 100% !important;
        }

        a[x-apple-data-detectors] {
            color: inherit !important;
            text-decoration: none !important;
            font-size: inherit !important;
            font-family: inherit !important;
            font-weight: inherit !important;
            line-height: inherit !important;
        }

        /* MOBILE STYLES */
        @media screen and (max-width:600px) {
            h1 {
                font-size: 32px !important;
                line-height: 32px !important;
            }
        }

        div[style*="margin: 16px 0;"] {
            margin: 0 !important;
        }
    </style>
</head>

<body style=" margin: 0 !important; padding: 0 !important;">
<table border="0" cellpadding="0" cellspacing="0" width="100%">
        <tr>
            <td  align="left"  style="padding: 0px 10px 0px 10px;">
                 <table border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width: 600px;">
                    <tr>
                        <td bgcolor="#ffffff" align="left" style="padding: 20px 30px 40px 30px; color: #666666;  font-size: 14px; font-family: Helvetica, Arial, sans-serif; line-height: 25px;">

                            '.$details.'
                        </td>
                    </tr>
                    <tr>
                        <td bgcolor="#ffffff" align="left">
                            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                <tr>
                                    <td bgcolor="#ffffff" align="left" style="padding: 20px 30px 60px 30px;">
                                        <table border="0" cellspacing="0" cellpadding="0">
                                            <tr>
                                                <td align="center" style="border-radius: 3px;" bgcolor="#1E73B6"><a href="'.STEP_root.'master/defectdetails.php?id='.$ndefectId.'" target="_blank" style="font-size: 16px; font-family: Helvetica, Arial, sans-serif; color: #ffffff; text-decoration: none; color: #ffffff; text-decoration: none; padding: 8px 15px; border-radius: 2px; border: 1px solid #1E73B6; display: inline-block;">View Defect</a></td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body></html>';

    }
}

$len = count($emailarr);
for($i=0; $i< $len; $i++){

$mail->AddAddress(trim($emailarr[$i]));
}
$mail->Subject    = "$subject";

$mail->AltBody    = "To view the message, please use an HTML compatible email viewer!"; // optional, comment out and test

$mail->MsgHTML($body);

if(!$mail->Send()) {


	mysqli_query($conn,"update s_notifications set s_n_emailflag = '2' where s_n_id = '".$nNotificationId."' ");
	return 1;
} else {
	mysqli_query($conn,"update s_notifications set s_n_emailflag = '1' where s_n_id = '".$nNotificationId."' ");
	return 0;
}
}

}

// echo json_encode($msgarr);
