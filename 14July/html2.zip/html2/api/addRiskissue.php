<?php
include('config.php');
session_start(); // Start a new or resume an existing session
 
// Initialize variables for the user ID and account ID
$enteredby = 0;$accountId = 0;
 
// Initialize the variable to store the ID of the newly inserted record
$nId = -1;

// Check if the session contains the user ID and account ID
if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
}

// Check if the request method is POST
if($_SERVER['REQUEST_METHOD'] === 'POST'){

    // Retrieve the activityId from the POST data, defaulting to "0" if not set
    $activityId = (isset($_POST['activityId']) ? $_POST['activityId'] : "0");

    $date = date("Y-m-d");

    // Construct the SQL query using a prepared statement
    $sql = "INSERT INTO s_riskissue (s_r_activityId, s_r_type, s_r_raiseddate, s_r_plan, s_r_desc, s_r_status, s_r_probability, s_r_impact, s_r_enteredby, accountId) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    // Prepare the statement
    $stmt = mysqli_prepare($conn, $sql);

    if ($stmt) {
        // Bind the parameters to the statement
        mysqli_stmt_bind_param($stmt, "ssssssssii", $activityId, $type, $date, $plan, $desc, $status, $probability, $impact, $enteredby, $accountId);

        // Set default values for empty fields
        $type = '';
        $plan = '';
        $desc = '';
        $status = '';
        $probability = '';
        $impact = '';

        // Execute the statement
        if (mysqli_stmt_execute($stmt)) {
            // Retrieve the ID of the newly inserted record
            $nId = mysqli_insert_id($conn);
        } else {
            // Handle execution errors
            error_log("Error executing statement: " . mysqli_stmt_error($stmt));
        }

        // Close the statement
        mysqli_stmt_close($stmt);
    } else {
        // Handle preparation errors
        error_log("Error preparing statement: " . mysqli_error($conn));
    }
}
// Output the ID of the newly inserted record (or -1 if the insertion failed)
echo $nId;
