<?php
include('config.php');
session_start();
 
$enteredby = 0;$accountId = 0;
 /** this script saves the defect type in master */
$msgarr = array();

if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
}
if($_SERVER['REQUEST_METHOD'] === 'POST'){

	$id = (isset($_POST['defecttypeId']) ? intval($_POST['defecttypeId']) : 0);
	$defecttypename = (isset($_POST['defecttypename']) ? mysqli_real_escape_string($conn,$_POST['defecttypename']) : "");
	$activestatus = (isset($_POST['activestatus']) ? $_POST['activestatus'] : "Active");

	if (!empty($id) && $id != "0") {
        // Update query using prepared statements
        $sql = "UPDATE s_defecttypemaster SET s_dt_name = ?, s_dt_activestatus = ? WHERE s_dt_id = ? AND accountId = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "ssii", $defecttypename, $activestatus, $id, $accountId);

        if (mysqli_stmt_execute($stmt)) {
            $msgarr["status"] = "Success";
            $msgarr["message"] = "Defect type updated successfully.";
        } else {
            $msgarr["status"] = "Error";
            $msgarr["message"] = "Something went wrong. Please try again.";
        }
        mysqli_stmt_close($stmt);
    } else {
        // Insert query using prepared statements
        $sql = "INSERT INTO s_defecttypemaster (s_dt_name, s_dt_enteredby, accountId, s_dt_activestatus) VALUES (?, ?, ?, ?)";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "siis", $defecttypename, $enteredby, $accountId, $activestatus);

        if (mysqli_stmt_execute($stmt)) {
            $msgarr["status"] = "Success";
            $msgarr["message"] = "Defect type added successfully.";
        } else {
            $msgarr["status"] = "Error";
            $msgarr["message"] = "Something went wrong. Please try again.";
        }
        mysqli_stmt_close($stmt);
    }
}
echo json_encode($msgarr);