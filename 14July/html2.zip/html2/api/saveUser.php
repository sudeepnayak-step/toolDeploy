<?php
header('Access-Control-Allow-Origin: *');
include('config.php');
header( 'Content-type: text/html; charset=utf-8' );
require_once('class.phpmailer.php');

$updateRecords = "";$auditlogDesc = "";
$msgarr = array();



$enteredby = (isset($_POST["enteredby"]) && !empty($_POST["enteredby"]) ? $_POST["enteredby"] : 0);
$accountId = (isset($_POST["accountId"]) && !empty($_POST["accountId"]) ? $_POST["accountId"] : 0);
$userempid = (isset($_POST["userempid"]) && !empty($_POST["userempid"])  ? $_POST["userempid"] : 0);

if($_SERVER['REQUEST_METHOD'] === 'POST'){

  $id = (isset($_POST['uid']) ? $_POST['uid'] : "0");
  $roleId = (isset($_POST['roleId']) ? $_POST['roleId'] : "0");
  $roleId_change = (isset($_POST['roleId_change']) && !empty($_POST['roleId_change']) ? $_POST['roleId_change'] : "0");
  if($roleId_change == "1"){
    if($auditlogDesc == ""){
      $auditlogDesc = "Role";
    }else{
      $auditlogDesc .= ", Role";
    }
    if($updateRecords == ""){
      $updateRecords = "roleId = '".$roleId."'";
    }else{
      $updateRecords .= ", roleId = '".$roleId."'";
    }
  }

$groupId = (isset($_POST['groupId']) ? $_POST['groupId'] : "0");
  $groupId_change = (isset($_POST['groupId_change']) && !empty($_POST['groupId_change']) ? $_POST['groupId_change'] : "0");
  if($groupId_change == "1"){
    if($auditlogDesc == ""){
      $auditlogDesc = "Group";
    }else{
      $auditlogDesc .= ", Group";
    }
    if($updateRecords == ""){
      $updateRecords = "groupId = '".$groupId."'";
    }else{
      $updateRecords .= ", groupId = '".$groupId."'";
    }
  }


  $userId = (isset($_POST['userId']) ? $_POST['userId'] : "0");
  $activestatus = (isset($_POST['activestatus']) ? $_POST['activestatus'] : "Active");
  $activestatus_change = (isset($_POST['activestatus_change']) && !empty($_POST['activestatus_change']) ? $_POST['activestatus_change'] : "0");
  if($activestatus_change == "1"){
    if($auditlogDesc == ""){
      $auditlogDesc = "Status";
    }else{
      $auditlogDesc .= ", Status";
    }
    if($updateRecords == ""){
      $updateRecords = "s_e_activestatus = '".$activestatus."'";
    }else{
      $updateRecords .= ", s_e_activestatus = '".$activestatus."'";
    }
  }

  $firstname = (isset($_POST['firstname']) ? mysqli_real_escape_string($conn,sanitize($_POST['firstname'])) : "");
  $firstname_change = (isset($_POST['firstname_change']) && !empty($_POST['firstname_change']) ? $_POST['firstname_change'] : "0");
  if($firstname_change == "1"){
    if($auditlogDesc == ""){
      $auditlogDesc = "First name";
    }else{
      $auditlogDesc .= ", First name";
    }
    if($updateRecords == ""){
      $updateRecords = "s_e_fname = '".$firstname."'";
    }else{
      $updateRecords .= ", s_e_fname = '".$firstname."'";
    }
  }

  $middlename = (isset($_POST['middlename']) ? mysqli_real_escape_string($conn,sanitize($_POST['middlename'])) : "");
  $middlename_change = (isset($_POST['middlename_change']) && !empty($_POST['middlename_change']) ? $_POST['middlename_change'] : "0");
  if($middlename_change == "1"){
    if($auditlogDesc == ""){
      $auditlogDesc = "Middle name";
    }else{
      $auditlogDesc .= ", Middle name";
    }
    if($updateRecords == ""){
      $updateRecords = "s_e_mname = '".$middlename."'";
    }else{
      $updateRecords .= ", s_e_mname = '".$middlename."'";
    }
  }

  $lastname = (isset($_POST['lastname']) ? mysqli_real_escape_string($conn,sanitize($_POST['lastname'])) : "");
  $lastname_change = (isset($_POST['lastname_change']) && !empty($_POST['lastname_change']) ? $_POST['lastname_change'] : "0");
  if($lastname_change == "1"){
    if($auditlogDesc == ""){
      $auditlogDesc = "Last name";
    }else{
      $auditlogDesc .= ", Last name";
    }
    if($updateRecords == ""){
      $updateRecords = "s_e_lname = '".$lastname."'";
    }else{
      $updateRecords .= ", s_e_lname = '".$lastname."'";
    }
  }

  $emailid = (isset($_POST['emailid']) ? mysqli_real_escape_string($conn,sanitize($_POST['emailid'])) : "");
  $emailid_change = (isset($_POST['emailid_change']) && !empty($_POST['emailid_change']) ? $_POST['emailid_change'] : "0");
  if($emailid_change == "1"){
    if($auditlogDesc == ""){
      $auditlogDesc = "Email ID";
    }else{
      $auditlogDesc .= ", Email ID";
    }
    if($updateRecords == ""){
      $updateRecords = "s_e_emailid = '".$emailid."'";
    }else{
      $updateRecords .= ", s_e_emailid = '".$emailid."'";
    }
  }

  $phoneno = (isset($_POST['phoneno']) ? sanitize($_POST['phoneno']) : "");
  $phoneno_change = (isset($_POST['phoneno_change']) && !empty($_POST['phoneno_change']) ? $_POST['phoneno_change'] : "0");
  if($phoneno_change == "1"){
    if($auditlogDesc == ""){
      $auditlogDesc = "Phone No.";
    }else{
      $auditlogDesc .= ", Phone No.";
    }
    if($updateRecords == ""){
      $updateRecords = "s_e_phoneno = '".$phoneno."'";
    }else{
      $updateRecords .= ", s_e_phoneno = '".$phoneno."'";
    }
  }

  $sendactivation = (isset($_POST['sendactivation']) ? $_POST['sendactivation'] : "");


  if(!empty($id) && $id !="0") {

      if($updateRecords !=""){
        $sql = "UPDATE s_employees SET  $updateRecords where s_e_id = ? and accountId = ? ";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "si", $id,$accountId);
        $stmt_executed = mysqli_stmt_execute($stmt);
    
        if((isset($stmt_executed) && $stmt_executed)){
          $emparr = array();
          $emparr['userId'] = $userId;
          $emparr['username'] = $emailid;
          $emparr['email'] = $emailid;
          $emparr['type'] = "Employee";
          $emparr['employeeId'] = $id;
          $emparr['roleId'] = $roleId;
	$emparr['groupId'] = $groupId;
          $emparr['accountId'] = $accountId;
          $emparr['accountactivestatus'] = $activestatus;
          $emparr['accountstatus'] = "Created";
          $emparr['enteredby'] = $enteredby;


          $msgarr["empdata"] = $emparr;
          $msgarr["status"] = "Success";
          $msgarr["message"] = "User updated successfully.";
          if($auditlogDesc != ""){
            // Use prepared statements for INSERT query
            $auditlogSql = "INSERT INTO s_auditlogs (s_a_desc, s_a_module, s_a_enteredby, accountId, s_a_recordId, s_a_recordnum) VALUES (?, ?, ?, ?, ?, ?)";
            $stmt_audit = mysqli_prepare($conn, $auditlogSql);
            $auditmodule = "User";			
            mysqli_stmt_bind_param($stmt_audit, "ssiiis", $auditlogDesc,$auditmodule, $enteredby, $accountId, $id,$emailid);
            mysqli_stmt_execute($stmt_audit);
            mysqli_stmt_close($stmt_audit);
          }
        }else{
          $msgarr["status"] = "Error";
          $msgarr["message"] = "Something went wrong. Please try again.";
        }
		    mysqli_stmt_close($stmt);
      }else{
          $emparr = array();
          $emparr['userId'] = $userId;
          $emparr['username'] = $emailid;
          $emparr['email'] = $emailid;
          $emparr['type'] = "Employee";
          $emparr['employeeId'] = $id;
          $emparr['roleId'] = $roleId;
	$emparr['groupId'] = $groupId;
          $emparr['accountId'] = $accountId;
          $emparr['accountactivestatus'] = $activestatus;
          $emparr['accountstatus'] = "Created";
          $emparr['enteredby'] = $enteredby;


          $msgarr["empdata"] = $emparr;
          $msgarr["status"] = "Success";
          $msgarr["message"] = "User updated successfully.";
      }
  }else{

      $expirytime = date('Y-m-d', strtotime('+1 years'));
      $sql = "INSERT INTO s_employees (s_e_fname, s_e_mname, s_e_lname, s_e_emailid, s_e_phoneno, roleId, groupId, userId, s_e_enteredby, s_e_activestatus, accountId, s_e_accountstatus) VALUES (?, ?, ?, ?, ?, ?, ?, '0', ?, ?, ?, '')";
      $stmt = mysqli_prepare($conn, $sql);
      mysqli_stmt_bind_param($stmt, "sssssisisi", $firstname, $middlename, $lastname, $emailid, $phoneno, $roleId, $groupId, $enteredby, $activestatus, $accountId);
      $stmtresult = mysqli_stmt_execute($stmt);
      if($stmtresult){
          $insertedId = mysqli_insert_id($conn);
          $emparr = array();
          $emparr['userId'] = "0";
          $emparr['username'] = $emailid;
          $emparr['email'] = $emailid;
          $emparr['type'] = "Employee";
          $emparr['employeeId'] = $insertedId;
          $emparr['roleId'] = $roleId;
	 $emparr['groupId'] = $groupId;
          $emparr['accountId'] = $accountId;
          $emparr['accountactivestatus'] = $activestatus;
          $emparr['accountstatus'] = "Created";
          $emparr['enteredby'] = $enteredby;

          $msgarr["status"] = "Success";
          $msgarr["empdata"] = $emparr;
          $msgarr["message"] = "User added successfully.";
        
      }else{
        
          $msgarr["status"] = "Error";
          $msgarr["message"] = "Something went wrong. Please try again.";
      }
      mysqli_stmt_close($stmt);

  }
}



function sendEmail($nActivationNum){
	  global $conn,$emailid,$firstname,$accountId;
		echo $accountId;die;
    $emailsqldata = mysqli_query($conn,"SELECT *  from s_emailsetting where accountId = '".$accountId."' order by s_es_id desc limit 1");
    $e_host = "";
    $e_port = "";
    $e_fromname = "";
    $e_username = "";
    $e_password = "";
    $e_id = 0;

	while($data = mysqli_fetch_assoc($emailsqldata)){
    $e_host = $data['s_es_host'];
    $e_port =  $data['s_es_port'];
    $e_fromname =  $data['s_es_fromname'];
    $e_username =  $data['s_es_username'];
    $e_password =  $data['s_es_password'];
    $e_id =  $data['s_es_id'];

    }
    $subject = "STEP - Account Activation";
    $mail             = new PHPMailer(); // defaults to using php "mail()"
    $mail->IsSMTP(); // enable SMTP
    $mail->IsHTML(true);
    $mail->SMTPDebug  = 0;                     // enables SMTP debug information (for testing)
    $mail->SMTPAuth   = false;                  // enable SMTP authentication
    $mail->SMTPSecure = true;                 // sets the prefix to the servier
    $mail->SMTPAutoTLS=false;
    $mail->Host       = "$e_host";      // sets GMAIL as the SMTP server
    $mail->Port       = $e_port;   // set the SMTP port for the GMAIL server
    $mail->Mailer = "smtp";
    $body             = "Dear $firstname,<br/><br/>Your account has been created on STEP. Please click on the following link and activate your account to login.<br/><br/>
      <a href='".STEP_root."accountactivation.php?token=".$nActivationNum."' >Activate</a>";
    //$mail->Username   = "$e_username";  // GMAIL username
    //$mail->Password   = "$e_password"     ;       // GMAIL password

    $mail->SetFrom("", "$e_fromname");

    $mail->AddAddress(trim($emailid));
    $mail->Subject    = "$subject";

    $mail->AltBody    = "To view the message, please use an HTML compatible email viewer!"; // optional, comment out and test

    $mail->MsgHTML($body);

    if(!$mail->Send()) {
      return 1;
    } else {
      return 0;
    }


}
echo json_encode($msgarr);
