<?php
header('Access-Control-Allow-Origin: *');
include('config.php');

   /** This PHP script retrieves the defect data from a database. 
 * It formats the data and returns it in JSON format. */

$projarr['data'] = array();
$temp_defectId = isset($_GET['id']) ? intval($_GET['id']) : 0;

$sql = "SELECT d.*,IFNULL(p.s_p_name,'') as projectname,
	IFNULL(r.s_r_name,'') as releaseNum,
	IFNULL(t.s_t_testcasenum,'') as testcasenum,
	IFNULL(ds.s_ds_name,'') as defectstatus,
	IFNULL(dt.s_dt_name,'') as defecttype

	from s_defect d 
	left join s_project p on p.s_p_id = d.projectId 
	left join s_release r on r.s_r_id = d.releaseId 
	left join s_testcase t on t.s_t_id = d.testcaseId 
	left join s_defectstatusmaster ds on ds.s_ds_id = d.defectstatusId 
	left join s_defecttypemaster dt on dt.s_dt_id = d.defecttypeId  
		
	where d.s_d_id = ?  ";

	
	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "i",$temp_defectId);
	mysqli_stmt_execute($stmt);
	$result = mysqli_stmt_get_result($stmt);

	
	$projarr = array();
	while($data = mysqli_fetch_assoc($result)){

		$accountId = $data['accountId'];
		$nextId = 0;
		$prvId = 0;

		// Fetch nextId using prepared statement
		$nextSql = "SELECT s_d_id as nextId FROM s_defect WHERE accountId = ? AND s_d_id = (SELECT MIN(s_d_id) FROM s_defect WHERE s_d_id > ?)";
		$nextStmt = mysqli_prepare($conn, $nextSql);
		mysqli_stmt_bind_param($nextStmt, "ii", $accountId, $temp_defectId);
		mysqli_stmt_execute($nextStmt);
		$nextResult = mysqli_stmt_get_result($nextStmt);
		while ($nextdata = mysqli_fetch_assoc($nextResult)) {
			$nextId = $nextdata['nextId'];
		}

		// Fetch prvId using prepared statement
		$prvSql = "SELECT s_d_id as prvId FROM s_defect WHERE accountId = ? AND s_d_id = (SELECT MAX(s_d_id) FROM s_defect WHERE s_d_id < ?)";
		$prvStmt = mysqli_prepare($conn, $prvSql);
		mysqli_stmt_bind_param($prvStmt, "ii", $accountId, $temp_defectId);
		mysqli_stmt_execute($prvStmt);
		$prvResult = mysqli_stmt_get_result($prvStmt);
		while ($prvdata = mysqli_fetch_assoc($prvResult)) {
			$prvId = $prvdata['prvId'];
		}
		$attachmentsarr = array();
		$assignmentarr = array();

		// Fetch assignment data using prepared statement
		$assignSql = "SELECT d.*, CONCAT(IFNULL(s_e_fname,''), IFNULL(s_e_mname,''), ' ', IFNULL(s_e_lname,'')) as assignee 
		FROM s_defectassignmenthistory d 
		LEFT JOIN s_employees o1 ON o1.s_e_id = d.s_dh_assignto AND d.s_dh_assignto != '0' 
		WHERE d.defectId = ? AND d.accountId = ?";
		$assignStmt = mysqli_prepare($conn, $assignSql);
		mysqli_stmt_bind_param($assignStmt, "ii", $data['s_d_id'], $accountId);
		mysqli_stmt_execute($assignStmt);
		$assignResult = mysqli_stmt_get_result($assignStmt);
		while ($adata = mysqli_fetch_assoc($assignResult)) {
			$assignmentarr[] = $adata['assignee'];
		}
		$dir = STEP_dir."defectdata/".$accountId."/".$data['s_d_id']."/";
		if(is_dir($dir)) {

			$files = array_diff(scandir($dir), array('..', '.'));
			if(count($files) >0){
				foreach($files as $file){
					// echo $file;
					$ext = pathinfo($file, PATHINFO_EXTENSION);
					$attachmentsarr[] = array("filenamestr"=>$file,"extension"=>$ext,"filename"=>STEP_root.'defectdata/'.$accountId.'/'.$data['s_d_id']."/".$file,"filepath"=>'defectdata/'.$accountId.'/'.$data['s_d_id']."/".$file);;
				}
			}
		}
		$projarr = array("id"=>$data['s_d_id'],
			"defectnum"=>$data['s_d_defectnum'],
			"projectId"=>$data['projectname'],
			"releaseId"=>$data['releaseNum'],
			"testcaseId"=>$data['testcasenum'],
			"defecttypeId"=>$data['defecttype'],
			"defectstatusId"=>$data['defectstatus'],
			"module"=>$data['s_d_module'],
			"submodule"=>$data['s_d_submodule'],
			"severity"=>$data['s_d_severity'],
			"priority"=>$data['s_d_priority'],
			"shortdesc"=>$data['s_d_shortdesc'],
			"longdesc"=>$data['s_d_longdesc'],
			"testdata"=>$data['s_d_testdata'],
			"steps"=>$data['s_d_steps'],
			"expectedresult"=>$data['s_d_expectedresult'],
			"actualresult"=>$data['s_d_actualresult'],
			"comment"=>$data['s_d_comment'],
			"assignto"=>$data['s_d_assignto'],
		"attachments"=>$attachmentsarr,
		"assignee"=>$assignmentarr
		);
	}
echo json_encode($projarr);
?>