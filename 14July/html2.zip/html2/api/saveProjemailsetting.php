
<?php
include('config.php');
session_start();
 
$enteredby = 0;$accountId=0;
 /** this saves the email setting for this project */
$msgarr = array();

$msgarr["status"] = "Error";
$msgarr["message"] = "Something went wrong. Please try again.";
if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
}
$updateRecords = "";$auditlogDesc = "";$newFlag = 0;
if($_SERVER['REQUEST_METHOD'] === 'POST'){

$id = (isset($_POST['emailsettingId']) ? $_POST['emailsettingId'] : "0");

$hostname = (isset($_POST['hostname']) && !empty($_POST['hostname']) ? mysqli_real_escape_string($conn,$_POST['hostname']) : "");
$hostname_change = (isset($_POST['hostname_change']) && !empty($_POST['hostname_change']) ? $_POST['hostname_change'] : "0");
if($hostname_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "Hostname";
	}else{
		$auditlogDesc .= ", Hostname";
	}
	if($updateRecords == ""){
		$updateRecords = "s_projes_host = '".$hostname."'";
	}else{
		$updateRecords .= ", s_projes_host = '".$hostname."'";
	}
}


$scheduletime = (isset($_POST['scheduletime']) && !empty($_POST['scheduletime']) ? mysqli_real_escape_string($conn,$_POST['scheduletime']) : "");
$scheduletime_change = (isset($_POST['scheduletime_change']) && !empty($_POST['scheduletime_change']) ? $_POST['scheduletime_change'] : "0");
if($scheduletime_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "scheduletime";
	}else{
		$auditlogDesc .= ", scheduletime";
	}
	if($updateRecords == ""){
		$updateRecords = "s_projes_scheduletime = '".$scheduletime."'";
	}else{
		$updateRecords .= ", s_projes_scheduletime = '".$scheduletime."'";
	}
}


$subject = (isset($_POST['subject']) && !empty($_POST['subject']) ? mysqli_real_escape_string($conn,$_POST['subject']) : "");
$subject_change = (isset($_POST['subject_change']) && !empty($_POST['subject_change']) ? $_POST['subject_change'] : "0");
if($subject_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "subject";
	}else{
		$auditlogDesc .= ", subject";
	}
	if($updateRecords == ""){
		$updateRecords = "s_projes_subject = '".$subject."'";
	}else{
		$updateRecords .= ", s_projes_subject = '".$subject."'";
	}
}

$projectId = (isset($_POST['projectId']) && !empty($_POST['projectId'])? $_POST['projectId'] : "0");
$projectId_change = (isset($_POST['projectId_change']) && !empty($_POST['projectId_change']) ? $_POST['projectId_change'] : "0");
if($projectId_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "project";
	}else{
		$auditlogDesc .= ", project";
	}
	if($updateRecords == ""){
		$updateRecords = "projectId = '".$projectId."'";
	}else{
		$updateRecords .= ", projectId = '".$projectId."'";
	}
}

$portno = (isset($_POST['portno']) && !empty($_POST['portno']) ? mysqli_real_escape_string($conn,$_POST['portno']) : "");
$portno_change = (isset($_POST['portno_change']) && !empty($_POST['portno_change']) ? $_POST['portno_change'] : "0");
if($portno_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "portno";
	}else{
		$auditlogDesc .= ", portno";
	}
	if($updateRecords == ""){
		$updateRecords = "s_projes_port = '".$portno."'";
	}else{
		$updateRecords .= ", s_projes_port = '".$portno."'";
	}
}

$fromname = (isset($_POST['fromname']) && !empty($_POST['fromname']) ? mysqli_real_escape_string($conn,$_POST['fromname']) : "");
$fromname_change = (isset($_POST['fromname_change']) && !empty($_POST['fromname_change']) ? $_POST['fromname_change'] : "0");
if($fromname_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "fromname";
	}else{
		$auditlogDesc .= ", fromname";
	}
	if($updateRecords == ""){
		$updateRecords = "s_projes_fromname = '".$fromname."'";
	}else{
		$updateRecords .= ", s_projes_fromname = '".$fromname."'";
	}
}

$username = (isset($_POST['username']) && !empty($_POST['username']) ? mysqli_real_escape_string($conn,$_POST['username']) : "");
$username_change = (isset($_POST['username_change']) && !empty($_POST['username_change']) ? $_POST['username_change'] : "0");
if($username_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "username";
	}else{
		$auditlogDesc .= ", username";
	}
	if($updateRecords == ""){
		$updateRecords = "s_projes_username = '".$username."'";
	}else{
		$updateRecords .= ", s_projes_username = '".$username."'";
	}
}

$password = (isset($_POST['password']) ? $_POST['password'] : "");
$password_change = (isset($_POST['password_change']) && !empty($_POST['password_change']) ? $_POST['password_change'] : "0");
if($password_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "Password";
	}else{
		$auditlogDesc .= ", Password";
	}
	if($updateRecords == ""){
		$updateRecords = "s_projes_password = '".$password."'";
	}else{
		$updateRecords .= ", s_projes_password = '".$password."'";
	}
}

// $receiver = (isset($_POST['receiver']) ? $_POST['receiver'] : "");
$receiver = (isset($_POST['receiver']) && !empty($_POST['receiver']) ? mysqli_real_escape_string($conn,$_POST['receiver']) : "");
$receiver_change = (isset($_POST['receiver_change']) && !empty($_POST['receiver_change']) ? $_POST['receiver_change'] : "0");
if($receiver_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "receiver";
	}else{
		$auditlogDesc .= ", receiver";
	}
	if($updateRecords == ""){
		$updateRecords = "s_projes_receiver = '".$receiver."'";
	}else{
		$updateRecords .= ", s_projes_receiver = '".$receiver."'";
	}
}

$cc = (isset($_POST['cc'])  && !empty($_POST['cc']) ? mysqli_real_escape_string($conn,$_POST['cc']) : "");
$cc_change = (isset($_POST['cc_change']) && !empty($_POST['cc_change']) ? $_POST['cc_change'] : "0");
if($cc_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "cc";
	}else{
		$auditlogDesc .= ", cc";
	}
	if($updateRecords == ""){
		$updateRecords = "s_projes_cc = '".$cc."'";
	}else{
		$updateRecords .= ", s_projes_cc = '".$cc."'";
	}
}

$bcc = (isset($_POST['bcc'])   && !empty($_POST['bcc']) ? mysqli_real_escape_string($conn,$_POST['bcc']) : "");
$bcc_change = (isset($_POST['bcc_change'])   && !empty($_POST['bcc_change']) ? $_POST['bcc_change'] : "0");
if($bcc_change == "1"){
	if($auditlogDesc == ""){
		$auditlogDesc = "bcc";
	}else{
		$auditlogDesc .= ", bcc";
	}
	if($updateRecords == ""){
		$updateRecords = "s_projes_bcc = '".$bcc."'";
	}else{
		$updateRecords .= ", s_projes_bcc = '".$bcc."'";
	}
}

if(!empty($id) && $id !="0") {


	if($updateRecords !=""  ){
		if($updateRecords !=""){
			$sql = "UPDATE s_projemailsetting SET  $updateRecords where s_projes_id = ? ";
			$stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "s", $id);
            $result = mysqli_stmt_execute($stmt);
		}

		if((isset($result) && $result) || (isset($attachmentsLogs) && !empty($attachmentsLogs))){
			$newFlag = 0;
			$msgarr["status"] = "Success";
			$msgarr["message"] = "Email setting updated successfully.";
			
			if($auditlogDesc != ""){
				$auditlogSql = "insert into s_auditlogs (`s_a_desc`, `s_a_module`, `s_a_enteredby`,`accountId`,`s_a_recordId`,`s_a_recordnum` ) values ('".$auditlogDesc."','Project Email Setting','".$enteredby."','".$accountId."','".$id."','') ";
				
				mysqli_query( $conn, $auditlogSql);


			}
		}else{
			$msgarr["status"] = "Error";
			$msgarr["message"] = "Something went wrong. Please try again.";
		}
		if(isset($stmt)) mysqli_stmt_close($stmt);
	}else{

			$msgarr["status"] = "Success";
			$msgarr["message"] = "Email setting updated successfully.";
	}

}else{

	// Prepare the SQL statement with placeholders
	$sql = "INSERT INTO s_projemailsetting (
		`s_projes_subject`, 
		`projectId`, 
		`s_projes_host`, 
		`s_projes_port`, 
		`s_projes_fromname`, 
		`s_projes_username`, 
		`s_projes_password`, 
		`s_projes_receiver`, 
		`s_projes_cc`, 
		`s_projes_bcc`, 
		`accountId`, 
		`s_projes_enteredby`, 
		`s_projes_scheduletime`
	) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
	$stmt = mysqli_prepare($conn, $sql);
	mysqli_stmt_bind_param($stmt, "sssssssssssss", $subject, 
    $projectId, 
    $hostname, 
    $portno, 
    $fromname, 
    $username, 
    $password, 
    $receiver, 
    $cc, 
    $bcc, 
    $accountId, 
    $enteredby, 
    $scheduletime);

	if (mysqli_stmt_execute($stmt)) {
		$newFlag = 1;
		$msgarr["status"] = "Success";
			$msgarr["message"] = "Email setting added successfully.";
		$insertid = mysqli_insert_id($conn);
		
	}else{
		$msgarr["status"] = "Error";
		$msgarr["message"] = "Something went wrong. Please try again.";
	}
}
}

echo json_encode($msgarr);