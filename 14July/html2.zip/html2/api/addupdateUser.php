﻿<?php
// Enable CORS for cross-origin requests
header('Access-Control-Allow-Origin: *');
// Include the configuration file
include('config.php');
// Set the content type to HTML with UTF-8 encoding
header('Content-type: text/html; charset=utf-8');
// Include the PHPMailer library
require_once('class.phpmailer.php');

// Initialize an array to store messages
$msgarr = array();

// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize and validate input data
    $userid = isset($_POST['userid']) ? intval($_POST['userid']) : 0;
    $username = isset($_POST['username']) ? htmlspecialchars($_POST['username']) : "";
    $emailid = isset($_POST['email']) ? filter_var($_POST['email'], FILTER_SANITIZE_EMAIL) : "";
    $type = isset($_POST['type']) ? htmlspecialchars($_POST['type']) : "";
    $employeeId = isset($_POST['employeeId']) ? intval($_POST['employeeId']) : 0;
    $roleId = isset($_POST['roleId']) ? intval($_POST['roleId']) : 0;
    $groupId = isset($_POST['groupId']) ? intval($_POST['groupId']) : 0;
    $accountId = isset($_POST['accountId']) ? intval($_POST['accountId']) : 0;
    $enteredby = isset($_POST['enteredby']) ? intval($_POST['enteredby']) : 0;
    $activestatus = isset($_POST['accountactivestatus']) ? htmlspecialchars($_POST['accountactivestatus']) : "Active";
    $accountstatus = isset($_POST['accountstatus']) ? htmlspecialchars($_POST['accountstatus']) : "";
    $local = isset($_POST['local']) ? htmlspecialchars($_POST['local']) : "";

    $password = 'NULL';$utype = 'Employee';$licenseNumber = '0'; $accountStatus = 'Created';$activationTime = null;
    // If userid is empty or 0, insert a new user
    if (empty($userid) || $userid == 0) {
        $expirytime = date('Y-m-d', strtotime('+1 years'));
        $activationNum = md5(uniqid($userid, true));

        // Prepare the SQL statement to insert a new user
        $usersql = "INSERT INTO s_users (s_u_username, s_u_password, s_u_email, s_u_type, s_u_employeeId, accountId, s_u_licno, s_u_accountstatus, s_u_enteredby, s_u_activationnum, s_u_activationtime, s_u_expirytime, s_u_accountactivestatus, roleId, groupId) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = mysqli_prepare($conn, $usersql);
        mysqli_stmt_bind_param($stmt, "ssssiisssssssss", $emailid, $password, $emailid, $utype, $employeeId, $accountId, $licenseNumber, $accountstatus, $enteredby, $activationNum, $activationTime, $expirytime, $activestatus, $roleId, $groupId);

        if (mysqli_stmt_execute($stmt)) {
            $userId = mysqli_insert_id($conn);
            $msgarr["userdata"] = array("empid" => $employeeId, "userId" => $userId);
            $msgarr["status"] = "Success";
            $msgarr["message"] = "User  added successfully.";

            // Send activation email
            $emailstatus = sendEmail($activationNum);
            if ($emailstatus != "0") {
                $msgarr["status"] = "Success";
                $msgarr["message"] = "User  added successfully. But email didn't send.";
            }
        } else {
            $msgarr["status"] = "Error";
            $msgarr["message"] = "Failed to add user.";
        }
        mysqli_stmt_close($stmt);
    } else {
        // Prepare the SQL statement to update an existing user
        $updteactivatesql = "UPDATE s_users SET s_u_username = ?, s_u_email = ?, roleId = ?, groupId = ?  WHERE s_u_id = ?";
	//echo $updteactivatesql;die;
        $stmt = mysqli_prepare($conn, $updteactivatesql);
        mysqli_stmt_bind_param($stmt, "ssisi", $username, $emailid, $roleId, $groupId, $userid);
        mysqli_stmt_execute($stmt);
        $msgarr["status"] = "Success";
        $msgarr["message"] = "User  updated successfully.";
        mysqli_stmt_close($stmt);
    }
}


function sendEmail($nActivationNum){
	global $conn,$emailid,$accountId,$local;
	// echo $nActivationNum;

    $emailsqldata = mysqli_query($conn,"SELECT *  from s_emailsetting where accountId = '$accountId' order by s_es_id desc limit 1");
    $e_host = "";
    $e_port = "";
    $e_fromname = "";
    $e_username = "";
    $e_password = "";
    $e_id = 0;

    while($data = mysqli_fetch_assoc($emailsqldata)){
        $e_host = $data['s_es_host'];
        $e_port =  $data['s_es_port'];
        $e_fromname =  $data['s_es_fromname'];
        $e_username =  $data['s_es_username'];
        $e_password =  $data['s_es_password'];
        $e_id =  $data['s_es_id'];
    }
    $subject = "STEP - Account Activation";
	$mail             = new PHPMailer(); // defaults to using php "mail()"
 
    $mail->IsSMTP(); // enable SMTP
    $mail->IsHTML(true);
    $mail->SMTPDebug  = 0;                     // enables SMTP debug information (for testing)
    $mail->SMTPAuth   = true;                  // enable SMTP authentication
    $mail->SMTPSecure = "tls";                 // sets the prefix to the servier
    $mail->Host       = "$e_host";      // sets GMAIL as the SMTP server
    $mail->Port       = $e_port;   // set the SMTP port for the GMAIL server
    $mail->SMTPKeepAlive = true;
    $mail->Mailer = "smtp";
    $body             = $emaildsrbody;
    $mail->Username   = $e_username;  // GMAIL username
    $mail->Password   = $e_password    ;   
    $mail->SetFrom($e_username, $e_fromname);
    $body             = "Dear  Sir/Madam,<br/><br/>Your account has been created on STEP. Please click on the following link and activate your account to login.<br/><br/>
	<a href='".$local."accountactivation.php?token=".$nActivationNum."' >Activate</a>";

  $body = '<!DOCTYPE html>
<html>

<head>
    <title></title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <style type="text/css">
        body,
        table,
        td,
        a {
            -webkit-text-size-adjust: 100%;
            -ms-text-size-adjust: 100%;
        }

        table,
        td {
            mso-table-lspace: 0pt;
            mso-table-rspace: 0pt;
        }

        img {
            -ms-interpolation-mode: bicubic;
        }
        img {
            border: 0;
            height: auto;
            line-height: 100%;
            outline: none;
            text-decoration: none;
        }

        table {
            border-collapse: collapse !important;
        }

        body {
            height: 100% !important;
            margin: 0 !important;
            padding: 0 !important;
            width: 100% !important;
        }

        a[x-apple-data-detectors] {
            color: inherit !important;
            text-decoration: none !important;
            font-size: inherit !important;
            font-family: inherit !important;
            font-weight: inherit !important;
            line-height: inherit !important;
        }

        /* MOBILE STYLES */
        @media screen and (max-width:600px) {
            h1 {
                font-size: 32px !important;
                line-height: 32px !important;
            }
        }

        div[style*="margin: 16px 0;"] {
            margin: 0 !important;
        }
    </style>
</head>

<body style="background-color: #f4f4f4; margin: 0 !important; padding: 0 !important;">
    <div style="display: none; font-size: 1px; color: #fefefe; line-height: 1px; max-height: 0px; max-width: 0px; opacity: 0; overflow: hidden;"> </div>
    <table border="0" cellpadding="0" cellspacing="0" width="100%">
        <tr>
            <td bgcolor="#f4f4f4" align="center">
                <table border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width: 600px;">
                    <tr>
                        <td align="center" valign="top" style="padding: 40px 10px 40px 10px;"> </td>
                    </tr>
                </table>
            </td>
        </tr>
        <tr>
            <td bgcolor="#f4f4f4" align="center" style="padding: 0px 10px 0px 10px;">
                <table border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width: 600px;">
                    <tr>
                        <td bgcolor="#1E73B6" align="center" valign="top" style="padding: 40px 20px 20px 20px; border-radius: 4px 4px 0px 0px; color: #111111;  font-size: 48px; font-weight: 400; letter-spacing: 4px; line-height: 48px;">
                             <img src="../images/logo-03.png" width="125" height="120" style="display: block; border: 0px;" />
                          </td>
                    </tr>
                </table>
            </td>
        </tr>
        <tr>
            <td bgcolor="#f4f4f4" align="center" style="padding: 0px 10px 0px 10px;">
                <table border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width: 600px;">
                    <tr>
                        <td bgcolor="#ffffff" align="left" style="padding: 20px 30px 40px 30px; color: #666666;  font-size: 16px; font-weight: 400; line-height: 25px;">

                            <h1 style="font-size: 28px; font-weight: 400; margin: 2;">Account Activation</h1><br/>
                            <p style="margin: 0;">Hi,<br/><br/>

                Welcome to STEP!!<br/><br/>

                Your account has been created on STEP. Please click on the following link and activate your account to login.</p>
                        </td>
                    </tr>
                    <tr>
                        <td bgcolor="#ffffff" align="left">
                            <table width="100%" border="0" cellspacing="0" cellpadding="0">
                                <tr>
                                    <td bgcolor="#ffffff" align="center" style="padding: 20px 30px 60px 30px;">
                                        <table border="0" cellspacing="0" cellpadding="0">
                                            <tr>
                                                <td align="center" style="border-radius: 3px;" bgcolor="#1E73B6"><a href="'.$local.'accountactivation.php?token='.$nActivationNum.'" target="_blank" style="font-size: 20px; font-family: Helvetica, Arial, sans-serif; color: #ffffff; text-decoration: none; color: #ffffff; text-decoration: none; padding: 15px 25px; border-radius: 2px; border: 1px solid #1E73B6; display: inline-block;">Activate</a></td>
                                            </tr>
                                        </table>
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr> 
                    <tr>
                        <td bgcolor="#ffffff" align="left" style="padding: 0px 30px 0px 30px; color: #666666; font-size: 16px; font-weight: 400; line-height: 25px;">
                            <p style="margin: 0;">Happy Testing 😊<br/><br/>

STEP Team,

</p>
                        </td>
                    </tr> 
                    <tr>
                        <td bgcolor="#ffffff" align="left" style="padding: 20px 30px 20px 30px; color: #666666;  font-size: 16px; font-weight: 400; line-height: 25px;">
                            <p style="margin: 0;"><a href="https://www.steponestepahead.in/" target="_blank" style="color: #1E73B6;">www.steponestepahead.in</a></p>
                        </td>
                    </tr>
                    <tr>
                        <td bgcolor="#ffffff" align="center" style="padding: 30px 30px 30px 30px; border-radius: 4px 4px 4px 4px; color: #666666;  font-size: 18px; font-weight: 400; line-height: 25px;">
                            <h2 style="font-size: 13px; font-weight: 400; color: #666666; margin: 0;">STEP one step ahead<br/>

B Wing, Shah Industrial Estate, Andheri (East ), Mumbai, Maharashtra, India</h2>
                            <p style="margin: 0;">
                              <a href="https://www.uipath.com/legal/privacy-policy" target="_blank"  style="font-size: 13px; font-weight: 400; color: #666666; margin: 0;">Privacy Policy</a>
                               | 
                               <a href="https://www.uipath.com/company/contact-us" target="_blank"  style="font-size: 13px; font-weight: 400; color: #666666; margin: 0;">Contact Us</a>
                            </p>
                            <table border="0" cellspacing="0" cellpadding="0" align="center" style="margin-top: 20px;">
                      <tbody><tr>
                          <td valign="top"><a href="https://www.facebook.com/UiPath" target="_blank" style="text-decoration:none;"><img src="../images/fb.png" width="26" height="26" style="display:block;font-family: Arial, sans-serif; font-size:10px; line-height:18px; color:#feae39; " border="0" alt="Fb"></a></td>
                          <td width="7">&nbsp;</td>
                          <td valign="top"><a href="https://twitter.com/UiPath" target="_blank" style="text-decoration:none;"><img src="../images/twitter.png" width="26" height="26" style="display:block;font-family: Arial, sans-serif; font-size:10px; line-height:18px; color:#feae39; " border="0" alt="Tw"></a></td>
                          <td width="7">&nbsp;</td>
                          <td valign="top"><a href="#" target="_blank" style="text-decoration:none;"><img src="../images/linkedin.png" width="26" height="26" style="display:block;font-family: Arial, sans-serif; font-size:10px; line-height:18px; color:#feae39; " border="0" alt="linkedin"></a></td>
                          <td width="7">&nbsp;</td>
                          <td valign="top"><a href="https://www.youtube.com/user/UiPath" target="_blank" style="text-decoration:none;"><img src="../images/youtube.png" width="26" height="26" style="display:block;font-family: Arial, sans-serif; font-size:10px; line-height:18px; color:#feae39; " border="0" alt="Yt"></a></td>
                        </tr>
                      </tbody>
                  </table>
                        </td>
                    </tr>
                    
                </table>
            </td>
        </tr>
        
    </table>
</body>

</html>';


//$mail->Username   = "$e_username";  // GMAIL username
//$mail->Password   = "$e_password"     ;       // GMAIL password

//$mail->SetFrom("e_username", "$e_fromname");

// $mail->AddReplyTo('test@gmail.com', 'Dipika');


$mail->AddAddress(trim($emailid));
// $mail->Subject    = "Daily Status Report -".$dsrdate;
$mail->Subject    = "$subject";

$mail->AltBody    = "To view the message, please use an HTML compatible email viewer!"; // optional, comment out and test

$mail->MsgHTML($body);

if(!$mail->Send()) {
	return 1;
  // echo "Mailer Error: " . $mail->ErrorInfo;
} else {
	return 0;
  // echo "Message sent!";
}


}
echo json_encode($msgarr);
