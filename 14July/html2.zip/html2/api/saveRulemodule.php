<?php
include('config.php');
session_start();
 
$enteredby = 0;$accountId = 0;
 

if(isset($_SESSION["id"])){
    $enteredby = $_SESSION["id"];
    $accountId = $_SESSION["accountId"];
}
if($_SERVER['REQUEST_METHOD'] === 'POST'){

    $id = (isset($_POST['moduleId']) ? $_POST['moduleId'] : "0");
    $modulename = (isset($_POST['modulename']) ? $_POST['modulename'] : "");
    $activestatus = (isset($_POST['activestatus']) ? $_POST['activestatus'] : "");

    if (!empty($id) && $id != "0") {
        // Update query using prepared statements
        $sql = "UPDATE s_rule_module SET s_rm_name = ?, s_rm_activestatus = ? WHERE s_rm_id = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "ssi", $modulename, $activestatus, $id);
        mysqli_stmt_execute($stmt);
        if ($stmt) mysqli_stmt_close($stmt);
        
    } else {
        // Insert query using prepared statements
        $sql = "INSERT INTO s_rule_module (s_rm_name, s_rm_activestatus, s_rm_enteredby) VALUES (?, ?, ?)";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "ssi", $modulename, $activestatus, $enteredby);
        mysqli_stmt_execute($stmt);
        if ($stmt) mysqli_stmt_close($stmt);
    }
}