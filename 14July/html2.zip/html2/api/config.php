<?php
$old_error_handler = set_error_handler("myErrorHandler");


$servername = "localhost";
$username = "root";
$password =  '$t3P@^A9T2O17';
$database = "testcalibre_vaptdb";


$sender_email = "stepuser57@gmail.com";
$sender_password = "gcufqqntigcopkbq" ;
$sender_name = "STEP Test Management ";

define('STEP_root', 'https://www.vapt.testcalibre.com/');
define('STEP_dir', '/var/www/html/');

$CFG  = new ArrayObject();
	
$CFG['wwwroot'] = "https://www.vapt.testcalibre.com/";

$CFG['dirroot'] = "/var/www/html/";
$CFG['stepcolor'] = "#1E73B6";

//header("X-Content-Type-Options: nosniff");
//header("X-Frame-Options: DENY");
//header("Strict-Transport-Security: max-age=31536000; includeSubDomains; preload");
//header("Content-Security-Policy: default-src 'self'");
//header("Content-Security-Policy: default-src 'self'; style-src 'self' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com;");
//header("Referrer-Policy: no-referrer");

// Create connection
$conn = new mysqli($servername, $username, $password,$database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$holidays = array();
$stmt = $conn->prepare("SELECT * FROM s_holiday_master WHERE s_h_activestatus = ?");
$status = "Active";
$stmt->bind_param("s", $status);
$stmt->execute();
$result = $stmt->get_result();
while ($data = $result->fetch_assoc()) {
    $holidays[$data['clientId']][] = $data['s_h_date'];
}
$stmt->close();

function GetTDColor($status){
	
	switch ($status) {
		case "In Progress":
			$bgcolor = "background:#FFEB9C;color:#9C5734";
			break;
		case "Completed":
			$bgcolor = "background:#C6EFCE;color:#006100";
			break;
		case "Delayed":
			$bgcolor = "background:#FFC7CE;color:#9C0006";
			break;
		case "Yet to Begin":
			$bgcolor = "background:#8EA9DB;color:#182060";
			$fontcolor = "#9C5734";
			break;
		default:
			$bgcolor = "transparent";
			$fontcolor = "black";
	}
	return $bgcolor;
}

function GetRagColor($value){
	
	switch ($value) {
		case "G":
			$bgcolor = "background:#00B050";
			break;
		case "A":
			$bgcolor = "background:#FF9933";
			break;
		case "R":
			$bgcolor = "background:#FF0000";
			break;
		default:
			$bgcolor = "background:transparent";
	}
	return $bgcolor;
}
	

function GetDateDuration($pClient,$startdate,$enddate){
	global $holidays;

	$start = DateTime::createFromFormat('d/m/Y', $startdate); 
	$end = DateTime::createFromFormat('d/m/Y', $enddate); 

	$end->modify('+1 day');

	$interval = $end->diff($start);

	// total days
	$days = $interval->days;

	// create an iterateable period of date (P1D equates to 1 day)
	$period = new DatePeriod($start, new DateInterval('P1D'), $end);

	$count = 0;
	foreach($period as $dt) {

		$curr = $dt->format('D');
		$day_of_week = intval($dt->format('w'));
		// substract if Saturday or Sunday
		$isWeekend = ($day_of_week == 6) || ($day_of_week == 0);
		$isHoliday = (isset($holidays[$pClient]) ? (in_array($dt->format('Y-m-d'), $holidays[$pClient])) : false);
		if(!$isWeekend && !$isHoliday){
		$count++;
		}
	}
	return $count; 
}
        

	
function myErrorHandler($errno, $errstr, $errfile, $errline) {
    global $conn;
    $stmt = $conn->prepare("INSERT INTO myerror_log (`s_errno`, `s_errstr`, `s_errfile`, `s_errlineno`) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $errno, $errstr, $errfile, $errline);
    $stmt->execute();
    $stmt->close();
    return true;
}
	
/**
 * Sanitize and validate user input to prevent XSS and SQL injection.
 *
 * @param string $input The user input to sanitize.
 * @param string $type The type of input (e.g., 'string', 'int', 'email').
 * @return mixed The sanitized and validated input.
 */
function sanitizeInput($input, $type = 'string') {
    if (is_array($input)) {
        return array_map('sanitizeInput', $input);
    }

    // Trim whitespace
    $input = trim($input);

    // Sanitize based on type
    switch ($type) {
        case 'string':
            // Escape HTML and special characters
            $input = htmlspecialchars(mysqli_real_escape_string($conn,$input), ENT_QUOTES, 'UTF-8');
            break;
        case 'int':
            // Ensure the input is an integer
            $input = filter_var($input, FILTER_SANITIZE_NUMBER_INT);
            break;
        case 'email':
            // Sanitize and validate email
            $input = filter_var($input, FILTER_SANITIZE_EMAIL);
            if (!filter_var($input, FILTER_VALIDATE_EMAIL)) {
                $input = ''; // Invalid email
            }
            break;
        case 'url':
            // Sanitize and validate URL
            $input = filter_var($input, FILTER_SANITIZE_URL);
            if (!filter_var($input, FILTER_VALIDATE_URL)) {
                $input = ''; // Invalid URL
            }
            break;
        default:
            // Default sanitization for strings
            $input = htmlspecialchars($input, ENT_QUOTES, 'UTF-8');
            break;
    }

    return $input;
}
function sanitize($data) {
    return htmlspecialchars(trim($data), ENT_QUOTES, 'UTF-8');
}
?>
