import mysql.connector
from mysql.connector import Error

try:
    connection = mysql.connector.connect(
        host='localhost',
        user='root',
        password='Mysql@#1234',  # use your MySQL root password
        database='sample1'  # replace with your actual database name
    )

    if connection.is_connected():
        cursor = connection.cursor()

        insert_query = """
        INSERT INTO users (name, email, age)
        VALUES (%s, %s, %s)
        """

        data = ("Jn", "jh1@example.com", 40)

        cursor.execute(insert_query, data)
        connection.commit()

        print("Data inserted successfully.")

except Error as e:
    print("Error while connecting to MySQL", e)

finally:
    if 'connection' in locals() and connection.is_connected():
        cursor.close()
        connection.close()
        print("MySQL connection closed.")
